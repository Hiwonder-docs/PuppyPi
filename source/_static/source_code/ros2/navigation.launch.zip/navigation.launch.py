import os #1
from ament_index_python.packages import get_package_share_directory #2
from launch_ros.actions import Node #3
from launch_ros.actions import PushRosNamespace #4
from launch import LaunchDescription, LaunchService #5
from launch.substitutions import LaunchConfiguration #6
from launch.launch_description_sources import PythonLaunchDescriptionSource #7
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, GroupAction, OpaqueFunction, TimerAction #8

def launch_setup(context): #10
    compiled = os.environ['need_compile'] #11
    if compiled == 'True': #12
        slam_package_path = get_package_share_directory('slam') #13
        navigation_package_path = get_package_share_directory('navigation') #14
    else: #15
        slam_package_path = '/home/ubuntu/ros2_ws/src/slam' #16
        navigation_package_path = '/home/ubuntu/ros2_ws/src/navigation' #17

    sim = LaunchConfiguration('sim', default='false').perform(context) #19
    map_name = LaunchConfiguration('map', default='map_01').perform(context) #20
    robot_name = LaunchConfiguration('robot_name', default=os.environ['HOST']).perform(context) #21
    master_name = LaunchConfiguration('master_name', default=os.environ['MASTER']).perform(context) #22
    use_teb = LaunchConfiguration('use_teb', default='true').perform(context) #23
    sim_arg = DeclareLaunchArgument('sim', default_value=sim) #24
    map_name_arg = DeclareLaunchArgument('map', default_value=map_name) #25
    master_name_arg = DeclareLaunchArgument('master_name', default_value=master_name) #26
    robot_name_arg = DeclareLaunchArgument('robot_name', default_value=robot_name) #27
    use_teb_arg = DeclareLaunchArgument('use_teb', default_value=use_teb) #28


    use_sim_time = 'true' if sim == 'true' else 'false' #31
    use_namespace = 'true' if robot_name != '/' else 'false' #32
    
    laser_filter_config = '/home/ubuntu/ros2_ws/src/navigation/config/laser_filter.yaml' #34

    base_launch = IncludeLaunchDescription( #36
        PythonLaunchDescriptionSource(os.path.join(slam_package_path, 'launch/include/robot.launch.py')), #37
        launch_arguments={ #38
            'sim': sim, #39
            'master_name': master_name, #40
            'robot_name': robot_name #41
        }.items(), #42
    ) #43

    navigation_launch = IncludeLaunchDescription( #45
        PythonLaunchDescriptionSource(os.path.join(navigation_package_path, 'launch/include/bringup.launch.py')), #46
        launch_arguments={ #47
            'use_sim_time': use_sim_time, #48
            'map': os.path.join(slam_package_path, 'maps', map_name + '.yaml'), #49
            'params_file': os.path.join(navigation_package_path, 'config', 'nav2_params.yaml'), #50
            'namespace': robot_name, #51
            'use_namespace': use_namespace, #52
            'autostart': 'true', #53
            'use_teb': use_teb, #54
            'laser_filter_config': laser_filter_config,   #55
        }.items(), #56
    ) #57

    bringup_launch = GroupAction( #59
     actions=[ #60
         PushRosNamespace(robot_name), #61
         base_launch, #62
         TimerAction( #63
             period=10.0,   #64
             actions=[navigation_launch], #65
         ), #66
      ] #67
    ) #68
    
    publish_point_node = Node( #70
        package='navigation', #71
        executable='publish_point', #72
        output='screen',     #73
    ) #74

    wait_for_5_sec = TimerAction( #76
        period=5.0,  # 5 #77
        actions=[publish_point_node] #78
    ) #79

    return [sim_arg, map_name_arg, master_name_arg, robot_name_arg, use_teb_arg, bringup_launch, wait_for_5_sec] #81

def generate_launch_description(): #83
    return LaunchDescription([ #84
        OpaqueFunction(function=launch_setup) #85
    ]) #86

if __name__ == '__main__': #88
    # Create and run the launch service #89
    ld = generate_launch_description() #90
    ls = LaunchService() #91
    ls.include_launch_description(ld) #92
    ls.run() #93
