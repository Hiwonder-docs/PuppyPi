#!/usr/bin/env python3 #1
# coding=utf8 #2
# Date:2024/04/27 #3
# Author:hiwonder #4

import math #6
import time #7
import rclpy #8
from rclpy.node import Node #9
from rclpy.duration import Duration #10
from threading import Timer, RLock #11
import numpy as np #12
from geometry_msgs.msg import Twist #13
from sensor_msgs.msg import LaserScan #14
from std_srvs.srv import SetBool, Trigger #15
from puppy_control_msgs.srv import SetInt64, SetFloat64List #16

MAX_SCAN_ANGLE = 360  # 激光的扫描角度 (the scanning angle of the laser) #18

class LidarController(Node): #20
    def __init__(self): #21
        super().__init__('lidar_app') #22
        
        # 初始化参数 #24
        self.running_mode = 0  # 1: 雷达避障模式 2: 雷达警卫模式 3: 警卫看守模式 #25
        self.threshold = 0.3  # meters 距离阈值 (distance threshold) #26
        self.scan_angle = math.radians(90)  # radians 向前的扫描角度 (the forward scanning angle) #27
        self.speed = 0.12  # 单位米，避障模式的速度 (speed in meters per second for obstacle avoidance mode) #28
        self.timestamp = 0 #29
        self.lock = RLock() #30
        self.lidar_sub = None #31
        self.heartbeat_timer = None #32

        # 创建Publisher #34
        self.velocity_pub = self.create_publisher(Twist, '/cmd_vel_nav', 10) #35
        # 初始化发布一个空的Twist消息 #36
        self.velocity_pub.publish(Twist()) #37

        # 创建服务 #39
        self.enter_srv = self.create_service(Trigger, '/lidar_app/enter', self.enter_func) #40
        self.exit_srv = self.create_service(Trigger, '/lidar_app/exit', self.exit_func) #41
        self.heartbeat_srv = self.create_service(SetBool, '/lidar_app/heartbeat', self.heartbeat_srv_cb) #42
        self.set_running_srv = self.create_service(SetInt64, "/lidar_app/set_running", self.set_running_srv_callback) #43
        self.set_parameters_srv = self.create_service(SetFloat64List, "/lidar_app/adjust_parameters", self.set_parameters_srv_callback) #44

        self.get_logger().info("LidarController node has been initialized.") #46

    def reset_value(self): #48
        with self.lock: #49
            self.running_mode = 0 #50
            self.threshold = 0.3 #51
            self.speed = 0.12 #52
            self.scan_angle = math.radians(90) #53

            if self.lidar_sub is not None: #55
                self.destroy_subscription(self.lidar_sub) #56
                self.lidar_sub = None #57

            if self.heartbeat_timer: #59
                self.heartbeat_timer.cancel() #60
                self.heartbeat_timer = None #61

    def enter_func(self, request, response): #63
        self.get_logger().info("Lidar entering operation mode") #64
        self.reset_value() #65
        self.lidar_sub = self.create_subscription(LaserScan, '/scan', self.lidar_callback, 10) #66
        response.success = True #67
        response.message = 'Entered' #68
        return response #69

    def exit_func(self, request, response): #71
        self.get_logger().info('Lidar exiting operation mode') #72
        self.reset_value() #73
        response.success = True #74
        response.message = 'Exited' #75
        return response #76

    def heartbeat_srv_cb(self, request, response): #78
        if self.heartbeat_timer: #79
            self.heartbeat_timer.cancel() #80
            self.heartbeat_timer = None #81
        if request.data: #82
            self.heartbeat_timer = Timer(5, self.trigger_exit) #83
            self.heartbeat_timer.start() #84
        response.success = request.data #85
        return response #86

    def trigger_exit(self): #88
        self.get_logger().info("Heartbeat timeout. Exiting operation mode.") #89
        # 使用服务调用退出 #90
        client = self.create_client(Trigger, '/lidar_app/exit') #91
        while not client.wait_for_service(timeout_sec=1.0): #92
            self.get_logger().info('/lidar_app/exit service not available, waiting...') #93
        request = Trigger.Request() #94
        future = client.call_async(request) #95
        rclpy.spin_until_future_complete(self, future) #96
        if future.result() is not None: #97
            self.get_logger().info('Exit service response: %s' % future.result().message) #98
        else: #99
            self.get_logger().error('Failed to call exit service') #100

    def lidar_callback(self, lidar_data: LaserScan): #102
        ranges = list(lidar_data.ranges) #103
        ranges = [9999.0 if r < 0.05 else r for r in ranges]  # 小于5cm当作无限远 (treat distances less than 5cm as infinity) #104
        twist = Twist() #105

        with self.lock: #107
            try: #108
                min_index = np.nanargmin(np.array(ranges))  # 找出距离最小值 (find out the minimum value of distance) #109
                dist = ranges[min_index] #110
                angle = lidar_data.angle_min + lidar_data.angle_increment * min_index  # 计算最小值对应的角度 (calculate the angle corresponding to the minimum value) #111
                angle = angle if angle < math.pi else angle - math.pi * 2  # 处理角度 (handle angle) #112
                self.get_logger().debug(f"Min distance: {dist:.2f} meters at angle: {math.degrees(angle):.2f} degrees") #113
            except ValueError: #114
                self.get_logger().warn("All ranges are NaN or empty.") #115
                return #116

            # 避障 (obstacle avoidance) #118
            if self.running_mode == 1 and self.timestamp <= time.time(): #119
                if abs(angle) < self.scan_angle / 2 and dist < self.threshold: #120
                    twist.linear.x = self.speed / 6 #121
                    twist.angular.z = self.speed * 3 * -np.sign(angle) #122
                    self.timestamp = time.time() + 0.8 #123
                    self.get_logger().info(f"Obstacle Avoidance: Adjusting direction towards {math.degrees(angle):.2f} degrees") #124
                else: #125
                    twist.linear.x = self.speed #126
                    twist.angular.z = 0.0 #127
                self.velocity_pub.publish(twist) #128

            # 追踪 (tracking) #130
            elif self.running_mode == 2 and self.timestamp <= time.time(): #131
                self.get_logger().debug("Entering tracking logic") #132
                if abs(angle) < self.scan_angle / 2: #133
                    if dist < self.threshold and abs(math.degrees(angle)) > 10: #134
                        twist.linear.x = 0.01  # 微小前进，用于微调方向 #135
                        twist.angular.z = self.speed * 3 * -np.sign(angle) #136
                        self.timestamp = time.time() + 0.4 #137
                        self.get_logger().info(f"Tracking: Adjusting direction towards {math.degrees(angle):.2f} degrees") #138
                    elif self.threshold <= dist < 0.35: #139
                        twist.linear.x = self.speed  # 正常前进 #140
                        twist.angular.z = 0.0 #141
                        self.timestamp = time.time() + 0.4 #142
                        self.get_logger().info("Tracking: Moving forward") #143
                    else: #144
                        twist.linear.x = 0.0 #145
                        twist.angular.z = 0.0 #146
                        self.get_logger().info("Tracking: Stopping") #147
                else: #148
                    twist.linear.x = 0.0 #149
                    twist.angular.z = 0.0 #150
                    self.get_logger().info("Tracking: Target out of scan angle") #151
                self.velocity_pub.publish(twist) #152

            # 警卫看守 (guard duty) #154
            elif self.running_mode == 3 and self.timestamp <= time.time(): #155
                if dist < self.threshold and abs(math.degrees(angle)) > 10: #156
                    twist.linear.x = 0.01  # 微小前进，用于微调方向 #157
                    twist.angular.z = self.speed * 3 * -np.sign(angle) #158
                    self.timestamp = time.time() + 0.4 #159
                    self.get_logger().info(f"Guard Duty: Adjusting direction towards {math.degrees(angle):.2f} degrees") #160
                else: #161
                    twist.linear.x = 0.0 #162
                    twist.angular.z = 0.0 #163
                    self.get_logger().info("Guard Duty: Stopping") #164
                self.velocity_pub.publish(twist) #165

    def set_running_srv_callback(self, request, response): #167
        new_running_mode = request.data #168
        self.get_logger().info(f"Setting running mode to {new_running_mode}") #169
        if not 0 <= new_running_mode <= 3: #170
            response.success = False #171
            response.message = f"Invalid running mode {new_running_mode}" #172
        else: #173
            with self.lock: #174
                self.running_mode = new_running_mode #175
                self.velocity_pub.publish(Twist()) #176
            response.success = True #177
            response.message = f"Running mode set to {new_running_mode}" #178
        return response #179

    def set_parameters_srv_callback(self, request, response): #181
        new_threshold, new_scan_angle, new_speed = request.data #182
        self.get_logger().info(f"Setting new parameters: threshold={new_threshold:.2f}, scan_angle={new_scan_angle:.2f}, speed={new_speed:.2f}") #183
        if not 0.3 <= new_threshold <= 1.5: #184
            response.success = False #185
            response.message = f"Threshold {new_threshold:.2f} is out of range (0.3 ~ 1.5)" #186
        elif new_speed <= 0: #187
            response.success = False #188
            response.message = "Speed must be greater than 0" #189
        else: #190
            with self.lock: #191
                self.threshold = new_threshold #192
                self.scan_angle = math.radians(new_scan_angle) #193
                self.speed = new_speed  # 移除缩放因子 #194
            response.success = True #195
            response.message = "Parameters updated successfully" #196
        return response #197

def main(args=None): #199
    rclpy.init(args=args) #200
    lidar_controller = LidarController() #201
    try: #202
        rclpy.spin(lidar_controller) #203
    except KeyboardInterrupt: #204
        lidar_controller.get_logger().info('Shutting down LidarController node.') #205
    finally: #206
        lidar_controller.reset_value() #207
        lidar_controller.destroy_node() #208
        rclpy.shutdown() #209

if __name__ == '__main__': #211
    main() #212
