#!/usr/bin/env python3 #1
# -*- coding: utf-8 -*- #2
# 日期: 2021/09/27 #3
# 作者: hiwonder #4
# 功能: 激光雷达控制节点 (Lidar Control Node) #5

import math #7
import time #8
import rclpy #9
from rclpy.node import Node #10
from threading import RLock #11
import numpy as np #12
from geometry_msgs.msg import Twist #13
from sensor_msgs.msg import LaserScan #14
from std_srvs.srv import SetBool, Trigger #15
from puppy_control_msgs.srv import SetInt64, SetFloat64List #16

MAX_SCAN_ANGLE = 360  # 激光雷达扫描角度 (degrees) #18

class LidarController(Node): #20
    def __init__(self, name): #21
        super().__init__(name) #22
        self.get_logger().info(''' #23
********************************************************** #24
************ 功能: 激光雷达控制例程 (Lidar Control Routine) ************ #25
********************************************************** #26
官方网站: https://www.hiwonder.com #27
在线商城: https://hiwonder.tmall.com #28
-------------------------------------------------- #29
提示: #30
 * 按下 Ctrl+C 可关闭程序，若失败请多次尝试！ #31
 * 激光雷达控制节点，提供避障、追踪和警卫模式 #32
-------------------------------------------------- #33
        ''') #34

        self.running_mode = 0  # 0: 停止, 1: 避障, 2: 追踪, 3: 警卫 #36
        self.threshold = 0.3  # 距离阈值 (米) #37
        self.scan_angle = math.radians(90)  # 前向扫描角度 (弧度) #38
        self.speed = 0.12  # 避障模式速度 (米/秒) #39
        self.timestamp = 0 #40
        self.lock = RLock() #41
        self.lidar_sub = None #42
        self.heartbeat_timer = None #43
        self.is_running = False  # 跟踪节点运行状态 #44

        # 创建发布者 #46
        self.velocity_pub = self.create_publisher(Twist, '/cmd_vel_nav', 10) #47
        self.velocity_pub.publish(Twist())  # 初始化速度为 0 #48

        # 创建服务 #50
        self.enter_srv = self.create_service(Trigger, '/lidar_app/enter', self.enter_func) #51
        self.exit_srv = self.create_service(Trigger, '/lidar_app/exit', self.exit_func) #52
        self.heartbeat_srv = self.create_service(SetBool, '/lidar_app/heartbeat', self.heartbeat_srv_cb) #53
        self.set_running_srv = self.create_service(SetInt64, '/lidar_app/set_running', self.set_running_srv_callback) #54
        self.set_parameters_srv = self.create_service(SetFloat64List, '/lidar_app/adjust_parameters', self.set_parameters_srv_callback) #55

    def reset_value(self): #57
        with self.lock: #58
            self.running_mode = 0 #59
            self.threshold = 0.3 #60
            self.speed = 0.12 #61
            self.scan_angle = math.radians(90) #62
            self.timestamp = 0 #63
            if self.lidar_sub is not None: #64
                self.destroy_subscription(self.lidar_sub) #65
                self.lidar_sub = None #66
            self.is_running = False #67
            self.velocity_pub.publish(Twist())  # 停止运动 #68

    def enter_func(self, request, response): #70
        with self.lock: #71
            if self.is_running: #72
                response.success = False #73
                response.message = '节点已在运行' #74
                return response #75
            self.get_logger().info('激光雷达进入运行模式') #76
            self.reset_value() #77
            self.lidar_sub = self.create_subscription(LaserScan, '/scan', self.lidar_callback, 10) #78
            self.is_running = True #79
            response.success = True #80
            response.message = '已进入运行模式' #81
            return response #82

    def exit_func(self, request, response): #84
        with self.lock: #85
            if not self.is_running: #86
                response.success = False #87
                response.message = '节点未在运行' #88
                return response #89
            self.get_logger().info('激光雷达退出运行模式') #90
            if self.heartbeat_timer: #91
                self.heartbeat_timer.cancel() #92
                self.heartbeat_timer = None #93
            self.reset_value() #94
            response.success = True #95
            response.message = '已退出运行模式' #96
            return response #97

    def heartbeat_srv_cb(self, request, response): #99
        with self.lock: #100
            if not self.is_running: #101
                response.success = False #102
                response.message = '节点未在运行' #103
                return response #104
            if self.heartbeat_timer: #105
                self.heartbeat_timer.cancel() #106
            if request.data: #107
                self.heartbeat_timer = self.create_timer(5.0, self.heartbeat_timeout) #108
                self.get_logger().info('心跳定时器已启动') #109
            response.success = request.data #110
            response.message = '心跳状态更新' #111
            return response #112

    def heartbeat_timeout(self): #114
        with self.lock: #115
            if self.is_running: #116
                self.get_logger().info('心跳超时，自动退出运行模式') #117
                self.reset_value() #118

    def lidar_callback(self, lidar_data: LaserScan): #120
        if not self.is_running: #121
            return #122
        ranges = list(lidar_data.ranges) #123
        ranges = [9999.0 if r < 0.05 else r for r in ranges]  # 小于5cm视为无限远 #124
        twist = Twist() #125

        with self.lock: #127
            if not self.is_running: #128
                return #129
            min_index = np.nanargmin(np.array(ranges)) #130
            dist = ranges[min_index] #131
            angle = lidar_data.angle_min + lidar_data.angle_increment * min_index #132
            angle = angle if angle < math.pi else angle - math.pi * 2 #133

            # 避障模式 #135
            if self.running_mode == 1 and self.timestamp <= time.time(): #136
                if abs(angle) < self.scan_angle / 2 and dist < self.threshold: #137
                    twist.linear.x = self.speed / 6 #138
                    twist.angular.z = self.speed * 3 * -np.sign(angle) #139
                    self.timestamp = time.time() + 0.8 #140
                else: #141
                    twist.linear.x = self.speed #142
                    twist.angular.z = 0.0 #143
                self.velocity_pub.publish(twist) #144

            # 追踪模式 #146
            elif self.running_mode == 2 and self.timestamp <= time.time(): #147
                if abs(angle) < self.scan_angle / 2: #148
                    if dist < self.threshold and abs(math.degrees(angle)) > 10: #149
                        twist.linear.x = 0.01 #150
                        twist.angular.z = self.speed * 3 * np.sign(angle) #151
                        self.timestamp = time.time() + 0.4 #152
                    else: #153
                        if dist < self.threshold and dist > 0.35: #154
                            twist.linear.x = self.speed #155
                            twist.angular.z = 0.0 #156
                            self.timestamp = time.time() + 0.4 #157
                        else: #158
                            twist.linear.x = 0.0 #159
                            twist.angular.z = 0.0 #160
                else: #161
                    twist.linear.x = 0.0 #162
                    twist.angular.z = 0.0 #163
                self.velocity_pub.publish(twist) #164

            # 警卫模式 #166
            elif self.running_mode == 3 and self.timestamp <= time.time(): #167
                if dist < self.threshold and abs(math.degrees(angle)) > 10: #168
                    twist.linear.x = 0.01 #169
                    twist.angular.z = self.speed * 3 * np.sign(angle) #170
                    self.timestamp = time.time() + 0.4 #171
                else: #172
                    twist.linear.x = 0.0 #173
                    twist.angular.z = 0.0 #174
                self.velocity_pub.publish(twist) #175

    def set_running_srv_callback(self, request, response): #177
        new_running_mode = request.data #178
        self.get_logger().info(f'设置运行模式为 {new_running_mode}') #179
        with self.lock: #180
            if not 0 <= new_running_mode <= 3: #181
                response.success = False #182
                response.message = f'无效的运行模式 {new_running_mode}' #183
            else: #184
                self.running_mode = new_running_mode #185
                self.velocity_pub.publish(Twist()) #186
                response.success = True #187
                response.message = f'运行模式已设置为 {new_running_mode}' #188
            return response #189

    def set_parameters_srv_callback(self, request, response): #191
        try: #192
            new_threshold, new_scan_angle, new_speed = request.data #193
            self.get_logger().info(f'设置参数: 阈值={new_threshold:.2f}, 扫描角度={new_scan_angle:.2f}, 速度={new_speed:.2f}') #194
            with self.lock: #195
                if not 0.3 <= new_threshold <= 1.5: #196
                    response.success = False #197
                    response.message = f'阈值 {new_threshold:.2f} 超出范围 (0.3 ~ 1.5)' #198
                elif new_speed <= 0: #199
                    response.success = False #200
                    response.message = '速度必须大于 0' #201
                else: #202
                    self.threshold = new_threshold #203
                    self.scan_angle = math.radians(new_scan_angle) #204
                    self.speed = new_speed * 0.002 #205
                    response.success = True #206
                    response.message = '参数更新成功' #207
                return response #208
        except ValueError: #209
            response.success = False #210
            response.message = '参数格式错误' #211
            return response #212

    def shutdown(self): #214
        self.get_logger().info('关闭激光雷达控制节点...') #215
        with self.lock: #216
            self.reset_value() #217
        self.get_logger().info('节点已关闭') #218

def main(args=None): #220
    rclpy.init(args=args) #221
    node = LidarController('lidar_app') #222
    try: #223
        rclpy.spin(node) #224
    except KeyboardInterrupt: #225
        pass #226
    finally: #227
        node.shutdown() #228
        node.destroy_node() #229
        rclpy.shutdown() #230

if __name__ == '__main__': #232
    main() #233
