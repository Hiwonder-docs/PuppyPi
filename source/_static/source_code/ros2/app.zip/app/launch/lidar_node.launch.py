from launch import LaunchDescription #1
from launch.actions import IncludeLaunchDescription #2
from launch_ros.actions import Node #3
from launch.launch_description_sources import PythonLaunchDescriptionSource #4
from ament_index_python.packages import get_package_share_directory #5
import os #6

def generate_launch_description(): #8
    # Define the paths to the launch files #9
    lidar_launch_path = os.path.join(get_package_share_directory('peripherals'), 'launch', 'lidar.launch.py') #10
    puppy_control_launch_path = os.path.join('/home/ubuntu/ros2_ws/src/driver/puppy_control/launch', 'puppy_control.launch.py') #11

    return LaunchDescription([ #13
        # Include the lidar launch file #14
        IncludeLaunchDescription( #15
            PythonLaunchDescriptionSource(lidar_launch_path) #16
        ), #17

        # Node for lidar application #19
        Node( #20
            package='app', #21
            executable='lidar', #22
            name='lidar_app', #23
            output='screen' #24
        ), #25
        
        # Include the puppy control launch file #27
        IncludeLaunchDescription( #28
            PythonLaunchDescriptionSource(puppy_control_launch_path) #29
        ), #30
    ]) #31

