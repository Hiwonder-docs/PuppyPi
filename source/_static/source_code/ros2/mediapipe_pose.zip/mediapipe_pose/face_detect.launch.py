import os #1
from launch_ros.actions import Node #2
from launch import LaunchDescription #3
from launch.actions import IncludeLaunchDescription, GroupAction #4
from launch.launch_description_sources import PythonLaunchDescriptionSource #5
from launch.substitutions import LaunchConfiguration #6

def generate_launch_description(): #8

    puppy_control_package_path = '/home/ubuntu/ros2_ws/src/driver/puppy_control' #10
    peripherals_package_path = '/home/ubuntu/ros2_ws/src/peripherals' #11

    puppy_control_node = GroupAction([ #13
        IncludeLaunchDescription( #14
            PythonLaunchDescriptionSource( #15
                os.path.join(puppy_control_package_path, 'launch/puppy_control.launch.py') #16
            ) #17
        ), #18
        IncludeLaunchDescription( #19
            PythonLaunchDescriptionSource( #20
                os.path.join(peripherals_package_path, 'launch/usb_cam.launch.py') #21
            ) #22
        ), #23
        Node( #24
            package='example', #25
            executable='face_detect', #26
            name='face_detect_node', #27
            output='screen' #28
        ), #29
    ]) #30

    return LaunchDescription([ #32
        puppy_control_node #33
    ]) #34
