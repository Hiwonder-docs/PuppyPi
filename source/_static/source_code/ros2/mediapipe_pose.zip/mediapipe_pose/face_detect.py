#!/usr/bin/env python3 #1
# encoding: utf-8 #2
import cv2 #3
import queue #4
import rclpy #5
import threading #6
import numpy as np #7
import mediapipe as mp #8
from rclpy.node import Node #9
from cv_bridge import CvBridge #10
from sensor_msgs.msg import Image #11
from std_srvs.srv import Empty #12

class SegmentationNode(Node): #14
    def __init__(self, name): #15
        super().__init__(name) #16
        self.running = True #17
        
        # 初始化 MediaPipe 面部检测 #19
        self.face = mp.solutions.face_detection #20
        self.face_detection = self.face.FaceDetection(min_detection_confidence=0.6) #21
        self.img_h, self.img_w = 0, 0 #22
        self.bridge = CvBridge() #23
        
        # 图像队列 #25
        self.image_queue = queue.Queue(maxsize=2) #26
        self.image_sub = self.create_subscription( #27
            Image, 'image_raw', self.image_callback, 10)  # 增加队列大小以提高性能 #28
        
        # 创建服务客户端 #30
        self.go_home_client = self.create_client(Empty, '/puppy_control/go_home') #31
        
        self.get_logger().info('\033[1;32m%s\033[0m' % 'Segmentation node started') #33
        
        # 启动主处理线程 #35
        threading.Thread(target=self.main, daemon=True).start() #36
        
        # 调用 go_home 服务 #38
        self.call_go_home_service() #39

    def image_callback(self, ros_image): #41
        try: #42
            # 将 ROS 图像转换为 OpenCV 格式（BGR） #43
            rgb_image = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #44
            self.img_h, self.img_w = rgb_image.shape[:2] #45
            
            # 转换为 RGB 供 MediaPipe 处理 #47
            img_rgb = cv2.cvtColor(rgb_image, cv2.COLOR_BGR2RGB) #48
            results = self.face_detection.process(img_rgb) #49
            
            # 绘制检测结果 #51
            if results.detections: #52
                for detection in results.detections: #53
                    bboxC = detection.location_data.relative_bounding_box #54
                    bbox = ( #55
                        int(bboxC.xmin * self.img_w), #56
                        int(bboxC.ymin * self.img_h), #57
                        int(bboxC.width * self.img_w), #58
                        int(bboxC.height * self.img_h) #59
                    ) #60
                    cv2.rectangle(rgb_image, bbox, (0, 255, 0), 2) #61
            
            # 管理图像队列 #63
            if self.image_queue.full(): #64
                self.image_queue.get_nowait()   #65
            self.image_queue.put(rgb_image) #66
            
        except Exception as e: #68
            self.get_logger().error(f"Error in image_callback: {str(e)}") #69

    def call_go_home_service(self): #71
        """调用 /puppy_control/go_home 服务""" #72
        if not self.go_home_client.wait_for_service(timeout_sec=5.0): #73
            self.get_logger().error('Go home service not available') #74
            return #75
        
        request = Empty.Request() #77
        future = self.go_home_client.call_async(request) #78
        future.add_done_callback(self.go_home_callback) #79

    def go_home_callback(self, future): #81
        """处理 go_home 服务调用结果""" #82
        try: #83
            future.result() #84
            self.get_logger().info('Go home service called successfully') #85
        except Exception as e: #86
            self.get_logger().error(f'Go home service call failed: {str(e)}') #87

    def main(self): #89
        """主处理循环""" #90
        while self.running and rclpy.ok(): #91
            try: #92
                image = self.image_queue.get(block=True, timeout=1.0) #93
                cv2.imshow('MediaPipe Face Detect', image) #94
                
                key = cv2.waitKey(1) #96
                if key in (ord('q'), 27):  # 支持 'q' 或 ESC 退出 #97
                    self.running = False #98
                    break #99
                
            except queue.Empty: #101
                continue #102
            except Exception as e: #103
                self.get_logger().error(f"Error in main loop: {str(e)}") #104
        
        # 清理 #106
        cv2.destroyAllWindows() #107
        self.get_logger().info('Display window closed') #108

    def destroy_node(self): #110
        """清理节点""" #111
        self.running = False #112
        super().destroy_node() #113

def main(): #115
    rclpy.init() #116
    node = SegmentationNode('self_segmentation') #117
    try: #118
        rclpy.spin(node) #119
    except KeyboardInterrupt: #120
        node.get_logger().info('Node interrupted by user') #121
    finally: #122
        node.destroy_node() #123
        rclpy.shutdown() #124
        node.get_logger().info('Node shutdown complete') #125

if __name__ == "__main__": #127
    main() #128
