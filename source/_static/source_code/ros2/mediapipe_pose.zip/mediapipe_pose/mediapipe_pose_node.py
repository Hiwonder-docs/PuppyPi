#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: liuyuan #3
# @Date: 2025/01/13 #4

import rclpy #6
from rclpy.node import Node #7
from sensor_msgs.msg import Image #8
from cv_bridge import CvBridge #9
from enum import Enum #10
from dataclasses import dataclass, field #11
import cv2 #12
import mediapipe as mp #13
import time #14
import signal #15
import sys #16
import math #17
import queue #18
import threading #19
import queue #20
import numpy as np #21
from sdk import PID #22
from collections import deque #23
from puppy_control_msgs.srv import SetRunActionName #24
from std_srvs.srv import Trigger, Empty #25
from ros_robot_controller_msgs.msg import BuzzerState,PWMServoState,SetPWMServoState #26


class Landmark(Enum): #29
    NOSE = 0 #30
    LEFT_SHOULDER = 11 #31
    RIGHT_SHOULDER = 12 #32
    LEFT_ELBOW = 13 #33
    RIGHT_ELBOW = 14 #34
    LEFT_WRIST = 15 #35
    RIGHT_WRIST = 16 #36
    LEFT_HIP = 23 #37
    RIGHT_HIP = 24 #38

@dataclass #40
class Servo: #41
    name: str #42
    channel: int #43
    angle_min: int #44
    angle_max: int #45
    pulse_min: int #46
    pulse_max: int #47
    initial_pulse: int #48
    invert: bool = False #49
    pid: pid = field(default_factory=lambda: pid()) #50
    #pid: PID = field(default_factory=lambda: PID()) #51
    current_pulse: int = field(init=False) #52

    def __post_init__(self): #54
        self.current_pulse = self.initial_pulse #55


class MediaPipePoseNode(Node): #58
    def __init__(self): #59
        super(MediaPipePoseNode, self).__init__('mediapipe_pose_node') #60

        self.scale_percent = 50 #62
        self.alpha = 0.2   #63

        # 初始化 CvBridge #65
        self.bridge = CvBridge() #66

        # 初始化 MediaPipe Pose #68
        self.mp_pose = mp.solutions.pose #69
        self.pose = self.mp_pose.Pose( #70
            static_image_mode=False, #71
            model_complexity=1, #72
            smooth_landmarks=True, #73
            min_detection_confidence=0.5, #74
            min_tracking_confidence=0.5 #75
        ) #76
        self.mp_drawing = mp.solutions.drawing_utils #77

        self.servos = { #79
            'left_upper': Servo( #80
                name='left_upper', #81
                channel=1, #82
                angle_min=60, #83
                angle_max=120, #84
                pulse_min=862, #85
                pulse_max=1966, #86
                initial_pulse=1011, #87
                invert=False, #88
                pid=PID.PID(P=1.0, I=0.05, D=0.01) #89
            ), #90
            'left_forearm': Servo( #91
                name='left_forearm', #92
                channel=2, #93
                angle_min=90, #94
                angle_max=180, #95
                pulse_min=953, #96
                pulse_max=1818, #97
                initial_pulse=862, #98
                invert=False, #99
                pid=PID.PID(P=1.0, I=0.05, D=0.01) #100
            ), #101
            'right_upper': Servo( #102
                name='right_upper', #103
                channel=3, #104
                angle_min=60, #105
                angle_max=120, #106
                pulse_min=981, #107
                pulse_max=2138, #108
                initial_pulse=1989, #109
                invert=True, #110
                pid=PID.PID(P=1.0, I=0.05, D=0.01) #111
            ), #112
            'right_forearm': Servo( #113
                name='right_forearm', #114
                channel=4, #115
                angle_min=90, #116
                angle_max=180, #117
                pulse_min=1253, #118
                pulse_max=2288, #119
                initial_pulse=1989, #120
                invert=True, #121
                pid=PID.PID(P=1.0, I=0.05, D=0.01) #122
            ) #123
        } #124


        # 订阅摄像头图像话题 #127
        self.image_sub = self.create_subscription(Image, 'image_raw', self.image_callback, 10)        #128
        self.buzzer_pub = self.create_publisher(BuzzerState, 'ros_robot_controller/set_buzzer', 1) #129
        self.pwm_pub = self.create_publisher(SetPWMServoState,'ros_robot_controller/pwm_servo/set_state',10) #130
        self.run_action_group_srv = self.create_client(SetRunActionName, 'puppy_control/runActionGroup') #131
        self.run_action_group_srv.wait_for_service() #132
        self.cli = self.create_client(Empty,'puppy_control/go_home') #133

        self.play_mode = False #135
        self.stop_event = threading.Event() #136

        self.angle_queue = queue.Queue(maxsize=50) #138
        self.display_queue = queue.Queue(maxsize=10) #139
        
        msg = SetRunActionName.Request() #141
        msg.name = '2_legs_stand.d6ac' #142
        msg.wait = True #143
        self.run_action_group_srv.call_async(msg)       #144

        # 初始化线程 #146
        self.servo_thread = threading.Thread(target=self.servo_control_thread, name="ServoControlThread") #147
        self.servo_thread.start() #148

        self.display_thread = threading.Thread(target=self.image_display_thread, name="ImageDisplayThread") #150
        self.display_thread.start() #151


        #for servo in self.servos.values(): #154
            #servo.current_pulse = servo.initial_pulse #155

        self.angle_history = { #157
            'left_upper': deque(maxlen=5), #158
            'right_upper': deque(maxlen=5), #159
            'left_forearm': deque(maxlen=5), #160
            'right_forearm': deque(maxlen=5) #161
        } #162


        self.filtered_angles = { #165
            'left_upper': None, #166
            'right_upper': None, #167
            'left_forearm': None, #168
            'right_forearm': None #169
        } #170
        # 手部交叉检测历史 #171
        self.hands_crossed_history = deque(maxlen=10) #172

        self.get_logger().info("MediaPipePoseNode 初始化完成。") #174

    def convert_landmarks_to_pixels(self, img, landmarks): #176
        """将 MediaPipe 关键点转换为像素坐标""" #177
        img_height, img_width, _ = img.shape #178
        return [(int(lm.x * img_width), int(lm.y * img_height)) for lm in landmarks] #179

    def is_T_pose(self, pixel_landmarks): #181
        """判断是否为 T 姿势""" #182
        try: #183
            left_shoulder = pixel_landmarks[Landmark.LEFT_SHOULDER.value] #184
            right_shoulder = pixel_landmarks[Landmark.RIGHT_SHOULDER.value] #185
            left_elbow = pixel_landmarks[Landmark.LEFT_ELBOW.value] #186
            right_elbow = pixel_landmarks[Landmark.RIGHT_ELBOW.value] #187
            left_wrist = pixel_landmarks[Landmark.LEFT_WRIST.value] #188
            right_wrist = pixel_landmarks[Landmark.RIGHT_WRIST.value] #189
        except IndexError: #190
            self.get_logger().info("检测到的关键点数量不足以判断 T 姿势。") #191
            return False #192

        angle_threshold = 20 #194
        horizontal_threshold = 20 #195

        left_arm_angle = self.calculate_angle(left_shoulder, left_elbow, left_wrist) #197
        right_arm_angle = self.calculate_angle(right_shoulder, right_elbow, right_wrist) #198


        left_straight = abs(left_arm_angle - 180) < angle_threshold #201
        right_straight = abs(right_arm_angle - 180) < angle_threshold #202

        left_horizontal = self.is_horizontal(left_shoulder, left_wrist, horizontal_threshold) #204
        right_horizontal = self.is_horizontal(right_shoulder, right_wrist, horizontal_threshold) #205

        return left_straight and right_straight and left_horizontal and right_horizontal #207

    def is_hands_crossed_on_chest(self, pixel_landmarks): #209
        """判断双手是否交叉抱胸""" #210
        try: #211
            nose = pixel_landmarks[Landmark.NOSE.value] #212
            left_shoulder = pixel_landmarks[Landmark.LEFT_SHOULDER.value] #213
            right_shoulder = pixel_landmarks[Landmark.RIGHT_SHOULDER.value] #214
            left_elbow = pixel_landmarks[Landmark.LEFT_ELBOW.value] #215
            right_elbow = pixel_landmarks[Landmark.RIGHT_ELBOW.value] #216
            left_wrist = pixel_landmarks[Landmark.LEFT_WRIST.value] #217
            right_wrist = pixel_landmarks[Landmark.RIGHT_WRIST.value] #218
        except IndexError: #219
            self.get_logger().info("检测到的关键点数量不足以判断双手交叉抱胸。") #220
            return False #221

        chest_upper = nose[1] #223
        chest_lower = min(left_shoulder[1], right_shoulder[1]) + 50 #224

        left_wrist_in_chest = chest_upper < left_wrist[1] < chest_lower #226
        right_wrist_in_chest = chest_upper < right_wrist[1] < chest_lower #227


        if not (left_wrist_in_chest and right_wrist_in_chest): #230
            return False #231

        left_wrist_right_of_right_shoulder = left_wrist[0] > right_shoulder[0] #233
        right_wrist_left_of_left_shoulder = right_wrist[0] < left_shoulder[0] #234

        if not (left_wrist_right_of_right_shoulder and right_wrist_left_of_left_shoulder): #236
            return False #237

        left_elbow_angle = self.calculate_angle(left_wrist, left_elbow, left_shoulder) #239
        right_elbow_angle = self.calculate_angle(right_wrist, right_elbow, right_shoulder) #240

        elbow_angle_threshold = 70 #242
        elbows_bent = left_elbow_angle < elbow_angle_threshold and right_elbow_angle < elbow_angle_threshold #243

        hands_distance = abs(left_wrist[0] - right_wrist[0]) #245
        hands_distance_threshold = 100  # 像素 #246


        hands_close = hands_distance < hands_distance_threshold #249

        return elbows_bent and hands_close #251

    def is_horizontal(self, shoulder, wrist, threshold): #253
        """判断手腕是否水平""" #254
        vertical_diff = abs(shoulder[1] - wrist[1]) #255
        return vertical_diff < threshold #256

    @staticmethod #258
    def calculate_angle(a, b, c): #259
        """ #260
        计算点 b 处的夹角，点 a, b, c 坐标为 (x, y) #261
        """ #262
        try: #263
            vector1 = (a[0] - b[0], a[1] - b[1]) #264
            vector2 = (c[0] - b[0], c[1] - b[1]) #265

            len1 = math.hypot(*vector1) #267
            len2 = math.hypot(*vector2) #268

            if len1 == 0 or len2 == 0: #270
                return 0.0 #271

            dot = vector1[0] * vector2[0] + vector1[1] * vector2[1] #273
            angle = math.acos(max(min(dot / (len1 * len2), 1.0), -1.0)) * (180.0 / math.pi) #274
            return angle #275
        except Exception as e: #276
            self.get_logger().info(f"计算角度时出错: {e}") #277
            return 0.0 #278
            
    def calculate_shoulder_angle(self, shoulder, elbow, neck): #280
        """计算肩部角度""" #281
        return self.calculate_angle(elbow, shoulder, neck) #282
        
    def apply_low_pass_filter(self, servo_name, new_angle): #284
        """应用低通滤波器平滑角度""" #285
        if self.filtered_angles[servo_name] is None: #286
            self.filtered_angles[servo_name] = new_angle #287
        else: #288
            self.filtered_angles[servo_name] = self.alpha * new_angle + (1 - self.alpha) * self.filtered_angles[servo_name] #289
        return self.filtered_angles[servo_name] #290

    def map_arm_angle_to_pulse(self, angle, servo: Servo): #292
        """ #293
        将手臂角度映射到伺服舵机的脉冲宽度 #294
        """ #295
        # 限制角度在伺服的范围内 #296
        clamped_angle = max(servo.angle_min, min(servo.angle_max, angle)) #297

        if servo.invert: #299
            clamped_angle = servo.angle_max - (clamped_angle - servo.angle_min) #300

        # 线性映射角度到脉冲宽度 #302
        pulse = ((clamped_angle - servo.angle_min) / (servo.angle_max - servo.angle_min)) * \ #303
                (servo.pulse_max - servo.pulse_min) + servo.pulse_min #304
        pulse = int(round(pulse)) #305

        # 限制脉冲在有效范围内 #307
        pulse = max(servo.pulse_min, min(servo.pulse_max, pulse)) #308

        return pulse #310
        
    def map_arm_angle_to_pulse01(self, angle, servo: Servo): #312
        """ #313
        将手臂角度映射到伺服舵机的脉冲宽度 #314
        """ #315
        # 限制角度在伺服的范围内 #316
        clamped_angle = max(servo.angle_min, min(servo.angle_max, angle)) #317

        if servo.invert: #319
            clamped_angle = servo.angle_max - (clamped_angle - servo.angle_min) #320
            

        # 线性映射角度到脉冲宽度 #323
        pulse = ((servo.angle_max - clamped_angle) / (servo.angle_max - servo.angle_min)) * \ #324
                (servo.pulse_max - servo.pulse_min) + servo.pulse_min #325
        pulse = int(round(pulse)) #326

        # 限制脉冲在有效范围内 #328
        pulse = max(servo.pulse_min, min(servo.pulse_max, pulse)) #329

        return pulse #331

    def control_servo_based_on_pulses(self, target_pulses): #333
        """ #334
        平滑地将当前脉冲宽度过渡到目标脉冲宽度 #335
        """ #336
        step = 10  # #337
        msg = SetPWMServoState() #338
        msg.duration = 0.2 #339

        adjustments = True #341
        while adjustments and not self.stop_event.is_set(): #342
            adjustments = False #343
            pwm_list = [] #344
            for servo_name, target_pulse in target_pulses.items(): #345
                servo = self.servos[servo_name] #346
                current_pulse = servo.current_pulse #347
                if abs(current_pulse - target_pulse) > step: #348
                    adjustments = True #349
                    if current_pulse < target_pulse: #350
                        servo.current_pulse += step #351
                    else: #352
                        servo.current_pulse -= step #353
                    pos = PWMServoState() #354
                    pos.id = [servo.channel] #355
                    pos.position = [int(servo.current_pulse)] #356
                    pwm_list.append(pos) #357
            msg.state = pwm_list #358
            self.pwm_pub.publish(msg) #359

    def servo_control_thread(self): #361
        while not self.stop_event.is_set(): #362
            try: #363
                pulses = self.angle_queue.get(timeout=0.1) #364
                self.control_servo_based_on_pulses(pulses) #365
            except queue.Empty: #366
                continue #367
            except Exception as e: #368
                pass #369

    def image_display_thread(self): #371
        """图像显示线程""" #372
        self.get_logger().info("图像显示线程启动。") #373
        while not self.stop_event.is_set(): #374
            try: #375
                cv_image = self.display_queue.get(timeout=0.1) #376
                cv2.imshow("MediaPipe Pose", cv_image) #377
                if cv2.waitKey(1) & 0xFF == ord('q'): #378
                    self.get_logger().info("按下 'q' 键，关闭窗口并退出。") #379
                    self.stop_all() #380
            except queue.Empty: #381
                continue #382
            except Exception as e: #383
                self.get_logger().info(f"图像显示线程出错: {e}") #384
        cv2.destroyAllWindows() #385
        self.get_logger().info("图像显示线程停止。") #386

    def image_callback(self, msg): #388
        """图像回调函数""" #389
        try: #390
            # 将 ROS 图像消息转换为 OpenCV 图像 #391
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8') #392
            cv_image = cv2.resize(cv_image, (640, 480), interpolation=cv2.INTER_AREA) #393

            # 转换为 RGB 并使用 MediaPipe 处理 #395
            rgb_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB) #396
            results = self.pose.process(rgb_image) #397

            if results.pose_landmarks: #399
                self.mp_drawing.draw_landmarks(cv_image, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS) #400
                pixel_landmarks = self.convert_landmarks_to_pixels(cv_image, results.pose_landmarks.landmark) #401

                if not self.play_mode: #403
                    if self.is_T_pose(pixel_landmarks): #404
                        self.enter_play_mode() #405
                else: #406
                    self.process_play_mode(pixel_landmarks) #407
                try: #408
                    self.display_queue.put_nowait(cv_image) #409
                except queue.Full: #410
                    self.get_logger().info("图像显示队列已满，丢弃当前帧。") #411
        except Exception as e: #412
            self.get_logger().info(f"处理图像时出错: {e}") #413

    def buzzer_warn(self): #415
        msg = BuzzerState() #416
        msg.freq = 1900 #417
        msg.on_time = 0.2 #418
        msg.off_time = 0.01 #419
        msg.repeat = 2 #420
        self.buzzer_pub.publish(msg)  #421
    
    def enter_play_mode(self): #423
        """进入玩法模式""" #424
        self.play_mode = True #425

        # 定义期望角度 #427
        # 根据实际需求调整这些值 #428
        desired_set_point_left_upper = 90      #429
        desired_set_point_right_upper = 90     #430
        desired_set_point_left_forearm = 135    #431
        desired_set_point_right_forearm = 135  #432

        # 设置 PID 控制器的目标点 #434
        self.servos['left_upper'].pid.SetPoint = desired_set_point_left_upper #435
        self.servos['right_upper'].pid.SetPoint = desired_set_point_right_upper #436
        self.servos['left_forearm'].pid.SetPoint = desired_set_point_left_forearm #437
        self.servos['right_forearm'].pid.SetPoint = desired_set_point_right_forearm #438

        

        # 播放蜂鸣器声音 #442
        self.buzzer_warn() #443

    def exit_play_mode(self): #445
        """退出玩法模式""" #446
        self.play_mode = False #447
        self.get_logger().info("Exiting play mode.") #448


        # 播放退出蜂鸣器声音 #451
        self.buzzer_warn() #452

    def process_play_mode(self, pixel_landmarks): #454
        """处理玩法模式下的舵机控制""" #455
        try: #456
            # 提取相关关键点 #457
            nose = pixel_landmarks[Landmark.NOSE.value] #458
            left_shoulder = pixel_landmarks[Landmark.LEFT_SHOULDER.value] #459
            right_shoulder = pixel_landmarks[Landmark.RIGHT_SHOULDER.value] #460
            left_elbow = pixel_landmarks[Landmark.LEFT_ELBOW.value] #461
            right_elbow = pixel_landmarks[Landmark.RIGHT_ELBOW.value] #462
            left_wrist = pixel_landmarks[Landmark.LEFT_WRIST.value] #463
            right_wrist = pixel_landmarks[Landmark.RIGHT_WRIST.value] #464
            left_hip = pixel_landmarks[Landmark.LEFT_HIP.value] #465
            right_hip = pixel_landmarks[Landmark.RIGHT_HIP.value] #466
            # 计算左上臂角度 #467
            left_shoulder_angle = self.calculate_shoulder_angle(left_shoulder, left_elbow, nose) #468
            self.filtered_angles['left_upper'] = self.apply_low_pass_filter('left_upper', left_shoulder_angle) #469
            self.servos['left_upper'].pid.update(left_shoulder_angle) #470
            pulse_correction_left_upper = self.servos['left_upper'].pid.output #471
            pulse_left_upper = self.servos['left_upper'].current_pulse + pulse_correction_left_upper #472
            pulse_left_upper = self.map_arm_angle_to_pulse01(self.filtered_angles['left_upper'], self.servos['left_upper']) #473
            # 计算右上臂角度 #474
            right_shoulder_angle = self.calculate_shoulder_angle(right_shoulder, right_elbow, nose) #475
            self.filtered_angles['right_upper'] = self.apply_low_pass_filter('right_upper', right_shoulder_angle) #476
            self.servos['right_upper'].pid.update(right_shoulder_angle) #477
            pulse_correction_right_upper = self.servos['right_upper'].pid.output #478
            pulse_right_upper = self.servos['right_upper'].current_pulse + pulse_correction_right_upper #479
            pulse_right_upper = self.map_arm_angle_to_pulse01(self.filtered_angles['right_upper'], self.servos['right_upper']) #480
            # 计算左前臂角度 #481
            left_forearm_angle = self.calculate_angle(left_shoulder, left_elbow, left_wrist) #482
            self.filtered_angles['left_forearm'] = self.apply_low_pass_filter('left_forearm', left_forearm_angle) #483
            self.servos['left_forearm'].pid.update(left_forearm_angle) #484
            pulse_correction_left_forearm = self.servos['left_forearm'].pid.output #485
            pulse_left_forearm = self.servos['left_forearm'].current_pulse + pulse_correction_left_forearm #486
            pulse_left_forearm = self.map_arm_angle_to_pulse(self.filtered_angles['left_forearm'], self.servos['left_forearm']) #487
            # 计算右前臂角度 #488
            right_forearm_angle = self.calculate_angle(right_shoulder, right_elbow, right_wrist) #489
            self.filtered_angles['right_forearm'] = self.apply_low_pass_filter('right_forearm', right_forearm_angle) #490
            self.servos['right_forearm'].pid.update(right_forearm_angle) #491
            pulse_correction_right_forearm = self.servos['right_forearm'].pid.output #492
            pulse_right_forearm = self.servos['right_forearm'].current_pulse + pulse_correction_right_forearm #493
            pulse_right_forearm = self.map_arm_angle_to_pulse(self.filtered_angles['right_forearm'], self.servos['right_forearm']) #494

            pulses = { #496
                'left_upper': pulse_left_upper, #497
                'right_upper': pulse_right_upper, #498
                'left_forearm': pulse_left_forearm, #499
                'right_forearm': pulse_right_forearm #500
            } #501
            self.angle_queue.put(pulses) #502

            if self.is_hands_crossed_on_chest(pixel_landmarks): #504
                self.exit_play_mode() #505
        except IndexError: #506
            self.get_logger().info("关键点检测不到，无法处理玩法模式。") #507
        except Exception as e: #508
            self.get_logger().info(f"处理玩法模式时出错: {e}") #509

    def run(self): #511
        """运行节点""" #512
        rclpy.spin(self) #513

    def stop_all(self): #515
        """关闭节点""" #516
        self.cli.call_async(Empty.Request()) #517
        rclpy.shutdown() #518
        time.sleep(2) #519
        if not self.stop_event.is_set(): #520
            self.get_logger().info("正在关闭 MediaPipePoseNode...") #521
            self.stop_event.set() #522
            self.servo_thread.join() #523
            self.display_thread.join() #524
            cv2.destroyAllWindows() #525
            self.get_logger().info("MediaPipePoseNode 已关闭。") #526

    def signal_handler(self, signum, frame): #528
        """信号处理器，实现关闭""" #529
        self.get_logger().info("接收到退出信号，正在关闭...") #530
        self.stop_all() #531
        sys.exit(0) #532
        
def main(): #534
    rclpy.init() #535
    node = MediaPipePoseNode() #536
    try: #537
        signal.signal(signal.SIGINT, node.signal_handler) #538
        signal.signal(signal.SIGTERM, node.signal_handler) #539
        node.run() #540
    except KeyboardInterrupt: #541
        node.stop_all() #542

if __name__ == '__main__': #544
    main() #545
