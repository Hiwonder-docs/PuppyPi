#!/usr/bin/env python3 #1
# encoding: utf-8 #2
import cv2 #3
import sys #4
from sdk import fps #5
import queue #6
import rclpy #7
import threading #8
import numpy as np #9
import mediapipe as mp #10
from rclpy.node import Node #11
from sensor_msgs.msg import Image #12
from std_msgs.msg import String #13
from std_srvs.srv import SetBool, Trigger, Empty #14
from puppy_control_msgs.srv import SetRunActionName #15
from cv_bridge import CvBridge   #16
sys.path.append('/home/ubuntu/software/puppypi_control/')  #17
from servo_controller import setServoPulse #18
from action_group_control import runActionGroup, stopActionGroup #19

class SegmentationNode(Node): #21
    def __init__(self, name): #22
        rclpy.init() #23
        super().__init__(name) #24
        self.running = True #25
        self.mp_selfie_segmentation = mp.solutions.selfie_segmentation #26
        self.mp_drawing = mp.solutions.drawing_utils #27
        self.fps = fps.FPS() #28
        self.image_queue = queue.Queue(maxsize=2) #29
        self.BG_COLOR = (192, 192, 192)  # gray #30
        self.image_sub = self.create_subscription(Image, '/image_raw', self.image_callback, 1) #31
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start') #32
        self.cli = self.create_client(Empty,'/puppy_control/go_home') #33
        self.cli.call_async(Empty.Request()) #34
        
        self.bridge = CvBridge()  # Initialize CvBridge #36
        threading.Thread(target=self.main, daemon=True).start() #37

    def image_callback(self, ros_image): #39
        try: #40
            rgb_image = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #41
        except Exception as e: #42
            self.get_logger().error(f"Error converting ROS image to OpenCV: {e}") #43
            return #44
        
        if self.image_queue.full(): #46
            self.image_queue.get() #47
        self.image_queue.put(rgb_image) #48

    def main(self): #50
        with self.mp_selfie_segmentation.SelfieSegmentation(model_selection=1) as selfie_segmentation: #51
            bg_image = None #52
            while self.running: #53
                try: #54
                    image = self.image_queue.get(block=True, timeout=1) #55
                except queue.Empty: #56
                    if not self.running: #57
                        break #58
                    else: #59
                        continue #60
                
                # To improve performance, optionally mark the image as not writeable to pass by reference. #62
                image.flags.writeable = False #63
                results = selfie_segmentation.process(image) #64
                image.flags.writeable = True #65
                
                # image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #67
                
                # Draw selfie segmentation on the background image. #69
                condition = np.stack((results.segmentation_mask,) * 3, axis=-1) > 0.1 #70
                
                # 如果没有背景图像，则创建一个灰色背景 #72
                if bg_image is None: #73
                    bg_image = np.zeros(image.shape, dtype=np.uint8) #74
                    bg_image[:] = self.BG_COLOR #75
                
                # 根据分割结果合成输出图像 #77
                output_image = np.where(condition, image, bg_image) #78
                
                self.fps.update() #80
                result_image = self.fps.show_fps(output_image) #81
                
                cv2.imshow('MediaPipe Selfie Segmentation', result_image) #83
                key = cv2.waitKey(1) #84
                if key == ord('q') or key == 27:  # Press q or esc to exit #85
                    break #86
            
            cv2.destroyAllWindows() #88
            rclpy.shutdown() #89

def main(): #91
    node = SegmentationNode('self_segmentation') #92
    try: #93
        rclpy.spin(node) #94
    except KeyboardInterrupt: #95
        node.destroy_node() #96
        rclpy.shutdown() #97
        print('shutdown') #98
    finally: #99
        print('shutdown finish') #100

if __name__ == "__main__": #102
    main() #103
