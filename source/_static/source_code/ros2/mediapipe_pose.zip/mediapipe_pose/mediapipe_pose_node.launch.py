import os #1
from ament_index_python.packages import get_package_share_directory #2

from launch_ros.actions import Node #4
from launch import LaunchDescription, LaunchService #5
from launch.substitutions import LaunchConfiguration #6
from launch.launch_description_sources import PythonLaunchDescriptionSource #7
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, OpaqueFunction #8

def launch_setup(context): #10
    compiled = os.environ['need_compile'] #11
    imu_frame = LaunchConfiguration('imu_frame', default='imu_link') #12
    
    imu_frame_arg = DeclareLaunchArgument('imu_frame', default_value=imu_frame) #14
    
    if compiled == 'True': #16
        peripherals_package_path = get_package_share_directory('peripherals') #17
        robot_controller_package_path = get_package_share_directory('ros_robot_controller') #18
        controller_package_path = get_package_share_directory('puppy_control') #19
        example_package_path = get_package_share_directory('example') #20
    else: #21
        peripherals_package_path = '/home/ubuntu/ros2_ws/src/peripherals' #22
        robot_controller_package_path = '/home/ubuntu/ros2_ws/src/driver/ros_robot_controller' #23
        controller_package_path = '/home/ubuntu/ros2_ws/src/driver/puppy_control' #24
        example_package_path = '/home/ubuntu/ros2_ws/src/example' #25
    depth_camera_launch = IncludeLaunchDescription( #26
        PythonLaunchDescriptionSource( #27
            os.path.join(peripherals_package_path, 'launch/usb_cam.launch.py')), #28
    ) #29
    
    robot_controller_launch = IncludeLaunchDescription( #31
        PythonLaunchDescriptionSource([os.path.join(robot_controller_package_path, 'launch/ros_robot_controller.launch.py') #32
        ]), #33
        launch_arguments={ #34
            'imu_frame': imu_frame, #35
        }.items() #36
    ) #37
    
    controller_launch = IncludeLaunchDescription( #39
        PythonLaunchDescriptionSource( #40
            os.path.join(controller_package_path, 'launch/puppy_control.launch.py')), #41
    ) #42
    

    mediapipe_pose_node = Node( #45
        package='example', #46
        executable='mediapipe_pose', #47
        output='screen', #48
    ) #49

    return [depth_camera_launch, #51
            robot_controller_launch, #52
            controller_launch, #53
            mediapipe_pose_node, #54
            ] #55

def generate_launch_description(): #57
    return LaunchDescription([ #58
        OpaqueFunction(function = launch_setup) #59
    ]) #60

if __name__ == '__main__': #62
    # 创建一个LaunchDescription对象 #63
    ld = generate_launch_description() #64

    ls = LaunchService() #66
    ls.include_launch_description(ld) #67
    ls.run() #68
