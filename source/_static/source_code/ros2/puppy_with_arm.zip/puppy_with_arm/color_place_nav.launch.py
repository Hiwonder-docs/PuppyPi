import os #1
from launch_ros.actions import Node #2
from launch import LaunchService #3

from launch import LaunchDescription #5
from launch.actions import IncludeLaunchDescription, GroupAction #6
from launch.launch_description_sources import PythonLaunchDescriptionSource #7

def launch_setup(context): #9
    peripherals_package_path = '/home/ubuntu/ros2_ws/src/peripherals' #10

    puppy_control_node = GroupAction([  #12
        IncludeLaunchDescription( #13
            PythonLaunchDescriptionSource( #14
                os.path.join(peripherals_package_path, 'launch/usb_cam.launch.py'))), #15

        Node( #17
            package='example', #18
            executable='color_place_nav', #19
            name='color_place_nav_node', #20
            output='screen', #21
        ), #22
    ])  #23
    
    # 返回 LaunchDescription 对象 #25
    return LaunchDescription([ #26
        puppy_control_node #27
    ]) #28

def generate_launch_description(): #30
    return launch_setup(None) #31

if __name__ == '__main__': #33
    ld = generate_launch_description() #34
    
    ls = LaunchService() #36
    ls.include_launch_description(ld) #37
    ls.run() #38
