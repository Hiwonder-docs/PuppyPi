#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import yaml   #4
import os   #5
from cv_bridge import CvBridge #6
import cv2 #7
import numpy as np #8
import math #9
import rclpy #10
import time #11
from threading import Timer #12
from rclpy.node import Node #13
from ros_robot_controller_msgs.msg import BuzzerState #14
from sensor_msgs.msg import Image #15
from puppy_control_msgs.srv import SetRunActionName #16
from sdk import Misc #17

sys.path.append('/home/ubuntu/software/puppypi_control/') #19
from servo_controller import setServoPulse #20


class ColorDetectWithArm(Node): #23
    def __init__(self): #24
        super().__init__('color_detect_with_arm') #25

        # 初始化 CvBridge 实例 #27
        self.bridge = CvBridge() #28

        # 定义 YAML 文件路径 #30
        yaml_file_path = '/home/ubuntu/software/lab_tool/lab_config.yaml' #31
        
        # 尝试从YAML文件中加载 color_range_list #33
        if not os.path.exists(yaml_file_path): #34
            self.get_logger().error(f"YAML file not found at {yaml_file_path}") #35
        else: #36
            try: #37
                with open(yaml_file_path, 'r') as file: #38
                    self.color_range_list = yaml.safe_load(file)['color_range_list'] #39
                self.get_logger().info(f"Loaded color ranges: {self.color_range_list}") #40
            except Exception as e: #41
                self.get_logger().error(f"Failed to load color_range_list from YAML: {e}") #42
                self.color_range_list = {} #43

        # 创建发布者和服务客户端 #45
        self.buzzer_pub = self.create_publisher(BuzzerState, '/ros_robot_controller/set_buzzer', 1) #46
        self.runActionGroup_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #47

        # 创建图像订阅 #49
        self.create_subscription(Image, '/image_raw', self.image_callback, 10) #50
        # 使用定时器定期调用 move 函数 #51
        self.create_timer(1.0, self.move) #52

        # 初始变量 #54
        self.detect_color = 'None' #55
        self.color_list = [] #56
        self.action_finish = True #57
        self.target_color = 'red' #58
        self.draw_color = (255, 255, 0)  # Yellow in BGR #59

    def init_move(self): #61
        while not self.runActionGroup_srv.wait_for_service(timeout_sec=1.0): #62
            self.get_logger().info('Service not available, waiting...') #63
        req = SetRunActionName.Request() #64
        req.name = 'look_down.d6a' #65
        self.runActionGroup_srv.call_async(req) #66

    def move(self): #68
        if self.detect_color == self.target_color: #69
            msg = BuzzerState() #70
            msg.freq = 1900 #71
            msg.on_time = 0.1 #72
            msg.off_time = 0.9 #73
            msg.repeat = 1 #74
            self.buzzer_pub.publish(msg) #75

            self.action_finish = False #77
            time.sleep(0.8) #78

            req = SetRunActionName.Request() #80
            req.name = 'grab.d6a' #81
            self.runActionGroup_srv.call_async(req) #82
            time.sleep(0.5) #83
            self.set_servo_pulse(9, 1200, 300) #84
            time.sleep(0.3) #85
            self.set_servo_pulse(9, 1500, 300) #86

            req.name = 'look_down.d6a' #88
            self.runActionGroup_srv.call_async(req) #89
            time.sleep(0.8) #90
            
            self.detect_color = 'None' #92
            self.draw_color = (255, 255, 0) #93

        self.action_finish = True #95

    def run(self, img): #97
        size = (320, 240) #98
        img_copy = img.copy() #99
        img_h, img_w = img.shape[:2] #100

        frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #102
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #103
        frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #104

        max_area = 0 #106
        color_area_max = None #107
        areaMaxContour_max = 0 #108

        if self.action_finish: #110
            for i in self.color_range_list: #111
                if i in ['red', 'green', 'blue']: #112
                    frame_mask = cv2.inRange(frame_lab, np.array(self.color_range_list[i]['min']), np.array(self.color_range_list[i]['max'])) #113
                    eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #114
                    dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #115
                    dilated[0:120, :] = 0 #116
                    dilated[:, 0:80] = 0 #117
                    dilated[:, 240:320] = 0 #118
                    contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2] #119
                    areaMaxContour, area_max = self.get_area_max_contour(contours) #120

                    if areaMaxContour is not None and area_max > max_area: #122
                        max_area = area_max #123
                        color_area_max = i #124
                        areaMaxContour_max = areaMaxContour #125

            if max_area > 4000: #127
                ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max) #128
                centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #129
                centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #130
                radius = int(Misc.map(radius, 0, size[0], 0, img_w)) #131
                cv2.circle(img, (centerX, centerY), radius, self.draw_color, 2) #132
                print(f"Detected Color: {color_area_max}, Center: ({centerX}, {centerY}), Radius: {radius}") #133
                
                self.detect_color = color_area_max #135
                self.draw_color = (0, 0, 255) if color_area_max == 'red' else (0, 255, 0) #136
            else: #137
                print("No valid color detected") #138

        cv2.rectangle(img, (190, 270), (450, 480), (0, 255, 255), 2) #140
        if self.detect_color == self.target_color: #141
            cv2.putText(img, "Target Color", (225, 250), cv2.FONT_HERSHEY_SIMPLEX, 1, self.draw_color, 2) #142
        else: #143
            cv2.putText(img, "Not Target Color", (200, 250), cv2.FONT_HERSHEY_SIMPLEX, 1, self.draw_color, 2) #144

        cv2.putText(img, "Color: " + self.detect_color, (225, 210), cv2.FONT_HERSHEY_SIMPLEX, 1, self.draw_color, 2) #146
        return img #147

    def image_callback(self, ros_image): #149
        try: #150
            cv2_img = self.bridge.imgmsg_to_cv2(ros_image, "bgr8") #151
            cv2_img = cv2.flip(cv2_img, 1) #152
            frame_result = self.run(cv2_img) #153
            cv2.imshow('Frame', frame_result) #154
            cv2.waitKey(1) #155
        except Exception as e: #156
            self.get_logger().error(f"Failed to process image: {e}") #157

    def get_area_max_contour(self, contours): #159
        contour_area_max = 0 #160
        area_max_contour = None #161
        for c in contours: #162
            contour_area_temp = math.fabs(cv2.contourArea(c)) #163
            if contour_area_temp > contour_area_max: #164
                contour_area_max = contour_area_temp #165
                if contour_area_temp > 50: #166
                    area_max_contour = c #167
        return area_max_contour, contour_area_max #168

    def set_servo_pulse(self, id, pulse, time): #170
        setServoPulse(id, pulse, time) #171

def main(args=None): #173
    rclpy.init(args=args) #174
    color_detect_with_arm = ColorDetectWithArm() #175
    color_detect_with_arm.init_move() #176
    rclpy.spin(color_detect_with_arm) #177

    color_detect_with_arm.destroy_node() #179
    rclpy.shutdown() #180

if __name__ == '__main__': #182
    main() #183
