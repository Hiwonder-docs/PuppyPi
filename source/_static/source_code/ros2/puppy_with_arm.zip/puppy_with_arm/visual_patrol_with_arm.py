#!/usr/bin/env python3 #1
# coding=utf8 #2
# ROS2版本：巡线夹取（支持红、绿、蓝物块夹取和按颜色放置） #3
import sys #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9
from enum import Enum #10
import rclpy #11
from rclpy.node import Node #12
from sensor_msgs.msg import Image #13
from cv_bridge import CvBridge #14
from std_msgs.msg import String #15
import gpiod #16
import yaml #17
import os #18
sys.path.append('/home/ubuntu/software/puppypi_control/') #19
from servo_controller import setServoPulse #20
from action_group_control import runActionGroup, stopActionGroup #21
from puppy_kinematics import HiwonderPuppy, PWMServoParams #22
from sdk.ArmMoveIK import ArmIK #23
from sdk import Misc #24

# 机器人姿态配置 #26
puppy = HiwonderPuppy(setServoPulse=setServoPulse, servoParams=PWMServoParams(), dof='8') #27
Stand = {'roll': math.radians(0), 'pitch': math.radians(0), 'yaw': 0.000, 'height': -10, 'x_shift': -1, 'stance_x': 0, 'stance_y': 0} #28
DownStair = {'roll': math.radians(0), 'pitch': math.radians(-2), 'yaw': 0.000, 'height': -10, 'x_shift': 1, 'stance_x': 0, 'stance_y': 0} #29
Bend = {'roll': math.radians(0), 'pitch': math.radians(-17), 'yaw': 0.000, 'height': -10, 'x_shift': -0.1, 'stance_x': 0, 'stance_y': 0} #30
PuppyPose = Stand.copy() #31

# 步态配置 #33
GaitConfig = {'overlap_time': 0.15, 'swing_time': 0.15, 'clearance_time': 0.0, 'z_clearance': 3} #34

# 移动控制 #36
PuppyMove = {'x': 0, 'y': 0, 'yaw_rate': 0} #37

# GPIO按键配置 #39
key1_pin = 25  # KEY1短按启动程序 #40
key2_pin = 23  # KEY2短按停止程序 #41
try: #42
    chip = gpiod.chip("gpiochip0")   #43
    key1 = chip.get_line(key1_pin) #44
    key2 = chip.get_line(key2_pin) #45
    config = gpiod.line_request() #46
    config.consumer = "key" #47
    config.request_type = gpiod.line_request.DIRECTION_INPUT #48
    config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #49
    key1.request(config) #50
    key2.request(config) #51
except Exception as e: #52
    print(f"GPIO初始化失败: {str(e)}") #53
    sys.exit(1) #54
    
# 全局变量 #56
line_color = 'black'  # 默认巡线颜色 #57
block_color = 'None' #58
block_center_point = (0, 0)  # 物块中心点坐标 #59
AK = ArmIK() #60
color_list = [] #61
line_centerx = -1  # 线条中心坐标位置 #62
img_centerx = 320  # 图像中心X坐标（640/2） #63
size = (640, 480)  # 图像尺寸 #64
Debug = False #65

# ROI配置 #67
roi = [ #68
    (330, 350, 0, 640, 0), #69
    (360, 400, 0, 640, 0), #70
    (410, 460, 0, 640, 1) #71
] #72
roi_h1 = roi[0][0] #73
roi_h2 = roi[1][0] - roi[0][0] #74
roi_h3 = roi[2][0] - roi[1][0] #75
roi_h_list = [roi_h1, roi_h2, roi_h3] #76

# 机器人状态机 #78
class PuppyStatus(Enum): #79
    START = 0 #80
    NORMAL = 1  # 正常巡线 #81
    FOUND_TARGET = 3  # 发现目标物块 #82
    STOP = 10 #83
    END = 20 #84

puppyStatus = PuppyStatus.STOP #86
puppyStatusLast = PuppyStatus.END #87

# ROS2节点定义 #89
class PuppyControlNode(Node): #90
    def __init__(self): #91
        super().__init__('puppy_control_node') #92
        self.bridge = CvBridge() #93
        self.line_color = 'black'  # 巡线颜色 #94
        self.target_colors = ['red', 'green', 'blue']  # 支持夹取的颜色列表 #95
        self.left_colors = ['green', 'blue']  # 放置到左边的颜色 #96
        self.right_colors = ['red']  # 放置到右边的颜色 #97
        self.lab_data = self.load_config() #98

        # 订阅图像话题 #100
        self.image_sub = self.create_subscription( #101
            Image, '/image_raw', self.image_callback, 10) #102
        
        # 发布状态 #104
        self.status_pub = self.create_publisher(String, '/puppy_status', 10) #105

        # 启动移动线程 #107
        self.move_thread = threading.Thread(target=self.move) #108
        self.move_thread.daemon = True #109
        self.move_thread.start() #110

        # 初始化机器人 #112
        self.init_puppy() #113

    def load_config(self): #115
        # 加载颜色范围配置 #116
        config_path = os.path.expanduser('/home/ubuntu/software/lab_tool/lab_config.yaml') #117
        try: #118
            with open(config_path, 'r') as file: #119
                config = yaml.safe_load(file) #120
            return config['color_range_list'] #121
        except Exception as e: #122
            self.get_logger().error(f"加载配置文件失败: {str(e)}") #123
            return {} #124

    def init_puppy(self): #126
        # 初始化机器人姿态和步态 #127
        puppy.stance_config( #128
            self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #129
            PuppyPose['pitch'], PuppyPose['roll']) #130
        puppy.gait_config( #131
            overlap_time=GaitConfig['overlap_time'], #132
            swing_time=GaitConfig['swing_time'], #133
            clearance_time=GaitConfig['clearance_time'], #134
            z_clearance=GaitConfig['z_clearance']) #135
        puppy.start() #136
        puppy.move_stop(servo_run_time=500) #137
        AK.setPitchRangeMoving((8.51, 0, 3.3), 500) #138
        setServoPulse(9, 1500, 500) #139
        time.sleep(0.5) #140

    def stance(self, x=0.0, y=0.0, z=-11.0, x_shift=2.0): #142
        # 姿态配置函数，单位cm #143
        return np.array([ #144
            [x + x_shift, x + x_shift, -x + x_shift, -x + x_shift], #145
            [y, y, y, y], #146
            [z, z, z, z], #147
        ]) #148

    def get_area_max_contour(self, contours): #150
        # 找出面积最大的轮廓 #151
        contour_area_max = 0 #152
        area_max_contour = None #153
        for c in contours: #154
            contour_area_temp = math.fabs(cv2.contourArea(c)) #155
            if contour_area_temp > contour_area_max: #156
                contour_area_max = contour_area_temp #157
                if contour_area_temp >= 5: #158
                    area_max_contour = c #159
        return area_max_contour, contour_area_max #160

    def process_image(self, img): #162
        # 图像处理：巡线和颜色识别 #163
        global line_centerx, block_color, block_center_point, color_list #164
        img_copy = img.copy() #165
        img_h, img_w = img.shape[:2] #166
        frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #167
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #168

        centroid_x_sum = 0 #170
        weight_sum = 0 #171
        n = 0 #172
        center_x_3 = [None] * 3 #173

        # 巡线处理 #175
        for r in roi: #176
            roi_h = roi_h_list[n] #177
            n += 1 #178
            blobs = frame_gb[r[0]:r[1], r[2]:r[3]] #179
            frame_lab = cv2.cvtColor(blobs, cv2.COLOR_BGR2LAB) #180
            if self.line_color in self.lab_data: #181
                frame_mask = cv2.inRange( #182
                    frame_lab, #183
                    tuple(self.lab_data[self.line_color]['min']), #184
                    tuple(self.lab_data[self.line_color]['max'])) #185
                opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((6, 6), np.uint8)) #186
                closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((6, 6), np.uint8)) #187
                cnts = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)[-2] #188
                cnt_large = self.get_area_max_contour(cnts)[0] #189

                if cnt_large is not None: #191
                    rect = cv2.minAreaRect(cnt_large) #192
                    box = np.int0(cv2.boxPoints(rect)) #193
                    for i in range(4): #194
                        box[i, 1] = box[i, 1] + (n - 1) * roi_h + roi[0][0] #195
                        box[i, 1] = int(Misc.map(box[i, 1], 0, size[1], 0, img_h)) #196
                        box[i, 0] = int(Misc.map(box[i, 0], 0, size[0], 0, img_w)) #197
                    cv2.drawContours(img, [box], -1, (0, 0, 255), 2)   #198

                    pt1_x, pt1_y = box[0, 0], box[0, 1] #200
                    pt3_x, pt3_y = box[2, 0], box[2, 1] #201
                    center_x, center_y = (pt1_x + pt3_x) / 2, (pt1_y + pt3_y) / 2 #202
                    cv2.circle(img, (int(center_x), int(center_y)), 5, (0, 0, 255), -1) #203
                    center_x_3[n-1] = center_x #204
                    centroid_x_sum += center_x * r[4] #205
                    weight_sum += r[4] #206

        if weight_sum != 0: #208
            line_centerx = int(centroid_x_sum / weight_sum) #209
            cv2.circle(img, (line_centerx, int(center_y)), 10, (0, 255, 255), -1) #210
            if Debug: #211
                self.get_logger().info(f"line_centerx: {line_centerx}") #212
        else: #213
            line_centerx = -1 #214

        # 颜色识别 #216
        if puppyStatus == PuppyStatus.NORMAL: #217
            frame_lab_all = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #218
            max_area = 0 #219
            color_area_max = None #220
            area_max_contour = None #221

            for color in self.target_colors: #223
                if color in self.lab_data: #224
                    frame_mask = cv2.inRange( #225
                        frame_lab_all, #226
                        tuple(self.lab_data[color]['min']), #227
                        tuple(self.lab_data[color]['max'])) #228
                    eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #229
                    dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #230
                    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE) #231
                    contour, area = self.get_area_max_contour(contours) #232
                    if contour is not None and area > max_area: #233
                        max_area = area #234
                        color_area_max = color #235
                        area_max_contour = contour #236

            if max_area > 200: #238
                ((centerX, centerY), radius) = cv2.minEnclosingCircle(area_max_contour) #239
                centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #240
                centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #241
                block_center_point = (centerX, centerY) #242
                self.get_logger().info(f"检测到物块: 颜色={color_area_max}, 中心=({centerX}, {centerY}), 面积={max_area}") #243

                cv2.circle(img, (centerX, centerY), int(radius), (0, 255, 255), 2) #245

                color_map = {'red': 1, 'green': 2, 'blue': 3} #247
                color_list.append(color_map.get(color_area_max, 0)) #248
                if len(color_list) == 3: #249
                    color = int(round(np.mean(np.array(color_list)))) #250
                    color_list = [] #251
                    block_color = {1: 'red', 2: 'green', 3: 'blue', 0: 'None'}.get(color, 'None') #252
                    self.get_logger().info(f"确认物块颜色: {block_color}") #253
            else: #254
                block_color = 'None' #255
        else: #256
            block_center_point = (0, 0) #257

        # 添加状态和颜色信息到图像 #259
        cv2.putText(img, f"Status: {puppyStatus}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2) #260
        cv2.putText(img, f"Block: {block_color}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2) #261
        return img #262

    def image_callback(self, msg): #264
        # 图像处理回调 #265
        global puppyStatus #266
        try: #267
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8") #268
            processed_img = self.process_image(cv_image) #269
            cv2.imshow('Frame', processed_img) #270
            cv2.waitKey(1) #271
        except Exception as e: #272
            self.get_logger().error(f"图像处理错误: {str(e)}") #273

        # 检查按键 #275
        if key1.get_value() == 0: #276
            time.sleep(0.05) #277
            if key1.get_value() == 0: #278
                puppyStatus = PuppyStatus.START #279
        if key2.get_value() == 0: #280
            time.sleep(0.05) #281
            if key2.get_value() == 0: #282
                puppyStatus = PuppyStatus.STOP #283
                stopActionGroup() #284

    def place_block(self, block_color): #286
        # 根据颜色放置物块 #287
        try: #288
            if block_color in self.right_colors: #289
                self.get_logger().info(f"放置{block_color}到右边区域") #290
                PuppyMove['x'] = 0 #291
                PuppyMove['yaw_rate'] = math.radians(15) #292
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #293
                time.sleep(2) #294
                PuppyMove['yaw_rate'] = math.radians(10) #295
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #296
                time.sleep(1) #297
                puppy.move_stop(servo_run_time=500) #298
                time.sleep(0.5) #299
                runActionGroup('place.d6a', True) #300
                # 回正 #301
                PuppyMove['x'] = 0 #302
                PuppyMove['yaw_rate'] = math.radians(-20) #303
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #304
                time.sleep(2) #305
                PuppyMove['yaw_rate'] = math.radians(-10) #306
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #307
                time.sleep(1) #308
                puppy.move_stop(servo_run_time=500) #309
                time.sleep(0.5) #310
            elif block_color in self.left_colors: #311
                self.get_logger().info(f"放置{block_color}到左边区域") #312
                PuppyMove['x'] = 0 #313
                PuppyMove['yaw_rate'] = math.radians(-20) #314
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #315
                time.sleep(2) #316
                PuppyMove['yaw_rate'] = math.radians(-10) #317
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #318
                time.sleep(1) #319
                puppy.move_stop(servo_run_time=500) #320
                time.sleep(0.5) #321
                runActionGroup('place.d6a', True) #322
                # 回正 #323
                PuppyMove['x'] = 0 #324
                PuppyMove['yaw_rate'] = math.radians(20) #325
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #326
                time.sleep(2) #327
                PuppyMove['yaw_rate'] = math.radians(10) #328
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #329
                time.sleep(1) #330
                puppy.move_stop(servo_run_time=500) #331
                time.sleep(0.5) #332
            else: #333
                self.get_logger().warn(f"无效的物块颜色{block_color}，跳过放置") #334
        except Exception as e: #335
            self.get_logger().error(f"放置动作失败: {str(e)}") #336
            return False #337
        return True #338

    def move(self): #340
        # 移动控制线程 #341
        global puppyStatus, puppyStatusLast, block_center_point, block_color, line_centerx #342
        while rclpy.ok(): #343
            if puppyStatus == PuppyStatus.START: #344
                # 启动阶段：初始化姿态 #345
                puppy.move_stop(servo_run_time=500) #346
                PuppyPose = Bend.copy() #347
                puppy.stance_config( #348
                    self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #349
                    PuppyPose['pitch'], PuppyPose['roll']) #350
                time.sleep(0.5) #351
                puppyStatus = PuppyStatus.NORMAL #352

            elif puppyStatus == PuppyStatus.NORMAL: #354
                # 正常巡线：寻找目标颜色物块 #355
                if block_center_point[1] > 350 and block_color in self.target_colors and abs(block_center_point[0] - line_centerx) < 80: #356
                    puppyStatus = PuppyStatus.FOUND_TARGET #357
                    puppy.move_stop(servo_run_time=500) #358
                    time.sleep(0.5) #359
                elif line_centerx != -1: #360
                    value = line_centerx - img_centerx #361
                    if abs(value) <= 50: #362
                        PuppyMove['x'] = 10 #363
                        PuppyMove['yaw_rate'] = math.radians(0) #364
                    elif abs(value) > 80: #365
                        PuppyMove['x'] = 8 #366
                        PuppyMove['yaw_rate'] = math.radians(-11.0) #367
                    elif abs(value) > 50: #368
                        PuppyMove['x'] = 8 #369
                        PuppyMove['yaw_rate'] = math.radians(-18.0) #370
                    puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #371

            elif puppyStatus == PuppyStatus.FOUND_TARGET: #373
                # 发现目标：执行夹取和放置 #374
                if block_color in self.target_colors: #375
                    try: #376
                        runActionGroup('grab.d6a', True) #377
                        PuppyPose = Stand.copy() #378
                        puppy.stance_config( #379
                            self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']+1), #380
                            PuppyPose['pitch'], PuppyPose['roll']) #381
                        time.sleep(0.5) #382
                        # 执行放置 #383
                        if self.place_block(block_color): #384
                            # 恢复巡线姿态 #385
                            PuppyPose = Bend.copy() #386
                            puppy.stance_config( #387
                                self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #388
                                PuppyPose['pitch'], PuppyPose['roll']) #389
                            time.sleep(0.5) #390
                            puppyStatus = PuppyStatus.NORMAL #391
                        else: #392
                            self.get_logger().error("放置失败，恢复巡线状态") #393
                            puppyStatus = PuppyStatus.NORMAL #394
                    except Exception as e: #395
                        self.get_logger().error(f"夹取动作失败: {str(e)}") #396
                        puppyStatus = PuppyStatus.NORMAL #397
                else: #398
                    self.get_logger().warn(f"物块颜色{block_color}无效，跳过夹取") #399
                    puppyStatus = PuppyStatus.NORMAL #400

            elif puppyStatus == PuppyStatus.STOP: #402
                # 停止状态 #403
                puppy.move_stop(servo_run_time=500) #404
                PuppyPose = Stand.copy() #405
                puppy.stance_config( #406
                    self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #407
                    PuppyPose['pitch'], PuppyPose['roll']) #408
                time.sleep(0.5) #409

            if puppyStatusLast != puppyStatus: #411
                self.get_logger().info(f'当前状态: {puppyStatus}') #412
                status_msg = String() #413
                status_msg.data = str(puppyStatus) #414
                self.status_pub.publish(status_msg) #415
            puppyStatusLast = puppyStatus #416
            time.sleep(0.02) #417

def main(args=None): #419
    rclpy.init(args=args) #420
    node = PuppyControlNode() #421
    try: #422
        rclpy.spin(node) #423
    except KeyboardInterrupt: #424
        node.get_logger().info("节点停止") #425
    finally: #426
        cv2.destroyAllWindows() #427
        node.destroy_node() #428
        rclpy.shutdown() #429

if __name__ == '__main__': #431
    main() #432
