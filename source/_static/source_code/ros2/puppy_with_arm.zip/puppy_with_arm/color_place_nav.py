#!/usr/bin/env python3 #1
# coding=utf-8 #2
# ROS2版本：自主识别并放置物块（优化版，导航后直接进入PLACE状态，无按键触发） #3
import sys #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9
from enum import Enum #10
import rclpy #11
from rclpy.node import Node #12
from sensor_msgs.msg import Image #13
from cv_bridge import CvBridge #14
from std_msgs.msg import String #15
from std_srvs.srv import Trigger #16
import yaml #17
import os #18

# 添加PuppyPi控制路径 #20
sys.path.append('/home/ubuntu/software/puppypi_control/') #21
from servo_controller import setServoPulse #22
from action_group_control import runActionGroup, stopActionGroup #23
from puppy_kinematics import HiwonderPuppy, PWMServoParams #24
from sdk.ArmMoveIK import ArmIK #25
from sdk import Misc #26

# 机器人姿态配置 #28
puppy = HiwonderPuppy(setServoPulse=setServoPulse, servoParams=PWMServoParams(), dof='8') #29
Stand = { #30
    'roll': math.radians(0.0), #31
    'pitch': math.radians(0.0), #32
    'yaw': 0.0, #33
    'height': -10.0, #34
    'x_shift': -0.5, #35
    'stance_x': 0.0, #36
    'stance_y': 0.0 #37
} #38
Bend = { #39
    'roll': math.radians(0.0), #40
    'pitch': math.radians(-17.0), #41
    'yaw': 0.0, #42
    'height': -10.0, #43
    'x_shift': 0.5, #44
    'stance_x': 0.0, #45
    'stance_y': 0.0 #46
} #47
PuppyPose = Stand.copy() #48

# 步态配置 #50
GaitConfig = { #51
    'overlap_time': 0.15, #52
    'swing_time': 0.15, #53
    'clearance_time': 0.0, #54
    'z_clearance': 3.0 #55
} #56

# 移动控制 #58
PuppyMove = {'x': 0.0, 'y': 0.0, 'yaw_rate': 0.0} #59

# 全局变量 #61
block_color = 'None' #62
block_center_point = (0, 0)  # 物块中心点坐标 #63
AK = ArmIK() #64
color_list = [] #65
img_centerx = 320  # 图像中心X坐标（640/2） #66
size = (640, 480)  # 图像尺寸 #67
Debug = False #68

# 机器人状态机 #70
class PuppyStatus(Enum): #71
    STOP = 0  # 停止状态（初始状态） #72
    PLACE = 1  # 放置物块 #73

puppyStatus = PuppyStatus.STOP #75
puppyStatusLast = PuppyStatus.STOP #76

# ROS2节点定义 #78
class PuppyControlNode(Node): #79
    def __init__(self): #80
        super().__init__('puppy_control_node') #81
        self.bridge = CvBridge() #82
        self.place_color = 'red'  # 放置颜色 #83
        self.lab_data = self.load_config() #84

        # 订阅图像话题 #86
        self.image_sub = self.create_subscription( #87
            Image, '/image_raw', self.image_callback, 10) #88

        # 发布状态 #90
        self.status_pub = self.create_publisher(String, '/puppy_status', 10) #91

        # 添加放置服务 #93
        self.place_service = self.create_service( #94
            Trigger, '/automatic_pick/place', self.place_callback) #95
            
        self.goal_status_subscriber = self.create_subscription(String, '/move_base/status', self.goal_status_callback, 1) #97

        # 启动移动线程 #99
        self.move_thread = threading.Thread(target=self.move, daemon=True) #100
        self.nav_status = False  # 控制线程启动状态 #101
        self.move_thread.start() #102

        # 初始化机器人 #104
        self.init_puppy() #105

    def load_config(self): #107
        """从YAML文件加载颜色阈值配置""" #108
        config_path = os.path.expanduser('/home/ubuntu/software/lab_tool/lab_config.yaml') #109
        try: #110
            with open(config_path, 'r') as file: #111
                config = yaml.safe_load(file) #112
            return config['color_range_list'] #113
        except FileNotFoundError: #114
            self.get_logger().error(f"配置文件 {config_path} 未找到，使用默认颜色阈值") #115

    def init_puppy(self): #117
        """初始化机器人姿态和步态""" #118
        puppy.stance_config( #119
            self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #120
            PuppyPose['pitch'], PuppyPose['roll']) #121
        puppy.gait_config( #122
            overlap_time=GaitConfig['overlap_time'], #123
            swing_time=GaitConfig['swing_time'], #124
            clearance_time=GaitConfig['clearance_time'], #125
            z_clearance=GaitConfig['z_clearance']) #126
        puppy.start() #127
        puppy.move_stop(servo_run_time=500) #128
        AK.setPitchRangeMoving((8.51, 0, 3.3), 500) #129
        setServoPulse(9, 1500, 500) #130
        time.sleep(0.5) #131

    def stance(self, x=0.0, y=0.0, z=-11.0, x_shift=2.0): #133
        """姿态配置函数""" #134
        return np.array([ #135
            [x + x_shift, x + x_shift, -x + x_shift, -x + x_shift], #136
            [y, y, y, y], #137
            [z, z, z, z], #138
        ]) #139

    def get_area_max_contour(self, contours): #141
        """找出面积最大的轮廓""" #142
        contour_area_max = 0 #143
        area_max_contour = None #144
        for c in contours: #145
            contour_area_temp = math.fabs(cv2.contourArea(c)) #146
            if contour_area_temp > contour_area_max: #147
                contour_area_max = contour_area_temp #148
                if contour_area_temp >= 5: #149
                    area_max_contour = c #150
        return area_max_contour, contour_area_max #151

    def process_image(self, img): #153
        """图像处理：识别目标颜色""" #154
        global block_color, block_center_point, color_list #155
        img_copy = img.copy() #156
        img_h, img_w = img.shape[:2] #157
        frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #158
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #159
        frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #160

        max_area = 0 #162
        color_area_max = None #163
        area_max_contour = None #164

        for color in ['red', 'green', 'blue']: #166
            if color in self.lab_data: #167
                frame_mask = cv2.inRange( #168
                    frame_lab, #169
                    tuple(self.lab_data[color]['min']), #170
                    tuple(self.lab_data[color]['max'])) #171
                eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #172
                dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #173
                contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE) #174
                contour, area = self.get_area_max_contour(contours) #175
                if contour is not None and area > max_area: #176
                    max_area = area #177
                    color_area_max = color #178
                    area_max_contour = contour #179

        if max_area > 200: #181
            ((centerX, centerY), radius) = cv2.minEnclosingCircle(area_max_contour) #182
            centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #183
            centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #184
            block_center_point = (centerX, centerY) #185
            if Debug: #186
                self.get_logger().info(f"物块中心坐标: x={block_center_point[0]}, y={block_center_point[1]}") #187
            cv2.circle(img, (centerX, centerY), int(radius), (0, 255, 255), 2) #188

            color_map = {'red': 1, 'green': 2, 'blue': 3} #190
            color_list.append(color_map.get(color_area_max, 0)) #191
            if len(color_list) == 3: #192
                color = int(round(np.mean(np.array(color_list)))) #193
                color_list = [] #194
                block_color = {1: 'red', 2: 'green', 3: 'blue', 0: 'None'}.get(color, 'None') #195
        else: #196
            block_color = 'None' #197

        return img #199

    def image_callback(self, msg): #201
        """图像处理回调""" #202
        try: #203
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8") #204
            processed_img = self.process_image(cv_image) #205
            cv2.imshow('Frame', processed_img) #206
            cv2.waitKey(1) #207
        except Exception as e: #208
            self.get_logger().error(f"图像处理错误: {str(e)}") #209

    def goal_status_callback(self, msg): #211
        global puppyStatus #212
        status = msg.data #213
        if status == 'success': #214
            if not self.nav_status: #215
                self.get_logger().info("收到放置请求，开始放置动作") #216
                puppyStatus = PuppyStatus.PLACE #217
                self.nav_status = True #218
            else: #219
                self.get_logger().error("放置动作已在运行") #220
            
    
    
    def place_callback(self, request, response): #224
        """处理 /automatic_pick/place 服务请求，触发放置动作""" #225
        global puppyStatus #226
        if not self.nav_status: #227
            self.get_logger().info("收到放置请求，开始放置动作") #228
            puppyStatus = PuppyStatus.PLACE #229
            self.nav_status = True #230
            response.success = True #231
            response.message = "放置动作已触发" #232
        else: #233
            self.get_logger().error("放置动作已在运行") #234
            response.success = False #235
            response.message = "放置动作已在运行" #236
        return response #237

    def move(self): #239
        """移动控制线程""" #240
        global puppyStatus, puppyStatusLast, block_color, block_center_point #241
        while rclpy.ok(): #242
            if puppyStatus == PuppyStatus.STOP: #243
                # 停止状态：初始化姿态并等待触发 #244
                puppy.move_stop(servo_run_time=500) #245
                PuppyPose = Stand.copy() #246
                puppy.stance_config( #247
                    self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #248
                    PuppyPose['pitch'], PuppyPose['roll']) #249
                time.sleep(0.5) #250

            elif puppyStatus == PuppyStatus.PLACE: #252
                # 放置物块：寻找放置颜色区域 #253
                PuppyPose = Bend.copy() #254
                puppy.stance_config( #255
                    self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #256
                    PuppyPose['pitch'], PuppyPose['roll']) #257
                time.sleep(0.5) #258

                if (block_center_point[1] > 270 and block_color == self.place_color and #260
                        abs(block_center_point[0] - img_centerx) < 70): #261
                    puppy.move_stop(servo_run_time=100) #262
                    self.get_logger().info("开始放置") #263
                    runActionGroup('place.d6a', True) #264
                    time.sleep(0.5) #265
                    puppyStatus = PuppyStatus.STOP #266
                    self.nav_status = False  # 允许下一次触发 #267
                else: #268
                    value = block_center_point[0] - img_centerx #269
                    if block_center_point[1] <= 230: #270
                        PuppyMove['x'] = 10.0 #271
                        PuppyMove['yaw_rate'] = math.radians(0.0) #272
                    elif abs(value) > 80: #273
                        PuppyMove['x'] = 5.0 #274
                        PuppyMove['yaw_rate'] = math.radians(-11.0 * np.sign(value)) #275
                    elif abs(value) > 50: #276
                        PuppyMove['x'] = 5.0 #277
                        PuppyMove['yaw_rate'] = math.radians(-5.0 * np.sign(value)) #278
                    elif block_center_point[1] <= 270: #279
                        PuppyMove['x'] = 8.0 #280
                        PuppyMove['yaw_rate'] = math.radians(0.0) #281
                    puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #282

            if puppyStatusLast != puppyStatus: #284
                self.get_logger().info(f'当前状态: {puppyStatus}') #285
                status_msg = String() #286
                status_msg.data = str(puppyStatus) #287
                self.status_pub.publish(status_msg) #288
            puppyStatusLast = puppyStatus #289
            time.sleep(0.02) #290

def main(args=None): #292
    rclpy.init(args=args) #293
    node = PuppyControlNode() #294
    try: #295
        rclpy.spin(node) #296
    except KeyboardInterrupt: #297
        node.get_logger().info("节点停止") #298
    finally: #299
        cv2.destroyAllWindows() #300
        node.destroy_node() #301
        rclpy.shutdown() #302

if __name__ == '__main__': #304
    main() #305
