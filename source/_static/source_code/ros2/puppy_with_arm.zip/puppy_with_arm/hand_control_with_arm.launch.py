from launch import LaunchDescription #1
from launch_ros.actions import Node #2
from launch.launch_description_sources import PythonLaunchDescriptionSource #3
from launch.actions import IncludeLaunchDescription #4
from launch.substitutions import PathJoinSubstitution #5
from launch_ros.substitutions import FindPackageShare #6
def generate_launch_description(): #7
    return LaunchDescription([ #8
        Node( #9
            package='example',  #10
            executable='hand_control_with_arm',  #11
            name='hand_control_with_arm_node',  #12
            output='screen', #13
        ), #14
        IncludeLaunchDescription( #15
            PythonLaunchDescriptionSource( #16
                ['/home/ubuntu/ros2_ws/src/driver/ros_robot_controller/launch/ros_robot_controller.launch.py'] #17
            ), #18
        ), #19
        IncludeLaunchDescription( #20
            PythonLaunchDescriptionSource( #21
                ['/home/ubuntu/ros2_ws/src/peripherals/launch/web_video_server.launch.py'] #22
            ), #23
        ), #24
        IncludeLaunchDescription( #25
            PythonLaunchDescriptionSource( #26
                ['/home/ubuntu/ros2_ws/src/peripherals/launch/usb_cam.launch.py'] #27
            ), #28
        ), #29
        IncludeLaunchDescription( #30
            PythonLaunchDescriptionSource( #31
                ['/home/ubuntu/ros2_ws/src/driver/puppy_control/launch/puppy_control.launch.py'] #32
            ), #33
        ), #34
    ]) #35
