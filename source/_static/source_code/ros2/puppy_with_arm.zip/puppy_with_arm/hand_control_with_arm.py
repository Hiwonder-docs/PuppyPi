#!/usr/bin/env python3 #1
# encoding: utf-8 #2
import cv2 #3
import sys #4
import os #5
import enum #6
import math   #7
import time #8
import queue #9
import rclpy #10
import threading #11
import numpy as np #12
import faulthandler #13
import mediapipe as mp #14
from rclpy.node import Node #15
from cv_bridge import CvBridge #16
from sensor_msgs.msg import Image #17
from sdk.common import vector_2d_angle, distance #18
from sdk.ArmMoveIK import ArmIK #19
from collections import deque #20
sys.path.append('/home/ubuntu/software/puppypi_control/') #21
from servo_controller import setServoPulse #22

faulthandler.enable() #24

def distance(point_1, point_2): #26
    """ #27
    计算两个点间的距离(calculate the distance between two points) #28
    """ #29
    return math.sqrt((point_1[0] - point_2[0]) ** 2 + (point_1[1] - point_2[1]) ** 2) #30

def get_hand_landmarks(img, landmarks): #32
    """ #33
    将landmarks从medipipe的归一化输出转为像素坐标 #34
    """ #35
    h, w, _ = img.shape #36
    landmarks = [(lm.x * w, lm.y * h) for lm in landmarks] #37
    return np.array(landmarks) #38

def cv2_image2ros(image, frame_id='', node=None): #40
    """ #41
    将opencv的图片转换为ROS2 Image消息 #42
    """ #43
    bridge = CvBridge() #44
    ros_image = bridge.cv2_to_imgmsg(image, encoding="rgb8") #45
    ros_image.header.stamp = node.get_clock().now().to_msg() #46
    ros_image.header.frame_id = frame_id #47
    return ros_image #48

class HandControlWithArmNode(Node): #50
    def __init__(self, name): #51
        super().__init__(name)  # ROS2 中的节点初始化 #52
        self.mpHands = mp.solutions.hands #53
        self.hands = self.mpHands.Hands(static_image_mode=False, #54
                                        max_num_hands=1, #55
                                        min_detection_confidence=0.7, #56
                                        min_tracking_confidence=0.7) #57
        self.mpDraw = mp.solutions.drawing_utils #58
        self.ak = ArmIK() #59
        self.last_time = time.time() #60
        self.last_out = 0 #61

        self.frames = 0 #63

        self.window_size = 5  # 定义滑动窗口大小（滤波窗口大小） #65
        self.distance_measurements = deque(maxlen=self.window_size)  # 创建一个队列用于存储最近的距离测量数据 #66

        self.filtered_distance = 0 #68
        self.image = None #69

        # 定时器用于定期处理图像和发布数据 #71
        self.timer = self.create_timer(0.05, self.timer_callback)  # 每50ms执行一次 #72

        self.image_subscriber = self.create_subscription( #74
            Image, #75
            '/image_raw', #76
            self.image_callback, #77
            10  # 缓存队列大小 #78
        ) #79
        self.result_publisher = self.create_publisher(Image, '~/image_result', 10)  # 图像处理结果发布 #80

        # 启动线程用于伺服电机控制 #82
        self.th = threading.Thread(target=self.move, daemon=True) #83
        self.th.start() #84

    def image_callback(self, ros_image): #86
        """ #87
        图像订阅回调，接收ROS图像消息并强制转换为RGB8格式的OpenCV图像 #88
        """ #89
        bridge = CvBridge() #90
        try: #91
            # 强制转换成 RGB8 格式 #92
            cv_image = bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #93
            
            # 将图像保存在 self.image 变量中 #95
            self.image = cv_image #96

        except Exception as e: #98
            self.get_logger().info(f"Error converting image: {e}") #99


    def init_arm(self): #102
        """ #103
        初始化机械臂位置 #104
        """ #105
        setServoPulse(9, 1500, 300) #106
        setServoPulse(10, 800, 300) #107
        setServoPulse(11, 850, 300) #108
        time.sleep(0.3) #109

    def move(self): #111
        """ #112
        伺服电机控制线程，根据手指之间的距离移动机械臂 #113
        """ #114
        while rclpy.ok(): #115
            if self.filtered_distance > 0 and self.filtered_distance < 100: #116
                out = np.interp(self.filtered_distance, [15, 90], [1500, 900]) #117
                setServoPulse(9, int(out), 0) #118
            else: #119
                time.sleep(0.01) #120

    def timer_callback(self): #122
        """ #123
        定时器回调函数，用于图像处理和发布图像 #124
        """ #125
        if self.image is not None: #126
            image_flip = cv2.flip(self.image, 1) #127
            image_re = cv2.resize(image_flip, (320, 240), interpolation=cv2.INTER_NEAREST) #128
            self.image = None #129
            bgr_image = cv2.cvtColor(image_re, cv2.COLOR_RGB2BGR) #130
            try: #131
                results = self.hands.process(image_re) #132
                if results.multi_hand_landmarks: #133
                    for hand_landmarks in results.multi_hand_landmarks: #134
                        # 绘制手部关键点连线 #135
                        self.mpDraw.draw_landmarks(bgr_image, hand_landmarks, self.mpHands.HAND_CONNECTIONS) #136
                        landmarks = get_hand_landmarks(image_re, hand_landmarks.landmark) #137

                        # 计算拇指和食指尖之间的距离 #139
                        cv2.line(bgr_image, (int(landmarks[4][0]), int(landmarks[4][1])), #140
                                 (int(landmarks[8][0]), int(landmarks[8][1])), (0, 255, 255), 2) #141
                        cv2.circle(bgr_image, (int(landmarks[8][0]), int(landmarks[8][1])), 4, (0, 255, 255), -1) #142
                        cv2.circle(bgr_image, (int(landmarks[4][0]), int(landmarks[4][1])), 4, (0, 255, 255), -1) #143

                        # 计算手指尖的距离 #145
                        distanceSum = distance(landmarks[8], landmarks[4]) #146

                        distanceSum = max(15, min(distanceSum, 90)) #148
                        self.distance_measurements.append(distanceSum) #149
                        self.filtered_distance = np.mean(self.distance_measurements) #150
                        self.filtered_distance = round(self.filtered_distance, 2) #151

                        cv2.putText(bgr_image, 'DST: ' + str(self.filtered_distance), (5, 220), #153
                                    cv2.FONT_HERSHEY_PLAIN, 2, (255, 0, 255), 2) #154

                self.frames += 1 #156
                delta_time = time.time() - self.last_time #157
                cur_fps = np.around(self.frames / delta_time, 1) #158
                cv2.putText(bgr_image, 'FPS: ' + str(cur_fps), (5, 30), #159
                            cv2.FONT_HERSHEY_PLAIN, 2, (255, 0, 255), 2) #160

            except Exception as e: #162
                self.get_logger().info(f"Error: {e}") #163

            # 发布处理后的图像 #165
            self.result_publisher.publish(cv2_image2ros(cv2.resize(bgr_image, (640, 480)), self.get_name(), self)) #166

def main(args=None): #168
    rclpy.init(args=args) #169
    node = HandControlWithArmNode('hand_control') #170
    try: #171
        rclpy.spin(node) #172
    except KeyboardInterrupt: #173
        pass #174
    finally: #175
        node.destroy_node() #176
        rclpy.shutdown() #177

if __name__ == '__main__': #179
    main() #180
