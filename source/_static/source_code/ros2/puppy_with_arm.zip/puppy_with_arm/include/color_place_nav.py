#!/usr/bin/env python3 #1
# coding=utf8 #2

import sys #4
import cv2 #5
import math #6
import time #7
import rclpy #8
import json #9
from rclpy.node import Node #10
from enum import Enum #11
import threading #12
import numpy as np #13
from sensor_msgs.msg import Image #14
from puppy_control_msgs.msg import Velocity, Pose, Gait #15
from cv_bridge import CvBridge #16
from sdk import Misc #17
from action_msgs.msg import GoalStatusArray #18
from puppy_control_msgs.srv import SetRunActionName #19

sys.path.append('/home/ubuntu/software/puppypi_control/') #21
from servo_controller import setServoPulse #22
from sdk.ArmMoveIK import ArmIK #23


def cv2_image2ros(image, frame_id='', node=None): #26
    """ #27
    将opencv的图片转换为ROS2 Image消息 #28
    """ #29
    bridge = CvBridge() #30
    ros_image = bridge.cv2_to_imgmsg(image, encoding="bgr8") #31
    if node: #32
        ros_image.header.stamp = node.get_clock().now().to_msg() #33
    ros_image.header.frame_id = frame_id #34
    return ros_image #35


def getAreaMaxContour(contours): #38
    """ #39
    找出面积最大的轮廓 #40
    """ #41
    contour_area_max = 0 #42
    area_max_contour = None #43

    for c in contours: #45
        contour_area_temp = math.fabs(cv2.contourArea(c)) #46
        if contour_area_temp > contour_area_max: #47
            contour_area_max = contour_area_temp #48
            if contour_area_temp >= 5: #49
                area_max_contour = c #50

    return area_max_contour, contour_area_max #52


Bend = {'roll': math.radians(0), 'pitch': math.radians(-17.0), 'yaw': 0.0, 'height': -10.0, 'x_shift': 0.5, 'stance_x': 0, 'stance_y': 0} #55
Stand = {'roll': math.radians(0), 'pitch': math.radians(0), 'yaw': 0.0, 'height': -10.0, 'x_shift': -1.0, 'stance_x': 0, 'stance_y': 0} #56
GaitConfig = {'overlap_time': 0.15, 'swing_time': 0.15, 'clearance_time': 0.0, 'z_clearance': 3.0} #57

PuppyPose = Bend.copy() #59
PuppyMove = {'x': 0, 'y': 0, 'yaw_rate': 0} #60

target_color = 'red' #62
nav_status = False   #63
image = None         #64
block_center_point = (0, 0) #65

AK = ArmIK() #67

class PuppyStatus(Enum): #69
    START = 0 #70
    NORMAL = 1 #71
    FOUND_TARGET = 2 #72
    PLACE = 3 #73
    STOP = 4 #74
    END = 5 #75


puppyStatus = PuppyStatus.START #78

size = (320, 240) #80
img_centerx = 320 #81


class HandControlWithArmNode(Node): #84
    def __init__(self): #85
        super().__init__('navigation_status_listener') #86

        # 定义颜色范围列表，直接写入代码 #88
        self.color_range_list = { #89
            'red': {'min': [8, 137, 116], 'max': [141, 255, 238]}, #90
            'blue': {'min': [100, 150, 0], 'max': [140, 255, 255]}, #91
            # 可以根据需要添加更多的颜色范围 #92
        } #93

        # 发布者和订阅者 #95
        self.puppy_gait_config_pub = self.create_publisher(Gait, '/puppy_control/gait', 10) #96
        self.puppy_velocity_pub = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #97
        self.puppy_pose_pub = self.create_publisher(Pose, '/puppy_control/pose', 10) #98
        self.result_publisher = self.create_publisher(Image, '~/image_result', 10) #99

        self.image_subscriber = self.create_subscription(Image, '/image_raw', self.image_callback, 10) #101
        self.goal_status_subscriber = self.create_subscription(GoalStatusArray, '/move_base/status', self.goal_status_callback, 10) #102

        # 服务 #104
        self.run_action_group_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #105

        # 变量初始化 #107
        self.image = None #108
        self.nav_status = False #109

        # 定时器，用于替代 while rclpy.ok() 的循环，定期调用图像处理逻辑 #111
        self.timer = self.create_timer(0.1, self.run)  # 每100ms调用一次run方法 #112

        # 线程 #114
        self.th1 = threading.Thread(target=self.move, daemon=True) #115

        # 初始化状态 #117
        self.init_pose() #118

    def init_pose(self): #120
        PuppyPose['stance_x'] = float(PuppyPose.get('stance_x', 0)) #121
        PuppyPose['stance_y'] = float(PuppyPose.get('stance_y', 0)) #122
        PuppyPose['x_shift'] = float(PuppyPose.get('x_shift', 0)) #123
        PuppyPose['height'] = float(PuppyPose.get('height', 0)) #124
        PuppyPose['roll'] = float(PuppyPose.get('roll', 0)) #125
        PuppyPose['pitch'] = float(PuppyPose.get('pitch', 0)) #126
        PuppyPose['yaw'] = float(PuppyPose.get('yaw', 0)) #127

        run_time = int(500) #129

        self.puppy_pose_pub.publish(Pose( #131
            stance_x=PuppyPose['stance_x'], #132
            stance_y=PuppyPose['stance_y'], #133
            x_shift=PuppyPose['x_shift'], #134
            height=PuppyPose['height'], #135
            roll=PuppyPose['roll'], #136
            pitch=PuppyPose['pitch'], #137
            yaw=PuppyPose['yaw'], #138
            run_time=run_time #139
        )) #140

    def image_callback(self, ros_image): #142
        bridge = CvBridge() #143
        self.image = bridge.imgmsg_to_cv2(ros_image, "rgb8") #144

    def goal_status_callback(self, msg): #146
        if len(msg.status_list) > 0: #147
            status = msg.status_list[0].status #148
            if status == 3 and not self.nav_status: #149
                self.get_logger().info("Target arrived") #150
                self.th1.start() #151
                self.nav_status = True #152

    def move(self): #154
        global block_center_point #155
        global PuppyPose #156
        global puppyStatus #157

        while rclpy.ok(): #159
            if puppyStatus == PuppyStatus.START: #160
                PuppyPose = Bend.copy() #161
                self.puppy_pose_pub.publish(Pose(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #162
                                                 height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time=500)) #163
                self.puppy_gait_config_pub.publish(Gait(overlap_time=GaitConfig['overlap_time'], swing_time=GaitConfig['swing_time'], #164
                                                        clearance_time=GaitConfig['clearance_time'], z_clearance=GaitConfig['z_clearance'])) #165
                time.sleep(1) #166
                puppyStatus = PuppyStatus.NORMAL #167
            elif puppyStatus == PuppyStatus.NORMAL: #168
                if block_center_point[1] > 270 and abs(block_center_point[0] - img_centerx) < 70: #169
                    self.call_go_home() #170
                    time.sleep(0.1) #171
                    self.run_action_group('place.d6a') #172
                    puppyStatus = PuppyStatus.STOP #173
                else: #174
                    self.adjust_position() #175

            elif puppyStatus == PuppyStatus.STOP: #177
                AK.setPitchRangeMoving((8.51, 0, 3.3), 500) #178
                time.sleep(0.5) #179
                PuppyPose = Stand.copy() #180
                self.puppy_pose_pub.publish(Pose(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #181
                                                 height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time=500)) #182
                time.sleep(0.5) #183

    def adjust_position(self): #185
        value = block_center_point[0] - img_centerx #186
        if block_center_point[1] <= 250: #187
            PuppyMove['x'] = 10 #188
            PuppyMove['yaw_rate'] = math.radians(0) #189
        elif abs(value) > 80: #190
            PuppyMove['x'] = 5 #191
            PuppyMove['yaw_rate'] = math.radians(-11 * np.sign(value)) #192
        elif abs(value) > 50: #193
            PuppyMove['x'] = 5 #194
            PuppyMove['yaw_rate'] = math.radians(-5 * np.sign(value)) #195
        elif block_center_point[1] <= 270: #196
            PuppyMove['x'] = 8 #197
            PuppyMove['yaw_rate'] = math.radians(0) #198

        self.puppy_velocity_pub.publish(Velocity(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate'])) #200

    def call_go_home(self): #202
        """ #203
        异步调用“go_home”服务，让机器人返回初始位置 #204
        """ #205
        go_home_client = self.create_client(SetRunActionName, '/puppy_control/go_home') #206
        while not go_home_client.wait_for_service(timeout_sec=1.0): #207
            self.get_logger().info('go_home service not available, waiting again...') #208

        request = SetRunActionName.Request() #210
        request.name = 'go_home' #211
        request.times = 1 #212

        future = go_home_client.call_async(request) #214
        rclpy.spin_until_future_complete(self, future) #215

        if future.result() is not None: #217
            self.get_logger().info("Successfully called go_home service.") #218
        else: #219
            self.get_logger().error("Failed to call go_home service.") #220

    def run_action_group(self, action_name): #222
        """ #223
        调用运行动作组服务 #224
        """ #225
        if not self.run_action_group_srv.wait_for_service(timeout_sec=1.0): #226
            self.get_logger().error('runActionGroup service not available.') #227
            return #228

        request = SetRunActionName.Request() #230
        request.name = action_name #231
        request.times = 1 #232

        future = self.run_action_group_srv.call_async(request) #234
        rclpy.spin_until_future_complete(self, future) #235

        if future.result() is not None: #237
            self.get_logger().info(f"Action group '{action_name}' executed.") #238
        else: #239
            self.get_logger().error(f"Failed to execute action group '{action_name}'.") #240

    def run(self): #242
        """ #243
        定时器回调，用于图像处理并发布结果 #244
        """ #245
        global image, block_center_point #246

        if self.image is not None: #248
            img_copy = self.image.copy() #249
            img_h, img_w = self.image.shape[:2] #250
            frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #251
            frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #252
            bgr_image = cv2.cvtColor(frame_gb, cv2.COLOR_RGB2BGR) #253
            frame_lab_all = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2LAB) #254

            max_area = 0 #256
            areaMaxContour_max = 0 #257
            frame_mask = cv2.inRange( #258
                frame_lab_all, #259
                (self.color_range_list[target_color]['min'][0], #260
                 self.color_range_list[target_color]['min'][1], #261
                 self.color_range_list[target_color]['min'][2]), #262
                (self.color_range_list[target_color]['max'][0], #263
                 self.color_range_list[target_color]['max'][1], #264
                 self.color_range_list[target_color]['max'][2]) #265
            ) #266

            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #268
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #269
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2] #270

            areaMaxContour, area_max = getAreaMaxContour(contours) #272
            if areaMaxContour is not None: #273
                if area_max > max_area: #274
                    max_area = area_max #275
                    areaMaxContour_max = areaMaxContour #276

            if max_area > 200: #278
                ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max) #279
                centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #280
                centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #281
                radius = int(Misc.map(radius, 0, size[0], 0, img_w)) #282

                block_center_point = (centerX, centerY) #284

                cv2.circle(bgr_image, (centerX, centerY), radius, (0, 255, 255), 2) #286

            # 发布处理后的图像 #288
            self.result_publisher.publish(cv2_image2ros(cv2.resize(bgr_image, (640, 480)), 'navigation_status_listener', self)) #289


def main(args=None): #292
    rclpy.init(args=args) #293
    node = HandControlWithArmNode() #294

    try: #296
        rclpy.spin(node) #297
    except KeyboardInterrupt: #298
        pass #299
    finally: #300
        node.destroy_node() #301
        rclpy.shutdown() #302


if __name__ == '__main__': #305
    main() #306

