#!/usr/bin/python3 #1
# coding=utf8 #2
# 第11章 ROS机器狗结合机械臂课程\第5课 巡线夹取(11.ROS Robot Combine Robotic Arm Course\Lesson 5 Line Following Gripping) #3
import sys #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9
from enum import Enum #10
from sdk.ArmMoveIK import ArmIK #11
from sdk import Misc #12
from sdk import Camera #13
from sdk import yaml_handle #14
import gpiod #15


sys.path.append('/home/ubuntu/software/puppypi_control/')  #18
from servo_controller import setServoPulse #19
from action_group_control import runActionGroup, stopActionGroup #20
from puppy_kinematics import HiwonderPuppy, PWMServoParams #21

puppy = HiwonderPuppy(setServoPulse = setServoPulse, servoParams = PWMServoParams(), dof = '8') #23

Stand = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-1, 'stance_x':0, 'stance_y':0} #25
DownStair = {'roll':math.radians(0), 'pitch':math.radians(-2), 'yaw':0.000, 'height':-10, 'x_shift':1, 'stance_x':0, 'stance_y':0} #26
Bend = {'roll':math.radians(0), 'pitch':math.radians(-17), 'yaw':0.000, 'height':-10, 'x_shift':-0.1, 'stance_x':0, 'stance_y':0} #27

PuppyPose = Stand.copy() #29
# stance_x：4条腿在x轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the X-axis, measured in centimeters) #30
# stance_y：4条腿在y轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the Y-axis, measured in centimeters) #31
# x_shift: 4条腿在x轴上同向移动的距离，越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡，单位cm(the distance traveled by the four legs along the x-axis determines the degree of forward or backward tilt during walking: smaller distances lead to more forward tilt, while larger distances result in more backward tilt. Adjusting the x_shift parameter can help maintain balance during the dog's movement, measured in centimeters) #32
# height： 狗的高度，脚尖到大腿转动轴的垂直距离，单位cm(the height of the dog, measured from the toe to the axis  of rotation of the thigh, is in centimeters) #33
# pitch： 狗身体的俯仰角，单位弧度(the pitch angle of the dog's body, measured in radians) #34


GaitConfig = {'overlap_time':0.15, 'swing_time':0.15, 'clearance_time':0.0, 'z_clearance':3} #37
# GaitConfig = GaitConfigFast.copy() #38
# overlap_time:4脚全部着地的时间，单位秒(the time when all four legs touch the ground, measured in seconds) #39
# swing_time：2脚离地时间，单位秒(the time duration when legs are off the ground, measured in second) #40
# clearance_time：前后脚间隔时间，单位秒(the time interval between the front and rear legs, measured in seconds) #41
# z_clearance：走路时，脚抬高的距离，单位cm(the distance the paw needs to be raised during walking, measured in centimeters) #42

PuppyMove = {'x':0, 'y':0, 'yaw_rate':0} #44
# x:直行控制，  前进方向为正方向，单位cm/s(straightforward control, with the forward direction as the positive direction, measured in centimeters per second) #45
# y:侧移控制，左侧方向为正方向，单位cm/s，目前无此功能(lateral movement control, with the left direction as the positive direction, measured in cm/s. currently, this function is not available) #46
# yaw_rate：转弯控制，逆时针方向为正方向，单位rad/s(turning control, with counterclockwise direction as the positive direction, measured in rad/s) #47


if sys.version_info.major == 2: #50
    print('Please run this program with python3!') #51
    sys.exit(0) #52

key1_pin = 25 # KEY1短按启动程序(KEY1 short press to start the program) #54
key2_pin = 23 # KEY2短按停止程序(KEY2 short press to stop the program) #55

chip = gpiod.chip("gpiochip0") #57
    
key1 = chip.get_line(key1_pin) #59
config = gpiod.line_request() #60
config.consumer = "key1" #61
config.request_type = gpiod.line_request.DIRECTION_INPUT #62
config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #63
key1.request(config) #64

key2 = chip.get_line(key2_pin) #66
config = gpiod.line_request() #67
config.consumer = "key2" #68
config.request_type = gpiod.line_request.DIRECTION_INPUT #69
config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #70
key2.request(config) #71

line_color = ('black') # 要巡线的颜色(line following color) #73
block_color = 'None' #74
block_center_point = (0,0) # 物块中心点坐标(block center point coordinates) #75
AK = ArmIK() #76
color_list = [] #77

class PuppyStatus(Enum): #79
    START = 0 #80
    NORMAL = 1 # 正常前进中(move forward normally) #81
    FOUND_TARGET = 3 # 已经发现目标物块(the block has been found) #82
    STOP = 10 #83
    END = 20             #84

puppyStatus = PuppyStatus.STOP #86
puppyStatusLast = PuppyStatus.END #87


line_centerx = -1 # 线条中心坐标位置(the central coordinate position of the line) #90
img_centerx = 320 # 理论值是640/2 = 320具体值需要根据不同机器的实际运行情况微调一下(the theoretical value is 640/2 = 320. The specific value needs to be fine-tuned based on the actual operating conditions of different machines) #91
def move(): #92
    global line_centerx, puppyStatus, puppyStatusLast, block_center_point #93
    global block_color #94

    while True: #96
        while(puppyStatus == PuppyStatus.START) :  # 启动阶段，初始化姿态(start stage, initialization posture) #97
            
            puppy.move_stop(servo_run_time = 500) #99
            PuppyPose = Bend.copy() #100
            puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #101
            time.sleep(0.5) #102
            puppyStatus = PuppyStatus.NORMAL  #103
            break #104

        while(puppyStatus == PuppyStatus.NORMAL) : # 正常巡线阶段(normal line following stage) #106
            
            if block_center_point[1] > 350 and abs(block_center_point[0] - line_centerx) < 80: # 已经发现目标物块,只有物块在线上才满足(target object detected, it is considered valid only if the objects is on the line) #108
                puppyStatus = PuppyStatus.FOUND_TARGET #109
                puppy.move_stop(servo_run_time = 500) #110
                time.sleep(0.5) #111
                break #112
            if line_centerx != -1: #113
                value = line_centerx - img_centerx #114
                # 巡线检测(line following detection) #115
                if abs(value) <= 50: #116
                    PuppyMove['x'] = 10 #117
                    PuppyMove['yaw_rate'] = math.radians(0) #118
                elif abs(value) > 80: #119
                    PuppyMove['x'] = 8 #120
                    PuppyMove['yaw_rate'] = math.radians(-11 * np.sign(value)) #121
                elif abs(value) > 50: #122
                    PuppyMove['x'] = 8 #123
                    PuppyMove['yaw_rate'] = math.radians(-5 * np.sign(value)) #124

                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #126
            break #127

        while(puppyStatus == PuppyStatus.FOUND_TARGET) : # 发现物块(find the block) #129
            if block_color == 'red': #130
                runActionGroup('grab.d6a',True) # 执行动作组(perform action group) #131
                PuppyPose = Stand.copy() #132
                puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']+1), PuppyPose['pitch'], PuppyPose['roll']) #133
                time.sleep(0.5) #134
                PuppyMove['x'] = 0 #135
                PuppyMove['yaw_rate'] = math.radians(15) #136
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #137
                time.sleep(2) #138
                
                PuppyMove['yaw_rate'] = math.radians(10) #140
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #141
                time.sleep(1) #142
                puppy.move_stop(servo_run_time = 500) #143
                time.sleep(0.5) #144

                runActionGroup('place.d6a',True) # 执行动作组(perform action group) #146

                PuppyMove['x'] = 0 #148
                PuppyMove['yaw_rate'] = math.radians(-20) #149
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #150
                time.sleep(2) #151
                PuppyMove['yaw_rate'] = math.radians(-10) #152
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #153
                time.sleep(1) #154
                puppy.move_stop(servo_run_time = 500) #155
                time.sleep(0.5) #156

            elif block_color == 'green' or block_color == 'blue': #158
            
                runActionGroup('grab.d6a',True) # 执行动作组(perform action group) #160
                PuppyPose = Stand.copy() #161
                puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']+1), PuppyPose['pitch'], PuppyPose['roll']) #162
                time.sleep(0.5) #163
                
                PuppyMove['x'] = 0 #165
                PuppyMove['yaw_rate'] = math.radians(-20) #166
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #167
                time.sleep(2) #168
                
                PuppyMove['yaw_rate'] = math.radians(-10) #170
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #171
                time.sleep(1) #172
                puppy.move_stop(servo_run_time = 500) #173
                time.sleep(0.5) #174

                runActionGroup('place.d6a',True) # 执行动作组(perform action group) #176

                PuppyMove['x'] = 0 #178
                PuppyMove['yaw_rate'] = math.radians(20) #179
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #180
                time.sleep(2) #181
                PuppyMove['yaw_rate'] = math.radians(10) #182
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #183
                time.sleep(1) #184
                puppy.move_stop(servo_run_time = 500) #185
                time.sleep(0.5) #186
            
            PuppyPose = Bend.copy() #188
            puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #189
            time.sleep(0.5) #190
            puppyStatus = PuppyStatus.NORMAL #191
            

        while(puppyStatus == PuppyStatus.STOP) : #194
            puppy.move_stop(servo_run_time = 500) #195
            PuppyPose = Stand.copy() #196
            puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #197
            time.sleep(0.5) #198
            break #199
        

        time.sleep(0.02) #202

        if puppyStatusLast != puppyStatus: #204
            print('puppyStatus',puppyStatus) #205
        puppyStatusLast = puppyStatus #206
# 运行子线程(run sub-thread) #207
th = threading.Thread(target=move) #208
th.daemon = True #209


roi = [ # [ROI, weight] #212
        (330, 350,  0, 640, 0),  #213
        (360, 400,  0, 640, 0),  #214
        (410, 460,  0, 640, 1) #215
       ] #216
roi_h1 = roi[0][0] #217
roi_h2 = roi[1][0] - roi[0][0] #218
roi_h3 = roi[2][0] - roi[1][0] #219

roi_h_list = [roi_h1, roi_h2, roi_h3] #221

size = (640, 480) #223

lab_data = None #225

def load_config(): #227
    global lab_data #228
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path)['color_range_list'] #229

load_config() #231

# 找出面积最大的轮廓(find out the contour with the maximal area) #233
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #234
def getAreaMaxContour(contours): #235
    contour_area_temp = 0 #236
    contour_area_max = 0 #237
    area_max_contour = None #238

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #240
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate the contour area) #241
        if contour_area_temp > contour_area_max: #242
            contour_area_max = contour_area_temp #243
            if contour_area_temp >= 5:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than 300, the contour with the maximal area is valid to filter the interference) #244
                area_max_contour = c #245

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #247

def run(img): #249
    global line_centerx #250
    global line_color, puppyStatus, block_center_point #251
    global block_color #252
    global color_list #253
    global Debug #254
    
    img_copy = img.copy() #256
    img_h, img_w = img.shape[:2] #257
    
    
    if line_color == (): #260
        return img #261
    
    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #263
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #264
            
    centroid_x_sum = 0 #266
    weight_sum = 0 #267
   
    n = 0 #269

    center_x_3 = [None]*3 #271
    #将图像分割成上中下三个部分，这样处理速度会更快，更精确(segment the image into top, middle, and bottom sections. This approach will improve processing speed and accuracy) #272
    for r in roi: #273
        roi_h = roi_h_list[n] #274
        n += 1        #275
        blobs = frame_gb[r[0]:r[1], r[2]:r[3]] #276
        frame_lab = cv2.cvtColor(blobs, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #277
        
        for i in lab_data: #279
            if i in line_color: #280
                
                frame_mask = cv2.inRange(frame_lab, #282
                                             (lab_data[i]['min'][0], #283
                                              lab_data[i]['min'][1], #284
                                              lab_data[i]['min'][2]), #285
                                             (lab_data[i]['max'][0], #286
                                              lab_data[i]['max'][1], #287
                                              lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(operate the bitwise operation to original image and mask) #288
                opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((6, 6), np.uint8))  # 开运算(opening operation) #289
                closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((6, 6), np.uint8))  # 闭运算(closing operation) #290
               
        cnts = cv2.findContours(closed , cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)[-2]#找出所有轮廓(find out all the contours) #292
        cnt_large = getAreaMaxContour(cnts)[0]#找到最大面积的轮廓(find out the contour with the maximal area) #293
        
        if cnt_large is not None:#如果轮廓不为空(if contour is not none) #295
            rect = cv2.minAreaRect(cnt_large)#最小外接矩形(the minimum bounding rectangle) #296
            box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #297
            for i in range(4): #298
                box[i, 1] = box[i, 1] + (n - 1)*roi_h + roi[0][0] #299
                box[i, 1] = int(Misc.map(box[i, 1], 0, size[1], 0, img_h)) #300
            for i in range(4): #301
                box[i, 0] = int(Misc.map(box[i, 0], 0, size[0], 0, img_w)) #302
                
            cv2.drawContours(img, [box], -1, (0,0,255), 2)#画出四个点组成的矩形(draw the rectangle formed by the four points) #304
            
            #获取矩形的对角点(obtain the diagonal points of the rectangle) #306
            pt1_x, pt1_y = box[0, 0], box[0, 1] #307
            pt3_x, pt3_y = box[2, 0], box[2, 1]             #308
            center_x, center_y = (pt1_x + pt3_x) / 2, (pt1_y + pt3_y) / 2#中心点(center point) #309
            cv2.circle(img, (int(center_x), int(center_y)), 5, (0,0,255), -1)#画出中心点(draw the center point) #310
            center_x_3[n-1] = center_x #311
                                   
            #按权重不同对上中下三个中心点进行求和(sum the weighted values of the top, middle, and bottom centroids, each with a different weight) #313
            centroid_x_sum += center_x * r[4] #314
            weight_sum += r[4] #315

           
    if puppyStatus == PuppyStatus.NORMAL : #318
        
        frame_lab_all = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #320
        max_area = 0 #321
        color_area_max = None     #322
        areaMaxContour_max = 0 #323
    
        for i in lab_data: #325
            if i in ['red', 'green','blue']: #326
                frame_mask = cv2.inRange(frame_lab_all, #327
                                                (lab_data[i]['min'][0], #328
                                                lab_data[i]['min'][1], #329
                                                lab_data[i]['min'][2]), #330
                                                (lab_data[i]['max'][0], #331
                                                lab_data[i]['max'][1], #332
                                                lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #333
                eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #334
                dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #335
                
                contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out the contour) #337
                areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #338
                if areaMaxContour is not None: #339
                    if area_max > max_area:#找最大面积(find the maximal area) #340
                        max_area = area_max #341
                        color_area_max = i #342
                        areaMaxContour_max = areaMaxContour #343
        if max_area > 200:  # 有找到最大面积(the maximal area is found) #344
            ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max)  # 获取最小外接圆(obtain the minimum circumcircle) #345
            centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #346
            centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #347
            radius = int(Misc.map(radius, 0, size[0], 0, img_w))   #348
            block_center_point = (centerX,centerY)    #349
            
            if Debug: #351
                # print("block_center_x",block_center_point[0])    #352
                print("block_center_y",block_center_point[1])      #353
            cv2.circle(img, (centerX, centerY), radius, (0,255,255), 2)#画圆(draw circle) #354
            
            if color_area_max == 'red':  #红色最大(red is the maximal area) #356
                color = 1 #357
            elif color_area_max == 'green':  #绿色最大(green is the maximal area) #358
                color = 2 #359
            elif color_area_max == 'blue':  #蓝色最大(blue is the maximal area) #360
                color = 3 #361
            else: #362
                color = 0 #363
            color_list.append(color) #364

            if len(color_list) == 3:  #多次判断(multiple judgement) #366
                # 取平均值(take average value) #367
                color = int(round(np.mean(np.array(color_list)))) #368
                color_list = [] #369
                if color == 1: #370
                    block_color = 'red' #371
                    
                elif color == 2: #373
                    block_color = 'green' #374
                    
                elif color == 3: #376
                    block_color = 'blue' #377
                   
                else: #379
                    block_color = 'None' #380
                    
                if Debug: #382
                    print('block_color is',block_color)           #383
        else: #384
            block_color = 'None' #385
           
    else: #387
        block_center_point = (0,0) #388
        

    if weight_sum is not 0: #391
        #求最终得到的中心点(calculate the final obtained center point) #392
        cv2.circle(img, (line_centerx, int(center_y)), 10, (0,255,255), -1)#画出中心点(draw the center point) #393
        line_centerx = int(centroid_x_sum / weight_sum)   #394
        if Debug: #395
            print("line_centerx",line_centerx) #396
    else: #397
        line_centerx = -1 #398
    return img #399

def stance(x = 0, y = 0, z = -11, x_shift = 2):# 单位cm(unit: cm) #401
    # x_shift越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡(the smaller the x_shift, the more forward-leaning the walk; the larger, the more backward-leaning. Adjusting x_shift can balance the robot dog's gait) #402
    return np.array([ #403
                        [x + x_shift, x + x_shift, -x + x_shift, -x + x_shift], #404
                        [y, y, y, y], #405
                        [z, z, z, z], #406
                    ])#此array的组合方式不要去改变(please refrain from altering the combination of this array) #407

if __name__ == '__main__': #409

    puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #411
    puppy.gait_config(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #412
                            , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']) #413
    # overlap_time:4脚全部着地的时间，swing_time：2脚离地时间，z_clearance：走路时，脚抬高的距离(overlap_time: The time when all four feet touch the ground, swing_time: The time when two feet are off the ground, z_clearance: The height at which the feet are lifted during walking) #414

    puppy.start() # 启动(start) #416
    puppy.move_stop(servo_run_time = 500) #417

    AK.setPitchRangeMoving((8.51,0,3.3),500) #419
    setServoPulse(9,1500,500) #420
    time.sleep(0.5) #421
    
    
    Debug = False #424
    
    if Debug: #426
        PuppyPose = Bend.copy() #427
        puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #428
        time.sleep(0.5) #429
        puppyStatus = PuppyStatus.NORMAL #430
    else: #431
        th.start()  #432
    #   开启机器狗移动线程(start the moving thread of robot dog) #433
    #   如果只是想看摄像头画面，调试画面，不想让机器人移动，可以把Debug设置为True，同时不要去按按钮(if you only want to view the camera feed and debug the image without moving the robot, you can set Debug to True, and avoid pressing any buttons) #434
    #   等调试完再把Debug设置为False，观察实际运行情况(once debugging is complete, set Debug to False, and observe the actual operation) #435

    my_camera = Camera.Camera() #437
    my_camera.camera_open() #438
    
    while True: #440
        img = my_camera.frame #441
        if img is not None: #442
            frame = img.copy() #443
            Frame = run(frame)            #444
            cv2.imshow('Frame', Frame) #445
            key = cv2.waitKey(1) #446
            if key == 27: #447
                break #448
        else: #449
            time.sleep(0.01) #450

        if key1.get_value() == 0: #452
            time.sleep(0.05) #453
            if key1.get_value() == 0: #454
                puppyStatus = PuppyStatus.START #455
        if key2.get_value() == 0: #456
            time.sleep(0.05) #457
            if key2.get_value() == 0: #458
                puppyStatus = PuppyStatus.STOP #459
                stopActionGroup() #460
    my_camera.camera_close() #461
    cv2.destroyAllWindows() #462

