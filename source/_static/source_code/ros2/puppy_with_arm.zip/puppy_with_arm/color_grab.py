#!/usr/bin/env python3 #1
# coding=utf8 #2
# ROS2版本：自主识别夹取（支持自定义夹取和放置颜色） #3
import sys #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9
from enum import Enum #10
import rclpy #11
from rclpy.node import Node #12
from sensor_msgs.msg import Image #13
from cv_bridge import CvBridge #14
from std_msgs.msg import String #15
import gpiod #16
import yaml #17
import os #18

sys.path.append('/home/ubuntu/software/puppypi_control/') #20
from servo_controller import setServoPulse #21
from action_group_control import runActionGroup, stopActionGroup #22
from puppy_kinematics import HiwonderPuppy, PWMServoParams #23
from sdk.ArmMoveIK import ArmIK #24
from sdk import Misc #25

# 机器人姿态配置 #27
puppy = HiwonderPuppy(setServoPulse=setServoPulse, servoParams=PWMServoParams(), dof='8') #28
Stand = {'roll': math.radians(0.0), 'pitch': math.radians(0.0), 'yaw': 0.000, 'height': -10.0, 'x_shift': -0.5, 'stance_x': 0.0, 'stance_y': 0.0} #29
Bend = {'roll': math.radians(0.0), 'pitch': math.radians(-17.0), 'yaw': 0.000, 'height': -10.0, 'x_shift': 0.5, 'stance_x': 0.0, 'stance_y': 0.0} #30
PuppyPose = Stand.copy() #31

# 步态配置 #33
GaitConfig = {'overlap_time': 0.15, 'swing_time': 0.15, 'clearance_time': 0.0, 'z_clearance': 3} #34

# 移动控制 #36
PuppyMove = {'x': 0, 'y': 0, 'yaw_rate': 0} #37

# GPIO按键配置 #39
key1_pin = 25  # KEY1短按启动程序 #40
key2_pin = 23  # KEY2短按停止程序 #41
try: #42
    chip = gpiod.chip("gpiochip0")   #43
    key1 = chip.get_line(key1_pin) #44
    key2 = chip.get_line(key2_pin) #45
    config = gpiod.line_request() #46
    config.consumer = "key" #47
    config.request_type = gpiod.line_request.DIRECTION_INPUT #48
    config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #49
    key1.request(config) #50
    key2.request(config) #51
except Exception as e: #52
    print(f"GPIO初始化失败: {str(e)}") #53
    sys.exit(1) #54


# 全局变量 #57
block_color = 'None' #58
block_center_point = (0, 0)  # 物块中心点坐标 #59
AK = ArmIK() #60
color_list = [] #61
img_centerx = 320  # 图像中心X坐标（640/2） #62
size = (640, 480)  # 图像尺寸 #63
Debug = False #64

# 机器人状态机 #66
class PuppyStatus(Enum): #67
    START = 0 #68
    NORMAL = 1  # 正常前进 #69
    FOUND_TARGET = 3  # 发现目标物块 #70
    PLACE = 4  # 放置物块 #71
    STOP = 10 #72
    END = 20 #73

puppyStatus = PuppyStatus.STOP #75
puppyStatusLast = PuppyStatus.END #76

# ROS2节点定义 #78
class PuppyControlNode(Node): #79
    def __init__(self): #80
        super().__init__('puppy_control_node') #81
        self.bridge = CvBridge() #82
        self.target_color = 'red'  # 夹取颜色 #83
        self.place_color = 'red'  # 放置颜色 #84
        self.lab_data = self.load_config() #85

        # 订阅图像话题 #87
        self.image_sub = self.create_subscription( #88
            Image, '/image_raw', self.image_callback, 10) #89
        
        # 发布状态 #91
        self.status_pub = self.create_publisher(String, '/puppy_status', 10) #92

        # 启动移动线程 #94
        self.move_thread = threading.Thread(target=self.move) #95
        self.move_thread.daemon = True #96
        self.move_thread.start() #97

        # 初始化机器人 #99
        self.init_puppy() #100

    def load_config(self): #102
        config_path = os.path.expanduser('/home/ubuntu/software/lab_tool/lab_config.yaml') #103
        with open(config_path, 'r') as file: #104
            config = yaml.safe_load(file) #105
        return config['color_range_list'] #106

    def init_puppy(self): #108
        # 初始化机器人姿态和步态 #109
        puppy.stance_config( #110
            self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #111
            PuppyPose['pitch'], PuppyPose['roll']) #112
        puppy.gait_config( #113
            overlap_time=GaitConfig['overlap_time'], #114
            swing_time=GaitConfig['swing_time'], #115
            clearance_time=GaitConfig['clearance_time'], #116
            z_clearance=GaitConfig['z_clearance']) #117
        puppy.start() #118
        puppy.move_stop(servo_run_time=500) #119
        AK.setPitchRangeMoving((8.51, 0, 3.3), 500) #120
        setServoPulse(9, 1500, 500) #121
        time.sleep(0.5) #122

    def stance(self, x=0.0, y=0.0, z=-11.0, x_shift=2.0): #124
        # 姿态配置函数 #125
        return np.array([ #126
            [x + x_shift, x + x_shift, -x + x_shift, -x + x_shift], #127
            [y, y, y, y], #128
            [z, z, z, z], #129
        ]) #130

    def get_area_max_contour(self, contours): #132
        # 找出面积最大的轮廓 #133
        contour_area_max = 0 #134
        area_max_contour = None #135
        for c in contours: #136
            contour_area_temp = math.fabs(cv2.contourArea(c)) #137
            if contour_area_temp > contour_area_max: #138
                contour_area_max = contour_area_temp #139
                if contour_area_temp >= 5: #140
                    area_max_contour = c #141
        return area_max_contour, contour_area_max #142

    def process_image(self, img): #144
        # 图像处理：识别目标颜色 #145
        global block_color, block_center_point, color_list #146
        img_copy = img.copy() #147
        img_h, img_w = img.shape[:2] #148
        frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #149
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #150
        frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #151

        max_area = 0 #153
        color_area_max = None #154
        area_max_contour = None #155

        for color in ['red', 'green', 'blue']: #157
            if color in self.lab_data: #158
                frame_mask = cv2.inRange( #159
                    frame_lab, #160
                    tuple(self.lab_data[color]['min']), #161
                    tuple(self.lab_data[color]['max'])) #162
                eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #163
                dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #164
                contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE) #165
                contour, area = self.get_area_max_contour(contours) #166
                if contour is not None and area > max_area: #167
                    max_area = area #168
                    color_area_max = color #169
                    area_max_contour = contour #170

        if max_area > 200: #172
            ((centerX, centerY), radius) = cv2.minEnclosingCircle(area_max_contour) #173
            centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #174
            centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #175
            block_center_point = (centerX, centerY) #176
            
            if Debug: #178
                self.get_logger().info(f"block_center_x: {block_center_point[0]}, block_center_y: {block_center_point[1]}") #179
            cv2.circle(img, (centerX, centerY), int(radius), (0, 255, 255), 2) #180

            color_map = {'red': 1, 'green': 2, 'blue': 3} #182
            color_list.append(color_map.get(color_area_max, 0)) #183
            if len(color_list) == 3: #184
                color = int(round(np.mean(np.array(color_list)))) #185
                color_list = [] #186
                block_color = {1: 'red', 2: 'green', 3: 'blue', 0: 'None'}.get(color, 'None') #187
        else: #188
            block_color = 'None' #189

        return img #191

    def image_callback(self, msg): #193
        # 图像处理回调 #194
        global puppyStatus #195
        try: #196
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8") #197
            processed_img = self.process_image(cv_image) #198
            cv2.imshow('Frame', processed_img) #199
            cv2.waitKey(1) #200
        except Exception as e: #201
            self.get_logger().error(f"图像处理错误: {str(e)}") #202

        # 检查按键 #204
        if key1.get_value() == 0: #205
            time.sleep(0.05) #206
            if key1.get_value() == 0: #207
                puppyStatus = PuppyStatus.START #208
        if key2.get_value() == 0: #209
            time.sleep(0.05) #210
            if key2.get_value() == 0: #211
                puppyStatus = PuppyStatus.STOP #212
                stopActionGroup() #213

    def move(self): #215
        # 移动控制线程 #216
        global puppyStatus, puppyStatusLast, block_center_point, block_color #217
        while rclpy.ok(): #218
            if puppyStatus == PuppyStatus.START: #219
                # 启动阶段：初始化姿态 #220
                puppy.move_stop(servo_run_time=500) #221
                PuppyPose = Bend.copy() #222
                puppy.stance_config( #223
                    self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #224
                    PuppyPose['pitch'], PuppyPose['roll']) #225
                time.sleep(0.5) #226
                puppyStatus = PuppyStatus.NORMAL #227

            elif puppyStatus == PuppyStatus.NORMAL: #229
                # 正常前进：寻找目标颜色物块 #230
                if (block_center_point[1] > 355 and block_center_point[1] < 370 and #231
                    block_color == self.target_color and abs(block_center_point[0] - img_centerx) < 50): #232
                    puppyStatus = PuppyStatus.FOUND_TARGET #233
                    puppy.move_stop(servo_run_time=500) #234
                    time.sleep(0.5) #235
                else: #236
                    value = block_center_point[0] - img_centerx #237
                    if block_center_point[1] <= 300: #238
                        PuppyMove['x'] = 10.0 #239
                        PuppyMove['yaw_rate'] = math.radians(0.0) #240
                    elif abs(value) > 80: #241
                        PuppyMove['x'] = 5 #242
                        PuppyMove['yaw_rate'] = math.radians(-11.0 * np.sign(value)) #243
                    elif abs(value) > 50: #244
                        PuppyMove['x'] = 5.0 #245
                        PuppyMove['yaw_rate'] = math.radians(-5.0 * np.sign(value)) #246
                    elif block_center_point[1] <= 355: #247
                        PuppyMove['x'] = 8.0 #248
                        PuppyMove['yaw_rate'] = math.radians(0.0) #249
                    elif block_center_point[1] >= 370: #250
                        PuppyMove['x'] = -5.0 #251
                        PuppyMove['yaw_rate'] = math.radians(0.0) #252
                    puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #253

            elif puppyStatus == PuppyStatus.FOUND_TARGET: #255
                # 发现目标：执行夹取 #256
                runActionGroup('grab.d6a', True) #257
                PuppyPose = Stand.copy() #258
                puppy.stance_config( #259
                    self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']+1), #260
                    PuppyPose['pitch'], PuppyPose['roll']) #261
                time.sleep(0.5) #262
                PuppyMove['x'] = 10.0 #263
                PuppyMove['yaw_rate'] = math.radians(0.0) #264
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #265
                time.sleep(1) #266
                PuppyMove['x'] = 5 #267
                PuppyMove['yaw_rate'] = math.radians(20.0) #268
                puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #269
                time.sleep(3) #270
                puppy.move_stop(servo_run_time=500) #271
                time.sleep(0.5) #272
                PuppyPose = Bend.copy() #273
                puppy.stance_config( #274
                    self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #275
                    PuppyPose['pitch'], PuppyPose['roll']) #276
                time.sleep(0.5) #277
                puppyStatus = PuppyStatus.PLACE #278

            elif puppyStatus == PuppyStatus.PLACE: #280
                # 放置物块：寻找放置颜色区域 #281
                if (block_center_point[1] > 270 and block_color == self.place_color and #282
                    abs(block_center_point[0] - img_centerx) < 70): #283
                    puppy.move_stop(servo_run_time=100) #284
                    time.sleep(0.1) #285
                    runActionGroup('place.d6a', True) #286
                    puppyStatus = PuppyStatus.STOP #287
                else: #288
                    value = block_center_point[0] - img_centerx #289
                    if block_center_point[1] <= 230: #290
                        PuppyMove['x'] = 10.0 #291
                        PuppyMove['yaw_rate'] = math.radians(0.0) #292
                    elif abs(value) > 80: #293
                        PuppyMove['x'] = 5.0 #294
                        PuppyMove['yaw_rate'] = math.radians(-11.0 * np.sign(value)) #295
                    elif abs(value) > 50: #296
                        PuppyMove['x'] = 5.0 #297
                        PuppyMove['yaw_rate'] = math.radians(-5.0 * np.sign(value)) #298
                    elif block_center_point[1] <= 270: #299
                        PuppyMove['x'] = 8.0 #300
                        PuppyMove['yaw_rate'] = math.radians(0.0) #301
                    puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #302

            elif puppyStatus == PuppyStatus.STOP: #304
                # 停止状态 #305
                puppy.move_stop(servo_run_time=500) #306
                PuppyPose = Stand.copy() #307
                puppy.stance_config( #308
                    self.stance(PuppyPose['stance_x'], PuppyPose['stance_y'], PuppyPose['height'], PuppyPose['x_shift']), #309
                    PuppyPose['pitch'], PuppyPose['roll']) #310
                time.sleep(0.5) #311

            if puppyStatusLast != puppyStatus: #313
                self.get_logger().info(f'当前状态: {puppyStatus}') #314
                status_msg = String() #315
                status_msg.data = str(puppyStatus) #316
                self.status_pub.publish(status_msg) #317
            puppyStatusLast = puppyStatus #318
            time.sleep(0.02) #319

def main(args=None): #321
    rclpy.init(args=args) #322
    node = PuppyControlNode() #323
    try: #324
        rclpy.spin(node) #325
    except KeyboardInterrupt: #326
        node.get_logger().info("节点停止") #327
    finally: #328
        cv2.destroyAllWindows() #329
        node.destroy_node() #330
        rclpy.shutdown() #331

if __name__ == '__main__': #333
    main() #334
