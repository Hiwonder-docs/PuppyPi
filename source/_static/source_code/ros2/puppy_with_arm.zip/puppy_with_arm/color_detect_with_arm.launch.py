from launch import LaunchDescription #1
from launch_ros.actions import Node #2
from launch.launch_description_sources import PythonLaunchDescriptionSource #3
from launch.actions import IncludeLaunchDescription #4
import os #5

def generate_launch_description(): #7
    # Define paths to external launch files #8
    ros_robot_controller_launch_path = '/home/ubuntu/ros2_ws/src/driver/ros_robot_controller/launch/ros_robot_controller.launch.py' #9
    usb_cam_launch_path = '/home/ubuntu/ros2_ws/src/peripherals/launch/usb_cam.launch.py' #10
    puppy_control_launch_path = '/home/ubuntu/ros2_ws/src/driver/puppy_control/launch/puppy_control.launch.py' #11

    return LaunchDescription([ #13
        # Define the color detect with arm node #14
        Node( #15
            package='example', #16
            executable='color_detect_with_arm', #17
            name='color_detect_with_arm_node', #18
            output='screen' #19
        ), #20

        # Include ros_robot_controller launch #22
        IncludeLaunchDescription( #23
            PythonLaunchDescriptionSource(ros_robot_controller_launch_path) #24
        ), #25

        # Include usb_cam launch #27
        IncludeLaunchDescription( #28
            PythonLaunchDescriptionSource(usb_cam_launch_path) #29
        ), #30

        # Include puppy_control launch #32
        IncludeLaunchDescription( #33
            PythonLaunchDescriptionSource(puppy_control_launch_path) #34
        ), #35
    ]) #36

