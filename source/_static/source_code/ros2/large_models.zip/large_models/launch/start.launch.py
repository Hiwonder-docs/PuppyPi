import os #1
from ament_index_python.packages import get_package_share_directory #2

from launch import LaunchDescription, LaunchService #4
from launch.actions import IncludeLaunchDescription, OpaqueFunction #5
from launch.launch_description_sources import PythonLaunchDescriptionSource #6

def launch_setup(context): #8
    vocal_detect_launch = IncludeLaunchDescription( #9
        PythonLaunchDescriptionSource( #10
            os.path.join(get_package_share_directory('large_models'), 'launch/vocal_detect.launch.py')), #11
    ) #12

    agent_process_launch = IncludeLaunchDescription( #14
        PythonLaunchDescriptionSource( #15
            os.path.join(get_package_share_directory('large_models'), 'launch/agent_process.launch.py')), #16
    ) #17

    tts_node_launch = IncludeLaunchDescription( #19
        PythonLaunchDescriptionSource( #20
            os.path.join(get_package_share_directory('large_models'), 'launch/tts_node.launch.py')), #21
    ) #22

    return [vocal_detect_launch, #24
            agent_process_launch, #25
            tts_node_launch, #26
            ] #27

def generate_launch_description(): #29
    return LaunchDescription([ #30
        OpaqueFunction(function = launch_setup) #31
    ]) #32

if __name__ == '__main__': #34
    # 创建一个LaunchDescription对象(create a LaunchDescription object) #35
    ld = generate_launch_description() #36

    ls = LaunchService() #38
    ls.include_launch_description(ld) #39
    ls.run() #40

