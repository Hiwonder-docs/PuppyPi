from launch_ros.actions import Node #1
from launch import LaunchDescription, LaunchService #2
from launch.actions import OpaqueFunction  #3

def launch_setup(context): #5
    tts_node = Node( #6
        package='large_models', #7
        executable='tts_node', #8
        output='screen', #9
    ) #10

    return [ #12
            tts_node #13
            ] #14

def generate_launch_description(): #16
    return LaunchDescription([ #17
        OpaqueFunction(function = launch_setup) #18
    ]) #19

if __name__ == '__main__': #21
    # 创建一个LaunchDescription对象 #22
    ld = generate_launch_description() #23

    ls = LaunchService() #25
    ls.include_launch_description(ld) #26
    ls.run() #27
