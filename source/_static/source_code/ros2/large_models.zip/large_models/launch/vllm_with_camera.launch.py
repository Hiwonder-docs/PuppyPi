import os #1
from ament_index_python.packages import get_package_share_directory #2
from launch import LaunchDescription #3
from launch.actions import IncludeLaunchDescription #4
from launch.launch_description_sources import PythonLaunchDescriptionSource #5
from launch_ros.actions import Node #6

def generate_launch_description(): #8
    compiled = os.environ.get('need_compile', 'False') #9
    if compiled == 'True': #10
        peripherals_package_path = get_package_share_directory('peripherals') #11
    else: #12
        peripherals_package_path = '/home/ubuntu/ros2_ws/src/peripherals' #13

    # 引入 large_models 包中的子 Launch 文件 #15
    vocal_detect_launch = IncludeLaunchDescription( #16
        PythonLaunchDescriptionSource( #17
            os.path.join(get_package_share_directory('large_models'), 'launch/vocal_detect.launch.py')) #18
    ) #19

    agent_process_launch = IncludeLaunchDescription( #21
        PythonLaunchDescriptionSource( #22
            os.path.join(get_package_share_directory('large_models'), 'launch/agent_process.launch.py')) #23
    ) #24

    tts_node_launch = IncludeLaunchDescription( #26
        PythonLaunchDescriptionSource( #27
            os.path.join(get_package_share_directory('large_models'), 'launch/tts_node.launch.py')) #28
    ) #29

    # 启动 puppy_control 节点 #31
    puppy_control_node = Node( #32
        package='puppy_control', #33
        executable='puppy_control', #34
        name='puppy', #35
        output='screen', #36
        parameters=[ #37
            {'joint_state_pub_topic': 'true'}, #38
            {'joint_state_controller_pub_topic': 'true'} #39
        ] #40
    ) #41

    # 启动 USB 摄像头节点 #43
    camera_node = Node( #44
        package='usb_cam', #45
        executable='usb_cam_node_exe', #46
        name='usb_cam', #47
        output='screen', #48
        parameters=[os.path.join(peripherals_package_path, 'config', 'usb_cam_param_1.yaml')], #49
    ) #50
    with_camera_launch = Node( #51
            package='large_models',   #52
            executable='/usr/bin/python3',   #53
            output='screen',   #54
            arguments=[ #55
                os.path.join('/home/ubuntu/ros2_ws/src/large_models/large_models', 'vllm_with_camera.py')  #56
            ] #57
        ) #58
    # 返回所有节点和子 Launch #59
    return LaunchDescription([ #60
        vocal_detect_launch, #61
        agent_process_launch, #62
        tts_node_launch, #63
        puppy_control_node, #64
        with_camera_launch, #65
        camera_node #66
    ]) #67
