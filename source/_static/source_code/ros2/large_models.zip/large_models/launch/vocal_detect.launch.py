import os #1
from launch_ros.actions import Node #2
from launch import LaunchDescription, LaunchService #3
from launch.substitutions import LaunchConfiguration #4
from launch.actions import OpaqueFunction, DeclareLaunchArgument #5

def launch_setup(context, *args, **kwargs): #7
    mode = LaunchConfiguration('mode', default=1) #8
    enable_wakeup = LaunchConfiguration('enable_wakeup', default='true') #9
    #awake_method = LaunchConfiguration('awake_method', default=os.environ['MIC_TYPE']) #10
    awake_method = LaunchConfiguration('awake_method', default="wonderEchoPro") #11
    chinese_awake_words = LaunchConfiguration('chinese_awake_words', default='xiao3 huan4 xiao3 huan4') #12
    enable_setting = LaunchConfiguration('enable_setting', default='false') #13
    
    mode_arg = DeclareLaunchArgument('mode', default_value=mode) #15
    enable_wakeup_arg = DeclareLaunchArgument('enable_wakeup', default_value=enable_wakeup)  #16
    awake_method_arg = DeclareLaunchArgument('awake_method', default_value=awake_method) #17
    awake_words_arg = DeclareLaunchArgument('chinese_awake_words', default_value=chinese_awake_words) #18
    enable_setting_arg = DeclareLaunchArgument('enable_setting', default_value=enable_setting) #19

    vocal_detect_node = Node( #21
        package='large_models', #22
        executable='vocal_detect', #23
        output='screen', #24
        parameters=[{"port": "/dev/ttyUSB0", #25
                     "mic_type": "mic6_circle", #26
                     "awake_method": awake_method, #27
                     "awake_word": chinese_awake_words, #28
                     "enable_setting": enable_setting, #29
                     "enable_wakeup": enable_wakeup, #30
                     "mode": mode}] #31
    ) #32

    return [ #34
            mode_arg, #35
            enable_wakeup_arg, #36
            awake_method_arg, #37
            awake_words_arg, #38
            enable_setting_arg, #39
            vocal_detect_node, #40
            ] #41

def generate_launch_description(): #43
    return LaunchDescription([ #44
        OpaqueFunction(function = launch_setup) #45
    ]) #46

if __name__ == '__main__': #48
    # 创建一个LaunchDescription对象 #49
    ld = generate_launch_description() #50

    ls = LaunchService() #52
    ls.include_launch_description(ld) #53
    ls.run() #54
