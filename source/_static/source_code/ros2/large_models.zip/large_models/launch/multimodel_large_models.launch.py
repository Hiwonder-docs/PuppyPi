import os #1
from ament_index_python.packages import get_package_share_directory #2
from launch_ros.actions import Node #3
from launch import LaunchDescription, LaunchService #4
from launch.actions import IncludeLaunchDescription, OpaqueFunction #5
from launch.launch_description_sources import PythonLaunchDescriptionSource #6

def launch_setup(context): #8

    ros_robot_controller_launch = IncludeLaunchDescription( #10
            PythonLaunchDescriptionSource(['/home/ubuntu/ros2_ws/src/driver/ros_robot_controller/launch/ros_robot_controller.launch.py']),) #11
            
    usb_cam_launch = IncludeLaunchDescription( #13
            PythonLaunchDescriptionSource(['/home/ubuntu/ros2_ws/src/peripherals/launch/usb_cam.launch.py']),) #14
            
    puppy_control_launch = IncludeLaunchDescription( #16
            PythonLaunchDescriptionSource(['/home/ubuntu/ros2_ws/src/driver/puppy_control/launch/puppy_control.launch.py']),) #17
    
    vocal_detect_launch = IncludeLaunchDescription( #19
        PythonLaunchDescriptionSource( #20
            os.path.join(get_package_share_directory('large_models'), 'launch/vocal_detect.launch.py')),) #21
            
    function_call_node = Node( #23
            package='large_models',  #24
            executable='function_call',  #25
            #name='function_call',  #26
            output='screen', #27
        ) #28
        
    visual_patrol_executable = Node( #30
            package='large_models',  #31
            executable='visual_patrol_node',  #32
            #name='function_call',  #33
            output='screen', #34
        ) #35
        
    kick_ball_executable = Node( #37
            package='large_models',  #38
            executable='kick_ball_node',  #39
            #name='function_call',  #40
            output='screen', #41
        ) #42

    agent_process_launch = IncludeLaunchDescription( #44
        PythonLaunchDescriptionSource( #45
            os.path.join(get_package_share_directory('large_models'), 'launch/agent_process.launch.py')), #46
    ) #47

    tts_node_launch = IncludeLaunchDescription( #49
        PythonLaunchDescriptionSource( #50
            os.path.join(get_package_share_directory('large_models'), 'launch/tts_node.launch.py')), #51
    ) #52

    return [ #54
            ros_robot_controller_launch, #55
            usb_cam_launch, #56
            puppy_control_launch,          #57
            vocal_detect_launch, #58
            agent_process_launch, #59
            tts_node_launch, #60
            kick_ball_executable, #61
            visual_patrol_executable, #62
            function_call_node, #63
            
            ] #65

def generate_launch_description(): #67
    return LaunchDescription([ #68
        OpaqueFunction(function = launch_setup) #69
    ]) #70

if __name__ == '__main__': #72
    # 创建一个LaunchDescription对象(create a LaunchDescription object) #73
    ld = generate_launch_description() #74

    ls = LaunchService() #76
    ls.include_launch_description(ld) #77
    ls.run() #78

