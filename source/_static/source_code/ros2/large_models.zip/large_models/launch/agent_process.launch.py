from launch_ros.actions import Node #1
from launch import LaunchDescription, LaunchService #2
from launch.substitutions import LaunchConfiguration #3
from launch.actions import OpaqueFunction, DeclareLaunchArgument #4

def launch_setup(context): #6
    camera_topic = LaunchConfiguration('camera_topic', default='image_raw') #7
    camera_topic_arg = DeclareLaunchArgument('camera_topic', default_value=camera_topic) #8

    agent_process_node = Node( #10
        package='large_models', #11
        executable='agent_process', #12
        output='screen', #13
        parameters=[{"camera_topic": camera_topic}], #14
    ) #15

    return [ #17
            camera_topic_arg, #18
            agent_process_node #19
            ] #20

def generate_launch_description(): #22
    return LaunchDescription([ #23
        OpaqueFunction(function = launch_setup) #24
    ]) #25

if __name__ == '__main__': #27
    # 创建一个LaunchDescription对象 #28
    ld = generate_launch_description() #29

    ls = LaunchService() #31
    ls.include_launch_description(ld) #32
    ls.run() #33
