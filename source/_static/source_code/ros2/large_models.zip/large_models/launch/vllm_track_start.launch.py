import os #1
from ament_index_python.packages import get_package_share_directory #2
from launch import LaunchDescription #3
from launch.actions import IncludeLaunchDescription #4
from launch.launch_description_sources import PythonLaunchDescriptionSource #5
from launch_ros.actions import Node #6

def generate_launch_description(): #8
    compiled = os.environ.get('need_compile', 'False') #9
    if compiled == 'True': #10
        peripherals_package_path = get_package_share_directory('peripherals') #11
    else: #12
        peripherals_package_path = '/home/ubuntu/ros2_ws/src/peripherals' #13

    # 启动 vocal_detect 节点 #15
    vocal_detect_launch = IncludeLaunchDescription( #16
        PythonLaunchDescriptionSource( #17
            os.path.join(get_package_share_directory('large_models'), 'launch/vocal_detect.launch.py')) #18
    ) #19

    # 启动 agent_process 节点 #21
    agent_process_launch = IncludeLaunchDescription( #22
        PythonLaunchDescriptionSource( #23
            os.path.join(get_package_share_directory('large_models'), 'launch/agent_process.launch.py')) #24
    ) #25

    # 启动 tts_node 节点 #27
    tts_node_launch = IncludeLaunchDescription( #28
        PythonLaunchDescriptionSource( #29
            os.path.join(get_package_share_directory('large_models'), 'launch/tts_node.launch.py')) #30
    ) #31

    llm_tracking_launch = Node( #33
        package='large_models',   #34
        executable='/usr/bin/python3',   #35
        name='llm_tracking_node',   #36
        output='screen',   #37
        arguments=[ #38
            os.path.join('/home/ubuntu/ros2_ws/src/large_models/large_models', 'llm_tracking.py')  #39
        ] #40
    ) #41

    # 启动 USB 摄像头节点 #43
    camera_node = Node( #44
        package='usb_cam', #45
        executable='usb_cam_node_exe', #46
        name='usb_cam', #47
        output='screen', #48
        parameters=[os.path.join(peripherals_package_path, 'config', 'usb_cam_param_1.yaml')] #49
    ) #50
    
    color_tracking_launch = Node( #52
        package='large_models',   #53
        executable='/usr/bin/python3',   #54
        #name='color_tracking_node',   #55
        output='screen',   #56
        arguments=[ #57
            os.path.join('/home/ubuntu/ros2_ws/src/large_models/large_models', 'vllm_color_tracking.py')  #58
        ] #59
    ) #60
    # 返回所有节点和子 Launch #61
    return LaunchDescription([ #62
        vocal_detect_launch, #63
        agent_process_launch, #64
        tts_node_launch, #65
        llm_tracking_launch,  #66
        color_tracking_launch, #67
        camera_node, #68
    ]) #69
