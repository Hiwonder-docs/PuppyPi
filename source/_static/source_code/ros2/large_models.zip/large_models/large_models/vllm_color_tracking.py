#!/usr/bin/python3 #1
# coding=utf8 #2
import rclpy #3
from rclpy.node import Node #4
from std_srvs.srv import Trigger, SetBool #5
from sensor_msgs.msg import Image #6
from std_msgs.msg import Bool  #7
from cv_bridge import CvBridge, CvBridgeError #8
from large_models_msgs.srv import SetColor #9
import threading #10
import time #11
import cv2 #12

from puppy_controller import PuppyController, PuppyStatus #14

class ControlServiceNode(Node): #16
    def __init__(self): #17
        super().__init__('color_tracking_node') #18

        self.controller = PuppyController(debug=False) #20

        self.bridge = CvBridge() #22
        self.image_sub = self.create_subscription( #23
            Image, #24
            'image_raw', #25
            self.image_callback, #26
            10) #27

        # 新增订阅 /vocal_detect/wakeup #29
        self.wakeup_sub = self.create_subscription( #30
            Bool, #31
            '/vocal_detect/wakeup', #32
            self.wakeup_callback, #33
            10) #34

        self.latest_image = None #36
        self.image_lock = threading.Lock() #37

        self.enter_service = self.create_service(Trigger, 'color_tracking/enter', self.enter_callback) #39
        self.enable_service = self.create_service(SetBool, 'color_tracking/enable_color_tracking', self.enable_callback) #40
        self.set_color_service = self.create_service(SetColor, 'color_tracking/set_color', self.set_color_callback) #41
        self.stop_service = self.create_service(Trigger, 'color_tracking/stop', self.stop_callback) #42

        self.get_logger().info('控制服务节点启动，等待服务请求') #44

    def image_callback(self, msg): #46
        try: #47
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8') #48
            with self.image_lock: #49
                self.latest_image = cv_image #50
        except CvBridgeError as e: #51
            self.get_logger().error(f"转换图像失败: {e}") #52

    def get_latest_image(self): #54
        with self.image_lock: #55
            return self.latest_image.copy() if self.latest_image is not None else None #56

    def enter_callback(self, request, response): #58
        with self.controller.status_lock: #59
            if self.controller.status == PuppyStatus.STOP: #60
                response.success = False #61
                response.message = "机器人处于停止状态，无法进入颜色跟踪模式。" #62
                self.get_logger().warn(response.message) #63
                return response #64

            if self.controller.target_color == 'None': #66
                response.success = False #67
                response.message = '未设置目标颜色，请先调用 /color_tracking/set_color 服务设置目标颜色。' #68
                self.get_logger().warn(response.message) #69
                return response #70

            if self.controller.status not in [PuppyStatus.START, PuppyStatus.NORMAL, PuppyStatus.FOUND_TARGET]: #72
                self.controller.status = PuppyStatus.START #73
                response.success = True #74
                response.message = '进入颜色跟踪模式' #75
                self.get_logger().info('开始颜色跟踪') #76
            else: #77
                response.success = False #78
                response.message = '颜色跟踪模式已运行' #79
        return response #80

    def enable_callback(self, request, response): #82
        with self.controller.status_lock: #83
            if self.controller.status == PuppyStatus.STOP: #84
                response.success = False #85
                response.message = "机器人处于停止状态，无法启动颜色跟踪。" #86
                self.get_logger().warn(response.message) #87
                return response #88

            if request.data: #90
                if self.controller.target_color == 'None': #91
                    response.success = False #92
                    response.message = "未设置目标颜色，请先调用 /color_tracking/set_color 设定目标颜色。" #93
                    self.get_logger().warn(response.message) #94
                    return response #95
                self.controller.color_tracking_enabled = True #96
                self.controller.status = PuppyStatus.START #97
                response.success = True #98
                response.message = "颜色跟踪已启用" #99
                self.get_logger().info(response.message) #100
            else: #101
                self.controller.color_tracking_enabled = False #102
                self.controller.status = PuppyStatus.STOP #103
                response.success = True #104
                response.message = "颜色跟踪已禁用" #105
                self.get_logger().info(response.message) #106
        return response #107

    def set_color_callback(self, request, response): #109
        if request.color in self.controller.lab_data: #110
            with self.controller.status_lock: #111
                self.controller.target_color = request.color #112
                self.controller.color_tracking_enabled = True #113
                self.controller.status = PuppyStatus.START #114
                response.success = True #115
                response.message = f"目标颜色设置为 {self.controller.target_color}" #116
                self.get_logger().info(response.message) #117
        else: #118
            response.success = False #119
            response.message = f"颜色 {request.color} 未在配置文件中找到" #120
            self.get_logger().warn(response.message) #121
        return response #122

    def stop_color_tracking(self): #124
        with self.controller.status_lock: #125
            if self.controller.status != PuppyStatus.STOP: #126
                self.controller.color_tracking_enabled = False #127
                self.controller.status = PuppyStatus.STOP #128
                self.get_logger().info("颜色跟踪已停止（由语音唤醒触发）。") #129

    def stop_callback(self, request, response): #131
        self.stop_color_tracking() #132
        response.success = True #133
        response.message = "颜色跟踪已停止" #134
        return response #135

    # 新增唤醒话题回调 #137
    def wakeup_callback(self, msg: Bool): #138
        if msg.data: #139
            self.get_logger().info("检测到语音唤醒，停止颜色跟踪玩法。") #140
            self.stop_color_tracking() #141

def main(args=None): #143
    rclpy.init(args=args) #144
    node = ControlServiceNode() #145
    try: #146
        while rclpy.ok(): #147
            rclpy.spin_once(node, timeout_sec=0.01) #148
            img = node.get_latest_image() #149
            if img is not None: #150
                processed_img = node.controller.process_image(img.copy()) #151
                cv2.imshow('Frame', processed_img) #152
                key = cv2.waitKey(1) #153
                if key == 27: #154
                    break #155
            else: #156
                time.sleep(0.01) #157
    except KeyboardInterrupt: #158
        pass #159
    finally: #160
        cv2.destroyAllWindows() #161
        try: #162
            node.controller.puppy.move_stop(servo_run_time=500) #163
        except Exception as e: #164
            print(f"停止移动异常: {e}") #165
        node.controller.puppy.stop() #166
        rclpy.shutdown() #167

if __name__ == '__main__': #169
    main() #170
