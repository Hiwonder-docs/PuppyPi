#!/usr/bin/env python3 #1
# coding=utf8 #2

import os #4
import rclpy #5
from rclpy.node import Node #6
from puppy_control_msgs.srv import SetRunActionName #7
from puppy_control_msgs.msg import Velocity, Pose, Gait #8
import time #9
import math #10
import subprocess #11
class PuppyControlNode(Node): #12
    def __init__(self): #13
        super().__init__('puppy_control_node') #14
        
        self.pose_publisher = self.create_publisher(Pose, '/puppy_control/pose', 10) #16
        self.gait_publisher = self.create_publisher(Gait, '/puppy_control/gait', 10) #17
        self.velocity_publisher = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #18
        self.run_action_group_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #19
        while not self.run_action_group_srv.wait_for_service(timeout_sec=1.0): #20
            self.get_logger().info('Service /puppy_control/runActionGroup not available, waiting...') #21
    
    def set_run_action(self, action_name): #23
        msg = SetRunActionName.Request() #24
        msg.name = f'{action_name}.d6ac' #25
        msg.wait = True #26
        self.run_action_group_srv.call_async(msg) #27

    def set_move(self, x=0.00, y=0.0, yaw_rate=0.0): #29
        velocity_msg = Velocity(x=x, y=y, yaw_rate=yaw_rate) #30
        self.velocity_publisher.publish(velocity_msg) #31

    def forward(self): #33
        self.set_move(x=5.0) #34
        time.sleep(2) #35
        self.set_move(x=0.0) #36

    def back(self): #38
        self.set_move(x=-5.0) #39
        time.sleep(2) #40
        self.set_move(x=0.0) #41

    def turn_left(self): #43
        self.set_move(x=-5.0, yaw_rate=math.radians(-30)) #44
        time.sleep(2) #45
        self.set_move(x=0.0, yaw_rate=math.radians(0)) #46

    def turn_right(self): #48
        self.set_move(x=-5.0, yaw_rate=math.radians(30)) #49

        time.sleep(2) #51
        self.set_move(x=0.0, yaw_rate=math.radians(0)) #52
        
    # def man(self): #54
    #     subprocess.run(["paplay", "--stream-name=man_audio", "--device=default",  #55
    #                 "/home/ubuntu/ros2_ws/src/large_models/large_models/large_models/resources/audio/man.wav"]) #56

    # def woman(self): #58
    #     subprocess.run(["paplay", "--stream-name=woman_audio", "--device=default",  #59
    #                 "/home/ubuntu/ros2_ws/src/large_models/large_models/large_models/resources/audio/schoolgirl.wav"]) #60
    def man(self): #61
        try: #62
            subprocess.run( #63
                ["paplay", #64
                "/home/ubuntu/ros2_ws/src/large_models/large_models/resources/audio/man.wav"], #65
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True #66
            ) #67
        except subprocess.CalledProcessError as e: #68
            self.get_logger().error(f"Error playing man.wav: {e}") #69

    def woman(self): #71
        try: #72
            subprocess.run( #73
                ["paplay", #74
                "/home/ubuntu/ros2_ws/src/large_models/large_models/resources/audio/schoolgirl.wav"], #75
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True #76
            ) #77
        except subprocess.CalledProcessError as e: #78
            self.get_logger().error(f"Error playing schoolgirl.wav: {e}") #79

    def init(self): #81
        self.set_run_action('stand') #82

    def boxing(self): #84
        self.set_run_action('boxing') #85

    def bow(self): #87
        self.set_run_action('bow') #88

    def push_up(self): #90
        self.set_run_action('push-up01') #91

    def shake_hands(self): #93
        self.set_run_action('shake_hands') #94

    def shake_hand(self): #96
        self.set_run_action('shake_hand') #97

    def lie_down(self): #99
        self.set_run_action('lie_down') #100

    def moonwalk(self): #102
        self.set_run_action('moonwalk') #103

    def kick_ball_left(self): #105
        self.set_run_action('kick_ball_left') #106

    def kick_ball_right(self): #108
        self.set_run_action('kick_ball_right') #109

    def nod(self): #111
        self.set_run_action('nod') #112

    def wave(self): #114
        self.set_run_action('wave') #115

    def temp(self): #117
        self.set_run_action('temp') #118

    def stand(self): #120
        self.set_run_action('stand') #121

    def sit(self): #123
        self.set_run_action('sit') #124
        
    def kick_ball(self, color='red'): #126
        os.system('ros2 run example kick_ball_demo' + ' ' + color) #127
        
    def visual_patrol(self, color='red'): #129
        os.system('ros2 run example visual_patrol_demo' + ' ' + color) #130
       
        
def main(args=None): #133
    rclpy.init(args=args) #134
    puppy_control_node = PuppyControlNode() #135

    try: #137
        rclpy.spin(puppy_control_node) #138
    except KeyboardInterrupt: #139
        puppy_control_node.get_logger().info('Node terminated by user') #140
    finally: #141
        puppy_control_node.destroy_node() #142
        rclpy.shutdown() #143


if __name__ == '__main__': #146
    main() #147
        

   
