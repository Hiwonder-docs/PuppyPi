#!/usr/bin/python3 #1
# coding=utf8 #2

import cv2 #4
import time #5
import math #6
import threading #7
import numpy as np #8

from enum import Enum #10
from sdk.ArmMoveIK import ArmIK #11
from sdk import Misc, yaml_handle #12
from servo_controller import setServoPulse #13
from action_group_control import runActionGroup #14
from puppy_kinematics import HiwonderPuppy, PWMServoParams #15

class PuppyStatus(Enum): #17
    IDLE = 0 #18
    START = 1 #19
    NORMAL = 2 #20
    FOUND_TARGET = 3 #21
    ADJUSTING_YAW = 4 #22
    ADJUSTING_X = 5 #23
    STOP = 10 #24

class PuppyController: #26
    def __init__(self, debug=False): #27
        self.Debug = debug #28

        # 初始化机器人 #30
        self.puppy = HiwonderPuppy(setServoPulse=setServoPulse, servoParams=PWMServoParams(), dof='8') #31

        # 姿态定义 #33
        self.stand_pose = { #34
            'roll': math.radians(0.0), #35
            'pitch': math.radians(0.0), #36
            'yaw': 0.0, #37
            'height': -10.0, #38
            'x_shift': -1.0, #39
            'stance_x': 0.0, #40
            'stance_y': 0.0 #41
        } #42
        self.bend_pose = { #43
            'roll': math.radians(0.0), #44
            'pitch': math.radians(-17.0), #45
            'yaw': 0.0, #46
            'height': -10.0, #47
            'x_shift': 0.5, #48
            'stance_x': 0.0, #49
            'stance_y': 0.0 #50
        } #51
        self.current_pose = self.stand_pose.copy() #52

        # 步态配置 #54
        self.gait_config = { #55
            'overlap_time': 0.15, #56
            'swing_time': 0.15, #57
            'clearance_time': 0.0, #58
            'z_clearance': 3 #59
        } #60

        # 移动指令 #62
        self.puppy_move = {'x': 0, 'y': 0, 'yaw_rate': 0} #63

        self.arm_ik = ArmIK() #65

        self.status = PuppyStatus.IDLE #67
        self.status_last = PuppyStatus.STOP #68

        self.img_centerx = 320 #70
        self.block_color = 'None' #71
        self.block_center_point = (0, 0) #72
        self.radius = 0 #73
        self.size = (640, 480) #74
        self.lab_data = None #75
        self.MIN_RADIUS = 129 #76
        self.MAX_RADIUS = 140 #77

        self.color_tracking_enabled = False #79
        self.target_color = 'None' #80
        self.color_list = [] #81

        self.adjusting_counter_yaw = 0 #83
        self.required_frames_yaw = 3 #84

        # 夹取范围参数 #86
        self.clamp_y_lower = 380 #87
        self.clamp_y_upper = 390 #88
        self.clamp_x_error_thresh = 50 #89

        self.status_lock = threading.Lock() #91

        self.load_config() #93
        self.initialize_puppy() #94

        self.puppy.start() #96
        self.puppy.move_stop(servo_run_time=500) #97
        self.arm_ik.setPitchRangeMoving((8.51, 0, 3.3), 500) #98
        setServoPulse(9, 1500, 500) #99
        time.sleep(0.5) #100

        if self.Debug: #102
            self.current_pose = self.bend_pose.copy() #103
            self.puppy.stance_config( #104
                self.stance(self.current_pose['stance_x'], self.current_pose['stance_y'],  #105
                            self.current_pose['height'], self.current_pose['x_shift']), #106
                self.current_pose['pitch'], self.current_pose['roll'] #107
            ) #108
            time.sleep(0.5) #109
        else: #110
            self.move_thread = threading.Thread(target=self.move) #111
            self.move_thread.daemon = True #112
            self.move_thread.start() #113

    def load_config(self): #115
        """加载配置文件颜色范围""" #116
        self.lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path)['color_range_list'] #117

    def stance(self, x=0.0, y=0.0, z=-11.0, x_shift=2.0): #119
        """计算姿态xyz坐标数组""" #120
        return np.array([ #121
            [x + x_shift, x + x_shift, -x + x_shift, -x + x_shift], #122
            [y, y, y, y], #123
            [z, z, z, z], #124
        ]) #125

    def initialize_puppy(self): #127
        """初始化机器人姿态和步态""" #128
        self.puppy.stance_config( #129
            self.stance(self.current_pose['stance_x'], self.current_pose['stance_y'],  #130
                        self.current_pose['height'], self.current_pose['x_shift']), #131
            self.current_pose['pitch'], self.current_pose['roll'] #132
        ) #133
        self.puppy.gait_config(**self.gait_config) #134

    def get_area_max_contour(self, contours): #136
        """获取最大轮廓""" #137
        contour_area_max = 0 #138
        area_max_contour = None #139
        for c in contours: #140
            contour_area = abs(cv2.contourArea(c)) #141
            if contour_area > contour_area_max and contour_area >= 5: #142
                contour_area_max = contour_area #143
                area_max_contour = c #144
        return area_max_contour, contour_area_max #145

    def is_within_clamp_range(self, y, x_error): #147
        y_close = self.clamp_y_lower < y <= self.clamp_y_upper #148
        x_close = abs(x_error) < self.clamp_x_error_thresh #149
        print(f"[夹取范围判断] y_close={y_close}, x_close={x_close}") #150
        return y_close and x_close #151

    def is_within_range(self): #153
        y = self.block_center_point[1] #154
        x_error = self.block_center_point[0] - self.img_centerx #155
        y_in_range = self.clamp_y_lower < y < self.clamp_y_upper #156
        x_in_range = abs(x_error) < self.clamp_x_error_thresh #157
        color_correct = (self.block_color == self.target_color) #158
        if self.Debug: #159
            print(f"[目标范围判断] y_in_range={y_in_range}, x_in_range={x_in_range}, color_correct={color_correct}") #160
        return y_in_range and x_in_range and color_correct #161

    def process_image(self, img): #163
        if not self.color_tracking_enabled: #164
            return img #165

        img_copy = img.copy() #167
        img_h, img_w = img.shape[:2] #168

        frame_resize = cv2.resize(img_copy, self.size, interpolation=cv2.INTER_NEAREST) #170
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #171
        frame_lab_all = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #172

        if self.target_color not in self.lab_data: #174
            if self.Debug: #175
                print(f"[错误] 目标颜色 {self.target_color} 不在配置文件中！") #176
            return img #177

        color_range = self.lab_data[self.target_color] #179
        frame_mask = cv2.inRange( #180
            frame_lab_all, #181
            tuple(color_range['min']), #182
            tuple(color_range['max']) #183
        ) #184
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)) #185
        eroded = cv2.erode(frame_mask, kernel) #186
        dilated = cv2.dilate(eroded, kernel) #187

        contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2] #189
        area_max_contour, area_max = self.get_area_max_contour(contours) #190

        if area_max_contour is not None and area_max >= 5: #192
            ((centerX, centerY), radius_temp) = cv2.minEnclosingCircle(area_max_contour) #193
            centerX = int(Misc.map(centerX, 0, self.size[0], 0, img_w)) #194
            centerY = int(Misc.map(centerY, 0, self.size[1], 0, img_h)) #195
            radius = int(Misc.map(radius_temp, 0, self.size[0], 0, img_w)) #196
            self.block_center_point = (centerX, centerY) #197
            self.radius = radius #198
            # 画检测圆 #199
            cv2.circle(img, self.block_center_point, self.radius, (0, 255, 255), 2) #200

            color = 1 if self.MIN_RADIUS <= self.radius <= self.MAX_RADIUS else 0 #202
            self.color_list.append(color) #203
            if len(self.color_list) == 3: #204
                color_avg = int(round(np.mean(np.array(self.color_list)))) #205
                self.color_list = [] #206
                self.block_color = self.target_color if color_avg == 1 else 'None' #207

            # 方向微调计数逻辑 #209
            y = self.block_center_point[1] #210
            x_error = self.block_center_point[0] - self.img_centerx #211
            if (self.clamp_y_lower < y < self.clamp_y_upper) and (abs(x_error) < self.clamp_x_error_thresh): #212
                self.adjusting_counter_yaw += 1 #213
                if self.Debug: #214
                    print(f"[方向微调计数] 当前计数：{self.adjusting_counter_yaw}/{self.required_frames_yaw}") #215
                if self.adjusting_counter_yaw >= self.required_frames_yaw: #216
                    self.status = PuppyStatus.ADJUSTING_YAW #217
                    self.adjusting_counter_yaw = 0 #218
            else: #219
                if self.adjusting_counter_yaw > 0 and self.Debug: #220
                    print(f"[方向微调计数] 计数中断，重置") #221
                self.adjusting_counter_yaw = 0 #222

        else: #224
            self.block_color = 'None' #225
            self.radius = 0 #226
            if self.adjusting_counter_yaw > 0 and self.Debug: #227
                print(f"[方向微调计数] 目标丢失，计数清零") #228
            self.adjusting_counter_yaw = 0 #229

        # 绘制夹取范围区域矩形框（蓝色） #231
        cv2.rectangle(img, #232
                      (0, self.clamp_y_lower), #233
                      (img_w, self.clamp_y_upper), #234
                      (255, 0, 0), 2) #235

        # 绘制检测到目标的中心点（绿色小点） #237
        if self.block_center_point != (0, 0): #238
            cv2.circle(img, self.block_center_point, 5, (0, 255, 0), -1) #239

        # 画图像中心线（黄线） #241
        cv2.line(img, (self.img_centerx, 0), (self.img_centerx, img_h), (0, 255, 255), 2) #242

        # 根据状态绘制箭头（红色和绿色箭头） #244

        # 方向微调时，画箭头显示转向方向 #246
        if self.status == PuppyStatus.ADJUSTING_YAW: #247
            if self.puppy_move['yaw_rate'] > 0: #248
                cv2.arrowedLine(img, #249
                                (self.img_centerx, self.block_center_point[1]), #250
                                (self.img_centerx + 30, self.block_center_point[1]), #251
                                (0, 0, 255), 2) #252
            elif self.puppy_move['yaw_rate'] < 0: #253
                cv2.arrowedLine(img, #254
                                (self.img_centerx, self.block_center_point[1]), #255
                                (self.img_centerx - 30, self.block_center_point[1]), #256
                                (0, 0, 255), 2) #257

        # 位置微调时，画箭头显示前后移动方向 #259
        if self.status == PuppyStatus.ADJUSTING_X: #260
            if self.puppy_move['x'] > 0: #261
                cv2.arrowedLine(img, #262
                                (self.block_center_point[0], self.block_center_point[1]), #263
                                (self.block_center_point[0], self.block_center_point[1] - 30), #264
                                (0, 255, 0), 2) #265
            elif self.puppy_move['x'] < 0: #266
                cv2.arrowedLine(img, #267
                                (self.block_center_point[0], self.block_center_point[1]), #268
                                (self.block_center_point[0], self.block_center_point[1] + 30), #269
                                (0, 255, 0), 2) #270

        return img #272


    def move(self): #275
        """移动控制线程，控制机器人根据状态行为""" #276
        while True: #277
            try: #278
                if self.status == PuppyStatus.START: #279
                    self.puppy.move_stop(servo_run_time=500) #280
                    self.current_pose = self.bend_pose.copy() #281
                    self.puppy.stance_config( #282
                        self.stance(self.current_pose['stance_x'], self.current_pose['stance_y'], self.current_pose['height'], self.current_pose['x_shift']), #283
                        self.current_pose['pitch'], self.current_pose['roll']) #284
                    time.sleep(0.5) #285
                    self.status = PuppyStatus.NORMAL #286

                elif self.status == PuppyStatus.NORMAL: #288
                    if self.color_tracking_enabled: #289
                        value = self.block_center_point[0] - self.img_centerx #290
                        y = self.block_center_point[1] #291

                        if self.is_within_clamp_range(y, value): #293
                            self.status = PuppyStatus.FOUND_TARGET #294
                            self.puppy.move_stop(servo_run_time=500) #295
                        else: #296
                            move_x = 0.0 #297
                            yaw_rate = 0.0 #298
                            if y < self.clamp_y_lower: #299
                                move_x = 8.0 #300
                            if abs(value) > 80: #301
                                yaw_rate = math.radians(-8.0 * np.sign(value)) #302
                            elif abs(value) > 50.0: #303
                                yaw_rate = math.radians(-5.0 * np.sign(value)) #304

                            self.puppy_move['x'] = move_x #306
                            self.puppy_move['yaw_rate'] = yaw_rate #307

                            self.puppy.move(x=move_x, y=0, yaw_rate=yaw_rate) #309

                            if self.is_within_range(): #311
                                self.status = PuppyStatus.FOUND_TARGET #312
                                self.puppy.move_stop(servo_run_time=500) #313
                            else: #314
                                if self.clamp_y_lower < y < self.clamp_y_upper and abs(value) < self.clamp_x_error_thresh: #315
                                    self.adjusting_counter_yaw += 1 #316
                                    if self.adjusting_counter_yaw >= self.required_frames_yaw: #317
                                        self.status = PuppyStatus.ADJUSTING_YAW #318
                                        self.adjusting_counter_yaw = 0 #319
                    else: #320
                        self.puppy.move_stop(servo_run_time=100) #321
                    time.sleep(0.02) #322

                elif self.status == PuppyStatus.ADJUSTING_YAW: #324
                    error_x = self.block_center_point[0] - self.img_centerx #325
                    yaw_rate = 0.0 #326
                    if error_x < -10: #327
                        yaw_rate = math.radians(5.0) #328
                    elif error_x > 10: #329
                        yaw_rate = math.radians(-5.0) #330
                    if yaw_rate != 0.0: #331
                        self.puppy.move(x=0, y=0, yaw_rate=yaw_rate) #332
                    time.sleep(0.6) #333
                    self.puppy.move_stop(servo_run_time=510) #334
                    time.sleep(0.6) #335

                    if abs(error_x) <= 10: #337
                        y = self.block_center_point[1] #338
                        if self.clamp_y_lower < y < self.clamp_y_upper: #339
                            self.status = PuppyStatus.ADJUSTING_X #340
                        else: #341
                            self.status = PuppyStatus.NORMAL #342

                elif self.status == PuppyStatus.ADJUSTING_X: #344
                    error_y = self.block_center_point[1] - ((self.clamp_y_lower + self.clamp_y_upper) / 2) #345
                    move_x = 0.0 #346
                    if error_y < -10: #347
                        move_x = 5.0 #348
                    elif error_y > 10: #349
                        move_x = -5.0 #350
                    if self.clamp_y_lower < self.block_center_point[1] < self.clamp_y_upper: #351
                        if move_x != 0.0: #352
                            self.puppy.move(x=move_x, y=0, yaw_rate=0) #353
                        time.sleep(0.6) #354
                        self.puppy.move_stop(servo_run_time=510) #355
                        time.sleep(0.51) #356
                        if abs(error_y) <= 10: #357
                            self.status = PuppyStatus.FOUND_TARGET #358
                        else: #359
                            # 继续调整 #360
                            pass #361
                    else: #362
                        self.status = PuppyStatus.NORMAL #363

                elif self.status == PuppyStatus.FOUND_TARGET: #365
                    # 夹取动作 #366
                    runActionGroup('Clamping.d6a', True) #367
                    self.current_pose = self.stand_pose.copy() #368
                    self.puppy.stance_config( #369
                        self.stance(self.current_pose['stance_x'], self.current_pose['stance_y'], self.current_pose['height'], self.current_pose['x_shift'] + 1), #370
                        self.current_pose['pitch'], self.current_pose['roll'] #371
                    ) #372
                    time.sleep(0.5) #373
                    runActionGroup('place1.d6a', True) #374
                    time.sleep(1) #375
                    runActionGroup('look_down.d6a', True) #376
                    time.sleep(1) #377
                    with self.status_lock: #378
                        self.status = PuppyStatus.STOP #379
                        self.color_tracking_enabled = False #380
                    time.sleep(0.5) #381

                elif self.status == PuppyStatus.STOP: #383
                    self.puppy.move_stop(servo_run_time=500) #384
                    self.current_pose = self.stand_pose.copy() #385
                    self.puppy.stance_config( #386
                        self.stance(self.current_pose['stance_x'], self.current_pose['stance_y'], self.current_pose['height'], self.current_pose['x_shift']), #387
                        self.current_pose['pitch'], self.current_pose['roll'] #388
                    ) #389
                    time.sleep(0.1) #390

                with self.status_lock: #392
                    if self.status_last != self.status and self.Debug: #393
                        print(f"[状态变更] {self.status_last} => {self.status}") #394
                        self.status_last = self.status #395

                time.sleep(0.02) #397

            except Exception as e: #399
                if self.Debug: #400
                    print(f"[异常] 控制线程异常: {e}") #401
                with self.status_lock: #402
                    self.status = PuppyStatus.NORMAL #403

if __name__ == '__main__': #405
    print("请作为模块导入使用，不建议直接运行") #406
