#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/11/18 #4
import cv2 #5
import sys #6
import os #7
import math #8
import json #9
import queue #10
import rclpy #11
import time #12
from std_msgs.msg import String, Bool #13
import threading #14
from config import * #15
import numpy as np #16
import sdk.fps as fps #17
from sdk import common #18
from action import PuppyControlNode #19
from rclpy.node import Node #20
from sensor_msgs.msg import Image #21
from std_srvs.srv import SetBool, Trigger, Empty #22
from rclpy.executors import MultiThreadedExecutor #23
from rclpy.callback_groups import ReentrantCallbackGroup #24
from cv_bridge import CvBridge #25
from speech import speech #26
from large_models.config import * #27
from large_models_msgs.srv import SetModel, SetString, SetInt32 #28
from puppy_control_msgs.srv import SetRunActionName #29

sys.path.append('/home/ubuntu/software/puppypi_control/')  #31
from servo_controller import setServoPulse #32
from action_group_control import runActionGroup, stopActionGroup #33
speech.set_volume(80) #34
VLLM_PROMPT = ''' #35
''' #36

class VLLMWithCamera(Node): #38
    def __init__(self, name): #39
        rclpy.init() #40
        super().__init__(name) #41
        self.image_queue = queue.Queue(maxsize=2) #42
        self.vllm_result = '' #43
        self.running = True #44
        self.action_finish = False #45
        self.play_audio_finish = False #46
        self.bridge = CvBridge() #47
        self.client = speech.OpenAIAPI(api_key, base_url) #48
        self.puppy_control_node = PuppyControlNode() #49
        
        self.declare_parameter('camera_topic', 'image_raw') #51
        camera_topic = self.get_parameter('camera_topic').value #52
        timer_cb_group = ReentrantCallbackGroup() #53

        self.tts_text_pub = self.create_publisher(String, 'tts_node/tts_text', 1) #55
        self.create_subscription(Image, camera_topic, self.image_callback, 1) #56
        self.create_subscription(String, 'agent_process/result', self.vllm_result_callback, 10) #57
        self.create_subscription(Bool, 'tts_node/play_finish', self.play_audio_finish_callback, 1, callback_group=timer_cb_group) #58
        self.awake_client = self.create_client(SetBool, 'vocal_detect/enable_wakeup') #59
        self.awake_client.wait_for_service() #60
        self.set_model_client = self.create_client(SetModel, 'agent_process/set_model') #61
        self.set_model_client.wait_for_service() #62
        self.set_mode_client = self.create_client(SetInt32, 'vocal_detect/set_mode') #63
        self.set_mode_client.wait_for_service() #64
        self.set_prompt_client = self.create_client(SetString, 'agent_process/set_prompt') #65
        self.set_prompt_client.wait_for_service() #66
        self.cli = self.create_client(Empty,'/puppy_control/go_home') #67
        self.cli.call_async(Empty.Request()) #68
        self.timer = self.create_timer(0.1, self.init_process, callback_group=timer_cb_group) #69

    def get_node_state(self, request, response): #71
        return response #72


    def init_process(self): #75
        self.timer.cancel() #76
        
        msg = SetModel.Request() #78
        msg.model = vllm_model #79
        msg.model_type = 'vllm' #80
        if os.environ['ASR_LANGUAGE'] == 'Chinese': #81
            msg.model = stepfun_vllm_model #82
            msg.api_key = stepfun_api_key #83
            msg.base_url = stepfun_base_url #84
        else: #85
            msg.model = vllm_model #86
            msg.api_key = vllm_api_key #87
            msg.base_url = vllm_base_url #88
        self.send_request(self.set_model_client, msg) #89
        msg = SetString.Request() #90
        msg.data = VLLM_PROMPT #91
        self.send_request(self.set_prompt_client, msg) #92
        speech.play_audio(start_audio_path) #93
        threading.Thread(target=self.process, daemon=True).start() #94
        self.create_service(Empty, '~/init_finish', self.get_node_state) #95
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start') #96

    def send_request(self, client, msg): #98
        future = client.call_async(msg) #99
        while rclpy.ok(): #100
            if future.done() and future.result(): #101
                return future.result() #102

    def vllm_result_callback(self, msg): #104
        self.vllm_result = msg.data #105
    
    def play_audio_finish_callback(self, msg): #107
        self.play_audio_finish = msg.data #108
        
    def process(self): #110
        while self.running: #111
            image = self.image_queue.get(block=True) #112
            if self.vllm_result != '': #113
                msg = String() #114
                msg.data = self.vllm_result #115
                self.tts_text_pub.publish(msg) #116
                self.vllm_result = '' #117
                self.action_finish = True #118
            if self.play_audio_finish and self.action_finish: #119
                self.play_audio_finish = False #120
                self.action_finish = False #121
                msg = SetBool.Request() #122
                msg.data = True #123
                self.send_request(self.awake_client, msg) #124
            cv2.imshow('image', cv2.cvtColor(image, cv2.COLOR_RGB2BGR)) #125
            cv2.waitKey(1) #126
        cv2.destroyAllWindows() #127


    def image_callback(self, ros_image): #130
        try: #131
            # 使用 cv_bridge 将 ROS Image 转换为 OpenCV 图像 #132
            rgb_image = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='rgb8') #133

            if self.image_queue.full(): #135
                # 如果队列已满，丢弃最旧的图像 #136
                self.image_queue.get() #137

            # 将图像放入队列 #139
            self.image_queue.put(rgb_image) #140
        except Exception as e: #141
            self.get_logger().error(f"Error processing image: {e}") #142

def main(): #144
    node = VLLMWithCamera('vllm_with_camera') #145
    executor = MultiThreadedExecutor() #146
    executor.add_node(node) #147
    executor.spin() #148
    node.destroy_node() #149

if __name__ == "__main__": #151
    main() #152
