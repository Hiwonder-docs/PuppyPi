#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: liang #3
# @Date: 2024/12/03 #4

import re #6
import json #7
import time #8
import smbus #9
import rclpy #10
from rclpy.node import Node #11
from std_msgs.msg import String, Bool #12
from puppy_control_msgs.srv import SetRunActionName #13
from std_srvs.srv import SetBool, Trigger, Empty #14
from large_models_msgs.srv import * #15
from speech import speech #16
from config import * #17
speech.set_volume(80) #18
language = os.environ.get("ASR_LANGUAGE", "Chinese") #19

if language == 'Chinese': #21
    PROMPT = ''' #22
# 角色 #23
你是一款智能陪伴四足机器狗，专注机器人动作规划，解析人类指令并以幽默方式描述即将展开的行动序列，为交互增添无限趣味。 #24
## 技能 #25
### 指令解析与创意演绎 #26
- **智能解码**：瞬间领悟用户指令的核心意图。 #27
- **灵动编排**：依据解析成果，精心构建一系列连贯且富有逻辑性的动作指令序列。 #28
- **妙语生花**：为每个动作序列编织一句精炼（5至20字）、风趣且变化无穷的反馈信息，让交流过程妙趣横生。 #29
## 技能细则 #30
- **动作指令构造**：确保动作指令既准确反映用户需求，又能在执行层面保持流畅自然。 #31
- **反馈艺术**：创作的回应需富含个性，同时严格遵守长度限制，展现独特的互动魅力。 #32
## 技术规格 #33
- **输出格式**：严格遵循JSON格式，在输出前要去掉开头的```json和结尾的```，以{开头，以}结尾，你只需要回答一个列表即可，不要回答任何中文。 #34
- **结构要求**： #35
  - "type"键下承载一个字符串，要根据语义判断是动作还是检测。 #36
  - "action"键下承载一个按执行顺序排列的函数名称字符串数组，当找不到对应动作函数时action输出[]。 #37
  - "response"键则配以精心构思的简短回复，完美贴合上述字数与风格要求。 #38
  - "object"键键下承载detect和ocr，当语义不是action时object输出‘’。 #39
  - "position"键下承载detect和ocr，当语义不是action时position输出[]。 #40
- **特殊处理**：对于特定函数kick_ball与visual_patrol，其参数需精确包裹于双引号中。 #41
## 实施原则 #42
- 在最终输出前，实施全面校验，确保回复不仅格式合规，而且内容充满意趣，无一遗漏上述规范。 #43

## type的类型,只能是 "action"、"ocr" 或 "detect"。其他类型无效。 #45
- 当回答获取城市天气怎么样，需要联网进行获取温度天气，然后把获取的天气温湿度结果填入response里并且带入相关提示，action为空，object也为空。但是是获取室内温度的时候是object是有temperature的，回答是当前室内温度多少需要表达多少度并且带在该温度下的温馨提示。 #46
- action #47
- detect #48
- ocr #49
## 所有动作函数的优化描述示例（所有的动作只是这些没有其他的了，其他的都不算） #50
* 站立：stand() #51
- 获取室内温度：get_temperature() #52
*男生叫一声：man() #53
*女生叫一声：woman() #54
-你看到了什么？ image_understanding("图像识别") #55
## 示例 #56
### 任务示例：当前深圳市的天气温度怎么样。（回答是当前深圳市温度多少并且带温馨提示） #57
### 期望回应：{‘type’:'ocr','action':[], 'response':'现在深圳市的温度是24度','object':'','position':''} #58
### 任务示例：当前室内温度多少。（获取当前温度查询，并且播放当前多度，及降温提醒穿衣等温馨提示 #59
### 期望回应：{‘type’:'ocr','action':[‘get_temperature()’], 'response':'','object':temperature'','position':''} #60
''' #61
else: #62
    PROMPT = ''' #63
The type of "type" can only be "action", "ocr", or "detect". Other types are invalid. #64
- When answering questions about the weather in a city, an internet connection is required to obtain the temperature and weather conditions. The obtained results of temperature and humidity should be filled in the response along with relevant prompts. "action" is empty and "object" is also empty. However, when obtaining the indoor temperature, "object" has "temperature". When answering how much the current indoor temperature is, it is necessary to express the temperature in degrees and include a warm reminder at that temperature. - action #65
- detect #66
- ocr #67
## Examples of Optimization Descriptions for All Action Functions (These are all the actions, no others) #68
* Stand: stand() #69
- Get indoor temperature: get_temperature() #70
* A boy shouts: man() #71
* A girl shouts: woman() #72
- What do you see? image_understanding("Image recognition") #73
## Examples #74
### Task Example: What is the current temperature in Shenzhen? (The response should include the current indoor temperature and a warm reminder) #75
### Expected Response: {'type': 'ocr', 'action': [], 'response': 'The current temperature in Shenzhen is 24 degrees', 'object': '', 'position': ''} #76
### Task Example: What is the current indoor temperature? (Query the current temperature and provide a warm reminder such as dressing appropriately when it's cold) #77
### Expected Response: {'type': 'ocr', 'action': ['get_temperature()'], 'response': '', 'object': 'temperature', 'position': ''} #78
''' #79
class AHT10: #80
    CONFIG = [0x08, 0x00] #81
    MEASURE = [0x33, 0x00] #82

    def __init__(self, bus=1, addr=0x38): #84
        try: #85
            self.bus = smbus.SMBus(bus) #86
            self.addr = addr #87
            time.sleep(0.2) #88
        except Exception as e: #89
            print(f"AHT10初始化失败: {e}") #90

    def getData(self): #92
        try: #93
            self.bus.write_i2c_block_data(self.addr, 0xAC, self.MEASURE) #94
            time.sleep(0.5) #95
            data = self.bus.read_i2c_block_data(self.addr, 0x00) #96
            temp = ((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5] #97
            ctemp = ((temp * 200) / 1048576) - 50 #98
            return ctemp #99
        except Exception as e: #100
            print(f"读取温度失败: {e}") #101
            return None #102

class LLMTemperature(Node): #104
    def __init__(self): #105
        super().__init__('llm_temperature') #106
        self.aht10 = AHT10() #107
        self.processing = False #108
        self.asr_result = '' #109

        self.tts_text_pub = self.create_publisher(String, 'tts_node/tts_text', 10) #111
        self.play_finish_sub = self.create_subscription(Bool, '/tts_node/play_finish', self.play_audio_finish_callback, 10) #112
        self.agent_result_sub = self.create_subscription(String, 'agent_process/result', self.llm_result_callback, 10) #113
        self.asr_result_sub = self.create_subscription(String, 'vocal_detect/asr_result', self.asr_result_callback, 10) #114

        self.go_home_cli = self.create_client(Empty, '/puppy_control/go_home') #116
        self.awake_client = self.create_client(SetBool, 'vocal_detect/enable_wakeup') #117
        self.set_model_client = self.create_client(SetModel, 'agent_process/set_model') #118
        self.set_prompt_client = self.create_client(SetString, 'agent_process/set_prompt') #119

        self.wait_for_service(self.go_home_cli, '/puppy_control/go_home') #121
        self.wait_for_service(self.awake_client, 'vocal_detect/enable_wakeup') #122
        self.wait_for_service(self.set_model_client, 'agent_process/set_model') #123
        self.wait_for_service(self.set_prompt_client, 'agent_process/set_prompt') #124

        self.init_process() #126

    def wait_for_service(self, client, service_name): #128
        while not client.wait_for_service(timeout_sec=1.0): #129
            self.get_logger().warn(f'等待服务{service_name}可用...') #130

    def init_process(self): #132
        try: #133
            req_model = SetModel.Request() #134
            req_model.model = llm_model #135
            req_model.model_type = 'llm' #136
            req_model.api_key = api_key #137
            req_model.base_url = base_url #138
            future_model = self.set_model_client.call_async(req_model) #139
            rclpy.spin_until_future_complete(self, future_model) #140

            req_prompt = SetString.Request() #142
            req_prompt.data = PROMPT #143
            future_prompt = self.set_prompt_client.call_async(req_prompt) #144
            rclpy.spin_until_future_complete(self, future_prompt) #145

            # 播放 #147
            speech.play_audio(start_audio_path) #148

            req_go_home = Empty.Request() #150
            future_go_home = self.go_home_cli.call_async(req_go_home) #151
            rclpy.spin_until_future_complete(self, future_go_home) #152
        except Exception as e: #153
            self.get_logger().error(f"初始化过程失败: {e}") #154

    def asr_result_callback(self, msg: String): #156
        self.asr_result = msg.data #157

    def play_audio_finish_callback(self, msg: Bool): #159
        if msg.data: #160
            req = SetBool.Request() #161
            req.data = True #162
            self.awake_client.call_async(req) #163

    def get_temperature(self): #165
        return self.aht10.getData() #166
    
    def llm_result_callback(self, msg: String): #168
        """ #169
        处理从 'agent_process/result' 主题接收到的智能代理返回结果。 #170
        逻辑包括： #171
        - 解析JSON结构。 #172
        - 如果动作列表中包含get_temperature()且object为'temperature'， #173
        则读取传感器温度，通过LLM生成温馨提示后播报。 #174
        - 否则将ASR结果发送给远程LLM接口（带联网搜索），获得回复后播报。 #175
        """ #176
        if self.processing: #177
            self.get_logger().warn("当前正在处理消息，忽略新消息") #178
            return #179

        self.processing = True #181
        self.get_logger().info(f"接收到代理返回数据: {msg.data}") #182

        data = self.clean_json_message(msg.data) #184
        if not data: #185
            self.get_logger().warn("解析json失败，跳过处理") #186
            self.processing = False #187
            return #188

        action_list = data.get('action', []) #190
        response = data.get('response', '') #191
        obj = data.get('object', '') #192

        try: #194
            if "get_temperature()" in action_list and obj == 'temperature': #195
                temperature = self.get_temperature() #196
                language = os.environ.get("ASR_LANGUAGE", "Chinese")  # 获取语言环境 #197
                if temperature is not None: #198
                    if language == 'Chinese': #199
                        prompt_text = f"当前室内温度{temperature:.2f}度，请简单给我点提醒，并且播放当前温度。" #200
                    else: #201
                        prompt_text = f"The current indoor {temperature:.2f} temperature. Please give me a brief reminder and play the current temperature." #202
                    
                    self.client = speech.OpenAIAPI(api_key, base_url) #204
                    reply = self.client.llm(prompt_text, model=llm_model) #205
                    self.publish_tts(reply) #206
                else: #207
                    if language == 'Chinese': #208
                        self.publish_tts("温度读取失败，请稍后再试！") #209
                    else: #210
                        self.publish_tts("Failed to read temperature, please try again later!") #211
            else: #212
                if os.environ.get('ASR_LANGUAGE', 'Chinese') == 'Chinese': #213
                    params = { #214
                        "model": llm_model, #215
                        "messages": [ #216
                            {"role": "system", "content": PROMPT}, #217
                            {"role": "user", "content": self.asr_result} #218
                        ], #219
                        "extra_body": { #220
                            "enable_search": True #221
                        } #222
                    } #223
                else: #224
                    params = { #225
                        "model": 'gpt-4o-search-preview', #226
                        "web_search_options": {}, #227
                        "messages": [ #228
                            {"role": "system", "content": PROMPT}, #229
                            {"role": "user", "content": self.asr_result} #230
                        ] #231
                    } #232
                self.client = speech.OpenAIAPI(api_key, base_url) #233
                res = self.client.llm_origin(params) #234

                raw_text = res.choices[0].message.content.strip() #236
                json_start = raw_text.find('{') #237
                json_end = raw_text.rfind('}') + 1 #238
                if json_start != -1 and json_end > json_start: #239
                    json_str = raw_text[json_start:json_end] #240
                    res_json = json.loads(json_str) #241
                    reply = res_json.get('response', response) #242
                else: #243
                    reply = response or raw_text #244

                self.publish_tts(reply) #246

        except Exception as e: #248
            self.get_logger().error(f"处理LLM结果异常: {e}") #249
            # 出错时尝试播放已有response内容 #250
            self.publish_tts(response or ("抱歉，处理请求时出错。" if os.environ.get("ASR_LANGUAGE", "Chinese") == 'Chinese' else "Sorry, an error occurred while processing the request.")) #251

        self.processing = False #253


    def clean_json_message(self, message: str): #256
        try: #257
            # 找到json的起止位置 #258
            start = message.find('{') #259
            end = message.rfind('}') + 1 #260
            if start == -1 or end <= start: #261
                return None #262
            json_str = message[start:end] #263

            # 替换单引号为双引号（仅限简单场景） #265
            json_str_fix = json_str.replace("'", '"') #266

            return json.loads(json_str_fix) #268
        except Exception as e: #269
            self.get_logger().error(f"Json解析错误: {e}") #270
            return None #271


    def publish_tts(self, text: str): #274
        if text: #275
            msg = String() #276
            msg.data = text #277
            self.tts_text_pub.publish(msg) #278
            self.get_logger().info(f"播报内容: {text}") #279

def main(args=None): #281
    rclpy.init(args=args) #282
    node = LLMTemperature() #283
    try: #284
        rclpy.spin(node) #285
    except KeyboardInterrupt: #286
        pass #287
    finally: #288
        node.destroy_node() #289
        rclpy.shutdown() #290

if __name__ == '__main__': #292
    main() #293
