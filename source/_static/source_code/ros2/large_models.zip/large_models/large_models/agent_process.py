#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/11/18 #4
import queue #5
import rclpy #6
import numpy as np #7
from rclpy.node import Node #8
from cv_bridge import CvBridge #9
from std_msgs.msg import String #10
from sensor_msgs.msg import Image #11
from std_srvs.srv import Trigger, SetBool, Empty #12

from speech import speech #14
from large_models.config import * #15
from large_models_msgs.srv import SetString, SetModel, SetContent #16

class AgentProcess(Node): #18
    def __init__(self, name): #19
        rclpy.init() #20
        super().__init__(name) #21
        
        self.declare_parameter('camera_topic', 'depth_cam/rgb/image_raw') #23
        camera_topic = self.get_parameter('camera_topic').value #24

        self.prompt = '' #26
        self.model = llm_model  #27
        self.chat_text = '' #28
        self.model_type = 'llm' #29
        self.start_record_chat = False #30
        self.bridge = CvBridge() #31
        self.image_queue = queue.Queue(maxsize=2) #32
        self.client = speech.OpenAIAPI(api_key, base_url) #33
        
        self.result_pub = self.create_publisher(String, '~/result', 1) #35
        self.create_subscription(String, 'vocal_detect/asr_result', self.asr_callback, 1) #36
        self.create_subscription(Image, camera_topic, self.image_callback, 1)  # 摄像头订阅(subscribe to the camera) #37
        self.create_service(SetModel, '~/set_model', self.set_model_srv) #38
        self.create_service(SetString, '~/set_prompt', self.set_prompt_srv) #39
        self.create_service(SetContent, '~/set_llm_content', self.set_llm_content_srv) #40
        self.create_service(SetContent, '~/set_vllm_content', self.set_vllm_content_srv) #41

        self.create_service(SetBool, '~/record_chat', self.record_chat) #43
        self.create_service(Trigger, '~/get_chat', self.get_chat) #44
        self.create_service(Empty, '~/clear_chat', self.clear_chat) #45

        self.create_service(Empty, '~/init_finish', self.get_node_state) #47
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start') #48

    def get_node_state(self, request, response): #50
        return response #51

    def record_chat(self, request, response): #53
        self.get_logger().info('\033[1;32m%s\033[0m' % 'record chat') #54
        self.start_record_chat = request.data #55
        response.success = True #56
        return response #57

    def get_chat(self, request, response): #59
        self.get_logger().info('\033[1;32m%s\033[0m' % 'get chat') #60
        response.message = self.chat_text.rstrip(",") #61
        response.success = True #62
        return response #63

    def clear_chat(self, request, response): #65
        self.get_logger().info('\033[1;32m%s\033[0m' % 'clear chat') #66
        self.chat_text = '' #67
        self.record_chat = False #68
        return response #69

    def asr_callback(self, msg): #71
        # self.get_logger().info(msg.data) #72
        # 将识别结果传给智能体让他来回答 #73
        if msg.data != '': #74
            self.get_logger().info('\033[1;32m%s\033[0m' % 'thinking...') #75
            if self.start_record_chat: #76
                self.chat_text += msg.data + ',' #77
                self.get_logger().info('\033[1;32m%s\033[0m' % 'record chat:' + self.chat_text) #78
            res = '' #79
            if self.model_type == 'llm': #80
                res = self.client.llm(msg.data, self.prompt, model=self.model) #81
                self.get_logger().info('\033[1;32m%s\033[0m' % 'publish llm result:' + str(res)) #82
            elif self.model_type == 'vllm': #83
                image = self.image_queue.get(block=True) #84
                res = self.client.vllm(msg.data, image, prompt=self.prompt, model=self.model) #85
                self.get_logger().info('\033[1;32m%s\033[0m' % 'publish vllm result:' + str(res)) #86
            msg = String() #87
            msg.data = res #88
            self.result_pub.publish(msg) #89
        else: #90
            self.get_logger().info('\033[1;32m%s\033[0m' % 'asr result none') #91

    def image_callback(self, ros_image): #93
        cv_image = self.bridge.imgmsg_to_cv2(ros_image, "bgr8") #94
        bgr_image = np.array(cv_image, dtype=np.uint8) #95
        if self.image_queue.full(): #96
            # 如果队列已满，丢弃最旧的图像(if the queue is full, discard the oldest image) #97
            self.image_queue.get() #98
        # 将图像放入队列(put the image into the queue) #99
        self.image_queue.put(bgr_image) #100

    def set_model_srv(self, request, response): #102
        # 设置调用哪个模型 #103
        self.get_logger().info('\033[1;32m%s\033[0m' % 'set model') #104
        self.model = request.model #105
        self.model_type = request.model_type #106
        self.client = speech.OpenAIAPI(request.api_key, request.base_url) #107
        response.success = True #108
        return response #109

    def set_prompt_srv(self, request, response): #111
        # 设置大模型的prompt #112
        self.get_logger().info('\033[1;32m%s\033[0m' % 'set prompt') #113
        self.prompt = request.data #114
        response.success = True #115
        return response #116

    def set_llm_content_srv(self, request, response): #118
        # 输入文本传给智能体让他来回答 #119
        self.get_logger().info('\033[1;32m%s\033[0m' % 'thinking...') #120
        client = speech.OpenAIAPI(request.api_key, request.base_url) #121
        response.message = client.llm(request.query, request.prompt, model=request.model)  #122
        response.success = True #123
        return response #124

    def set_vllm_content_srv(self, request, response): #126
        # 输入提示词和文本，视觉智能体返回回答 #127
        if request.image.data: #128
            self.get_logger().info(f'receive image') #129
            image = self.bridge.imgmsg_to_cv2(request.image, desired_encoding="bgr8") #130
        else: #131
            image = self.image_queue.get(block=True) #132
        client = speech.OpenAIAPI(request.api_key, request.base_url) #133
        res = client.vllm(request.query, image, prompt=request.prompt, model=request.model)  #134
        response.message = res #135
        response.success = True #136
        return response #137

def main(): #139
    node = AgentProcess('agent_process') #140
    try: #141
        rclpy.spin(node) #142
    except KeyboardInterrupt: #143
        print('shutdown') #144
    finally: #145
        rclpy.shutdown()  #146

if __name__ == "__main__": #148
    main() #149
