#!/usr/bin/python3 #1
# coding=utf8 #2
# 第7章 ROS机器狗创意课程\4.AI视觉巡线行走(7.ROS Robot Creative Lesson\4.AI Visual Line Follow Walking) #3
import os #4
import cv2 #5
import math #6
import sys #7
import time #8
import numpy as np #9
import yaml #10
import threading #11
from cv_bridge import CvBridge, CvBridgeError #12
from std_srvs.srv import Trigger, SetBool #13
from large_models_msgs.srv import SetString #14
from std_srvs.srv import SetBool, Trigger, Empty #15
import rclpy #16
from rclpy.node import Node #17

from sensor_msgs.msg import Image #19
from std_srvs.srv import Empty #20
from puppy_control_msgs.msg import Velocity, Pose, Gait #21


def map_value(x, in_min, in_max, out_min, out_max): #24
    """映射函数，将 x 从 [in_min, in_max] 映射到 [out_min, out_max]""" #25
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min #26


class VisualPatrolDemo(Node): #29
    def __init__(self): #30
        super().__init__('visual_patrol_demo') #31

        # 初始化变量 #33
        self.is_shutdown = False #34
        self.__isRunning = False #35
        self.start_time = None #36
        self.elapsed_time = None #37
        self.enable_running = False #38

        self.__target_color = 'red' #40
        self.line_centerx = -1 #41
        self.img_centerx = 320  # 图像中心点x坐标（320/2） #42

        # 定义 ROI 和权重 #44
        self.roi = [ #45
            (120, 140,  0, 320, 0.1),  #46
            (160, 180,  0, 320, 0.2),  #47
            (200, 220,  0, 320, 0.7) #48
        ] #49
        self.roi_h_list = [self.roi[0][0], self.roi[1][0] - self.roi[0][0], self.roi[2][0] - self.roi[1][0]] #50

        # 定义颜色范围 RGB 用于可视化 #52
        self.range_rgb = { #53
            'red': (0, 0, 255), #54
            'blue': (255, 0, 0), #55
            'green': (0, 255, 0), #56
            'black': (0, 0, 0), #57
            'white': (255, 255, 255), #58
        } #59
        self.draw_color = self.range_rgb["black"] #60

        # 初始化 CvBridge #62
        self.bridge = CvBridge() #63

        # 读取颜色阈值配置 #65
        self.color_range_list = self.load_color_ranges('/home/ubuntu/software/lab_tool/lab_config.yaml') #66

        # Lock #68
        self.lock = threading.Lock() #69
        
        # 获取 PuppyPose 参数 #71
        self.PP = { #72
            'LookDown_20deg': { #73
                'roll': math.radians(0.0), #74
                'pitch': math.radians(-20.0), #75
                'yaw': 0.0, #76
                'height': -9.0, #77
                'x_shift': -0.1, #78
                'stance_x': 0.0, #79
                'stance_y': 0.0 #80
            }, #81
        } #82
        self.PuppyPose = self.PP['LookDown_20deg'].copy() #83

        # 定义步态配置 #85
        self.GaitConfig = { #86
            'overlap_time': 0.1, #87
            'swing_time': 0.15, #88
            'clearance_time': 0.0, #89
            'z_clearance': 3.0 #90
        } #91

        # 创建发布者 (create publisher) #93
        self.PuppyGaitConfigPub = self.create_publisher(Gait, 'puppy_control/gait', 10) #94
        self.PuppyVelocityPub = self.create_publisher(Velocity, 'puppy_control/velocity', 10) #95
        self.PuppyPosePub = self.create_publisher(Pose, 'puppy_control/pose', 10) #96
        self.cli = self.create_client(Empty,'/puppy_control/go_home') #97

        # 创建订阅者 #99
        self.image_sub = self.create_subscription(Image, 'image_raw', self.image_callback, 10) #100
        
        self.enter_srv = self.create_service(Trigger, '~/enter', self.enter_srv_callback) #102
        self.enable_running_srv = self.create_service(SetBool, '~/enable_running', self.enable_running_srv_callback) #103
        self.set_target_srv = self.create_service(SetString, '~/set_color_target', self.set_color_target_srv_callback) #104

        # 初始化 PuppyMove #106
        self.PuppyMove = {'x': 0.0, 'y': 0.0, 'yaw_rate': 0.0} #107
        self.get_logger().info(f"PuppyMove initialized: {self.PuppyMove}") #108

        # 设置运行标志位 #110
        self.__isRunning = True #111

        self.get_logger().info("视觉巡线节点初始化完成，开始运行。") #113

    def load_color_ranges(self, yaml_path): #115
        """加载颜色阈值配置""" #116
        try: #117
            with open(yaml_path, 'r', encoding='utf-8') as f: #118
                lab_config = yaml.safe_load(f) #119
                color_ranges = lab_config.get('color_range_list', {}) #120
                if 'red' not in color_ranges: #121
                    self.get_logger().warn("颜色阈值配置中未找到 'red' 的阈值。") #122
                self.get_logger().info(f"颜色阈值加载成功: {list(color_ranges.keys())}") #123
                return color_ranges #124
        except Exception as e: #125
            self.get_logger().error(f"无法加载颜色阈值配置文件: {e}") #126
            return {} #127

    def initialize_robot(self): #129
        """发布初始姿态和步态配置""" #130
        # 发布初始速度为零 #131
        velocity_msg = Velocity() #132
        velocity_msg.x = 0.0 #133
        velocity_msg.y = 0.0 #134
        velocity_msg.yaw_rate = 0.0 #135
        self.PuppyVelocityPub.publish(velocity_msg) #136
        self.get_logger().info("发布初始速度为零。") #137
        time.sleep(0.2) #138

        # 发布初始姿态 (publish initial posture) #140
        pose_msg = Pose() #141
        pose_msg.stance_x = float(self.PuppyPose['stance_x']) #142
        pose_msg.stance_y = float(self.PuppyPose['stance_y']) #143
        pose_msg.x_shift = float(self.PuppyPose['x_shift']) #144
        pose_msg.height = float(self.PuppyPose['height']) #145
        pose_msg.roll = float(self.PuppyPose['roll']) #146
        pose_msg.pitch = float(self.PuppyPose['pitch']) #147
        pose_msg.yaw = float(self.PuppyPose['yaw']) #148
        pose_msg.run_time = int(500) #149
        self.PuppyPosePub.publish(pose_msg) #150
        self.get_logger().info("发布初始姿态。") #151
        time.sleep(0.2) #152

        # 发布步态配置 #154
        gait_msg = Gait() #155
        gait_msg.overlap_time = float(self.GaitConfig['overlap_time']) #156
        gait_msg.swing_time = float(self.GaitConfig['swing_time']) #157
        gait_msg.clearance_time = float(self.GaitConfig['clearance_time']) #158
        gait_msg.z_clearance = float(self.GaitConfig['z_clearance']) #159
        self.PuppyGaitConfigPub.publish(gait_msg) #160
        self.get_logger().info("发布步态配置。") #161
        time.sleep(0.2) #162
        
    def enter_srv_callback(self, request, response):     #164
        self.get_logger().info('\033[1;32m%s\033[0m' % "enter visual patrol") #165
        self.initialize_robot() #166
        
        response.success = True #168
        response.message = "start" #169
        return response #170
    
    
    def enable_running_srv_callback(self, request, response): #173
        self.enable_running = request.data #174
        self.get_logger().info('\033[1;32m%s\033[0m' % 'enable  visual_patrol_demo') #175
        
        response.success = True #177
        return response #178
        
    def set_color_target_srv_callback(self, request, response): #180
        self.__target_color = request.data #181
        self.get_logger().info('\033[1;32mset color target %s\033[0m' % str(request.data)) #182
        
        response.success = True #184
        return response #185
        
    def move(self,): #187
        while True: #188
            self.get_logger().warn("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") #189
            with self.lock: #190
                # 根据检测到的线条位置调整机器人运动 #191
                if self.__isRunning and self.line_centerx != -1: #192
                    if abs(self.line_centerx - self.img_centerx) <= 50: #193
                        self.PuppyMove['x'] = 10.0 #194
                        self.PuppyMove['yaw_rate'] = 0.0 #195
                    elif self.line_centerx - self.img_centerx > 50: #196
                        self.PuppyMove['x'] = 8.0 #197
                        self.PuppyMove['yaw_rate'] = -15.0 #198
                    elif self.line_centerx - self.img_centerx < -50: #199
                        self.PuppyMove['x'] = 8.0 #200
                        self.PuppyMove['yaw_rate'] = 15.0              #201
                    self.PuppyVelocityPub.publish(velocity_msg) #202
                    
                elif self.__isRunning and self.line_centerx == -1: #204
                    # 如果未检测到线条，停下机器人 #205
                    velocity_msg = Velocity() #206
                    velocity_msg.x = 0.0 #207
                    velocity_msg.y = 0.0 #208
                    velocity_msg.yaw_rate = 0.0 #209
                    self.PuppyVelocityPub.publish(velocity_msg) #210
                    time.sleep(0.5) #211
                    self.cli = self.create_client(Empty,'/puppy_control/go_home') #212
                    self.get_logger().warn("未检测到线条，停下机器人。") #213
        
        
    def move_robot(self, error): #216
        """根据误差调整机器人的速度和转向""" #217
        if abs(error) <= 20: #218
            self.PuppyMove['x'] = 10.0 #219
            self.PuppyMove['yaw_rate'] = 0.0 #220
            
        elif error > 50: #222
            self.PuppyMove['x'] = 8.0 #223
            self.PuppyMove['yaw_rate'] = math.radians(-15.0) #224
        elif error < -50: #225
            self.PuppyMove['x'] = 8.0 #226
            self.PuppyMove['yaw_rate'] = math.radians(15.0) #227
       
        ''' #229
        else: #230
            self.PuppyMove['x'] = 8.0 #231
            #self.PuppyMove['yaw_rate'] = -0.004 * error  # 根据误差调整转向速度 #232
            self.PuppyMove['yaw_rate'] = -20.0 #233
        ''' #234

        # 发布速度消息 #236
        velocity_msg = Velocity() #237
        velocity_msg.x = self.PuppyMove['x'] #238
        velocity_msg.y = 0.0  # 保持 y 轴速度为 0 #239
        velocity_msg.yaw_rate = self.PuppyMove['yaw_rate'] #240
        self.PuppyVelocityPub.publish(velocity_msg) #241
        self.get_logger().info(f"发布速度指令: x={velocity_msg.x}, yaw_rate={velocity_msg.yaw_rate}") #242

    def getAreaMaxContour(self, contours): #244
        """找出面积最大的轮廓""" #245
        contour_area_max = 0 #246
        area_max_contour = None #247

        for c in contours: #249
            contour_area_temp = math.fabs(cv2.contourArea(c)) #250
            if contour_area_temp > contour_area_max: #251
                contour_area_max = contour_area_temp #252
                if contour_area_temp > 50: #253
                    area_max_contour = c #254

        return area_max_contour, contour_area_max #256

    def run(self, img): #258
        """处理图像，检测红色线条并计算中心位置""" #259
        size = (320, 240) #260
        img_h, img_w = img.shape[:2] #261

        frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_LINEAR) #263
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #264

        centroid_x_sum = 0 #266
        weight_sum = 0 #267

        # 绘制 ROI 区域用于调试 #269
        # for r in self.roi: #270
        #     cv2.rectangle(img, (r[2], r[0]), (r[3], r[1]), (255, 0, 0), 1) #271

        # 将图像分割成上中下三个部分 #273
        for idx, r in enumerate(self.roi): #274
            roi_h = self.roi_h_list[idx] #275
            blobs = frame_gb[r[0]:r[1], r[2]:r[3]] #276
            frame_lab = cv2.cvtColor(blobs, cv2.COLOR_BGR2LAB)  # 转换为 LAB 颜色空间 #277

            detect_color = self.__target_color #279
            if detect_color in self.color_range_list: #280
                color_range = self.color_range_list[detect_color] #281
                frame_mask = cv2.inRange(frame_lab, #282
                                         np.array(color_range['min'], dtype=np.uint8), #283
                                         np.array(color_range['max'], dtype=np.uint8)) #284
                # 形态学操作 #285
                opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)) #286
                closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)) #287
            else: #288
                self.line_centerx = -1 #289
                self.get_logger().warn(f"目标颜色 '{detect_color}' 不在颜色阈值列表中。") #290
                return img #291

            # 查找轮廓 #293
            contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE) #294
            cnt_large, area = self.getAreaMaxContour(contours) #295
            self.get_logger().debug(f"ROI {idx + 1}: 找到 {len(contours)} 个轮廓，最大面积为 {area}") #296

            if cnt_large is not None: #298
                rect = cv2.minAreaRect(cnt_large) #299
                box = np.int0(cv2.boxPoints(rect)) #300
                for i in range(4): #301
                    box[i, 1] = box[i, 1] + r[0] #302
                    box[i, 1] = int(map_value(box[i, 1], 0, size[1], 0, img_h)) #303
                for i in range(4): #304
                    box[i, 0] = int(map_value(box[i, 0], 0, size[0], 0, img_w)) #305

                # 绘制轮廓和中心点 #307
                cv2.drawContours(img, [box], -1, (0, 0, 255), 2) #308
                pt1_x, pt1_y = box[0, 0], box[0, 1] #309
                pt3_x, pt3_y = box[2, 0], box[2, 1] #310
                center_x, center_y = (pt1_x + pt3_x) / 2, (pt1_y + pt3_y) / 2 #311
                cv2.circle(img, (int(center_x), int(center_y)), 5, (0, 0, 255), -1) #312

                # 计算加权中心 #314
                centroid_x_sum += center_x * r[4] #315
                weight_sum += r[4] #316

                self.get_logger().debug(f"ROI {idx + 1}: center_x={center_x}, center_y={center_y}") #318
            else: #319
                #self.get_logger().debug(f"ROI {idx + 1}: 未检测到有效轮廓。") #320
                continue  # 未检测到轮廓，跳过 #321

        # 计算最终的中心点 #323
        if weight_sum != 0: #324
            self.line_centerx = int(centroid_x_sum / weight_sum) #325
            cv2.circle(img, (self.line_centerx, int(center_y)), 10, (0, 255, 255), -1) #326
            self.get_logger().info(f'line_centerx: {self.line_centerx}') #327
            self.start_time = None #328
        else: #329
            if self.start_time is None: #330
                self.start_time = time.time() #331
            self.elapsed_time = time.time() - self.start_time #332
            if self.elapsed_time > 3:            #333
                self.get_logger().info('Weight sum is zero for more than 3 seconds. Terminating program.') #334
                self.cli.call_async(Empty.Request()) #335
                self.line_centerx = -1 #336
                  
                self.enable_running = False   #338
                          
            else: #340
                self.line_centerx = -1 #341
                #self.get_logger().warn("未检测到任何有效的线条。") #342

        return img #344

    def image_callback(self, ros_image): #346
        """图像回调函数，处理图像并发布运动指令""" #347
        try: #348
            # 将 ROS 图像消息转换为 OpenCV 图像 #349
            cv2_img = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #350
        except CvBridgeError as e: #351
            self.get_logger().error(f"图像转换失败: {e}") #352
            return #353

        frame = cv2_img.copy() #355
        frame_result = frame #356

        # 处理图像并获取结果 #358
        if self.enable_running: #359
            frame_result = self.run(frame) #360
            if self.__isRunning and self.line_centerx != -1: #361
                error = self.line_centerx - self.img_centerx #362
                self.move_robot(error) #363
            elif self.__isRunning and self.line_centerx == -1: #364
                # 如果未检测到线条，停下机器人 #365
                velocity_msg = Velocity() #366
                velocity_msg.x = 0.0 #367
                velocity_msg.y = 0.0 #368
                velocity_msg.yaw_rate = 0.0 #369
                self.PuppyVelocityPub.publish(velocity_msg) #370

            # 显示处理后的图像 #372
            cv2.imshow('Frame', frame_result) #373
            cv2.waitKey(1) #374
        else: #375
            cv2.destroyAllWindows() #376


    def destroy_node(self): #379
        """节点销毁时发布停止指令""" #380
        self.is_shutdown = True #381
        velocity_msg = Velocity() #382
        velocity_msg.x = 0.0 #383
        velocity_msg.y = 0.0 #384
        velocity_msg.yaw_rate = 0.0 #385
        self.PuppyVelocityPub.publish(velocity_msg) #386
        self.get_logger().info("节点销毁，发布停止指令。") #387
        super().destroy_node() #388
        rclpy.shutdown() #389


def main(args=None): #392
    rclpy.init(args=args) #393
    visual_patrol_demo = VisualPatrolDemo() #394
    try: #395
        rclpy.spin(visual_patrol_demo) #396
    except KeyboardInterrupt: #397
        pass #398
    finally: #399
        visual_patrol_demo.destroy_node() #400
        rclpy.shutdown() #401


if __name__ == '__main__': #404
    main() #405
