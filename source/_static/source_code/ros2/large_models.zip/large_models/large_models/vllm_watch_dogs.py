#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: liang #3
# @Date: 2024/12/18 #4
import cv2 #5
import sys #6
import os #7
import math #8
import json #9
import time #10
import queue #11
import rclpy #12
import threading #13
from config import * #14
import numpy as np #15
import sdk.fps as fps #16
from sdk import common #17
from action import PuppyControlNode #18
from rclpy.node import Node #19
from sensor_msgs.msg import Image #20
from std_srvs.srv import SetBool, Trigger, Empty #21
from std_msgs.msg import String, Bool #22
from rclpy.executors import MultiThreadedExecutor #23
from rclpy.callback_groups import ReentrantCallbackGroup #24
from cv_bridge import CvBridge #25
from speech import speech #26
from large_models.config import * #27
from large_models_msgs.srv import SetModel, SetString, SetInt32 #28
from puppy_control_msgs.srv import SetRunActionName #29
sys.path.append('/home/ubuntu/software/puppypi_control/')  #30
from servo_controller import setServoPulse #31
from action_group_control import runActionGroup, stopActionGroup #32
speech.set_volume(70) #33

if os.environ["ASR_LANGUAGE"] == 'Chinese':  #35
    PROMPT = ''' #36
你作为智能机器人助手，可以实时识别图像中的障碍物，并在 `response` 中输出物品名称及相关提示信息。 #37
规则： #38
1. 如果识别到障碍物： #39
   - `object` 返回识别出的物品名称。 #40
   - 在 `response` 中提示用户障碍物的位置，并关心提醒注意安全。 #41
   - 如果指令包含动作需求，需根据指令提供对应的 `action`，函数名称只能从以下列表中选择： #42
     * 站立：stand() #43
     * 打拳：boxing() #44
     * 俯卧撑：push_up() #45
     * 握手：shake_hands() #46
     * 点头：nod() #47
     * 坐下：sit() #48
     * 踢左脚：kick_ball_left() #49
     * 踢右脚：kick_ball_right() #50
     * 跳舞：moonwalk() #51
     * 趴下：lie_down() #52
     * 伸懒腰：temp() #53
     * 撒娇：bow() #54
     * 叫一声：man() #55
   - 示例： #56
     如果指令为：   #57
     "看看有没有什么障碍物，如果有障碍物的话叫一声提醒我"   #58
     你返回： #59
     ```json #60
     { #61
      "type": "detect", #62
      "object": "障碍物名称", #63
      "action": ["man()"], #64
      "Play": ["detect"], #65
      "response": "门口有障碍物喔，叫一声提醒你了要注意避开喔" #66
     } #67
     ``` #68

2. 如果没有识别到障碍物： #70
   - `object` 返回 `"None"`。 #71
   - `action` 返回 `["None"]`。 #72
   - 在 `response` 中提示用户环境中没有障碍物，并提醒注意安全。 #73
   - 示例： #74
     如果指令为：   #75
     "我现在要出门了，帮我去门口看看有没有什么障碍物"   #76
     你返回： #77
     ```json #78
     { #79
      "type": "detect", #80
      "object": "None", #81
      "action": ["None"], #82
      "Play": ["detect"], #83
      "response": "门口没有障碍物喔，注意安全早点回家喔" #84
     } #85
     ``` #86

3. 任何 `action` 中的函数名称必须从列表中选择，如果无法匹配到任何动作，返回 `["None"]`。 #88

只需要按照以上规则，返回 JSON 格式的内容即可，不要添加其它内容。,不能乱做动作需要根据提示做动作，叫一声也是动作，也是要执行的 #90

''' #92
else: #93
    PROMPT = ''' #94
As an intelligent robot assistant, you can recognize obstacles in the image in real time and output item names and related prompt information in the 'response'. #95
Rule: #96
If an obstacle is identified: #97
-'object' returns the name of the recognized item. #98
-Remind the user of the location of obstacles in the 'response' and pay attention to safety. #99
-If the instruction contains action requirements, the corresponding 'action' must be provided based on the instruction, and the function name can only be selected from the following list: #100
*Standing: stand() #101
*Punching: boxing() #102
*Push ups: push_up() #103
*Handshake: shake_hands() #104
*Nodding: nod() #105
*Sit down: sit() #106
*Kick the left foot: kick_ball_left() #107
*Kick your right foot: kick_ball_right() #108
*Dancing: moonwalk() #109
*Get down: lie_down() #110
*Stretching lazily: temp() #111
*Being coquettish: bow() #112
*Call out: man() #113
-Example: #114
If the instruction is: #115
Check if there are any obstacles, and if there are any, let me know #116
You return: #117
```json #118
{ #119
"type": "detect", #120
"object":  The name of the obstacle, #121
"action": ["man()"], #122
"Play": ["detect"], #123
"response":  There is an obstacle at the door, I'm calling to remind you to avoid it #124
} #125
``` #126
If no obstacle is recognized: #127
-'Object' returns' None '. #128
-` action ` returns ` ["None"] `. #129
-Notify the user in the 'response' that there are no obstacles in the environment and remind them to pay attention to safety. #130
-Example: #131
If the instruction is: #132
I'm going out now, help me go to the door and see if there are any obstacles #133
You return: #134
```json #135
{ #136
"type": "detect", #137
"object": "None", #138
"action": ["None"], #139
"Play": ["detect"], #140
"response":  There are no obstacles at the door, be safe and go home early #141
} #142
``` #143
3. Just follow the above rules and return the content in JSON format without adding any other content., You can't do actions randomly.  #144
You need to follow the prompts to do actions. Calling out is also an action, and it must be executed #145
    ''' #146


class WATCHDOGS(Node): #149
    def __init__(self, name): #150
        super().__init__(name) #151
        self.image_queue = queue.Queue(maxsize=2) #152
        self.bridge = CvBridge() #153
        self.action = [] #154
        self.vllm_result = '' #155
        self.running = True #156
        self.client = speech.OpenAIAPI(api_key, base_url) #157
        self.puppy_control_node = PuppyControlNode() #158
        self.declare_parameter('camera_topic', 'image_raw') #159
        camera_topic = self.get_parameter('camera_topic').value #160
        timer_cb_group = ReentrantCallbackGroup() #161
        self.tts_text_pub = self.create_publisher(String, 'tts_node/tts_text', 1) #162
        self.create_subscription(Image, 'image_raw', self.image_callback, 1) #163
        self.create_subscription(String, 'agent_process/result', self.vllm_result_callback, 1) #164
        self.create_subscription(Bool, 'tts_node/play_finish', self.play_audio_finish_callback, 1, callback_group=timer_cb_group) #165
        self.awake_client = self.create_client(SetBool, 'vocal_detect/enable_wakeup') #166
        self.awake_client.wait_for_service() #167
        self.run_action_group_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #168
        self.set_model_client = self.create_client(SetModel, 'agent_process/set_model') #169
        self.set_model_client.wait_for_service() #170
        self.set_mode_client = self.create_client(SetInt32, 'vocal_detect/set_mode') #171
        self.set_mode_client.wait_for_service() #172
        self.set_prompt_client = self.create_client(SetString, 'agent_process/set_prompt') #173
        self.set_prompt_client.wait_for_service() #174
        self.cli = self.create_client(Empty,'/puppy_control/go_home') #175
        self.cli.call_async(Empty.Request()) #176
        timer_cb_group = ReentrantCallbackGroup() #177
        self.timer = self.create_timer(0.0, self.init_process, callback_group=timer_cb_group) #178

    def get_node_state(self, request, response): #180
        return response #181

    def init_process(self): #183
        self.timer.cancel() #184
        
        msg = SetModel.Request() #186
        msg.model = vllm_model #187
        msg.model_type = 'vllm' #188
        if os.environ['ASR_LANGUAGE'] == 'Chinese': #189
            msg.model = stepfun_vllm_model #190
            msg.api_key = stepfun_api_key #191
            msg.base_url = stepfun_base_url #192
        else: #193
            msg.model = vllm_model #194
            msg.api_key = vllm_api_key #195
            msg.base_url = vllm_base_url #196
        self.send_request(self.set_model_client, msg) #197

        msg = SetString.Request() #199
        msg.data = PROMPT #200
        self.send_request(self.set_prompt_client, msg) #201
        speech.play_audio(start_audio_path) #202
        threading.Thread(target=self.process, daemon=True).start() #203
        self.create_service(Empty, '~/init_finish', self.get_node_state) #204
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start') #205



    def send_request(self, client, msg): #209
        future = client.call_async(msg) #210
        while rclpy.ok(): #211
            if future.done() and future.result(): #212
                return future.result() #213


    def vllm_result_callback(self, msg): #216
        """纯回调函数""" #217
        self.vllm_result = msg.data   #218
        self.handle_vllm_result()  # 调用处理函数 #219
        
    def play_audio_finish_callback(self, msg): #221
        """TTS 播放完成后的回调，恢复唤醒检测""" #222
        self.play_audio_finish = msg.data #223
        if self.play_audio_finish: #224
            msg = SetBool.Request() #225
            msg.data = True #226
            self.send_request(self.awake_client, msg) #227

        
    def handle_vllm_result(self): #230
        """处理 VLLM 结果的逻辑，包括动作解析和响应发布"""   #231
        if not self.vllm_result: #232
            return #233

        try: #235
            result_json = self.vllm_result[self.vllm_result.find('{'):self.vllm_result.find('}') + 1] #236
            result = eval(result_json) #237
            action_list = result.get('action', []) #238
            response = result.get('response', '') #239
            for action in action_list: #240
                if action and action != "None": #241
                    try: #242
                        eval(f'self.puppy_control_node.{action}')  #243
                    except Exception as e: #244
                        self.get_logger().error(f"执行动作 '{action}' 失败: {e}") #245

            time.sleep(6) #247
            response_msg = String() #248
            response_msg.data = response #249
            self.tts_text_pub.publish(response_msg) #250
            self.cli.call_async(Empty.Request()) #251
            time.sleep(3) #252
            runActionGroup('look_down.d6ac', True) #253

        except Exception as e: #255
            self.get_logger().error(f"处理 VLLM 结果出错: {e}") #256
        finally: #257
            self.vllm_result = ''   #258

    def process(self): #260
            while self.running: #261
                image = self.image_queue.get(block=True) #262
                if self.vllm_result != '': #263
                    msg = String() #264
                    msg.data = self.vllm_result #265
                    #self.tts_text_pub.publish(msg) #266
                    self.vllm_result = '' #267

                cv2.imshow('image', image) #269
                cv2.waitKey(1) #270
            cv2.destroyAllWindows() #271

    def image_callback(self, ros_image): #273
        try: #274
            # 使用 cv_bridge 将 ROS Image 转换为 OpenCV 图像 #275
            rgb_image = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #276

            if self.image_queue.full(): #278
                # 如果队列已满，丢弃最旧的图像 #279
                self.image_queue.get() #280

            # 将图像放入队列 #282
            self.image_queue.put(rgb_image) #283
        except Exception as e: #284
            self.get_logger().error(f"Error processing image: {e}") #285


def main(): #288
    rclpy.init() #289
    node = WATCHDOGS('vllm_watch_dogs') #290
    executor = MultiThreadedExecutor() #291
    executor.add_node(node) #292
    try: #293
        executor.spin() #294
    except KeyboardInterrupt: #295
        node.get_logger().info('Shutting down node') #296
    finally: #297
        node.running = False #298
        node.destroy_node() #299


if __name__ == "__main__": #302
    main() #303
