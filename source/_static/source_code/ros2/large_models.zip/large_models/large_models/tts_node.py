#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/11/18 #4
import os #5
import time #6
import rclpy #7
import threading #8
from rclpy.node import Node #9
from std_srvs.srv import Trigger, Empty #10
from std_msgs.msg import String, Bool #11

from speech import speech #13
from large_models.config import * #14
speech.set_volume(30) #15
class TTSNode(Node): #16
    def __init__(self, name): #17
        rclpy.init() #18
        super().__init__(name) #19
        
        self.text = None #21
        speech.set_volume(100) #22
        self.language = os.environ["ASR_LANGUAGE"] #23
        if self.language == 'Chinese': #24
            self.tts = speech.RealTimeTTS(log=self.get_logger()) #25
        else: #26
            self.tts = speech.RealTimeOpenAITTS(log=self.get_logger()) #27
       
        self.play_finish_pub = self.create_publisher(Bool, '~/play_finish', 1) #29
        self.create_subscription(String, '~/tts_text', self.tts_callback, 1) #30

        threading.Thread(target=self.tts_process, daemon=True).start() #32
        self.create_service(Empty, '~/init_finish', self.get_node_state) #33
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start') #34

    def get_node_state(self, request, response): #36
        return response #37

    def tts_callback(self, msg): #39
        # self.get_logger().info(msg.data) #40
        self.text = msg.data #41

    def tts_process(self): #43
        while True: #44
            if self.text is not None: #45
                if self.text == '': #46
                    speech.play_audio(no_voice_audio_path) #47
                else: #48
                    self.tts.tts(self.text, model=tts_model, voice=voice_model) #49
                self.text = None #50
                msg = Bool() #51
                msg.data = True #52
                self.play_finish_pub.publish(msg) #53
            else: #54
                time.sleep(0.01) #55

def main(): #57
    node = TTSNode('tts_node') #58
    try: #59
        rclpy.spin(node) #60
    except KeyboardInterrupt: #61
        print('shutdown') #62
    finally: #63
        rclpy.shutdown()  #64

if __name__ == "__main__": #66
    main() #67
