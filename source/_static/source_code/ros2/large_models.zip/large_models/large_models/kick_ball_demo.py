#!/usr/bin/python3 #1
# coding=utf8 #2
import os #3
import sys #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9
from enum import Enum #10
import yaml #11
from cv_bridge import CvBridge #12
import rclpy #13
from rclpy.node import Node #14
from sensor_msgs.msg import Image #15
from puppy_control_msgs.msg import Velocity, Pose, Gait #16
from puppy_control_msgs.srv import SetRunActionName #17
from large_models_msgs.srv import SetString #18
from std_srvs.srv import SetBool, Trigger, Empty #19
from std_srvs.srv import Trigger, SetBool #20
from rclpy.executors import MultiThreadedExecutor #21

def map_value(x, in_min, in_max, out_min, out_max): #23
    return (x - in_min)*(out_max - out_min)/(in_max - in_min) + out_min #24

def emptyFunc(img=None): #26
    return img #27

def setRange(x, x_min, x_max): #29
    tmp = x if x > x_min else x_min #30
    tmp = tmp if tmp < x_max else x_max #31
    return tmp #32

class PuppyStatus(Enum): #34
    LOOKING_FOR = 0  # 寻找 #35
    LOOKING_FOR_LEFT = 1 #36
    LOOKING_FOR_RIGHT = 2 #37
    FOUND_TARGET = 3  # 已经发现目标 #38
    CLOSE_TO_TARGET = 4  # 靠近目标 #39
    CLOSE_TO_TARGET_FINE_TUNE = 5  # 细调 #40
    KICK_BALL = 6  # 踢球 #41
    STOP = 10 #42
    END = 20 #43

class KickBallDemo(Node): #45
    def __init__(self): #46
        super().__init__('kick_ball_demo') #47

        # Initialize variables #49
        self.is_shutdown = False #50
        self.debug = False #51
        self.haved_detect = False #52
        
        self.start_time = 0 #54
        self.elapsed_time = 0 #55
        
        self.__target_color = ('red',) #57
        
        self.enable_running = False #59
        self.thread_started = True #60
        self.thread = None #61

        # Initialize CvBridge #63
        self.bridge = CvBridge() #64

        # Initialize status #66
        self.puppyStatus = PuppyStatus.LOOKING_FOR #67
        self.puppyStatusLast = PuppyStatus.END #68

        # Expected centers #70
        self.expect_center = {'X':640/2,'Y':480/2} #71
        self.expect_center_kick_ball_left = {'X':150,'Y':480-150} #72
        self.expect_center_kick_ball_right = {'X':640-150,'Y':480-150} #73

        self.target_info = None #75

        # Range RGB #77
        self.range_rgb = { #78
            'red': (0, 0, 255), #79
            'blue': (255, 0, 0), #80
            'green': (0, 255, 0), #81
            'black': (0, 0, 0), #82
            'white': (255, 255, 255), #83
        } #84

        self.color_list = [] #86
        self.detect_color = 'None' #87
        self.draw_color = self.range_rgb["black"] #88

        # Size #90
        self.size = (320, 240) #91

        # Lock #93
        self.lock = threading.Lock() #94

        # Read color ranges from lab_config.yaml using yaml_handle.py logic #96
        with open('/home/ubuntu/software/lab_tool/lab_config.yaml', 'r', encoding='utf-8') as f: #97
            lab_config = yaml.safe_load(f) #98
            if 'color_range_list' in lab_config: #99
                self.color_range_list = lab_config['color_range_list'] #100
            else: #101
                self.get_logger().error("lab_config.yaml does not contain 'color_range_list'") #102
                self.color_range_list = {} #103
        self.PP = { #104
            'LookDown_10deg': { #105
                'roll': math.radians(0), #106
                'pitch': math.radians(-15.0), #107
                'yaw': 0.0, #108
                'height': -9.0, #109
                'x_shift': -0.1, #110
                'stance_x': 0.0,   #111
                'stance_y': 0.0    #112
            }, #113
            'LookDown_20deg': { #114
                'roll': math.radians(0), #115
                'pitch': math.radians(-20.0), #116
                'yaw': 0.0, #117
                'height': -9.0, #118
                'x_shift': -0.1, #119
                'stance_x': 0.0,  #120
                'stance_y': 0.0    #121
            }, #122
        } #123

        self.PuppyPose = self.PP['LookDown_10deg'].copy() #125

        self.GaitConfig = {'overlap_time': 0.15, 'swing_time': 0.15, 'clearance_time': 0.0, 'z_clearance': 3.0} #127
        # Create publishers #128
        self.PuppyGaitConfigPub = self.create_publisher(Gait, '/puppy_control/gait', 10) #129
        self.PuppyVelocityPub = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #130
        self.PuppyPosePub = self.create_publisher(Pose, '/puppy_control/pose', 10) #131

        # Create subscribers #133
        self.image_sub = self.create_subscription(Image, '/image_raw', self.image_callback, 10) #134

        # Create service clients #136
        self.runActionGroup_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #137
        
        self.enter_srv = self.create_service(Trigger, '~/enter', self.enter_srv_callback) #139
        self.enable_running_srv = self.create_service(SetBool, '~/enable_running', self.enable_running_srv_callback) #140
        self.set_target_srv = self.create_service(SetString, '~/set_color_target', self.set_color_target_srv_callback) #141
        self.cli = self.create_client(Empty,'/puppy_control/go_home') #142

        # Wait for the service to be available #144
        while not self.runActionGroup_srv.wait_for_service(timeout_sec=1.0): #145
            self.get_logger().info('Service /puppy_control/runActionGroup not available, waiting...') #146
   
    def initialize_robot(self): #148
        time.sleep(0.3) #149
        pose_msg = Pose() #150
        pose_msg.stance_x = float(self.PuppyPose['stance_x']) #151
        pose_msg.stance_y = float(self.PuppyPose['stance_y']) #152
        pose_msg.x_shift = float(self.PuppyPose['x_shift']) #153
        pose_msg.height = float(self.PuppyPose['height']) #154
        pose_msg.roll = float(self.PuppyPose['roll']) #155
        pose_msg.pitch = float(self.PuppyPose['pitch']) #156
        pose_msg.yaw = float(self.PuppyPose['yaw']) #157
        pose_msg.run_time = int(500)  # 确保是整数类型 #158

        self.PuppyPosePub.publish(pose_msg) #160
        time.sleep(0.2) #161
        gait_msg = Gait() #162
        gait_msg.overlap_time = float(self.GaitConfig['overlap_time']) #163
        gait_msg.swing_time = float(self.GaitConfig['swing_time']) #164
        gait_msg.clearance_time = float(self.GaitConfig['clearance_time']) #165
        gait_msg.z_clearance = float(self.GaitConfig['z_clearance']) #166
        self.PuppyGaitConfigPub.publish(gait_msg) #167
        time.sleep(0.2) #168
        #threading.Thread(target=self.move).start() #169

    def enter_srv_callback(self, request, response):     #171
        self.get_logger().info('\033[1;32m%s\033[0m' % "enter kick ball") #172
        self.initialize_robot() #173
        self.thread_started = False         #174
        time.sleep(0.02) #175
        
        response.success = True #177
        response.message = "start" #178
        return response #179
    
    
    def enable_running_srv_callback(self, request, response): #182
        self.enable_running = request.data #183
        self.get_logger().info('\033[1;32m%s\033[0m' % 'enable kick ball') #184
        
        response.success = True #186
        return response #187
        
    def set_color_target_srv_callback(self, request, response): #189
        #self.__target_color[0] = request.data #190
        self.__target_color = (request.data, ) #191
        self.get_logger().info('\033[1;32mset color target %s\033[0m' % str(self.__target_color[0])) #192
        
        response.success = True #194
        return response #195
    
    
    def move(self): #198
        time.sleep(2) #199
        which_foot_kick_ball = 'left'  # Initialize #200
        self.is_shutdown = True #201

        while self.is_shutdown: #203
            if not self.is_shutdown: #204
                break #205
            if self.enable_running:  #206
                time.sleep(0.01) #207
                if self.puppyStatus == PuppyStatus.LOOKING_FOR: #208
                    if self.haved_detect: #209
                        self.puppyStatus = PuppyStatus.FOUND_TARGET #210
                        self.start_time = 0 #211
                    else: #212
                        if self.start_time == 0: #213
                            self.start_time = time.time()                             #214
                        self.PuppyPose = self.PP['LookDown_10deg'].copy() #215
                        pose_msg = Pose() #216
                        pose_msg.stance_x = self.PuppyPose['stance_x'] #217
                        pose_msg.stance_y = self.PuppyPose['stance_y'] #218
                        pose_msg.x_shift = self.PuppyPose['x_shift'] #219
                        pose_msg.height = self.PuppyPose['height'] #220
                        pose_msg.roll = self.PuppyPose['roll'] #221
                        pose_msg.pitch = self.PuppyPose['pitch'] #222
                        pose_msg.yaw = self.PuppyPose['yaw'] #223
                        self.PuppyPosePub.publish(pose_msg) #224
                        time.sleep(0.2) #225
                        time.sleep(0.8) #226
                        self.puppyStatus = PuppyStatus.LOOKING_FOR_LEFT #227
                elif self.puppyStatus == PuppyStatus.LOOKING_FOR_LEFT: #228
                    if self.haved_detect: #229
                        self.puppyStatus = PuppyStatus.FOUND_TARGET #230
                    else: #231
                        
                        velocity_msg = Velocity() #233
                        velocity_msg.x = float(3.0) #234
                        velocity_msg.y = float(0.0) #235
                        velocity_msg.yaw_rate = float(math.radians(-12)) #236
                        self.PuppyVelocityPub.publish(velocity_msg) #237
    
                        time.sleep(3) #239
                        velocity_msg.yaw_rate = 0.0 #240
                        self.PuppyVelocityPub.publish(velocity_msg) #241
                        time.sleep(0.3) #242
                        time.sleep(0.8) #243
                        self.puppyStatus = PuppyStatus.LOOKING_FOR_RIGHT #244
                elif self.puppyStatus == PuppyStatus.LOOKING_FOR_RIGHT: #245
                    if self.haved_detect: #246
                        self.start_time = 0 #247
                        self.puppyStatus = PuppyStatus.FOUND_TARGET #248
                    else: #249
                        self.PuppyPose = self.PP['LookDown_10deg'].copy() #250
                        pose_msg = Pose() #251
                        pose_msg.stance_x = self.PuppyPose['stance_x'] #252
                        pose_msg.stance_y = self.PuppyPose['stance_y'] #253
                        pose_msg.x_shift = self.PuppyPose['x_shift'] #254
                        pose_msg.height = self.PuppyPose['height'] #255
                        pose_msg.roll = self.PuppyPose['roll'] #256
                        pose_msg.pitch = self.PuppyPose['pitch'] #257
                        pose_msg.yaw = self.PuppyPose['yaw'] #258
                        self.PuppyPosePub.publish(pose_msg) #259
                        time.sleep(0.2) #260
                        velocity_msg = Velocity() #261
                        velocity_msg.x = 2.0 #262
                        velocity_msg.y = 0.0 #263
                        velocity_msg.yaw_rate = float(math.radians(-12)) #264
                        self.PuppyVelocityPub.publish(velocity_msg) #265
                        self.elapsed_time = time.time() - self.start_time #266
                        #self.get_logger().info(f"self.elapsed_time:{self.elapsed_time}") #267
                        if self.elapsed_time > 3:  #268
                            self.start_time = 0 #269
                            self.elapsed_time = 0 #270
                            self.puppyStatus = PuppyStatus.LOOKING_FOR #271
                            velocity_msg = Velocity() #272
                            velocity_msg.x = 0.0 #273
                            velocity_msg.y = 0.0 #274
                            velocity_msg.yaw_rate = 0.0 #275
                            self.PuppyVelocityPub.publish(velocity_msg) #276
                            self.haved_detect = False                     #277
                            self.enable_running = False #278
                            self.is_shutdown = False #279
                elif self.puppyStatus == PuppyStatus.FOUND_TARGET: #280
                    if self.target_info is None: #281
                        self.puppyStatus = PuppyStatus.LOOKING_FOR #282
                        continue #283
                    if self.target_info['centerY'] > 380: #284
                        self.puppyStatus = PuppyStatus.CLOSE_TO_TARGET #285
                        self.PuppyPose = self.PP['LookDown_20deg'].copy() #286
                        pose_msg = Pose() #287
                        pose_msg.stance_x = self.PuppyPose['stance_x'] #288
                        pose_msg.stance_y = self.PuppyPose['stance_y'] #289
                        pose_msg.x_shift = self.PuppyPose['x_shift'] #290
                        pose_msg.height = self.PuppyPose['height'] #291
                        pose_msg.roll = self.PuppyPose['roll'] #292
                        pose_msg.pitch = self.PuppyPose['pitch'] #293
                        pose_msg.yaw = self.PuppyPose['yaw'] #294
                        self.PuppyPosePub.publish(pose_msg) #295
                        time.sleep(0.2) #296
                    else: #297
                        if self.expect_center['X'] - self.target_info['centerX'] < -80: #298
                            velocity_msg = Velocity() #299
                            velocity_msg.x = 3.0 #300
                            velocity_msg.y = 0.0 #301
                            velocity_msg.yaw_rate = float(math.radians(-12)) #302
                            self.PuppyVelocityPub.publish(velocity_msg) #303
                            time.sleep(0.2) #304
                        elif self.expect_center['X'] - self.target_info['centerX'] > 80: #305
                            velocity_msg = Velocity() #306
                            velocity_msg.x = 3.0 #307
                            velocity_msg.y = 0.0 #308
                            velocity_msg.yaw_rate = float(math.radians(12)) #309
                            self.PuppyVelocityPub.publish(velocity_msg) #310
                            time.sleep(0.2) #311
                        else: #312
                            velocity_msg = Velocity() #313
                            velocity_msg.x = 10.0 #314
                            velocity_msg.y = 0.0 #315
                            velocity_msg.yaw_rate = 0.0 #316
                            self.PuppyVelocityPub.publish(velocity_msg) #317
                            time.sleep(0.2) #318
                elif self.puppyStatus == PuppyStatus.CLOSE_TO_TARGET: #319
                    if self.target_info is None: #320
                        self.puppyStatus = PuppyStatus.LOOKING_FOR #321
                        continue #322
                    if self.target_info['centerY'] > 380: #323
                        velocity_msg = Velocity() #324
                        velocity_msg.x = 0.0 #325
                        velocity_msg.y = 0.0 #326
                        velocity_msg.yaw_rate = 0.0 #327
                        self.PuppyVelocityPub.publish(velocity_msg) #328
                        self.puppyStatus = PuppyStatus.CLOSE_TO_TARGET_FINE_TUNE #329
                        if self.expect_center['X'] > self.target_info['centerX']: #330
                            which_foot_kick_ball = 'left' #331
                        else: #332
                            which_foot_kick_ball = 'right' #333
                    else: #334
                        if self.expect_center['X'] - self.target_info['centerX'] < -50: #335
                            velocity_msg = Velocity() #336
                            velocity_msg.x = 4.0 #337
                            velocity_msg.y = 0.0 #338
                            velocity_msg.yaw_rate = float(math.radians(-8)) #339
                            self.PuppyVelocityPub.publish(velocity_msg) #340
                            time.sleep(0.2) #341
                        elif self.expect_center['X'] - self.target_info['centerX'] > 50: #342
                            velocity_msg = Velocity() #343
                            velocity_msg.x = 4.0 #344
                            velocity_msg.y = 0.0 #345
                            velocity_msg.yaw_rate = float(math.radians(8)) #346
                            self.PuppyVelocityPub.publish(velocity_msg) #347
                            time.sleep(0.2) #348
                        else: #349
                            velocity_msg = Velocity() #350
                            velocity_msg.x = 8.0 #351
                            velocity_msg.y = 0.0 #352
                            velocity_msg.yaw_rate = 0.0 #353
                            self.PuppyVelocityPub.publish(velocity_msg) #354
                            time.sleep(0.2) #355
                elif self.puppyStatus == PuppyStatus.CLOSE_TO_TARGET_FINE_TUNE: #356
                    if self.target_info is None: #357
                        self.puppyStatus = PuppyStatus.LOOKING_FOR #358
                        continue #359
                    if self.target_info['centerY'] < self.expect_center_kick_ball_left['Y']: #360
                        velocity_msg = Velocity() #361
                        velocity_msg.x = 4.0 #362
                        velocity_msg.y = 0.0 #363
                        velocity_msg.yaw_rate = 0.0 #364
                        self.PuppyVelocityPub.publish(velocity_msg) #365
                        time.sleep(0.1) #366
                    elif which_foot_kick_ball == 'left' and self.target_info['centerX'] > self.expect_center_kick_ball_left['X']: #367
                        velocity_msg = Velocity() #368
                        velocity_msg.x = 0.0 #369
                        velocity_msg.y = 0.0 #370
                        velocity_msg.yaw_rate = float(math.radians(-5)) #371
                        self.PuppyVelocityPub.publish(velocity_msg) #372
                        time.sleep(0.1) #373
                    elif which_foot_kick_ball == 'right' and self.target_info['centerX'] < self.expect_center_kick_ball_right['X']: #374
                        velocity_msg = Velocity() #375
                        velocity_msg.x = 0.0 #376
                        velocity_msg.y = 0.0 #377
                        velocity_msg.yaw_rate = float(math.radians(5)) #378
                        self.PuppyVelocityPub.publish(velocity_msg) #379
                        time.sleep(0.1) #380
                    else: #381
                        velocity_msg = Velocity() #382
                        velocity_msg.x = 5.0 #383
                        velocity_msg.y = 0.0 #384
                        if which_foot_kick_ball == 'left': #385
                            velocity_msg.yaw_rate = float(math.radians(-8)) #386
                        else: #387
                            velocity_msg.yaw_rate = float(math.radians(8)) #388
                        self.PuppyVelocityPub.publish(velocity_msg) #389
                        time.sleep(1.66) #390
                        velocity_msg.x = 0.0 #391
                        velocity_msg.y = 0.0 #392
                        velocity_msg.yaw_rate = 0.0 #393
                        self.PuppyVelocityPub.publish(velocity_msg) #394
                        self.puppyStatus = PuppyStatus.KICK_BALL #395
                elif self.puppyStatus == PuppyStatus.KICK_BALL: #396
                    velocity_msg = Velocity() #397
                    velocity_msg.x = 0.0 #398
                    velocity_msg.y = 0.0 #399
                    velocity_msg.yaw_rate = 0.0 #400
                    self.PuppyVelocityPub.publish(velocity_msg) #401
                    time.sleep(0.2) #402
                    request = SetRunActionName.Request() #403
                    if which_foot_kick_ball == 'left': #404
                        request.name = 'kick_ball_left.d6ac' #405
                    else: #406
                        request.name = 'kick_ball_right.d6ac' #407
                    request.wait = True #408
                    future = self.runActionGroup_srv.call_async(request)                     #409
                    future.add_done_callback(self.kick_ball_callback) #410
                    self.puppyStatus = PuppyStatus.LOOKING_FOR  #411
                    time.sleep(0.02)                   #412
                    self.haved_detect = False                     #413
                    self.enable_running = False #414
                    self.is_shutdown = False #415
                    self.puppyStatus = PuppyStatus.LOOKING_FOR #416
                    time.sleep(2) #417
                    self.cli.call_async(Empty.Request()) #418
                    time.sleep(1) #419
                elif self.puppyStatus == PuppyStatus.STOP: #420
                    velocity_msg = Velocity() #421
                    velocity_msg.x = 0.0 #422
                    velocity_msg.y = 0.0 #423
                    velocity_msg.yaw_rate = 0.0 #424
                    self.PuppyVelocityPub.publish(velocity_msg) #425
                else: #426
                    time.sleep(0.01) #427
            
                if self.puppyStatusLast != self.puppyStatus: #429
                    self.get_logger().info(f'puppyStatus: {self.puppyStatus}') #430
                self.puppyStatusLast = self.puppyStatus #431
            else: #432
                time.sleep(0.02) #433
    def kick_ball_callback(self, future): #434
        if future.result() is not None: #435
            response = future.result() #436
            self.get_logger().info('Kick ball action completed successfully.') #437
        else: #438
            self.get_logger().error('Service call failed %r' % (future.exception(),)) #439
        # 状态已经在 move 方法中重置为 LOOKING_FOR #440

    def run(self, img): #442
        img_h, img_w = img.shape[:2] #443
        frame_resize = cv2.resize(img, self.size, interpolation=cv2.INTER_NEAREST) #444
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #445
        frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #446
        max_area = 0 #447
        color_area_max = None #448
        areaMaxContour_max = None #449
        for i in self.color_range_list: #450
            if i in self.__target_color: #451
                color_range = self.color_range_list[i] #452
                frame_mask = cv2.inRange(frame_lab, #453
                                         np.array(color_range['min'], dtype=np.uint8), #454
                                         np.array(color_range['max'], dtype=np.uint8)) #455
                eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #456
                dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #457
                if self.debug: #458
                    cv2.imshow(i, dilated) #459
                contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE) #460
                areaMaxContour, area_max = self.getAreaMaxContour(contours) #461
                if areaMaxContour is not None: #462
                    if area_max > max_area: #463
                        max_area = area_max #464
                        color_area_max = i #465
                        areaMaxContour_max = areaMaxContour #466
        if max_area > 200: #467
            rect = cv2.minAreaRect(areaMaxContour_max) #468
            box = np.int0(cv2.boxPoints(rect)) #469
            centerX = int(map_value(rect[0][0], 0, self.size[0], 0, img_w)) #470
            centerY = int(map_value(rect[0][1], 0, self.size[1], 0, img_h)) #471
            sideX = int(map_value(rect[1][0], 0, self.size[0], 0, img_w)) #472
            sideY = int(map_value(rect[1][1], 0, self.size[1], 0, img_h)) #473
            angle = rect[2] #474
            for i in range(4): #475
                box[i, 1] = int(map_value(box[i, 1], 0, self.size[1], 0, img_h)) #476
            for i in range(4): #477
                box[i, 0] = int(map_value(box[i, 0], 0, self.size[0], 0, img_w)) #478
            cv2.drawContours(img, [box], -1, (0, 0, 255), 2) #479
            if color_area_max == 'red': #480
                color = 1 #481
            elif color_area_max == 'green': #482
                color = 2 #483
            elif color_area_max == 'blue': #484
                color = 3 #485
            else: #486
                color = 0 #487
            self.color_list.append(color) #488
            if len(self.color_list) == 3: #489
                color = int(round(np.mean(np.array(self.color_list)))) #490
                self.color_list = [] #491
                if color == 1: #492
                    self.detect_color = 'red' #493
                    self.draw_color = self.range_rgb["red"] #494
                elif color == 2: #495
                    self.detect_color = 'green' #496
                    self.draw_color = self.range_rgb["green"] #497
                elif color == 3: #498
                    self.detect_color = 'blue' #499
                    self.draw_color = self.range_rgb["blue"] #500
                else: #501
                    self.detect_color = 'None' #502
                    self.draw_color = self.range_rgb["black"] #503
        else: #504
            self.detect_color = 'None' #505
            self.draw_color = self.range_rgb["black"] #506
        if self.detect_color == self.__target_color[0]: #507
            self.haved_detect = True #508
            if sideX > sideY: #509
                self.target_info = {'centerX': centerX, 'centerY': centerY, 'sideX': sideX, 'sideY': sideY, 'scale': sideX/sideY, 'angle': angle} #510
            else: #511
                self.target_info = {'centerX': centerX, 'centerY': centerY, 'sideX': sideX, 'sideY': sideY, 'scale': sideY/sideX, 'angle': angle} #512
        else: #513
            self.haved_detect = False #514
        cv2.putText(img, "Color: " + self.detect_color, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, self.draw_color, 2) #515
        return img #516

    def getAreaMaxContour(self, contours): #518
        contour_area_temp = 0 #519
        contour_area_max = 0 #520
        area_max_contour = None #521
        for c in contours: #522
            contour_area_temp = math.fabs(cv2.contourArea(c)) #523
            if contour_area_temp > contour_area_max: #524
                contour_area_max = contour_area_temp #525
                if contour_area_temp >= 5: #526
                    area_max_contour = c #527
        return area_max_contour, contour_area_max #528

    def image_callback(self, ros_image): #530
        cv2_img = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #531
        frame = cv2_img.copy() #532
        frame_result = frame #533
        
        if not self.thread_started: #535
            self.thread = threading.Thread(target=self.move) #536
            self.thread.start() #537
            self.thread_started = True  #538
        
        if self.enable_running:              #540
            frame_result = self.run(frame)                         #541
            cv2.imshow('Frame', frame_result)            #542
            cv2.waitKey(1) #543
            
        else: #545
            
            cv2.destroyAllWindows() #547

    def destroy_node(self): #549
        self.is_shutdown = True #550
        velocity_msg = Velocity() #551
        velocity_msg.x = 0.0 #552
        velocity_msg.y = 0.0 #553
        velocity_msg.yaw_rate = 0.0 #554
        self.PuppyVelocityPub.publish(velocity_msg) #555
        super().destroy_node() #556
        rclpy.shutdown() #557
        #sys.exit(0) #558

def main(args=None): #560
    rclpy.init(args=args) #561
    kick_ball_demo = KickBallDemo() #562
    try: #563
        executor = MultiThreadedExecutor() #564
        executor.add_node(kick_ball_demo) #565
        executor.spin() #566
        #rclpy.spin(kick_ball_demo) #567
    except KeyboardInterrupt: #568
        pass #569
    finally: #570
        #kick_ball_demo.destroy_node() #571
        kick_ball_demo.destroy_node() #572
        rclpy.shutdown() #573

if __name__ == '__main__': #575
    main() #576
