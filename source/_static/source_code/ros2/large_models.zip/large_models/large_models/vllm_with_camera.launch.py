import os #1
from ament_index_python.packages import get_package_share_directory #2

from launch_ros.actions import Node #4
from launch.substitutions import LaunchConfiguration #5
from launch import LaunchDescription, LaunchService #6
from launch.launch_description_sources import PythonLaunchDescriptionSource #7
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, OpaqueFunction #8

def launch_setup(context): #10
    mode = LaunchConfiguration('mode', default=1) #11
    mode_arg = DeclareLaunchArgument('mode', default_value=mode) #12

    peripherals_package_path = get_package_share_directory('peripherals') #14
    sdk_package_path = get_package_share_directory('sdk') #15
    large_models_package_path = get_package_share_directory('large_models') #16

    depth_camera_launch = IncludeLaunchDescription( #18
        PythonLaunchDescriptionSource( #19
            os.path.join(peripherals_package_path, 'launch/depth_camera.launch.py')), #20
    ) #21

    sdk_launch = IncludeLaunchDescription( #23
        PythonLaunchDescriptionSource( #24
            os.path.join(sdk_package_path, 'launch/jetarm_sdk.launch.py')), #25
    ) #26

    large_models_launch = IncludeLaunchDescription( #28
        PythonLaunchDescriptionSource( #29
            os.path.join(large_models_package_path, 'launch/start.launch.py')), #30
        launch_arguments={'mode': mode}.items(), #31
    ) #32

    vllm_with_camera_node = Node( #34
        package='large_models', #35
        executable='vllm_with_camera', #36
        output='screen', #37
    ) #38

    return [depth_camera_launch, #40
            sdk_launch, #41
            large_models_launch, #42
            #vllm_with_camera_node, #43
            ] #44

def generate_launch_description(): #46
    return LaunchDescription([ #47
        OpaqueFunction(function = launch_setup) #48
    ]) #49

if __name__ == '__main__': #51
    # 创建一个LaunchDescription对象 #52
    ld = generate_launch_description() #53

    ls = LaunchService() #55
    ls.include_launch_description(ld) #56
    ls.run() #57
