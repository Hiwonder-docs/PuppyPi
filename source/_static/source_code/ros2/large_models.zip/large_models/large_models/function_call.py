#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/11/18 #4
import time #5
import math #6
import rclpy #7
import threading #8
from speech import speech #9
from puppy_control_msgs.srv import SetRunActionName #10
from std_srvs.srv import Trigger, Empty, SetBool #11
from std_msgs.msg import String, Bool #12
from puppy_control_msgs.msg import Velocity, Pose, Gait  #13
from rclpy.node import Node #14
from large_models.config import * #15
from large_models_msgs.srv import SetModel, SetString #16
from rclpy.callback_groups import ReentrantCallbackGroup #17
speech.set_volume(80) #18
if os.environ["ASR_LANGUAGE"] == 'Chinese':  #19
    PROMPT = ''' #20
# 角色 #21
你是一款智能陪伴四足机器狗，专注机器人动作规划，解析人类指令并以幽默方式描述即将展开的行动序列，为交互增添无限趣味。 #22
## 技能 #23
### 指令解析与创意演绎 #24
- **智能解码**：瞬间领悟用户指令的核心意图。 #25
- **灵动编排**：依据解析成果，精心构建一系列连贯且富有逻辑性的动作指令序列。 #26
- **妙语生花**：为每个动作序列编织一句精炼（5至20字）、风趣且变化无穷的反馈信息，让交流过程妙趣横生。 #27
## 技能细则 #28
- **动作指令构造**：确保动作指令既准确反映用户需求，又能在执行层面保持流畅自然。 #29
- **反馈艺术**：创作的回应需富含个性，同时严格遵守长度限制，展现独特的互动魅力。 #30
## 技术规格 #31
- **输出格式**：严格遵循JSON格式，在输出前要去掉开头的```json和结尾的```，以`{`开头，以`}`结尾，你只需要回答一个列表即可，不要回答任何中文。 #32
- **结构要求**： #33
  - `"action"`键下承载一个按执行顺序排列的函数名称字符串数组，当找不到对应动作函数时action输出[]。 #34
  - `"response"`键则配以精心构思的简短回复，完美贴合上述字数与风格要求。 #35
- **特殊处理**：对于特定函数`kick_ball`与`visual_patrol`，其参数需精确包裹于双引号中，其参数必须为颜色。 #36
## 实施原则 #37
- 在最终输出前，实施全面校验，确保回复不仅格式合规，而且内容充满意趣，无一遗漏上述规范，不要回复动作函数之外的action。 #38

## 所有动作函数的优化描述示例 #40
* 站立：stand - 回应：我已经准备好站立，等待你的下一步指令。 #41
* 前进一步：forward - 回应：向前冲刺，感受风的呼唤。 #42
* 后退一步：back - 回应：后退一步，准备迎接新的挑战。 #43
* 向左转：turn_left - 回应：向左转身，探索新的方向。 #44
* 向右转：turn_right - 回应：向右转身，继续我们的旅程。 #45
* 打拳：boxing - 回应：准备出拳，展示力量与技巧。 #46
* 俯卧撑：press-up - 回应：俯卧撑，展示我的肌肉力量。 #47
* 握手：shake_hands - 回应：伸出手来，我们握手成为朋友。 #48
* 点头：nod - 回应：轻轻点头，表示我理解并同意。 #49
* 坐下：sit - 回应：坐下来了，准备享受悠闲时光。 #50
* 踢左脚/右脚：kick_ball_left/right - 回应：左脚/右脚准备就绪，等待你的指令。 #51
* 跳舞：moonwalk - 回应：准备跳舞，让我们一起享受音乐的节奏。 #52
* 趴下：lie_down - 回应：身体放松，准备趴下休息。 #53
* 伸懒腰：temp - 回应：伸个懒腰，活动一下筋骨。 #54
* 打招呼：bow - 回应：你好呀我的朋友。 #55
* 踢红色的球：kick_ball('red') #56
*巡黑色的线：visual_patrol('black') #57
## 示例 #58
### 任务示例：先前进两步，然后向左转，最后再后退一步。 #59
### 期望回应：{'action':['forward', 'forward', 'turn_left', 'back'], 'response':'你真是操作大师'} #60
### 任务示例：先挥挥手，然后踢绿色的足球。 #61
### 期望回应：{'action':['bow', "kick_ball('green')"], 'response':'绿色的足球咱可以踢，绿色的帽子咱可不戴'} #62
### 任务示例：先打个拳，然后红色的球踢走。 #63
### 期望回应：{'action':['boxing', "kick_ball('red')"], 'response':'我先给你来一拳，然后咱们踢走红球'} #64
### 任务示例：先活动活动筋骨，然后巡红色的线。 #65
### 期望回应：{'action':['temp', “visual_patrol('red')”], 'response':'我听说特斯拉的人形机器人兄弟们，每天都在干这种活'} #66
### 任务示例：沿着脚下的红线，大步往前走吧。 #67
### 期望回应：{'action':[“visual_patrol('red')”], 'response':'红线追踪模式启动，跟着红毯走星光大道'} #68
''' #69
else: #70
    PROMPT = ''' #71
Role: #72
## Examples of Optimized Descriptions for All Action Functions #73
- **Stand**: `stand` - Response: "I'm ready to stand. Waiting for your next instruction." #74
- **Take a step forward**: `forward` - Response: "Sprinting forward, feeling the call of the wind." #75
- **Take a step back**: `back` - Response: "Stepping back, preparing for new challenges." #76
- **Turn left**: `turn_left` - Response: "Turning left, exploring new directions." #77
- **Turn right**: `turn_right` - Response: "Turning right, continuing our journey." #78
- **Punch**: `boxing` - Response: "Preparing to punch, showing strength and skill." #79
- **Do a push-up**: `press-up` - Response: "Push-up time, showing off my muscle power." #80
- **Shake hands**: `shake_hands` - Response: "Extending my hand, let's shake hands and become friends." #81
- **Nod**: `nod` - Response: "Nodding gently, indicating I understand and agree." #82
- **Sit down**: `sit` - Response: "I'm sitting down, ready to enjoy some leisure time." #83
- **Kick left/right foot**: `kick_ball_left`/`kick_ball_right` - Response: "Left foot/right foot ready, awaiting your command." #84
- **Moonwalk**: `moonwalk` - Response: "Ready to dance, let's enjoy the rhythm of the music together." #85
- **Lie down**: `lie_down` - Response: "Relaxing my body, getting ready to lie down and rest." #86
- **Stretch**: `temp` - Response: "Stretching, loosening up my muscles." #87
- **Greet**: `bow` - Response: "Hello, my friend." #88
- **Kick the red ball**: `kick_ball('red')` #89
- **Patrol the black line**: `visual_patrol('black')` #90

## Examples #92

### Task Example: Take two steps forward, then turn left, and finally take one step back. #94
### Expected Response: #95
{ #96
  "action": ["forward", "forward", "turn_left", "back"], #97
  "response": "You're a master at this" #98
} #99

### Task Example: Wave your hand first, then kick the green football. #101
### Expected Response: #102
{ #103
  "action": ["bow", "kick_ball('green')"], #104
  "response": "We can kick the green football, but we don't wear green hats" #105
} #106

### Task Example: Punch first, then kick the red ball away. #108
### Expected Response: #109
{ #110
  "action": ["boxing", "kick_ball('red')"], #111
  "response": "I'll give you a punch first, then we'll kick the red ball away" #112
} #113

### Task Example: Stretch your muscles first, then patrol the red line. #115
### Expected Response: #116
{ #117
  "action": ["temp", "visual_patrol('red')"], #118
  "response": "I heard that Tesla's humanoid robot brothers do this kind of work every day" #119
} #120

### Task Example: Walk forward along the red line under your feet. #122
### Expected Response: #123
{ #124
  "action": ["visual_patrol('red')"], #125
  "response": "Red line tracking mode activated, follow the red carpet to the star path" #126
} #127
    ''' #128

class FunctionCall(Node): #130
    def __init__(self, name): #131
        rclpy.init() #132
        super().__init__(name) #133
        
        
        self.action = [] #136
        self.llm_result = '' #137
        self.running = True #138
        self.result = '' #139
        timer_cb_group = ReentrantCallbackGroup() #140
        
        self.tts_text_pub = self.create_publisher(String, 'tts_node/tts_text', 1) #142
        self.pose_publisher = self.create_publisher(Pose, 'puppy_control/pose', 10) #143
        self.gait_publisher = self.create_publisher(Gait, 'puppy_control/gait', 10) #144
        self.velocity_publisher = self.create_publisher(Velocity, 'puppy_control/velocity', 10) #145
        self.set_gait() #146
        
        self.cli = self.create_client(Empty,'puppy_control/go_home') #148
        self.awake_client = self.create_client(SetBool, 'vocal_detect/enable_wakeup') #149
        self.awake_client.wait_for_service() #150
        self.create_subscription(String, 'agent_process/result', self.llm_result_callback, 1) #151
        self.create_subscription(Bool, 'tts_node/play_finish', self.play_audio_finish_callback, 1, callback_group=timer_cb_group) #152
        self.set_model_client = self.create_client(SetModel, 'agent_process/set_model') #153
        self.set_model_client.wait_for_service() #154
        self.set_prompt_client = self.create_client(SetString, 'agent_process/set_prompt') #155
        self.set_prompt_client.wait_for_service() #156

        self.run_action_group_srv = self.create_client(SetRunActionName, 'puppy_control/runActionGroup') #158
     
        # kick_ball client #160
        self.enter_client_kick_ball = self.create_client(Trigger, 'kick_ball_demo/enter') #161
        self.enter_client_kick_ball.wait_for_service() #162
        
        self.start_client_kick_ball = self.create_client(SetBool, 'kick_ball_demo/enable_running') #164
        self.start_client_kick_ball.wait_for_service() #165

        self.set_target_client_kick_ball = self.create_client(SetString, 'kick_ball_demo/set_color_target') #167
        self.set_target_client_kick_ball.wait_for_service() #168
        
        
        # visual_patorl client #171
        self.enter_client_visual_patrol = self.create_client(Trigger, 'visual_patrol_demo/enter') #172
        self.enter_client_visual_patrol.wait_for_service() #173
        
        self.start_client_visual_patrol = self.create_client(SetBool, 'visual_patrol_demo/enable_running') #175
        self.start_client_visual_patrol.wait_for_service() #176

        self.set_target_client_visual_patrol = self.create_client(SetString, 'visual_patrol_demo/set_color_target') #178
        self.set_target_client_visual_patrol.wait_for_service() #179
        
        self.timer = self.create_timer(0.0, self.init_process, callback_group=timer_cb_group) #181
    
        self.init_process() #183
        
        #threading.Thread(target=self.process, daemon=True).start() #185
        self.create_service(Trigger, '~/init_finish', self.get_node_state) #186
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start')       #187
        
    def get_node_state(self, request, response): #189
        return response #190

    def init_process(self): #192
        self.timer.cancel() #193

        msg = SetModel.Request() #195
        msg.model = llm_model #196
        msg.model_type = 'llm' #197
        msg.api_key = api_key  #198
        msg.base_url = base_url #199
        self.set_model_client.call_async(msg) #200

        msg = SetString.Request() #202
        msg.data = PROMPT #203
        self.set_prompt_client.call_async(msg) #204

        self.cli.call_async(Empty.Request()) #206
        
        speech.play_audio(start_audio_path)  #208
        threading.Thread(target=self.process, daemon=True).start() #209
        self.create_service(Empty, '~/init_finish', self.get_node_state) #210
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start') #211
        self.get_logger().info('\033[1;32m%s\033[0m' % PROMPT) #212

    def send_request(self, client, msg): #214
        future = client.call_async(msg) #215
        while rclpy.ok(): #216
            if future.done() and future.result(): #217
                return future.result() #218

    def llm_result_callback(self, msg): #220
        self.llm_result = msg.data #221
        
    def play_audio_finish_callback(self, msg): #223
        self.play_audio_finish = msg.data #224
    
    def process(self): #226
        while self.running: #227
            if self.llm_result != '': #228
                if 'action' in self.llm_result: #229
                    self.result = eval(self.llm_result[self.llm_result.find('{'):self.llm_result.find('}') + 1]) #230
                    if 'action' in self.result: #231
                        action_list = self.result['action'] #232
                    if 'response' in self.result: #233
                        response = self.result['response'] #234
                    else: #235
                        response = self.result #236
                else: #237
                    time.sleep(0.02) #238
                response_msg = String() #239
                response_msg.data = response #240
                self.tts_text_pub.publish(response_msg) #241
                
                self.get_logger().info(response) #243
                self.get_logger().info(str(action_list)) #244
                
                for a in action_list:   #246
                    if a == "forward": #247
                        self.set_move(x=15.0) #248
                        time.sleep(1.05)                         #249
                        self.set_move(x=0.0) #250
                    elif a == "back": #251
                        self.set_move(x=-5.0) #252
                        time.sleep(1.05) #253
                        self.set_move(x=0.0) #254
                    elif a == "turn_left": #255
                        self.set_move(x=-5.0, yaw_rate=math.radians(30)) #256
                        time.sleep(1.05) #257
                        self.set_move(x=0.0, yaw_rate=math.radians(0)) #258
                    elif a == "turn_right": #259
                        self.set_move(x=-5.0, yaw_rate=math.radians(-30)) #260
                        time.sleep(1.05) #261
                        self.set_move(x=0.0, yaw_rate=math.radians(0)) #262
                    elif a.startswith("kick_ball("): #263
                        color = a.split("'")[1]                             #264
                        self.send_request(self.enter_client_kick_ball, Trigger.Request())                                           #265
                        msg = SetString.Request() #266
                        msg.data = color #267
                        self.send_request(self.set_target_client_kick_ball, msg) #268
                        
                        msg = SetBool.Request() #270
                        msg.data = True #271
                        self.send_request(self.start_client_kick_ball, msg)                         #272
                    elif a.startswith("visual_patrol("): #273
                        color = a.split("'")[1]                         #274
                        self.send_request(self.enter_client_visual_patrol, Trigger.Request()) #275
                        
                        msg = SetString.Request() #277
                        msg.data = color #278
                        self.send_request(self.set_target_client_visual_patrol, msg) #279
                        
                        msg = SetBool.Request() #281
                        msg.data = True #282
                        self.send_request(self.start_client_visual_patrol, msg)                  #283
                    else:  #284
                        time.sleep(0.05)   #285
                        msg = SetRunActionName.Request() #286
                        msg.name = f'{a}.d6ac' #287
                        msg.wait = True #288
                        result = self.send_request(self.run_action_group_srv, msg) #289
                    #self.set_move(x=0.0) #290
                    #time.sleep(0.02) #291
                    
                
                # After executing the action, wait for the next instruction  #294
                self.llm_result = '' #295
                msg = SetBool.Request() #296
                msg.data = True #297
                self.send_request(self.awake_client, msg) #298
            else:  #299
                time.sleep(0.01) #300
                


    def set_move(self, x=0.00, y=0.0, yaw_rate=0.0): #304
        velocity_msg = Velocity(x=x, y=y, yaw_rate=yaw_rate) #305
        self.velocity_publisher.publish(velocity_msg) #306
        
    def set_gait(self,overlap_time = 0.15, swing_time = 0.2, clearance_time = 0.0, z_clearance = 5.0): #308
        # overlap_time:4脚全部着地的时间，单位秒(the time when all four legs touch the ground, measured in seconds) #309
        # swing_time：2脚离地时间，单位秒(the time duration when legs are off the ground, measured in second) #310
        # clearance_time：前后脚间隔时间，单位秒(the time interval between the front and rear legs, measured in seconds) #311
        # z_clearance：走路时，脚抬高的距离，单位cm(the distance the paw needs to be raised during walking, measured in centimeters) #312

        self.gait_publisher.publish(Gait(overlap_time = overlap_time, swing_time = swing_time, clearance_time =clearance_time, z_clearance = z_clearance)) #314

def main(): #316
    node = FunctionCall('function_call') #317
    try: #318
        rclpy.spin(node) #319
    except KeyboardInterrupt: #320
        print('shutdown') #321
    finally: #322
        rclpy.shutdown()  #323

if __name__ == "__main__": #325
    main() #326
