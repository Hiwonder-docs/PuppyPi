#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/11/18 #4
import time #5
import rclpy #6
import threading #7
from rclpy.node import Node #8
from std_msgs.msg import Int32, String, Bool #9
from std_srvs.srv import SetBool, Trigger, Empty #10

from speech import awake #12
from speech import speech #13
from large_models.config import * #14
from large_models_msgs.srv import SetInt32 #15

class VocalDetect(Node): #17
    def __init__(self, name): #18
        rclpy.init() #19
        super().__init__(name) #20

        self.running = True #22

        # 声明参数 #24
        self.declare_parameter('awake_method', 'xf') #25
        self.declare_parameter('mic_type', 'mic6_circle') #26
        self.declare_parameter('port', '/dev/ring_mic') #27
        self.declare_parameter('enable_wakeup', True) #28
        self.declare_parameter('enable_setting', False) #29
        self.declare_parameter('awake_word', 'hello hi wonder') #30
        self.declare_parameter('mode', 1) #31

        self.awake_method = self.get_parameter('awake_method').value #33
        mic_type = self.get_parameter('mic_type').value #34
        port = self.get_parameter('port').value #35
        awake_word = self.get_parameter('awake_word').value #36
        enable_setting = self.get_parameter('enable_setting').value  #37
        self.enable_wakeup = self.get_parameter('enable_wakeup').value #38
        self.mode = int(self.get_parameter('mode').value) #39

        if self.awake_method == 'xf': #41
            self.kws = awake.CircleMic(port, awake_word, mic_type, enable_setting) #42
        else: #43
            self.kws = awake.WonderEchoPro(port)  #44
        
        self.language = os.environ["ASR_LANGUAGE"]  #46
        if self.awake_method == 'xf': #47
            if self.language == 'Chinese': #48
                self.asr = speech.RealTimeASR(log=self.get_logger()) #49
            else: #50
                self.asr = speech.RealTimeOpenAIASR(log=self.get_logger()) #51
                self.asr.update_session(model=asr_model, language='en') #52
        else: #53
            if self.language == 'Chinese': #54
                self.asr = speech.RealTimeASR(log=self.get_logger()) #55
            else: #56
                self.asr = speech.RealTimeOpenAIASR(log=self.get_logger()) #57
                self.asr.update_session(model=asr_model, language='en') #58
        
        self.asr_pub = self.create_publisher(String, '~/asr_result', 1) #60
        self.wakeup_pub = self.create_publisher(Bool, '~/wakeup', 1) #61
        self.awake_angle_pub = self.create_publisher(Int32, '~/angle', 1) #62
        self.create_service(SetInt32, '~/set_mode', self.set_mode_srv) #63
        self.create_service(SetBool, '~/enable_wakeup', self.enable_wakeup_srv) #64

        threading.Thread(target=self.pub_callback, daemon=True).start() #66
        self.create_service(Empty, '~/init_finish', self.get_node_state) #67
        
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start') #69

    def get_node_state(self, request, response): #71
        return response #72

    def record(self, mode, angle=None): #74
        self.get_logger().info('\033[1;32m%s\033[0m' % 'asr...') #75
        if self.language == 'Chinese': #76
            asr_result = self.asr.asr(model=asr_model)  # 开启录音并识别 #77
        else: #78
            asr_result = self.asr.asr() #79
        if asr_result:  #80
            speech.play_audio(dong_audio_path) #81
            if self.awake_method == 'xf' and self.mode == 1:  #82
                msg = Int32() #83
                msg.data = int(angle) #84
                self.awake_angle_pub.publish(msg) #85
            asr_msg = String() #86
            asr_msg.data = asr_result #87
            self.asr_pub.publish(asr_msg) #88
            self.enable_wakeup = False #89
            self.get_logger().info('\033[1;32m%s\033[0m' % 'publish asr result:' + asr_result) #90
        else: #91
            self.get_logger().info('\033[1;32m%s\033[0m' % 'no voice detect') #92
            speech.play_audio(dong_audio_path) #93
            if mode == 1: #94
                speech.play_audio(no_voice_audio_path) #95

    def pub_callback(self): #97
        self.kws.start() #98
        while self.running: #99
            if self.enable_wakeup: #100
                if self.mode == 1: #101
                    result = self.kws.wakeup() #102
                    if result: #103
                        self.wakeup_pub.publish(Bool(data=True)) #104
                        speech.play_audio(wakeup_audio_path)  # 唤醒播放 #105
                        self.record(self.mode, result) #106
                    else: #107
                        time.sleep(0.02) #108
                elif self.mode == 2: #109
                    self.record(self.mode) #110
                    self.mode = 1 #111
                elif self.mode == 3: #112
                    self.record(self.mode) #113
                else: #114
                    time.sleep(0.02) #115
            else: #116
                time.sleep(0.02) #117
        rclpy.shutdown() #118

    def enable_wakeup_srv(self, request, response): #120
        self.get_logger().info('\033[1;32m%s\033[0m' % ('enable_wakeup')) #121
        self.kws.start() #122
        self.enable_wakeup = request.data #123
        response.success = True #124
        return response  #125

    def set_mode_srv(self, request, response): #127
        self.get_logger().info(f'\033[1;32mset mode: {request.data}\033[0m') #128
        self.kws.start() #129
        self.mode = int(request.data) #130
        if self.mode != 1: #131
            self.enable_wakeup = True #132
        response.success = True #133
        return response  #134

def main(): #136
    node = VocalDetect('vocal_detect') #137
    try: #138
        rclpy.spin(node) #139
    except KeyboardInterrupt: #140
        print('shutdown') #141
    finally: #142
        rclpy.shutdown()  #143

if __name__ == "__main__": #145
    main() #146
