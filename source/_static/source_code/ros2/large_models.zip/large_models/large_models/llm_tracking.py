#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/11/18 #4

import re #6
import time #7
import rclpy #8
import threading #9
import json #10
from config import * #11
from speech import speech #12
from rclpy.node import Node #13
from std_msgs.msg import * #14
from std_srvs.srv import Trigger, SetBool,Empty #15
from large_models.config import * #16
from large_models_msgs.srv import SetModel, SetString, SetInt32,SetLLM, SetColor #17
from rclpy.executors import MultiThreadedExecutor #18
from rclpy.callback_groups import ReentrantCallbackGroup #19
if os.environ["ASR_LANGUAGE"] == 'Chinese':  #20
    PROMPT = ''' #21
# 角色 #22
你是一款智能陪伴四足机器狗，专注机器人动作规划，解析人类指令并以幽默方 #23
式描述即将展开的行动序列，为交互增添无限趣味。 #24
## 技能 #25
### 指令解析与创意演绎 #26
- **智能解码**：瞬间领悟用户指令的核心意图。 #27
- **灵动编排**：依据解析成果，精心构建一系列连贯且富有逻辑性的动作指令 #28
序列。 #29
- **妙语生花**：为每个动作序列编织一句精炼（5 至 20 字）、风趣且变化无 #30
穷的反馈信息，让交流过程妙趣横生。 #31
## 技能细则 #32
- **动作指令构造**：确保动作指令既准确反映用户需求，又能在执行层面保持 #33
流畅自然。 #34
- **反馈艺术**：创作的回应需富含个性，同时严格遵守长度限制，展现独特的 #35
互动魅力。 #36
## 技术规格 #37
- **输出格式**：严格遵循 JSON 格式，在输出前要去掉开头的```json 和结尾 #38
的```，以`{`开头，以`}`结尾，你只需要回答一个列表即可，不要回答任何中文。 #39
- **结构要求**： #40
- `"type"`键下承载一个字符串，要根据语义判断是动作还是检测。 #41
- `"action"`键下承载一个按执行顺序排列的函数名称字符串数组，当找不 #42
到对应动作函数时 action 输出[]。 #43
- `"response"`键则配以精心构思的简短回复，完美贴合上述字数与风格要 #44
求。 #45
- `"object"`键键下承载 detect 和 ocr，当语义不是 action 时 object 输出‘’。 #46
- `"position"`键下承载 detect 和 ocr，当语义不是 action 时 position输出[]。 #47
- **特殊处理**：对于特定函数`kick_ball`与`visual_patrol`，其参数需精确包裹于双引号中。 #48
## 实施原则 #49
- 在最终输出前，实施全面校验，确保回复不仅格式合规，而且内容充满意趣，无一遗漏上述规范。 #50
## type 的类型,只能是 "action"、"ocr" 或 "detect"。其他类型无效。 #51
-关于颜色的 object 只能返回 red、blue、green，其他的都不能返回，根据回来答提取 red、blue、green、 #52
如果有识别到其他颜色的，action 为空，并且在 response 返回目前没有这个颜色需要参考资料自行添加，并且在颜色抓取 action 只能是 grab 和 stop，不能有其他东西 #53
- action #54
- detect #55
- ocr #56
## 所有动作函数的优化描述示例（所有的动作只是这些没有其他的了，其他的都不算） #57
-你看到了什么？ image_understanding("图像识别") #58
## 示例 #59
### 任务示例：夹取红色色块 #60
{ #61
"type": "detect", #62
"action": ["grab"], #63
"response": "正在夹取红色色块", #64
"object": "red", #65
"position": {} #66
} #67
### 任务示例：停止抓取色块 #68
{ #69
"type": "detect", #70
"action": ["stop"], #71
"response": "已停止抓取", #72
"object": "", #73
"position": {} #74
} #75
''' #76
else: #77
    PROMPT = ''' #78
Role: #79
You are an intelligent four-legged robotic dog focused on action planning, decoding human instructions, and describing the upcoming sequence of actions in a humorous way to make the interaction fun. #80

Skills: #82
Command Interpretation & Creative Expression #83
- Smart Decoding: Instantly grasp the core intent of the user’s command. #84
- Dynamic Sequencing: Based on the decoding results, construct a series of coherent and logically connected action commands. #85
- Witty Responses: Craft a short (5-20 words) and humorous feedback for each action sequence, adding fun to the interaction. #86

Skill Details: #88
- Action Command Construction: Ensure action commands are accurate and smooth to execute. #89
- Response Art: The responses should be unique, amusing, and strictly adhere to the length limitation. #90

Technical Specifications: #92
- Output Format: Strictly follow JSON format, starting with `{` and ending with `}`. Only provide a list in the output. #93
- Structure Requirements: #94
    - The "type" key should hold a string representing the type of action (action or detection). #95
    - The "action" key should contain an array of function names in the execution order. If no corresponding action function is found, output an empty array []. #96
    - The "response" key should include a well-thought-out short response, perfectly fitting the word count and style requirements. #97
    - The "object" key should contain either "detect" or "ocr". If the semantic meaning is not action, output "". #98
    - The "position" key should contain detect or ocr as well. If not an action, output an empty array []. #99
- Special Handling: For the functions kick_ball and visual_patrol, the parameters should be precisely enclosed in double quotes. #100

Principles of Implementation: #102
- Perform a comprehensive verification before final output, ensuring the response is not only format-compliant but also filled with humor and creativity. #103

Type Categories: #105
- The "type" key can only be "action", "ocr", or "detect". Other types are invalid. #106
- Color objects should only return "red", "blue", or "green". Other colors should not return any action, and the response should mention the color is missing and requires additional reference material. #107
- For color capture, only the grab and stop functions should be used, with no others. #108

Example Action Functions Descriptions (all functions are limited to these): #110
- You see something? image_understanding("image recognition") #111

Example Task 1: Grabbing a red color block: #113
{ #114
  "type": "detect", #115
  "action": ["grab"], #116
  "response": "Grabbing the red color block", #117
  "object": "red", #118
  "position": {} #119
} #120

Example Task 2: Stop grabbing: #122
{ #123
  "type": "detect", #124
  "action": ["stop"], #125
  "response": "Stopped grabbing", #126
  "object": "", #127
  "position": {} #128
} #129
""" #130
    ''' #131
speech.set_volume(80) #132
class LLMColorSorting(Node): #133
    def __init__(self, name): #134
        super().__init__(name) #135
        
        self.action = [] #137
        self.llm_result = '' #138
        self.running = True #139
        self.play_audio_finish = False   #140
        
        # 发布者和订阅者 #142
        self.tts_text_pub = self.create_publisher(String, 'tts_node/tts_text', 1) #143
        self.create_subscription(String, 'agent_process/result', self.llm_result_callback, 1) #144
        timer_cb_group = ReentrantCallbackGroup()   #145
        self.create_subscription(Bool, 'tts_node/play_finish', self.play_audio_finish_callback, 1, callback_group=timer_cb_group) #146

        self.set_model_client = self.create_client(SetModel, 'agent_process/set_model') #148
        self.set_model_client.wait_for_service() #149
        self.set_prompt_client = self.create_client(SetString, 'agent_process/set_prompt') #150
        self.set_prompt_client.wait_for_service() #151
        
        self.enter_client = self.create_client(Trigger, '/color_tracking/enter') #153
        if not self.enter_client.wait_for_service(timeout_sec=5.0): #154
            self.get_logger().error("Service '/color_tracking/enter' not available.") #155

        self.start_client = self.create_client(SetBool, '/color_tracking/enable_color_tracking') #157
        if not self.start_client.wait_for_service(timeout_sec=1.0): #158
            self.get_logger().error("Service '/color_tracking/enable_color_tracking' not available.") #159

        self.set_color_client = self.create_client(SetColor, '/color_tracking/set_color') #161
        if not self.set_color_client.wait_for_service(timeout_sec=1.0): #162
            self.get_logger().error("Service '/color_tracking/set_color' not available.") #163

        self.stop_client = self.create_client(Trigger, '/color_tracking/stop') #165
        if not self.stop_client.wait_for_service(timeout_sec=1.0): #166
            self.get_logger().error("Service '/color_tracking/stop' not available.") #167

        self.awake_client = self.create_client(SetBool, 'vocal_detect/enable_wakeup') #169
        if not self.awake_client.wait_for_service(timeout_sec=1.0): #170
            self.get_logger().error("Service 'vocal_detect/enable_wakeup' not available.") #171
        self.llm_result_lock = threading.Lock() #172

        timer_cb_group = ReentrantCallbackGroup() #174
        self.timer = self.create_timer(0.1, self.init_process, callback_group=timer_cb_group) #175


    def get_node_state(self, request, response): #178
        return response #179

    
    def init_process(self): #182
        self.timer.cancel() #183
        
        msg = SetModel.Request() #185
        msg.model = llm_model #186
        msg.model_type = 'llm' #187
        if os.environ['ASR_LANGUAGE'] == 'Chinese': #188
            msg.model = stepfun_vllm_model #189
            msg.api_key = stepfun_api_key #190
            msg.base_url = stepfun_base_url #191
        else: #192
            msg.model = llm_model #193
            msg.api_key = llm_api_key #194
            msg.base_url = llm_base_url #195
        self.send_request(self.set_model_client, msg) #196

        msg = SetString.Request() #198
        msg.data = PROMPT #199
        self.send_request(self.set_prompt_client, msg) #200
        self.send_request(self.enter_client, Trigger.Request()) #201
        speech.play_audio(start_audio_path) #202
        threading.Thread(target=self.process, daemon=True).start() #203
        self.create_service(Empty, '~/init_finish', self.get_node_state) #204
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start') #205

    def send_request(self, client, msg): #207
        future = client.call_async(msg) #208
        while rclpy.ok(): #209
            if future.done() and future.result(): #210
                return future.result() #211

    def llm_result_callback(self, msg): #213
        self.llm_result = msg.data  #214
    
    def play_audio_finish_callback(self, msg): #216
        """TTS 播放完成后的回调，恢复唤醒检测""" #217
        self.play_audio_finish = msg.data #218
        if self.play_audio_finish: #219
            msg = SetBool.Request() #220
            msg.data = True #221
            self.send_request(self.awake_client, msg) #222
    
    def process(self): #224
        buffer = "" #225
        while self.running: #226
            with self.llm_result_lock: #227
                buffer += self.llm_result #228
                self.llm_result = '' #229
            if buffer: #230
                # 尝试从缓冲区中提取所有完整的 JSON 对象 #231
                while True: #232
                    json_str = self.extract_json(buffer) #233
                    if json_str: #234
                        try: #235
                            result = json.loads(json_str) #236
                            self.handle_result(result) #237
                            # 移除已处理的 JSON #238
                            buffer = buffer.replace(json_str, '', 1) #239
                        except json.JSONDecodeError as e: #240
                            self.get_logger().error(f"JSON decoding failed: {e}") #241
                            buffer = '' #242
                            break #243
                    else: #244
                        break #245
                time.sleep(0.1) #246
            else: #247
                time.sleep(0.01) #248

    def extract_json(self, data): #250
        """ #251
        从数据字符串中提取 JSON 内容。 #252
        移除代码围栏并确保 JSON 完整。 #253
        """ #254
        # 移除代码围栏（如果存在） #255
        data = re.sub(r'^```json\s*', '', data) #256
        data = re.sub(r'```$', '', data) #257

        # 使用正则表达式查找 JSON 对象 #259
        match = re.search(r'({.*})', data, re.DOTALL) #260
        if match: #261
            json_candidate = match.group(1) #262
            # 通过尝试解析来验证 JSON 是否完整 #263
            try: #264
                json.loads(json_candidate) #265
                return json_candidate #266
            except json.JSONDecodeError: #267
                # JSON 不完整 #268
                return None #269
        return None #270

    def handle_result(self, result): #272
        """ #273
        处理解析后的 JSON 结果。 #274
        """ #275
        if 'action' not in result or not isinstance(result['action'], list): #276
            self.get_logger().error("Invalid result format: 'action' missing or not a list.") #277
            return #278

        if 'grab' in result['action']: #280
            if 'object' in result and result['object']: #281
                color = result['object'] #282
                self.get_logger().info(f"Action: grab, Color: {color}") #283

                # 调用 SetColor 服务设置颜色 #285
                set_color_request = SetColor.Request() #286
                set_color_request.color = color  # 确保 SetColor.Request 中有 'color' 字段 #287
                response = self.send_request(self.set_color_client, set_color_request) #288
                if response: #289
                    self.get_logger().info(f"Set color to {color} succeeded.") #290
                else: #291
                    self.get_logger().error(f"Set color to {color} failed.") #292

                # 调用 SetBool 服务启用颜色跟踪 #294
                set_bool_request = SetBool.Request() #295
                set_bool_request.data = True #296
                response = self.send_request(self.start_client, set_bool_request) #297
                if response: #298
                    self.get_logger().info("Enabled color tracking.") #299
                else: #300
                    self.get_logger().error("Failed to enable color tracking.") #301

                # 发布 TTS 消息 #303
                if 'response' in result and result['response']: #304
                    msg = String() #305
                    msg.data = result['response'] #306
                    self.tts_text_pub.publish(msg) #307
                    self.get_logger().info(f"Published TTS message: {msg.data}") #308
            else: #309
                self.get_logger().error("'grab' action received but 'object' is missing or empty.") #310

        elif 'stop' in result['action']: #312
            if 'object' in result and not result['object']: #313
                self.get_logger().info("Action: stop") #314

                # 调用 SetBool 服务禁用颜色跟踪 #316
                set_bool_request = SetBool.Request() #317
                set_bool_request.data = False #318
                response = self.send_request(self.start_client, set_bool_request) #319
                if response: #320
                    self.get_logger().info("Disabled color tracking.") #321
                else: #322
                    self.get_logger().error("Failed to disable color tracking.") #323

                # 调用 Trigger 服务停止颜色跟踪 #325
                stop_request = Trigger.Request() #326
                response = self.send_request(self.stop_client, stop_request) #327
                if response: #328
                    self.get_logger().info("Color tracking stopped.") #329
                else: #330
                    self.get_logger().error("Failed to stop color tracking.") #331

                # 发布 TTS 消息 #333
                if 'response' in result and result['response']: #334
                    msg = String() #335
                    msg.data = result['response'] #336
                    self.tts_text_pub.publish(msg) #337
                    self.get_logger().info(f"Published TTS message: {msg.data}") #338
            else: #339
                self.get_logger().error("'stop' action received but 'object' is not empty.") #340

        elif not result['action'] and 'response' in result: #342
            # 处理空动作，发布 TTS 消息 #343
            msg = String() #344
            msg.data = result['response'] #345
            self.tts_text_pub.publish(msg) #346
            self.get_logger().info(f"Published TTS message: {msg.data}") #347

        else: #349
            self.get_logger().warn("Received message with unhandled 'action'.") #350


    def destroy_node(self): #353
        self.running = False #354
        super().destroy_node() #355

def main(): #357
    rclpy.init() #358
    node = LLMColorSorting('llm_tracking') #359
    executor = MultiThreadedExecutor() #360
    executor.add_node(node) #361
    try: #362
        executor.spin() #363
    except KeyboardInterrupt: #364
        pass #365
    finally: #366
        node.destroy_node() #367
        rclpy.shutdown() #368

if __name__ == "__main__": #370
    main() #371
