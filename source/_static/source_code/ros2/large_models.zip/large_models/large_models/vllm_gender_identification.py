#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: liang #3
# @Date: 2024/12/18 #4
import cv2 #5
import math #6
import json #7
import time #8
import queue #9
import rclpy #10
import threading #11
from config import * #12
import numpy as np #13
import sdk.fps as fps #14
from sdk import common #15
from std_msgs.msg import String, Bool #16
from  action import PuppyControlNode   #17
from rclpy.node import Node #18
from sensor_msgs.msg import Image #19
from std_srvs.srv import SetBool, Trigger, Empty #20
from rclpy.executors import MultiThreadedExecutor #21
from rclpy.callback_groups import ReentrantCallbackGroup #22
from cv_bridge import CvBridge #23
import subprocess #24
from speech import speech #25
from large_models.config import * #26
from large_models_msgs.srv import SetModel, SetString, SetInt32 #27
#from track_anything import ObjectTracker #28
from large_models_msgs.srv import SetString #29
from puppy_control_msgs.srv import SetRunActionName #30
speech.set_volume(70) #31
if os.environ["ASR_LANGUAGE"] == 'Chinese':  #32
    PROMPT = ''' #33
你作为智能机器人助手，可以识别出图像中的内容，并根据我的描述识别是男生还是女生。 #34
输出要求： #35
- 返回一个 JSON 对象，包含以下字段： #36
  - "type": 始终为 "detect" #37
  - "object": 识别到的目标物体名称，若未识别到则为 "None" #38
  - "action": 键下承载一个按执行顺序排列的函数名称字符串数组，当找不到对应动作函数时action输出[] #39
  - "response": 根据识别到目标是man还是woman进行回复 #40
如果指令包含动作需求，需根据指令提供对应的 `action`（按执行顺序排列的函数名称字符串数组），函数名称只能从以下列表中选择： #41
* 站立：stand() #42
* 打拳：boxing() #43
* 俯卧撑：push_up() #44
* 打招呼: shake_hands() #45
* 点头：nod() #46
* 坐下：sit() #47
* 踢左脚：kick_ball_left() #48
* 踢右脚：kick_ball_right() #49
* 跳舞：moonwalk() #50
* 趴下：lie_down() #51
* 伸懒腰：temp() #52
* 撒娇：bow() #53
*识别到男生的叫一下:man() #54
*识别到女生的叫一下:woman() #55
如果识别到目标为"男"，object:"man",  #56
如果识别到目标为"女"，object:"woman" #57

如果并没有识别到男或者女，则需要说明面前没有男生或者女生需要回复"object": "None","action": ["None"], #59
只需要返回检测到的目标物体的名称以及动作执行结果。 #60
response是固定返回如果object:"man"，response：面前是个男孩子喔，要我去咬他吗，如果object:"woman"，response ：是女孩子要我去打个招呼吗 #61
例如，如果我的指令是： #62
"你面前的是男生还是女生" #63
你输出： #64
{ #65
 "type": "detect", #66
 "object": "man", #67
 "action": ["man()"], #68
 "response": "面前是个男孩子喔，要我去咬他吗" #69
} #70
如果指令要求多个动作，例如： #71
"你面前的男生,做两个俯卧撑，然后叫一下" #72
你输出： #73
{ #74
 "type": "detect", #75
 "object": "man", #76
 "action": ["push_up()", "push_up()","man()"], #77
 "response": "面前是个男孩子喔，要我去咬他吗" #78
} #79
只回复json本身即可，不要回复其它内容。不能乱做动作需要根据提示做动作，叫一声也是动作，也是要执行的，并且response是一定要返回输出，不管是那个response都需要返回 #80
''' #81
else: #82
    PROMPT = ''' #83
As an intelligent robot assistant, you can recognize the content in the image and identify whether it is a boy or a girl based on my description. #84
Output requirements: #85
-Return a JSON object containing the following fields: #86
-'type ': always' detect' #87
-object ": The name of the recognized target object, or" None "if not recognized #88
-'action': The key carries an array of function name strings arranged in order of execution. When the corresponding action function cannot be found, the action output is [] #89
-response: Respond based on whether the target is a man or a woman #90
If the instruction contains action requirements, the corresponding 'action' (an array of function name strings arranged in the order of execution) must be provided based on the instruction.  #91
The function name can only be selected from the following list: #92
*Standing: Stand() #93
*Boxing: Boxing () #94
*Push up: push_up() #95
*Say hello: shake_hands() #96
*Nod: nod() #97
*Sit down: sit() #98
*Kick left foot: kick_ball_left() #99
*Kick the right foot: kick_ball_right() #100
*Dancing: moonwalk() #101
*Lie down: lie_down() #102
*Stretching: temp() #103
*Being coquettish: bow() #104
*If you recognize a boy, call him man() #105
*If you recognize a girl, call her 'woman()' #106
If the target is identified as' male ', object:"man",  #107
If the target is identified as' female ', object:"woman" #108
If no male or female is recognized, it is necessary to indicate that there is no male or female in front of you and reply with "object": "None", "action": ["None"], #109
Just need to return the name of the detected target object and the result of the action execution. #110
response is a fixed return. If object: "man", response: There's a boy in front of me. Do you want me to bite him? If object: "woman", response: Is a girl asking me to say hello #111
For example, if my instruction is: #112
Is that a boy or a girl in front of you #113
You output: #114
{ #115
"type": "detect", #116
"object": "man", #117
"action": ["man()"], #118
response: "There's a boy in front of you, do you want me to bite him #119
} #120
If the instruction requires multiple actions, such as: #121
The boy in front of you, do two push ups and call out #122
You output: #123
{ #124
"type": "detect", #125
"object": "man", #126
"action": ["push_up()", "push_up()","man()"], #127
response: "There's a boy in front of you, do you want me to bite him #128
} #129
Simply reply to JSON itself, do not reply to any other content. You cannot do actions randomly. You need to follow the prompts to do actions. Calling is also an action that needs to be executed, and the response must return the output. Regardless of which response it is, it needs to be returned #130
    ''' #131
class GENDERIDENTIFICATION(Node): #132
    def __init__(self, name): #133
        rclpy.init() #134
        super().__init__(name) #135
        self.action_done_event = threading.Event() #136
        self.fps = fps.FPS() # 帧率统计器(frame rate counter) #137
        self.image_queue = queue.Queue(maxsize=2) #138
        self.bridge = CvBridge() #139
        self.action = [] #140
        self.vllm_result = '' #141
        self.running = True #142
        self.declare_parameter('camera_topic', 'image_raw') #143
        camera_topic = self.get_parameter('camera_topic').value #144
        timer_cb_group = ReentrantCallbackGroup() #145
        #self.yilm = speech.YiLM(lingyi_api_key, lingyi_base_url)f #146
        self.puppy_control_node = PuppyControlNode() #147
        self.tts_text_pub = self.create_publisher(String, 'tts_node/tts_text', 1) #148
        self.create_subscription(Image, camera_topic, self.image_callback, 1) #149
       
        self.create_subscription(String, 'agent_process/result', self.vllm_result_callback, 1) #151
        self.run_action_group_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #152
        self.create_subscription(Bool, 'tts_node/play_finish', self.play_audio_finish_callback, 1, callback_group=timer_cb_group) #153
        self.awake_client = self.create_client(SetBool, 'vocal_detect/enable_wakeup') #154
        self.awake_client.wait_for_service() #155
        self.set_model_client = self.create_client(SetModel, 'agent_process/set_model') #156
        self.set_model_client.wait_for_service() #157
        self.set_mode_client = self.create_client(SetInt32, 'vocal_detect/set_mode') #158
        self.set_mode_client.wait_for_service() #159
        self.set_prompt_client = self.create_client(SetString, 'agent_process/set_prompt') #160
        self.set_prompt_client.wait_for_service() #161
        self.cli = self.create_client(Empty,'/puppy_control/go_home') #162
        self.cli.call_async(Empty.Request()) #163
        self.timer = self.create_timer(0.0, self.init_process, callback_group=timer_cb_group) #164
        timer_cb_group = ReentrantCallbackGroup() #165

    def get_node_state(self, request, response): #167
        return response #168


    def init_process(self): #171
        self.timer.cancel() #172
        
        msg = SetModel.Request() #174
        msg.model = vllm_model #175
        msg.model_type = 'vllm' #176
        if os.environ['ASR_LANGUAGE'] == 'Chinese': #177
            msg.model = stepfun_vllm_model #178
            msg.api_key = stepfun_api_key #179
            msg.base_url = stepfun_base_url #180
        else: #181
            msg.model = vllm_model #182
            msg.api_key = vllm_api_key #183
            msg.base_url = vllm_base_url #184
        self.send_request(self.set_model_client, msg) #185

        msg = SetString.Request() #187
        msg.data = PROMPT #188
        self.send_request(self.set_prompt_client, msg) #189
        speech.play_audio(start_audio_path) #190
        threading.Thread(target=self.process, daemon=True).start() #191
        self.create_service(Empty, '~/init_finish', self.get_node_state) #192
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start') #193

        
    def send_request(self, client, msg): #196
            future = client.call_async(msg) #197
            while rclpy.ok(): #198
                if future.done() and future.result(): #199
                    return future.result() #200
            
    def vllm_result_callback(self, msg): #202
        """纯回调函数，仅接收数据并触发处理逻辑""" #203
        self.vllm_result = msg.data  # 仅存储接收到的数据 #204
        self.get_logger().info("接收到 VLLM 结果回调") #205
        self.handle_vllm_result()  # 调用独立的处理函数 #206
        
    def play_audio_finish_callback(self, msg): #208
        """TTS 播放完成后的回调，恢复唤醒检测""" #209
        self.play_audio_finish = msg.data #210
        if self.play_audio_finish: #211
            msg = SetBool.Request() #212
            msg.data = True #213
            self.send_request(self.awake_client, msg) #214
        
    def handle_vllm_result(self): #216
        """处理 VLLM 结果的逻辑，包括解析动作和发布响应""" #217
        if not self.vllm_result: #218
            return  # 如果没有结果，直接返回 #219

        try: #221
            # 提取 JSON 字符串并解析 #222
            start_idx = self.vllm_result.find('{') #223
            end_idx = self.vllm_result.find('}') + 1 #224
            if start_idx == -1 or end_idx == 0: #225
                raise ValueError("无效的 JSON 格式") #226
            result_json = self.vllm_result[start_idx:end_idx] #227
            result = json.loads(result_json)   #228

            action_list = result.get('action', []) #230
            response = result.get('response', '') #231
            self.publish_response(response) #232
            time.sleep(6) #233
            self.execute_actions(action_list) #234

        except Exception as e: #236
            self.get_logger().error(f"处理 VLLM 结果时出错: {e}") #237
        finally: #238
            self.vllm_result = ''  # 清空结果，避免重复处理 #239

    def execute_actions(self, action_list): #241
        """执行动作列表中的动作""" #242
        for action in action_list: #243
            if action and action != "None" and isinstance(action, str): #244
                try: #245
                    eval(f'self.puppy_control_node.{action}')  # 执行动作 #246
                    self.get_logger().info(f"成功执行动作: {action}") #247
                    self.cli.call_async(Empty.Request()) #248
                except Exception as e: #249
                    self.get_logger().error(f"执行动作 '{action}' 失败: {e}") #250
            else: #251
                self.get_logger().warn(f"无效的动作: {action}，跳过执行。") #252

    def publish_response(self, response): #254
        """发布中文响应消息""" #255
        if response: #256
            response_msg = String() #257
            response_msg.data = response #258
            time.sleep(1) #259
            self.tts_text_pub.publish(response_msg) #260
            self.get_logger().info(f"已发布响应消息: {response}") #261

    def process(self): #263
        while self.running: #264
            image = self.image_queue.get(block=True) #265
            if self.vllm_result != '': #266
                msg = String() #267
                msg.data = self.vllm_result #268
                # self.tts_text_pub.publish(msg) #269
                self.vllm_result = '' #270

            cv2.imshow('image', image) #272
            cv2.waitKey(1) #273
        cv2.destroyAllWindows() #274

    def image_callback(self, ros_image): #276
        try: #277
            # 使用 cv_bridge 将 ROS Image 转换为 OpenCV 图像 #278
            rgb_image = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #279

            if self.image_queue.full(): #281
                # 如果队列已满，丢弃最旧的图像 #282
                self.image_queue.get() #283

            # 将图像放入队列 #285
            self.image_queue.put(rgb_image) #286
        except Exception as e: #287
            self.get_logger().error(f"Error processing image: {e}") #288

def main(): #290
    node = GENDERIDENTIFICATION('vllm_gender_identification') #291
    executor = MultiThreadedExecutor() #292
    executor.add_node(node) #293
    try: #294
        executor.spin() #295
    except KeyboardInterrupt: #296
        node.get_logger().info('Shutting down node') #297
    finally: #298
        node.running = False #299
        node.destroy_node() #300

if __name__ == "__main__": #302
    main() #303
