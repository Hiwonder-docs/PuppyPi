#!/usr/bin/env python3 #1
# encoding: utf-8 #2
import os #3
import dashscope #4

###Only in China### #6
# 阶跃星辰key #7
stepfun_api_key = '' #8
stepfun_base_url = 'https://api.stepfun.com/v1' #9
stepfun_llm_model = '' #10
#'step-1v-8k'/'step-1o-vision-32k'/'step-1.5v-mini' #11
stepfun_vllm_model = 'step-1o-vision-32k' #12

# 阿里云key #14
aliyun_api_key = '' #15
aliyun_base_url = 'https://dashscope.aliyuncs.com/compatible-mode/v1' #16
aliyun_llm_model = 'qwen-max-latest'#'qwen-turbo'#'qwen-max-latest' #17
aliyun_vllm_model = 'qwen-vl-max-latest' #18
aliyun_tts_model = 'sambert-zhinan-v1' #19
aliyun_asr_model = 'paraformer-realtime-v2' #20
aliyun_voice_model = '' #21
###### #22

###Internationally### #24
vllm_api_key = '' #25
#svllm_api_key = '' #26
vllm_base_url = 'https://openrouter.ai/api/v1' #27
vllm_model = 'qwen/qwen2.5-vl-72b-instruct:free' #28

llm_api_key = '' #30
llm_base_url = 'https://api.openai.com/v1' #31
llm_model = 'gpt-4o-mini' #32
openai_vllm_model = 'gpt-4o' #33
openai_tts_model = 'tts-1' #34
openai_asr_model = 'whisper-1' #35
openai_voice_model = 'onyx' #36
###### #37

if os.environ["ASR_LANGUAGE"] == 'Chinese': #39
    # 实际调用的key #40
    api_key = aliyun_api_key #41
    dashscope.api_key = aliyun_api_key #42
    base_url = aliyun_base_url #43
    asr_model = aliyun_asr_model #44
    tts_model = aliyun_tts_model #45
    voice_model = aliyun_voice_model #46
    llm_model = aliyun_llm_model #47
    vllm_model = aliyun_vllm_model #48
else: #49
    api_key = llm_api_key #50
    os.environ["OPENAI_API_KEY"] = api_key #51
    base_url = llm_base_url #52
    asr_model = openai_asr_model #53
    tts_model = openai_tts_model #54
    voice_model = openai_voice_model #55

# 获取程序所在路径 #57
code_path = os.path.abspath(os.path.split(os.path.realpath(__file__))[0]) #58

if os.environ["ASR_LANGUAGE"] == 'Chinese': #60
    audio_path = os.path.join(code_path, 'resources/audio') #61
else: #62
    audio_path = os.path.join(code_path, 'resources/audio/en') #63

# 录音音频的路径 #65
recording_audio_path = os.path.join(audio_path, 'recording.wav') #66

# 语音合成音频的路径 #68
tts_audio_path = os.path.join(audio_path, "tts_audio.wav") #69

# 启动音频的路径 #71
start_audio_path = os.path.join(audio_path, "start_audio.wav") #72

# 唤醒回答音频的路径 #74
wakeup_audio_path = os.path.join(audio_path, "wakeup.wav") #75

# 出错音频的路径 #77
error_audio_path = os.path.join(audio_path, "error.wav") #78

# 没有检测到声音时音频的路径 #80
no_voice_audio_path = os.path.join(audio_path, "no_voice.wav") #81

# 录音完成时音频的路径 #83
dong_audio_path = os.path.join(audio_path, "dong.wav") #84

record_finish_audio_path = os.path.join(audio_path, "record_finish.wav") #86

start_track_audio_path = os.path.join(audio_path, "start_track.wav") #88

track_fail_audio_path = os.path.join(audio_path, "track_fail.wav") #90
