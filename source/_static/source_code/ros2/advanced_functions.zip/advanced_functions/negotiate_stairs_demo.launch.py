import os #1
from launch_ros.actions import Node #2
from launch import LaunchDescription #3
from launch.actions import IncludeLaunchDescription, GroupAction #4
from launch.launch_description_sources import PythonLaunchDescriptionSource #5
from launch.substitutions import LaunchConfiguration #6

def generate_launch_description(): #8
    # 定义 Launch 参数 #9
    model = LaunchConfiguration('model', default='0')  # 默认 model 为 0 #10

    puppy_control_package_path = '/home/ubuntu/ros2_ws/src/driver/puppy_control' #12
    peripherals_package_path = '/home/ubuntu/ros2_ws/src/peripherals' #13

    puppy_control_node = GroupAction([ #15
        IncludeLaunchDescription( #16
            PythonLaunchDescriptionSource( #17
                os.path.join(puppy_control_package_path, 'launch/puppy_control.launch.py') #18
            ) #19
        ), #20
        IncludeLaunchDescription( #21
            PythonLaunchDescriptionSource( #22
                os.path.join(peripherals_package_path, 'launch/usb_cam.launch.py') #23
            ) #24
        ), #25
        Node( #26
            package='example', #27
            executable='negotiate_stairs_demo', #28
            name='negotiate_stairs_node', #29
            output='screen', #30
            parameters=[{'model': model}]  # 使用 parameters 传递 model #31
        ), #32
    ]) #33

    return LaunchDescription([ #35
        puppy_control_node #36
    ]) #37
