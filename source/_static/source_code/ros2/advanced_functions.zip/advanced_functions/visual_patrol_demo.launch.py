#!/usr/bin/env python #1
import os #2
from launch_ros.actions import Node #3
from launch import LaunchDescription #4
from launch.actions import IncludeLaunchDescription, GroupAction #5
from launch.launch_description_sources import PythonLaunchDescriptionSource #6
from launch.substitutions import LaunchConfiguration #7


def generate_launch_description(): #10
    # 定义 Launch 参数 #11
    model = LaunchConfiguration('model', default='0')  # 默认 model=0（仅识别） #12

    puppy_control_package_path = '/home/ubuntu/ros2_ws/src/driver/puppy_control' #14
    peripherals_package_path = '/home/ubuntu/ros2_ws/src/peripherals' #15

    puppy_control_node = GroupAction([ #17
        IncludeLaunchDescription( #18
            PythonLaunchDescriptionSource( #19
                os.path.join(puppy_control_package_path, 'launch/puppy_control.launch.py') #20
            ) #21
        ), #22
        IncludeLaunchDescription( #23
            PythonLaunchDescriptionSource( #24
                os.path.join(peripherals_package_path, 'launch/usb_cam.launch.py') #25
            ) #26
        ), #27
        Node( #28
            package='example', #29
            executable='visual_patrol_demo', #30
            name='visual_patrol_node', #31
            output='screen', #32
            parameters=[{'model': model}]   #33
        ), #34
    ]) #35

    return LaunchDescription([ #37
        puppy_control_node #38
    ]) #39
