#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import cv2 #4
import time #5
import math #6
import numpy as np #7
from enum import Enum #8
import yaml #9
from sdk import Misc #10
import rclpy #11
from rclpy.node import Node #12
from rclpy.qos import QoSProfile #13
from sensor_msgs.msg import Image #14
from std_srvs.srv import Empty, SetBool #15
from interfaces.srv import * #16
from puppy_control_msgs.msg import Velocity, Pose, Gait #17
from puppy_control_msgs.srv import SetRunActionName #18
from cv_bridge import CvBridge #19
from threading import RLock #20

ROS_NODE_NAME = 'negotiate_stairs_demo' #22

class PuppyStatus(Enum): #24
    LOOKING_FOR = 0     # 寻找目标 #25
    FOUND_TARGET = 3    # 发现台阶目标 #26
    DOWN_STAIRS = 4     # 下台阶 #27
    STOP = 10           # 停止 #28
    END = 20            # 结束 #29

def getAreaMaxContour(contours): #31
    contour_area_temp = 0 #32
    contour_area_max = 0 #33
    area_max_contour = None #34

    for c in contours: #36
        contour_area_temp = math.fabs(cv2.contourArea(c)) #37
        if contour_area_temp > contour_area_max: #38
            contour_area_max = contour_area_temp #39
            if contour_area_temp >= 5: #40
                area_max_contour = c #41
    return area_max_contour, contour_area_max #42

class NegotiateStairsDemo(Node): #44
    def __init__(self): #45
        super().__init__(ROS_NODE_NAME) #46
        self.bridge = CvBridge() #47

        # 声明 model 参数，默认为 0 #49
        self.declare_parameter('model', 0) #50
        self.model = self.get_parameter('model').get_parameter_value().integer_value #51
        if self.model not in [0, 1]: #52
            self.get_logger().warn(f"无效的模型值 {self.model}，默认设置为 0") #53
            self.model = 0 #54
        self.get_logger().info(f"启动台阶识别与控制，模型：{self.model}（0=仅识别，1=识别并控制）") #55

        # 初始化实例变量 #57
        self.lock = RLock() #58
        self.is_shutdown = False #59
        self.is_running = True #60
        self.target_centre_point = None #61
        self.PuppyPose = None #62
        self.action_group_executed = False #63
        self.up_stairs_time = 0 #64
        self.last_detect_time = 0  # 控制检测频率 #65
        self.detect_interval = 0.1  # 每 100ms 检测一次 #66
        self.image_size = (320, 240)  # 优化：降低分辨率 #67

        # 加载颜色阈值参数 #69
        self.color_range_list = self.get_color_ranges() #70

        # 目标颜色 #72
        self.target_color = ['red'] #73
        self.puppyStatus = PuppyStatus.LOOKING_FOR #74
        self.puppyStatusLast = PuppyStatus.END #75

        # 初始化发布者和订阅者 #77
        qos_profile = QoSProfile(depth=10) #78
        self.velocity_publisher = self.create_publisher(Velocity, '/puppy_control/velocity', qos_profile) #79
        self.pose_publisher = self.create_publisher(Pose, '/puppy_control/pose', qos_profile) #80
        self.gait_publisher = self.create_publisher(Gait, '/puppy_control/gait', qos_profile) #81
        self.image_subscriber = self.create_subscription(Image, '/image_raw', self.image_callback, qos_profile) #82

        # 初始化服务代理 #84
        self.run_action_group_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #85
        while not self.run_action_group_srv.wait_for_service(timeout_sec=1.0): #86
            self.get_logger().info('等待 /puppy_control/runActionGroup 服务...') #87

        # 初始化定时器，50Hz（优化：降低频率） #89
        self.timer = self.create_timer(0.02, self.move) #90
        self.get_logger().info('台阶识别节点已启动') #91

    def get_color_ranges(self): #93
        try: #94
            with open('/home/ubuntu/software/lab_tool/lab_config.yaml', 'r') as file: #95
                config = yaml.safe_load(file) #96
                color_ranges = config.get('color_range_list', {}) #97
                return color_ranges #98
        except Exception as e: #99
            self.get_logger().error(f'加载颜色配置文件失败: {str(e)}') #100
            sys.exit(1) #101

    def move(self): #103
        if not self.is_running: #104
            return #105

        with self.lock: #107
            if self.model == 0: #108
                # model=0：仅识别，不控制运动 #109
                return #110

            # 状态机逻辑 #112
            if self.puppyStatus == PuppyStatus.LOOKING_FOR: #113
                if self.target_centre_point and self.target_centre_point[1] > 400: #114
                    self.puppyStatus = PuppyStatus.FOUND_TARGET #115
                    velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=0.0) #116
                    self.velocity_publisher.publish(velocity_msg) #117
                    self.up_stairs_time = time.time() #118
                    self.action_group_executed = False #119
                    self.get_logger().info('发现目标，准备执行上台阶动作') #120
                else: #121
                    velocity_msg = Velocity(x=10.0, y=0.0, yaw_rate=0.0) #122
                    self.velocity_publisher.publish(velocity_msg) #123
                    self.get_logger().info('未发现目标，继续向前移动') #124

            elif self.puppyStatus == PuppyStatus.FOUND_TARGET: #126
                if not self.action_group_executed: #127
                    self.run_action_group('up_stairs_2cm.d6ac', True) #128
                    self.action_group_executed = True #129
                    self.get_logger().info('执行上台阶动作组') #130

                if time.time() - self.up_stairs_time > 25: #132
                    self.puppyStatus = PuppyStatus.DOWN_STAIRS #133
                    pose_msg = Pose( #134
                        stance_x=0.0, stance_y=0.0, x_shift=0.0, #135
                        height=0.3, roll=0.0, pitch=0.0, yaw=0.0, run_time=500 #136
                    ) #137
                    self.pose_publisher.publish(pose_msg) #138
                    self.get_logger().info('超时，切换到下台阶状态') #139

            elif self.puppyStatus == PuppyStatus.DOWN_STAIRS: #141
                velocity_msg = Velocity(x=14.0, y=0.0, yaw_rate=0.0) #142
                self.velocity_publisher.publish(velocity_msg) #143
                self.get_logger().info('正在下台阶') #144
                self.puppyStatus = PuppyStatus.END #145

            elif self.puppyStatus == PuppyStatus.END: #147
                velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=0.0) #148
                self.velocity_publisher.publish(velocity_msg) #149
                self.get_logger().info('任务完成，停止移动') #150

            # 状态变化日志 #152
            if self.puppyStatusLast != self.puppyStatus: #153
                self.get_logger().info(f'当前状态: {self.puppyStatus}') #154
            self.puppyStatusLast = self.puppyStatus #155

    def run_action_group(self, action_name, wait): #157
        request = SetRunActionName.Request() #158
        request.name = action_name #159
        request.wait = wait #160
        self.get_logger().info(f'调用动作组服务: {action_name}') #161
        future = self.run_action_group_srv.call_async(request) #162
        future.add_done_callback(self.run_action_group_callback) #163

    def run_action_group_callback(self, future): #165
        try: #166
            response = future.result() #167
            self.get_logger().info(f'动作组执行结果: {response.message}') #168
            self.action_group_executed = False #169
        except Exception as e: #170
            self.get_logger().error(f'动作组服务调用失败: {str(e)}') #171

    def run(self, img): #173
        img_h, img_w = img.shape[:2] #174
        frame_resize = cv2.resize(img, self.image_size, interpolation=cv2.INTER_NEAREST) #175
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #176
        frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #177

        # 优化：控制检测频率 #179
        current_time = time.time() #180
        if current_time - self.last_detect_time < self.detect_interval: #181
            return img #182
        self.last_detect_time = current_time #183

        detect_color = None #185
        for color in self.target_color: #186
            if color in self.color_range_list: #187
                detect_color = color #188
                frame_mask = cv2.inRange( #189
                    frame_lab, #190
                    tuple(self.color_range_list[detect_color]['min']), #191
                    tuple(self.color_range_list[detect_color]['max']) #192
                ) #193
                # 优化：减小形态学操作内核 #194
                opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8)) #195
                closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8)) #196

        if detect_color: #198
            cnts = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)[-2] #199
            cnt_large, area_max = getAreaMaxContour(cnts) #200

            if cnt_large is not None: #202
                rect = cv2.minAreaRect(cnt_large) #203
                box = np.int0(cv2.boxPoints(rect)) #204
                centerX = rect[0][0] #205
                centerY = rect[0][1] #206
                centerX = int(Misc.map(centerX, 0, self.image_size[0], 0, img_w)) #207
                centerY = int(Misc.map(centerY, 0, self.image_size[1], 0, img_h)) #208
                for i in range(4): #209
                    box[i, 1] = int(Misc.map(box[i, 1], 0, self.image_size[1], 0, img_h)) #210
                    box[i, 0] = int(Misc.map(box[i, 0], 0, self.image_size[0], 0, img_w)) #211

                cv2.drawContours(img, [box], -1, (0, 0, 255, 255), 2) #213
                self.target_centre_point = [centerX, centerY] #214
                cv2.circle(img, (centerX, centerY), 5, (0, 0, 255), -1) #215
                # 打印目标颜色和中心点 #216
                self.get_logger().info(f"检测到目标颜色: {detect_color}, 中心点: {self.target_centre_point}") #217
            else: #218
                self.target_centre_point = None #219
                self.get_logger().info(f"未检测到目标颜色: {detect_color}") #220

        return img #222

    def image_callback(self, ros_image): #224
        try: #225
            cv_image = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #226
        except Exception as e: #227
            self.get_logger().error(f'图像转换失败: {str(e)}') #228
            return #229

        with self.lock: #231
            frame = cv_image.copy() #232
            if self.is_running: #233
                frame_result = self.run(frame) #234
                if self.puppyStatus != PuppyStatus.FOUND_TARGET: #235
                    cv2.imshow('Frame', frame_result) #236
                    cv2.waitKey(1) #237

    def cleanup(self): #239
        self.is_shutdown = True #240
        self.is_running = False #241
        velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=0.0) #242
        self.velocity_publisher.publish(velocity_msg) #243
        self.get_logger().info('节点关闭，停止移动') #244

    def destroy_node(self): #246
        self.cleanup() #247
        super().destroy_node() #248

def main(args=None): #250
    rclpy.init(args=args) #251
    node = NegotiateStairsDemo() #252
    try: #253
        rclpy.spin(node) #254
    except KeyboardInterrupt: #255
        node.get_logger().info('接收到键盘中断，关闭节点') #256
    finally: #257
        node.destroy_node() #258
        rclpy.shutdown() #259
        cv2.destroyAllWindows() #260

if __name__ == '__main__': #262
    main() #263
