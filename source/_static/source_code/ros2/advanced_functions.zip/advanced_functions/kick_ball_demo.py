#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import cv2 #4
import time #5
import math #6
import threading #7
import numpy as np #8
from enum import Enum #9
import yaml #10
from cv_bridge import CvBridge #11
import rclpy #12
from rclpy.node import Node #13
from sensor_msgs.msg import Image #14
from puppy_control_msgs.msg import Velocity, Pose, Gait #15
from puppy_control_msgs.srv import SetRunActionName #16
from sdk import Misc   #17

class PuppyStatus(Enum): #19
    LOOKING_FOR = 0             # 寻找目标 #20
    LOOKING_FOR_LEFT = 1        # 向左寻找 #21
    LOOKING_FOR_RIGHT = 2       # 向右寻找 #22
    FOUND_TARGET = 3            # 发现目标 #23
    CLOSE_TO_TARGET = 4         # 靠近目标 #24
    CLOSE_TO_TARGET_FINE_TUNE = 5  # 细调位置 #25
    KICK_BALL = 6               # 踢球 #26
    STOP = 10                   # 停止 #27
    END = 20                    # 结束 #28

class KickBallDemo(Node): #30
    def __init__(self): #31
        super().__init__('kick_ball_demo') #32

        # 声明 model 参数，默认为 0 #34
        self.declare_parameter('model', 0) #35
        self.model = self.get_parameter('model').get_parameter_value().integer_value #36
        if self.model not in [0, 1]: #37
            self.get_logger().warn(f"无效的模型值 {self.model}，默认设置为 0") #38
            self.model = 0 #39
        self.get_logger().info(f"启动踢球演示，模型：{self.model}（0=仅识别，1=识别并控制）") #40

        # 初始化变量 #42
        self.is_shutdown = False #43
        self.debug = False #44
        self.haved_detect = False #45
        self.action_finish = True #46
        self.__target_color = ('red',) #47
        self.lock = threading.Lock() #48
        self.last_detect_time = 0  # 控制检测频率 #49
        self.detect_interval = 0.01 #50
        self.size = (320, 240) #51

        # 初始化 CvBridge #53
        self.bridge = CvBridge() #54

        # 初始化状态 #56
        self.puppyStatus = PuppyStatus.LOOKING_FOR #57
        self.puppyStatusLast = PuppyStatus.END #58

        # 期望中心点 #60
        self.expect_center = {'X': 640/2, 'Y': 480/2} #61
        self.expect_center_kick_ball_left = {'X': 150, 'Y': 480-150} #62
        self.expect_center_kick_ball_right = {'X': 640-150, 'Y': 480-150} #63

        self.target_info = None #65

        # RGB 颜色定义 #67
        self.range_rgb = { #68
            'red': (0, 0, 255), #69
            'blue': (255, 0, 0), #70
            'green': (0, 255, 0), #71
            'black': (0, 0, 0), #72
            'white': (255, 255, 255), #73
        } #74

        self.color_list = [] #76
        self.detect_color = 'None' #77
        self.draw_color = self.range_rgb["black"] #78

        # 读取颜色范围配置 #80
        try: #81
            with open('/home/ubuntu/software/lab_tool/lab_config.yaml', 'r', encoding='utf-8') as f: #82
                lab_config = yaml.safe_load(f) #83
                if 'color_range_list' in lab_config: #84
                    self.color_range_list = lab_config['color_range_list'] #85
                else: #86
                    self.get_logger().error("配置文件 lab_config.yaml 未包含 'color_range_list'") #87
                    self.color_range_list = {} #88
        except Exception as e: #89
            self.get_logger().error(f"加载颜色配置文件失败: {str(e)}") #90
            sys.exit(1) #91

        # 姿态配置 #93
        self.PP = { #94
            'LookDown_10deg': { #95
                'roll': math.radians(0), #96
                'pitch': math.radians(-10.0), #97
                'yaw': 0.0, #98
                'height': -9.0, #99
                'x_shift': -0.1, #100
                'stance_x': 0.0, #101
                'stance_y': 0.0 #102
            }, #103
            'LookDown_20deg': { #104
                'roll': math.radians(0), #105
                'pitch': math.radians(-20.0), #106
                'yaw': 0.0, #107
                'height': -9.0, #108
                'x_shift': -0.1, #109
                'stance_x': 0.0, #110
                'stance_y': 0.0 #111
            }, #112
        } #113

        self.PuppyPose = self.PP['LookDown_10deg'].copy() #115
        self.GaitConfig = {'overlap_time': 0.15, 'swing_time': 0.15, 'clearance_time': 0.0, 'z_clearance': 3.0} #116

        # 创建发布者和订阅者 #118
        self.PuppyGaitConfigPub = self.create_publisher(Gait, '/puppy_control/gait', 10) #119
        self.PuppyVelocityPub = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #120
        self.PuppyPosePub = self.create_publisher(Pose, '/puppy_control/pose', 10) #121
        self.image_sub = self.create_subscription(Image, '/image_raw', self.image_callback, 10) #122

        # 创建服务客户端 #124
        self.runActionGroup_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #125
        while not self.runActionGroup_srv.wait_for_service(timeout_sec=1.0): #126
            self.get_logger().info('等待 /puppy_control/runActionGroup 服务...') #127

        # 初始化运动线程 #129
        if self.model == 1: #130
            self.th = threading.Thread(target=self.move, daemon=True) #131
            self.th.start() #132

        # 初始化姿态和步态 #134
        time.sleep(0.3) #135
        pose_msg = Pose( #136
            stance_x=float(self.PuppyPose['stance_x']), #137
            stance_y=float(self.PuppyPose['stance_y']), #138
            x_shift=float(self.PuppyPose['x_shift']), #139
            height=float(self.PuppyPose['height']), #140
            roll=float(self.PuppyPose['roll']), #141
            pitch=float(self.PuppyPose['pitch']), #142
            yaw=float(self.PuppyPose['yaw']), #143
            run_time=500 #144
        ) #145
        self.PuppyPosePub.publish(pose_msg) #146
        time.sleep(0.2) #147
        gait_msg = Gait( #148
            overlap_time=float(self.GaitConfig['overlap_time']), #149
            swing_time=float(self.GaitConfig['swing_time']), #150
            clearance_time=float(self.GaitConfig['clearance_time']), #151
            z_clearance=float(self.GaitConfig['z_clearance']) #152
        ) #153
        self.PuppyGaitConfigPub.publish(gait_msg) #154
        time.sleep(0.2) #155
        self.get_logger().info('踢球节点初始化完成') #156

    def move(self): #158
        time.sleep(2) #159
        which_foot_kick_ball = 'left'  # 初始化踢球脚 #160

        while not self.is_shutdown: #162
            time.sleep(0.02)  # 优化：降低循环频率 #163
            if self.model == 0: #164
                continue  # model=0 仅识别，不控制运动 #165

            with self.lock: #167
                if self.puppyStatus == PuppyStatus.LOOKING_FOR: #168
                    if self.haved_detect: #169
                        self.puppyStatus = PuppyStatus.FOUND_TARGET #170
                        self.get_logger().info('发现目标，进入 FOUND_TARGET 状态') #171
                    else: #172
                        self.PuppyPose = self.PP['LookDown_10deg'].copy() #173
                        pose_msg = Pose( #174
                            stance_x=self.PuppyPose['stance_x'], #175
                            stance_y=self.PuppyPose['stance_y'], #176
                            x_shift=self.PuppyPose['x_shift'], #177
                            height=self.PuppyPose['height'], #178
                            roll=self.PuppyPose['roll'], #179
                            pitch=self.PuppyPose['pitch'], #180
                            yaw=self.PuppyPose['yaw'], #181
                            run_time=500 #182
                        ) #183
                        self.PuppyPosePub.publish(pose_msg) #184
                        time.sleep(0.2) #185
                        self.get_logger().info('调整姿态至 LookDown_10deg，切换到 LOOKING_FOR_LEFT') #186
                        self.puppyStatus = PuppyStatus.LOOKING_FOR_LEFT #187

                elif self.puppyStatus == PuppyStatus.LOOKING_FOR_LEFT: #189
                    if self.haved_detect: #190
                        self.puppyStatus = PuppyStatus.FOUND_TARGET #191
                        self.get_logger().info('在左侧发现目标，进入 FOUND_TARGET 状态') #192
                    else: #193
                        velocity_msg = Velocity(x=3.0, y=0.0, yaw_rate=math.radians(-12)) #194
                        self.PuppyVelocityPub.publish(velocity_msg) #195
                        self.get_logger().info('向左旋转寻找目标') #196
                        time.sleep(3) #197
                        velocity_msg.yaw_rate = 0.0 #198
                        self.PuppyVelocityPub.publish(velocity_msg) #199
                        time.sleep(0.3) #200
                        self.get_logger().info('停止旋转，切换到 LOOKING_FOR_RIGHT') #201
                        self.puppyStatus = PuppyStatus.LOOKING_FOR_RIGHT #202

                elif self.puppyStatus == PuppyStatus.LOOKING_FOR_RIGHT: #204
                    if self.haved_detect: #205
                        self.puppyStatus = PuppyStatus.FOUND_TARGET #206
                        self.get_logger().info('在右侧发现目标，进入 FOUND_TARGET 状态') #207
                    else: #208
                        self.PuppyPose = self.PP['LookDown_10deg'].copy() #209
                        pose_msg = Pose( #210
                            stance_x=self.PuppyPose['stance_x'], #211
                            stance_y=self.PuppyPose['stance_y'], #212
                            x_shift=self.PuppyPose['x_shift'], #213
                            height=self.PuppyPose['height'], #214
                            roll=self.PuppyPose['roll'], #215
                            pitch=self.PuppyPose['pitch'], #216
                            yaw=self.PuppyPose['yaw'], #217
                            run_time=500 #218
                        ) #219
                        self.PuppyPosePub.publish(pose_msg) #220
                        velocity_msg = Velocity(x=2.0, y=0.0, yaw_rate=math.radians(-12)) #221
                        self.PuppyVelocityPub.publish(velocity_msg) #222
                        self.get_logger().info('向右旋转寻找目标') #223

                elif self.puppyStatus == PuppyStatus.FOUND_TARGET: #225
                    if self.target_info is None: #226
                        self.puppyStatus = PuppyStatus.LOOKING_FOR #227
                        self.get_logger().info('目标丢失，回到 LOOKING_FOR 状态') #228
                        continue #229
                    self.get_logger().info(f"目标中心: X={self.target_info['centerX']}, Y={self.target_info['centerY']}") #230
                    if self.target_info['centerY'] > 380: #231
                        self.puppyStatus = PuppyStatus.CLOSE_TO_TARGET #232
                        self.PuppyPose = self.PP['LookDown_20deg'].copy() #233
                        pose_msg = Pose( #234
                            stance_x=self.PuppyPose['stance_x'], #235
                            stance_y=self.PuppyPose['stance_y'], #236
                            x_shift=self.PuppyPose['x_shift'], #237
                            height=self.PuppyPose['height'], #238
                            roll=self.PuppyPose['roll'], #239
                            pitch=self.PuppyPose['pitch'], #240
                            yaw=self.PuppyPose['yaw'], #241
                            run_time=500 #242
                        ) #243
                        self.PuppyPosePub.publish(pose_msg) #244
                        self.get_logger().info('目标靠近，调整姿态至 LookDown_20deg') #245
                        time.sleep(0.2) #246
                    else: #247
                        if self.expect_center['X'] - self.target_info['centerX'] < -80: #248
                            velocity_msg = Velocity(x=3.0, y=0.0, yaw_rate=math.radians(-12)) #249
                            self.PuppyVelocityPub.publish(velocity_msg) #250
                            self.get_logger().info('目标偏右，向左调整') #251
                        elif self.expect_center['X'] - self.target_info['centerX'] > 80: #252
                            velocity_msg = Velocity(x=3.0, y=0.0, yaw_rate=math.radians(12)) #253
                            self.PuppyVelocityPub.publish(velocity_msg) #254
                            self.get_logger().info('目标偏左，向右调整') #255
                        else: #256
                            velocity_msg = Velocity(x=10.0, y=0.0, yaw_rate=0.0) #257
                            self.PuppyVelocityPub.publish(velocity_msg) #258
                            self.get_logger().info('目标居中，向前移动') #259
                        time.sleep(0.2) #260

                elif self.puppyStatus == PuppyStatus.CLOSE_TO_TARGET: #262
                    if self.target_info is None: #263
                        self.puppyStatus = PuppyStatus.LOOKING_FOR #264
                        self.get_logger().info('目标丢失，回到 LOOKING_FOR 状态') #265
                        continue #266
                    if self.target_info['centerY'] > 380: #267
                        velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=0.0) #268
                        self.PuppyVelocityPub.publish(velocity_msg) #269
                        self.puppyStatus = PuppyStatus.CLOSE_TO_TARGET_FINE_TUNE #270
                        which_foot_kick_ball = 'left' if self.expect_center['X'] > self.target_info['centerX'] else 'right' #271
                        self.get_logger().info(f'已靠近目标，准备使用 {which_foot_kick_ball} 脚踢球') #272
                    else: #273
                        if self.expect_center['X'] - self.target_info['centerX'] < -50: #274
                            velocity_msg = Velocity(x=3.0, y=0.0, yaw_rate=math.radians(-10)) #275
                            self.PuppyVelocityPub.publish(velocity_msg) #276
                            self.get_logger().info('目标偏右，微调向左') #277
                        elif self.expect_center['X'] - self.target_info['centerX'] > 50: #278
                            velocity_msg = Velocity(x=3.0, y=0.0, yaw_rate=math.radians(10)) #279
                            self.PuppyVelocityPub.publish(velocity_msg) #280
                            self.get_logger().info('目标偏左，微调向右') #281
                        else: #282
                            velocity_msg = Velocity(x=8.0, y=0.0, yaw_rate=0.0) #283
                            self.PuppyVelocityPub.publish(velocity_msg) #284
                            self.get_logger().info('目标居中，继续靠近') #285
                        time.sleep(0.2) #286

                elif self.puppyStatus == PuppyStatus.CLOSE_TO_TARGET_FINE_TUNE: #288
                    if self.target_info is None: #289
                        self.puppyStatus = PuppyStatus.LOOKING_FOR #290
                        self.get_logger().info('目标丢失，回到 LOOKING_FOR 状态') #291
                        continue #292
                    if self.target_info['centerY'] < self.expect_center_kick_ball_left['Y']: #293
                        velocity_msg = Velocity(x=4.0, y=0.0, yaw_rate=0.0) #294
                        self.PuppyVelocityPub.publish(velocity_msg) #295
                        self.get_logger().info('目标太远，继续向前微调') #296
                        time.sleep(0.1) #297
                    elif which_foot_kick_ball == 'left' and self.target_info['centerX'] > self.expect_center_kick_ball_left['X']: #298
                        velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=math.radians(-8)) #299
                        self.PuppyVelocityPub.publish(velocity_msg) #300
                        self.get_logger().info('左脚踢球，微调向左') #301
                        time.sleep(0.1) #302
                    elif which_foot_kick_ball == 'right' and self.target_info['centerX'] < self.expect_center_kick_ball_right['X']: #303
                        velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=math.radians(8)) #304
                        self.PuppyVelocityPub.publish(velocity_msg) #305
                        self.get_logger().info('右脚踢球，微调向右') #306
                        time.sleep(0.1) #307
                    else: #308
                        velocity_msg = Velocity( #309
                            x=5.0, #310
                            y=0.0, #311
                            yaw_rate=math.radians(-10) if which_foot_kick_ball == 'left' else math.radians(10) #312
                        ) #313
                        self.PuppyVelocityPub.publish(velocity_msg) #314
                        self.get_logger().info(f'准备踢球，使用 {which_foot_kick_ball} 脚') #315
                        time.sleep(1.8) #316
                        velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=0.0) #317
                        self.PuppyVelocityPub.publish(velocity_msg) #318
                        self.puppyStatus = PuppyStatus.KICK_BALL #319

                elif self.puppyStatus == PuppyStatus.KICK_BALL: #321
                    velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=0.0) #322
                    self.PuppyVelocityPub.publish(velocity_msg) #323
                    time.sleep(0.2) #324
                    request = SetRunActionName.Request() #325
                    request.name = 'kick_ball_left.d6ac' if which_foot_kick_ball == 'left' else 'kick_ball_right.d6ac' #326
                    request.wait = True #327
                    self.get_logger().info(f'执行踢球动作: {request.name}') #328
                    future = self.runActionGroup_srv.call_async(request) #329
                    future.add_done_callback(self.kick_ball_callback) #330
                    self.puppyStatus = PuppyStatus.LOOKING_FOR #331
                    self.haved_detect = False #332
                    self.get_logger().info('踢球完成，回到 LOOKING_FOR 状态') #333

                elif self.puppyStatus == PuppyStatus.STOP: #335
                    velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=0.0) #336
                    self.PuppyVelocityPub.publish(velocity_msg) #337
                    self.get_logger().info('停止所有运动') #338

                # 状态变化日志 #340
                if self.puppyStatusLast != self.puppyStatus: #341
                    self.get_logger().info(f'当前状态: {self.puppyStatus}') #342
                self.puppyStatusLast = self.puppyStatus #343

    def kick_ball_callback(self, future): #345
        try: #346
            response = future.result() #347
            self.get_logger().info(f'踢球动作执行完成: {response.message}') #348
        except Exception as e: #349
            self.get_logger().error(f'踢球动作服务调用失败: {str(e)}') #350

    def run(self, img): #352
        img_h, img_w = img.shape[:2] #353
        if not self.action_finish: #354
            return img #355

        # 优化：控制检测频率 #357
        current_time = time.time() #358
        if current_time - self.last_detect_time < self.detect_interval: #359
            return img #360
        self.last_detect_time = current_time #361

        frame_resize = cv2.resize(img, self.size, interpolation=cv2.INTER_NEAREST) #363
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #364
        frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #365
        max_area = 0 #366
        color_area_max = None #367
        areaMaxContour_max = None #368

        for i in self.color_range_list: #370
            if i in self.__target_color: #371
                color_range = self.color_range_list[i] #372
                frame_mask = cv2.inRange( #373
                    frame_lab, #374
                    np.array(color_range['min'], dtype=np.uint8), #375
                    np.array(color_range['max'], dtype=np.uint8) #376
                ) #377
                eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #378
                dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #379
                if self.debug: #380
                    cv2.imshow(i, dilated) #381
                contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE) #382
                areaMaxContour, area_max = self.getAreaMaxContour(contours) #383
                if areaMaxContour is not None and area_max > max_area: #384
                    max_area = area_max #385
                    color_area_max = i #386
                    areaMaxContour_max = areaMaxContour #387

        if max_area > 200: #389
            rect = cv2.minAreaRect(areaMaxContour_max) #390
            box = np.int0(cv2.boxPoints(rect)) #391
            centerX = int(Misc.map(rect[0][0], 0, self.size[0], 0, img_w)) #392
            centerY = int(Misc.map(rect[0][1], 0, self.size[1], 0, img_h)) #393
            sideX = int(Misc.map(rect[1][0], 0, self.size[0], 0, img_w)) #394
            sideY = int(Misc.map(rect[1][1], 0, self.size[1], 0, img_h)) #395
            angle = rect[2] #396
            for i in range(4): #397
                box[i, 1] = int(Misc.map(box[i, 1], 0, self.size[1], 0, img_h)) #398
                box[i, 0] = int(Misc.map(box[i, 0], 0, self.size[0], 0, img_w)) #399
            cv2.drawContours(img, [box], -1, (0, 0, 255), 2) #400

            if color_area_max == 'red': #402
                color = 1 #403
            elif color_area_max == 'green': #404
                color = 2 #405
            elif color_area_max == 'blue': #406
                color = 3 #407
            else: #408
                color = 0 #409
            self.color_list.append(color) #410
            if len(self.color_list) == 3: #411
                color = int(round(np.mean(np.array(self.color_list)))) #412
                self.color_list = [] #413
                if color == 1: #414
                    self.detect_color = 'red' #415
                    self.draw_color = self.range_rgb["red"] #416
                elif color == 2: #417
                    self.detect_color = 'green' #418
                    self.draw_color = self.range_rgb["green"] #419
                elif color == 3: #420
                    self.detect_color = 'blue' #421
                    self.draw_color = self.range_rgb["blue"] #422
                else: #423
                    self.detect_color = 'None' #424
                    self.draw_color = self.range_rgb["black"] #425
        else: #426
            self.detect_color = 'None' #427
            self.draw_color = self.range_rgb["black"] #428

        if self.detect_color == self.__target_color[0]: #430
            self.haved_detect = True #431
            if sideX > sideY: #432
                self.target_info = {'centerX': centerX, 'centerY': centerY, 'sideX': sideX, 'sideY': sideY, 'scale': sideX/sideY, 'angle': angle} #433
            else: #434
                self.target_info = {'centerX': centerX, 'centerY': centerY, 'sideX': sideX, 'sideY': sideY, 'scale': sideY/sideX, 'angle': angle} #435
            self.get_logger().info(f"检测到目标颜色: {self.detect_color}, 中心点: [{centerX}, {centerY}]") #436
        else: #437
            self.haved_detect = False #438
            self.target_info = None #439
            self.get_logger().info(f"未检测到目标颜色: {self.__target_color[0]}") #440

        cv2.putText(img, f"颜色: {self.detect_color}", (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, self.draw_color, 2) #442
        return img #443

    def getAreaMaxContour(self, contours): #445
        contour_area_temp = 0 #446
        contour_area_max = 0 #447
        area_max_contour = None #448
        for c in contours: #449
            contour_area_temp = math.fabs(cv2.contourArea(c)) #450
            if contour_area_temp > contour_area_max: #451
                contour_area_max = contour_area_temp #452
                if contour_area_temp >= 5: #453
                    area_max_contour = c #454
        return area_max_contour, contour_area_max #455

    def image_callback(self, ros_image): #457
        try: #458
            cv2_img = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #459
        except Exception as e: #460
            self.get_logger().error(f'图像转换失败: {str(e)}') #461
            return #462

        with self.lock: #464
            frame = cv2_img.copy() #465
            if self.action_finish: #466
                frame_result = self.run(frame) #467
                cv2.imshow('Frame', frame_result) #468
                cv2.waitKey(1) #469

    def destroy_node(self): #471
        self.is_shutdown = True #472
        with self.lock: #473
            velocity_msg = Velocity(x=0.0, y=0.0, yaw_rate=0.0) #474
            self.PuppyVelocityPub.publish(velocity_msg) #475
            self.get_logger().info('节点关闭，停止移动') #476
        cv2.destroyAllWindows() #477
        super().destroy_node() #478

def main(args=None): #480
    rclpy.init(args=args) #481
    kick_ball_demo = KickBallDemo() #482
    try: #483
        rclpy.spin(kick_ball_demo) #484
    except KeyboardInterrupt: #485
        kick_ball_demo.get_logger().info('接收到键盘中断，关闭节点') #486
    finally: #487
        kick_ball_demo.destroy_node() #488
        rclpy.shutdown() #489

if __name__ == '__main__': #491
    main() #492
