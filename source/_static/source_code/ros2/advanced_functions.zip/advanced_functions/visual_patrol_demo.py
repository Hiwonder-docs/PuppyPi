#!/usr/bin/python3 #1
# coding=utf8 #2
# 第7章 ROS机器狗创意课程\4.AI视觉巡线行走 #3
import cv2 #4
import math #5
import time #6
import numpy as np #7
import yaml #8
from cv_bridge import CvBridge, CvBridgeError #9
import rclpy #10
from rclpy.node import Node #11
from sensor_msgs.msg import Image #12
from std_srvs.srv import Empty #13
from puppy_control_msgs.msg import Velocity, Pose, Gait #14
from sdk import Misc  # 引入 sdk.Misc 模块 #15


class VisualPatrolDemo(Node): #18
    def __init__(self): #19
        super().__init__('visual_patrol_demo') #20

        # 声明并获取 launch 参数 #22
        self.declare_parameter('model', 0)  # 默认 model=0（仅识别） #23
        self.model = self.get_parameter('model').get_parameter_value().integer_value #24
        self.get_logger().info(f"启动模式: {'仅识别' if self.model == 0 else '识别并追踪'} (model={self.model})") #25

        # 初始化变量 #27
        self.is_shutdown = False #28
        self.__isRunning = False if self.model == 0 else True  # model=0 时不追踪 #29
        self.__target_color = 'red'  # 目标颜色为红色 #30
        self.line_centerx = -1 #31
        self.img_centerx = 320  # 图像中心点 x 坐标（640/2） #32

        # 定义 ROI 和权重 #34
        self.roi = [ #35
            (120, 140, 0, 320, 0.1),  # (y_min, y_max, x_min, x_max, weight) #36
            (160, 180, 0, 320, 0.2), #37
            (200, 220, 0, 320, 0.7) #38
        ] #39
        self.roi_h_list = [self.roi[0][0], self.roi[1][0] - self.roi[0][0], self.roi[2][0] - self.roi[1][0]] #40

        # 定义颜色范围 RGB 用于可视化 #42
        self.range_rgb = { #43
            'red': (0, 0, 255), #44
            'blue': (255, 0, 0), #45
            'green': (0, 255, 0), #46
            'black': (0, 0, 0), #47
            'white': (255, 255, 255), #48
        } #49
        self.draw_color = self.range_rgb["black"] #50

        # 初始化 CvBridge #52
        self.bridge = CvBridge() #53

        # 读取颜色阈值配置 #55
        self.color_range_list = self.load_color_ranges('/home/ubuntu/software/lab_tool/lab_config.yaml') #56

        # 获取 PuppyPose 参数 #58
        self.PP = { #59
            'LookDown_20deg': { #60
                'roll': math.radians(0.0), #61
                'pitch': math.radians(-20.0), #62
                'yaw': 0.0, #63
                'height': -9.0, #64
                'x_shift': -0.1, #65
                'stance_x': 0.0, #66
                'stance_y': 0.0 #67
            }, #68
        } #69
        self.PuppyPose = self.PP['LookDown_20deg'].copy() #70

        # 定义步态配置 #72
        self.GaitConfig = { #73
            'overlap_time': 0.1, #74
            'swing_time': 0.15, #75
            'clearance_time': 0.0, #76
            'z_clearance': 3.0 #77
        } #78

        # 创建发布者 #80
        self.PuppyGaitConfigPub = self.create_publisher(Gait, '/puppy_control/gait', 10) #81
        self.PuppyVelocityPub = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #82
        self.PuppyPosePub = self.create_publisher(Pose, '/puppy_control/pose', 10) #83

        # 创建订阅者 #85
        self.image_sub = self.create_subscription(Image, '/image_raw', self.image_callback, 10) #86

        # 初始化 PuppyMove #88
        self.PuppyMove = {'x': 0.0, 'y': 0.0, 'yaw_rate': 0.0} #89
        self.get_logger().info(f"PuppyMove 初始化: {self.PuppyMove}") #90

        # 发布初始姿态和步态配置 #92
        if self.__isRunning: #93
            self.initialize_robot() #94

        self.get_logger().info("视觉巡线节点初始化完成，开始运行。") #96

    def load_color_ranges(self, yaml_path): #98
        """加载颜色阈值配置""" #99
        try: #100
            with open(yaml_path, 'r', encoding='utf-8') as f: #101
                lab_config = yaml.safe_load(f) #102
                color_ranges = lab_config.get('color_range_list', {}) #103
                if 'red' not in color_ranges: #104
                    self.get_logger().warn("颜色阈值配置中未找到 'red' 的阈值。") #105
                self.get_logger().info(f"颜色阈值加载成功: {list(color_ranges.keys())}") #106
                return color_ranges #107
        except Exception as e: #108
            self.get_logger().error(f"无法加载颜色阈值配置文件: {e}") #109
            return {} #110

    def initialize_robot(self): #112
        """发布初始姿态和步态配置，并调用 go_home 服务""" #113
        # 发布初始速度为零 #114
        velocity_msg = Velocity() #115
        velocity_msg.x = 0.0 #116
        velocity_msg.y = 0.0 #117
        velocity_msg.yaw_rate = 0.0 #118
        self.PuppyVelocityPub.publish(velocity_msg) #119
        self.get_logger().info("发布初始速度为零。") #120
        time.sleep(0.2) #121

        # 调用 go_home 服务回到初始位置 #123
        go_home_client = self.create_client(Empty, '/puppy_control/go_home') #124
        while not go_home_client.wait_for_service(timeout_sec=1.0): #125
            self.get_logger().info('等待服务 /puppy_control/go_home 可用...') #126
        request = Empty.Request() #127
        future = go_home_client.call_async(request) #128
        rclpy.spin_until_future_complete(self, future) #129
        if future.result() is not None: #130
            self.get_logger().info("调用服务 /puppy_control/go_home 成功。") #131
        else: #132
            self.get_logger().error("调用服务 /puppy_control/go_home 失败。") #133

        # 发布初始姿态 #135
        pose_msg = Pose() #136
        pose_msg.stance_x = float(self.PuppyPose['stance_x']) #137
        pose_msg.stance_y = float(self.PuppyPose['stance_y']) #138
        pose_msg.x_shift = float(self.PuppyPose['x_shift']) #139
        pose_msg.height = float(self.PuppyPose['height']) #140
        pose_msg.roll = float(self.PuppyPose['roll']) #141
        pose_msg.pitch = float(self.PuppyPose['pitch']) #142
        pose_msg.yaw = float(self.PuppyPose['yaw']) #143
        pose_msg.run_time = int(500) #144
        self.PuppyPosePub.publish(pose_msg) #145
        self.get_logger().info("发布初始姿态。") #146
        time.sleep(0.2) #147

        # 发布步态配置 #149
        gait_msg = Gait() #150
        gait_msg.overlap_time = float(self.GaitConfig['overlap_time']) #151
        gait_msg.swing_time = float(self.GaitConfig['swing_time']) #152
        gait_msg.clearance_time = float(self.GaitConfig['clearance_time']) #153
        gait_msg.z_clearance = float(self.GaitConfig['z_clearance']) #154
        self.PuppyGaitConfigPub.publish(gait_msg) #155
        self.get_logger().info("发布步态配置。") #156
        time.sleep(0.2) #157

    def move_robot(self, error): #159
        """根据误差调整机器人的速度和转向""" #160
        if abs(error) <= 20: #161
            self.PuppyMove['x'] = 10.0 #162
            self.PuppyMove['yaw_rate'] = 0.0 #163
        elif error > 50: #164
            self.PuppyMove['x'] = 8.0 #165
            self.PuppyMove['yaw_rate'] = math.radians(-15.0) #166
        elif error < -50: #167
            self.PuppyMove['x'] = 8.0 #168
            self.PuppyMove['yaw_rate'] = math.radians(15.0) #169

        # 发布速度消息 #171
        velocity_msg = Velocity() #172
        velocity_msg.x = float(self.PuppyMove['x']) #173
        velocity_msg.y = 0.0 #174
        velocity_msg.yaw_rate = float(self.PuppyMove['yaw_rate']) #175
        self.PuppyVelocityPub.publish(velocity_msg) #176
        self.get_logger().info(f"发布速度指令: x={velocity_msg.x}, yaw_rate={velocity_msg.yaw_rate}") #177

    def getAreaMaxContour(self, contours): #179
        """找出面积最大的轮廓""" #180
        contour_area_max = 0 #181
        area_max_contour = None #182

        for c in contours: #184
            contour_area_temp = math.fabs(cv2.contourArea(c)) #185
            if contour_area_temp > contour_area_max: #186
                contour_area_max = contour_area_temp #187
                if contour_area_temp > 50: #188
                    area_max_contour = c #189

        return area_max_contour, contour_area_max #191

    def run(self, img): #193
        """处理图像，检测红色线条并计算中心位置""" #194
        size = (320, 240) #195
        img_h, img_w = img.shape[:2] #196

        frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_LINEAR) #198
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #199

        centroid_x_sum = 0 #201
        weight_sum = 0 #202

        for idx, r in enumerate(self.roi): #204
            roi_h = self.roi_h_list[idx] #205
            blobs = frame_gb[r[0]:r[1], r[2]:r[3]] #206
            frame_lab = cv2.cvtColor(blobs, cv2.COLOR_BGR2LAB) #207

            detect_color = self.__target_color #209
            if detect_color in self.color_range_list: #210
                color_range = self.color_range_list[detect_color] #211
                frame_mask = cv2.inRange(frame_lab, #212
                                         np.array(color_range['min'], dtype=np.uint8), #213
                                         np.array(color_range['max'], dtype=np.uint8)) #214
                # 形态学操作 #215
                opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)) #216
                closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)) #217

                # 调试信息：显示掩模图像 #219
                cv2.imshow('Mask', closed) #220
                cv2.waitKey(1) #221
            else: #222
                self.line_centerx = -1 #223
                self.get_logger().warn(f"目标颜色 '{detect_color}' 不在颜色阈值列表中。") #224
                return img #225

            # 查找轮廓 #227
            contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE) #228
            cnt_large, area = self.getAreaMaxContour(contours) #229
            self.get_logger().debug(f"ROI {idx + 1}: 找到 {len(contours)} 个轮廓，最大面积为 {area}") #230

            if cnt_large is not None: #232
                rect = cv2.minAreaRect(cnt_large) #233
                box = np.int0(cv2.boxPoints(rect)) #234
                for i in range(4): #235
                    box[i, 1] = box[i, 1] + r[0] #236
                    box[i, 1] = int(Misc.map(box[i, 1], 0, size[1], 0, img_h))  # 使用 Misc.map #237
                for i in range(4): #238
                    box[i, 0] = int(Misc.map(box[i, 0], 0, size[0], 0, img_w)) #239

                # 绘制轮廓和中心点 #241
                cv2.drawContours(img, [box], -1, (0, 0, 255), 2) #242
                pt1_x, pt1_y = box[0, 0], box[0, 1] #243
                pt3_x, pt3_y = box[2, 0], box[2, 1] #244
                center_x, center_y = (pt1_x + pt3_x) / 2, (pt1_y + pt3_y) / 2 #245
                cv2.circle(img, (int(center_x), int(center_y)), 5, (0, 0, 255), -1) #246

                # 计算加权中心 #248
                centroid_x_sum += center_x * r[4] #249
                weight_sum += r[4] #250

                self.get_logger().debug(f"ROI {idx + 1}: center_x={center_x}, center_y={center_y}") #252
            else: #253
                self.get_logger().debug(f"ROI {idx + 1}: 未检测到有效轮廓。") #254
                continue #255

        # 计算最终的中心点 #257
        if weight_sum != 0: #258
            self.line_centerx = int(centroid_x_sum / weight_sum) #259
            cv2.circle(img, (self.line_centerx, int(center_y)), 10, (0, 255, 255), -1) #260
            self.get_logger().info(f'line_centerx: {self.line_centerx}') #261
        else: #262
            self.line_centerx = -1 #263
            self.get_logger().warn("未检测到任何有效的线条。") #264

        return img #266

    def image_callback(self, ros_image): #268
        """图像回调函数，处理图像并发布运动指令""" #269
        try: #270
            cv2_img = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='bgr8') #271
        except CvBridgeError as e: #272
            self.get_logger().error(f"图像转换失败: {e}") #273
            return #274

        frame = cv2_img.copy() #276
        frame_result = frame #277

        # 处理图像并获取结果 #279
        frame_result = self.run(frame) #280

        # 显示处理后的图像 #282
        cv2.imshow('Frame', frame_result) #283
        cv2.waitKey(1) #284

        # 根据检测到的线条位置调整机器人运动（仅在追踪模式下） #286
        if self.__isRunning and self.line_centerx != -1: #287
            error = self.line_centerx - self.img_centerx #288
            self.move_robot(error) #289
        elif self.__isRunning and self.line_centerx == -1: #290
            # 未检测到线条，停下机器人 #291
            velocity_msg = Velocity() #292
            velocity_msg.x = 0.0 #293
            velocity_msg.y = 0.0 #294
            velocity_msg.yaw_rate = 0.0 #295
            self.PuppyVelocityPub.publish(velocity_msg) #296
            self.get_logger().warn("未检测到线条，停下机器人。") #297

    def destroy_node(self): #299
        """节点销毁时发布停止指令""" #300
        self.is_shutdown = True #301
        velocity_msg = Velocity() #302
        velocity_msg.x = 0.0 #303
        velocity_msg.y = 0.0 #304
        velocity_msg.yaw_rate = 0.0 #305
        self.PuppyVelocityPub.publish(velocity_msg) #306
        self.get_logger().info("节点销毁，发布停止指令。") #307
        cv2.destroyAllWindows() #308
        super().destroy_node() #309


def main(args=None): #312
    rclpy.init(args=args) #313
    visual_patrol_demo = VisualPatrolDemo() #314
    try: #315
        rclpy.spin(visual_patrol_demo) #316
    except KeyboardInterrupt: #317
        pass #318
    finally: #319
        visual_patrol_demo.destroy_node() #320
        rclpy.shutdown() #321


if __name__ == '__main__': #324
    main() #325
