#!/usr/bin/env python #1
import os #2
from launch_ros.actions import Node #3
from launch import LaunchDescription #4
from launch.actions import IncludeLaunchDescription, GroupAction #5
from launch.launch_description_sources import PythonLaunchDescriptionSource #6
from launch.substitutions import LaunchConfiguration #7

def generate_launch_description(): #9
    # 定义 Launch 参数 #10
    model = LaunchConfiguration('model', default='0')  # 默认 model 为 0 #11

    puppy_control_package_path = '/home/ubuntu/ros2_ws/src/driver/puppy_control' #13
    peripherals_package_path = '/home/ubuntu/ros2_ws/src/peripherals' #14

    puppy_control_node = GroupAction([ #16
        IncludeLaunchDescription( #17
            PythonLaunchDescriptionSource( #18
                os.path.join(puppy_control_package_path, 'launch/puppy_control.launch.py') #19
            ) #20
        ), #21
        IncludeLaunchDescription( #22
            PythonLaunchDescriptionSource( #23
                os.path.join(peripherals_package_path, 'launch/usb_cam.launch.py') #24
            ) #25
        ), #26
        Node( #27
            package='example', #28
            executable='kick_ball_demo', #29
            name='kick_ball_demo_node', #30
            output='screen', #31
            parameters=[{'model': model}]  # 使用 parameters 传递 model #32
        ), #33
    ]) #34

    return LaunchDescription([ #36
        puppy_control_node #37
    ]) #38
