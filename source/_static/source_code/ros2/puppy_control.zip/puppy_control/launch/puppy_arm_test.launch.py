from launch import LaunchDescription #1
from launch.actions import ExecuteProcess, RegisterEventHandler, TimerAction #2
from launch.event_handlers import OnProcessStart #3
from launch_ros.actions import Node #4

def generate_launch_description(): #6
    # 定义主控制节点 #7
    puppy_control_node = Node( #8
        package='puppy_control', #9
        executable='puppy_control', #10
        name='puppy', #11
        output='screen', #12
        parameters=[ #13
            {'joint_state_pub_topic': 'true'}, #14
            {'joint_state_controller_pub_topic': 'true'}, #15
        ], #16
    ) #17

    # 定义要延迟启动的测试节点 #19
    arm_test_node = Node( #20
        package='puppy_control',  #21
        executable='puppy_arm_test', #22
        name='arm_test', #23
        output='screen' #24
    ) #25

    delayed_arm_test = TimerAction( #27
        period=3.0, #28
        actions=[arm_test_node] #29
    ) #30

    return LaunchDescription([ #32
        puppy_control_node, #33
        delayed_arm_test #34
    ]) #35
