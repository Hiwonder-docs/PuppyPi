from launch import LaunchDescription #1
from launch_ros.actions import Node #2

def generate_launch_description(): #4
    return LaunchDescription([ #5
        Node( #6
            package='puppy_control', #7
            executable='puppy_control', #8
            name='puppy', #9
            output='screen', #10
            parameters=[ #11
                {'joint_state_pub_topic': 'true'},    #12
                {'joint_state_controller_pub_topic': 'true'},  #13
            ], #14
        ), #15
    ] #16
    ) #17
