#!/usr/bin/env python3 #1
# coding=utf8 #2
# Author: Summer #3
# Email: 997950600@qq.com #4

import os #6
import sys #7
import rclpy #8
from rclpy.node import Node #9
from std_msgs.msg import String #10

sys.path.append('/home/ubuntu/software/puppypi_control') #12
from servo_controller import setServoPulse #13
from action_group_control import runActionGroup, stopActionGroup #14

ROS_NODE_NAME = 'puppy_control' #16


class PUPPY(Node): #19
    def __init__(self): #20
        super().__init__('puppy_run_act') #21
        self.subscription = self.create_subscription( #22
            String, #23
            '/multi_robot/runActionGroup', #24
            self.runActionGroupFun, #25
            10 #26
        ) #27
        self.subscription  # prevent unused variable warning #28

    def runActionGroupFun(self, msg): #30
        self.get_logger().debug(f'Received message: {msg.data}') #31
        print(msg.data) #32
        runActionGroup(msg.data, False) #33
        return True #34


def main(args=None): #37
    rclpy.init(args=args) #38
    puppy = PUPPY() #39

    try: #41
        rclpy.spin(puppy) #42
    except KeyboardInterrupt: #43
        pass #44
    finally: #45
        puppy.destroy_node() #46
        rclpy.shutdown() #47


if __name__ == '__main__': #50
    main() #51

