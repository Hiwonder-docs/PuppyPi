#!/usr/bin/python3 #1
# coding=utf8 #2
# Author: Summer #3
# Email: 997950600@qq.com #4
import time #5
import os #6
import sys #7
import math #8
import numpy as np #9
import rclpy #10
from rclpy.node import Node #11
from std_msgs.msg import UInt8, UInt16, Float32, Float64, Bool, String, Float32MultiArray #12
from std_srvs.srv import Empty, SetBool #13
from ros_robot_controller_msgs.msg import BuzzerState #14
from geometry_msgs.msg import Point32, Polygon, Twist #15
from puppy_control_msgs.srv import SetRunActionName #16
from sensor_msgs.msg import Imu, JointState #17
from puppy_control_msgs.msg import Velocity, Gait, SetServo, Pose #18
from rclpy.duration import Duration #19
from sdk.ArmMoveIK import * #20
sys.path.append('/home/ubuntu/software/puppypi_control') #21
from servo_controller import setServoPulse, updatePulse #22
from action_group_control import runActionGroup, stopActionGroup #23
from puppy_kinematics import HiwonderPuppy, PWMServoParams #24
import time #25
from std_msgs.msg import Float64 #26
from ros_robot_controller_sdk import Board #27
from pwm_servo_control import PWMServoControl #28
ROS_NODE_NAME = 'puppy_control' #29

board = Board() #31
#board.enable_reception() #32
psc = PWMServoControl(board) #33

with_arm = 0 #35
if with_arm: #36
    offset = 0.1 #37
else: #38
    offset = 0 #39

# 定义PuppyPose各个姿态的参数 #41
Stand = {'roll': math.radians(0), 'pitch': math.radians(0), 'yaw': 0.000, 'height': -10.0, 'x_shift': -0.5 + offset, 'stance_x': 0, 'stance_y': 0} #42
LieDown = {'roll': 0.000, 'pitch': 0.000, 'yaw': 0.000, 'height': -5.0, 'x_shift': 2.0, 'stance_x': 0, 'stance_y': 0} #43
LookDown = {'roll': math.radians(0), 'pitch': math.radians(-15.0), 'yaw': 0.000, 'height': -10.0, 'x_shift': -0.5, 'stance_x': 0, 'stance_y': 0} #44
LookDown_10deg = {'roll': math.radians(0), 'pitch': math.radians(-10.0), 'yaw': 0.000, 'height': -9.0, 'x_shift': -0.1, 'stance_x': 0, 'stance_y': 0} #45
LookDown_20deg = {'roll': math.radians(0), 'pitch': math.radians(-20.0), 'yaw': 0.000, 'height': -9.0, 'x_shift': -0.1, 'stance_x': 0, 'stance_y': 0} #46
LookDown_30deg = {'roll': math.radians(0), 'pitch': math.radians(-30.0), 'yaw': 0.000, 'height': -9.6, 'x_shift': -1.4, 'stance_x': 1, 'stance_y': 0} #47

StandLow = {'roll': math.radians(0), 'pitch': math.radians(0), 'yaw': 0.000, 'height': -7.0, 'x_shift': -0.5, 'stance_x': 0, 'stance_y': 0} #49
PuppyPose = Stand.copy()  # 初始姿态设为蹲姿 #50

# 定义GaitConfig各个配置的参数 #52
GaitConfigFast = {'overlap_time': 0.1, 'swing_time': 0.15, 'clearance_time': 0.0, 'z_clearance': 5.0} #53
GaitConfigSlow = {'overlap_time': 0.4, 'swing_time': 0.3, 'clearance_time': 0.26, 'z_clearance': 4.0} #54
GaitConfigMarkTime = {'overlap_time': 0.2, 'swing_time': 0.1, 'clearance_time': 0.0, 'z_clearance': 5.0} #55
GaitConfig = GaitConfigFast.copy() #56

class MPU6050: #58

    def __init__(self, node): #60
        self.node = node #61
        self.subscription = self.node.create_subscription(Imu, '/ros_robot_controller/imu_raw', self.GetImuFun, 10) #62
        self.data = {'accel': [0, 0, 0], 'gyro': [0, 0, 0]} #63
        self.SecondOrderFilterX = self._SecondOrderFilter() #64
        self.SecondOrderFilterY = self._SecondOrderFilter() #65

    def GetImuFun(self, msg): #67
        self.data['accel'][0] = msg.linear_acceleration.x #68
        self.data['accel'][1] = msg.linear_acceleration.y #69
        self.data['accel'][2] = msg.linear_acceleration.z #70
        self.data['gyro'][0] = msg.angular_velocity.x #71
        self.data['gyro'][1] = msg.angular_velocity.y #72
        self.data['gyro'][2] = msg.angular_velocity.z #73

    def _SecondOrderFilter(self): #75
        x1 = 0 #76
        x2 = 0 #77
        y1 = 0 #78
        angle = 0 #79
        K2 = 0.02 #80

        def fun(angle_m, gyro_m, dt=0.01): #82
            nonlocal x1, x2, y1, angle, K2 #83
            x1 = (angle_m - angle) * (1 - K2) * (1 - K2) #84
            y1 = y1 + x1 * dt #85
            x2 = y1 + 2 * (1 - K2) * (angle_m - angle) + gyro_m #86
            angle = angle + x2 * dt #87
            return angle #88

        return fun #90

    def get_euler_angle(self, dt=0.01): #92
        data = self.data #93
        accel_Y = math.atan2(data['accel'][0], data['accel'][2]) * 180 / math.pi #94
        gyro_Y = data['gyro'][1] #95
        angleY = self.SecondOrderFilterY(-accel_Y, gyro_Y, dt) #96

        accel_X = math.atan2(data['accel'][1], data['accel'][2]) * 180 / math.pi #98
        gyro_X = data['gyro'][0] #99
        angleX = self.SecondOrderFilterX(accel_X, gyro_X, dt) #100

        return {'pitch': -math.radians(angleX), 'roll': -math.radians(angleY), 'yaw': 0} #102

class PUPPY(Node): #104
    def __init__(self): #105
        super().__init__(ROS_NODE_NAME) #106
        self.start_time = time.time() #107
        # 声明PuppyPose相关参数 #108
        self.declare_parameter('PuppyPose_Stand_roll', Stand['roll']) #109
        self.declare_parameter('PuppyPose_Stand_pitch', Stand['pitch']) #110
        self.declare_parameter('PuppyPose_Stand_yaw', Stand['yaw']) #111
        self.declare_parameter('PuppyPose_Stand_height', Stand['height']) #112
        self.declare_parameter('PuppyPose_Stand_x_shift', Stand['x_shift']) #113
        self.declare_parameter('PuppyPose_Stand_stance_x', Stand['stance_x']) #114
        self.declare_parameter('PuppyPose_Stand_stance_y', Stand['stance_y']) #115

        self.declare_parameter('PuppyPose_LieDown_roll', LieDown['roll']) #117
        self.declare_parameter('PuppyPose_LieDown_pitch', LieDown['pitch']) #118
        self.declare_parameter('PuppyPose_LieDown_yaw', LieDown['yaw']) #119
        self.declare_parameter('PuppyPose_LieDown_height', LieDown['height']) #120
        self.declare_parameter('PuppyPose_LieDown_x_shift', LieDown['x_shift']) #121
        self.declare_parameter('PuppyPose_LieDown_stance_x', LieDown['stance_x']) #122
        self.declare_parameter('PuppyPose_LieDown_stance_y', LieDown['stance_y']) #123

        self.declare_parameter('PuppyPose_LookDown_roll', LookDown['roll']) #125
        self.declare_parameter('PuppyPose_LookDown_pitch', LookDown['pitch']) #126
        self.declare_parameter('PuppyPose_LookDown_yaw', LookDown['yaw']) #127
        self.declare_parameter('PuppyPose_LookDown_height', LookDown['height']) #128
        self.declare_parameter('PuppyPose_LookDown_x_shift', LookDown['x_shift']) #129
        self.declare_parameter('PuppyPose_LookDown_stance_x', LookDown['stance_x']) #130
        self.declare_parameter('PuppyPose_LookDown_stance_y', LookDown['stance_y']) #131

        self.declare_parameter('PuppyPose_LookDown_10deg_roll', LookDown_10deg['roll']) #133
        self.declare_parameter('PuppyPose_LookDown_10deg_pitch', LookDown_10deg['pitch']) #134
        self.declare_parameter('PuppyPose_LookDown_10deg_yaw', LookDown_10deg['yaw']) #135
        self.declare_parameter('PuppyPose_LookDown_10deg_height', LookDown_10deg['height']) #136
        self.declare_parameter('PuppyPose_LookDown_10deg_x_shift', LookDown_10deg['x_shift']) #137
        self.declare_parameter('PuppyPose_LookDown_10deg_stance_x', LookDown_10deg['stance_x']) #138
        self.declare_parameter('PuppyPose_LookDown_10deg_stance_y', LookDown_10deg['stance_y']) #139

        self.declare_parameter('PuppyPose_LookDown_20deg_roll', LookDown_20deg['roll']) #141
        self.declare_parameter('PuppyPose_LookDown_20deg_pitch', LookDown_20deg['pitch']) #142
        self.declare_parameter('PuppyPose_LookDown_20deg_yaw', LookDown_20deg['yaw']) #143
        self.declare_parameter('PuppyPose_LookDown_20deg_height', LookDown_20deg['height']) #144
        self.declare_parameter('PuppyPose_LookDown_20deg_x_shift', LookDown_20deg['x_shift']) #145
        self.declare_parameter('PuppyPose_LookDown_20deg_stance_x', LookDown_20deg['stance_x']) #146
        self.declare_parameter('PuppyPose_LookDown_20deg_stance_y', LookDown_20deg['stance_y']) #147

        self.declare_parameter('PuppyPose_LookDown_30deg_roll', LookDown_30deg['roll']) #149
        self.declare_parameter('PuppyPose_LookDown_30deg_pitch', LookDown_30deg['pitch']) #150
        self.declare_parameter('PuppyPose_LookDown_30deg_yaw', LookDown_30deg['yaw']) #151
        self.declare_parameter('PuppyPose_LookDown_30deg_height', LookDown_30deg['height']) #152
        self.declare_parameter('PuppyPose_LookDown_30deg_x_shift', LookDown_30deg['x_shift']) #153
        self.declare_parameter('PuppyPose_LookDown_30deg_stance_x', LookDown_30deg['stance_x']) #154
        self.declare_parameter('PuppyPose_LookDown_30deg_stance_y', LookDown_30deg['stance_y']) #155

        self.declare_parameter('PuppyPose_StandLow_roll', StandLow['roll']) #157
        self.declare_parameter('PuppyPose_StandLow_pitch', StandLow['pitch']) #158
        self.declare_parameter('PuppyPose_StandLow_yaw', StandLow['yaw']) #159
        self.declare_parameter('PuppyPose_StandLow_height', StandLow['height']) #160
        self.declare_parameter('PuppyPose_StandLow_x_shift', StandLow['x_shift']) #161
        self.declare_parameter('PuppyPose_StandLow_stance_x', StandLow['stance_x']) #162
        self.declare_parameter('PuppyPose_StandLow_stance_y', StandLow['stance_y']) #163

        # 声明GaitConfig相关参数 #165
        self.declare_parameter('GaitConfigFast_overlap_time', GaitConfigFast['overlap_time']) #166
        self.declare_parameter('GaitConfigFast_swing_time', GaitConfigFast['swing_time']) #167
        self.declare_parameter('GaitConfigFast_clearance_time', GaitConfigFast['clearance_time']) #168
        self.declare_parameter('GaitConfigFast_z_clearance', GaitConfigFast['z_clearance']) #169

        self.declare_parameter('GaitConfigSlow_overlap_time', GaitConfigSlow['overlap_time']) #171
        self.declare_parameter('GaitConfigSlow_swing_time', GaitConfigSlow['swing_time']) #172
        self.declare_parameter('GaitConfigSlow_clearance_time', GaitConfigSlow['clearance_time']) #173
        self.declare_parameter('GaitConfigSlow_z_clearance', GaitConfigSlow['z_clearance']) #174

        self.declare_parameter('GaitConfigMarkTime_overlap_time', GaitConfigMarkTime['overlap_time']) #176
        self.declare_parameter('GaitConfigMarkTime_swing_time', GaitConfigMarkTime['swing_time']) #177
        self.declare_parameter('GaitConfigMarkTime_clearance_time', GaitConfigMarkTime['clearance_time']) #178
        self.declare_parameter('GaitConfigMarkTime_z_clearance', GaitConfigMarkTime['z_clearance']) #179

        self.declare_parameter('GaitConfig_current_overlap_time', GaitConfig['overlap_time']) #181
        self.declare_parameter('GaitConfig_current_swing_time', GaitConfig['swing_time']) #182
        self.declare_parameter('GaitConfig_current_clearance_time', GaitConfig['clearance_time']) #183
        self.declare_parameter('GaitConfig_current_z_clearance', GaitConfig['z_clearance']) #184

        # 声明其他参数 #186
        self.declare_parameter('joint_state_pub_topic', 'false') #187
        self.declare_parameter('joint_state_controller_pub_topic', 'false') #188

        # 从参数中读取PuppyPose和GaitConfig #190
        self.PuppyPose = { #191
            'Stand': { #192
                'roll': self.get_parameter('PuppyPose_Stand_roll').get_parameter_value().double_value, #193
                'pitch': self.get_parameter('PuppyPose_Stand_pitch').get_parameter_value().double_value, #194
                'yaw': self.get_parameter('PuppyPose_Stand_yaw').get_parameter_value().double_value, #195
                'height': self.get_parameter('PuppyPose_Stand_height').get_parameter_value().double_value, #196
                'x_shift': self.get_parameter('PuppyPose_Stand_x_shift').get_parameter_value().double_value, #197
                'stance_x': self.get_parameter('PuppyPose_Stand_stance_x').get_parameter_value().integer_value, #198
                'stance_y': self.get_parameter('PuppyPose_Stand_stance_y').get_parameter_value().integer_value #199
            }, #200
            'LieDown': { #201
                'roll': self.get_parameter('PuppyPose_LieDown_roll').get_parameter_value().double_value, #202
                'pitch': self.get_parameter('PuppyPose_LieDown_pitch').get_parameter_value().double_value, #203
                'yaw': self.get_parameter('PuppyPose_LieDown_yaw').get_parameter_value().double_value, #204
                'height': self.get_parameter('PuppyPose_LieDown_height').get_parameter_value().double_value, #205
                'x_shift': self.get_parameter('PuppyPose_LieDown_x_shift').get_parameter_value().double_value, #206
                'stance_x': self.get_parameter('PuppyPose_LieDown_stance_x').get_parameter_value().integer_value, #207
                'stance_y': self.get_parameter('PuppyPose_LieDown_stance_y').get_parameter_value().integer_value #208
            }, #209
            'LookDown': { #210
                'roll': self.get_parameter('PuppyPose_LookDown_roll').get_parameter_value().double_value, #211
                'pitch': self.get_parameter('PuppyPose_LookDown_pitch').get_parameter_value().double_value, #212
                'yaw': self.get_parameter('PuppyPose_LookDown_yaw').get_parameter_value().double_value, #213
                'height': self.get_parameter('PuppyPose_LookDown_height').get_parameter_value().double_value, #214
                'x_shift': self.get_parameter('PuppyPose_LookDown_x_shift').get_parameter_value().double_value, #215
                'stance_x': self.get_parameter('PuppyPose_LookDown_stance_x').get_parameter_value().integer_value, #216
                'stance_y': self.get_parameter('PuppyPose_LookDown_stance_y').get_parameter_value().integer_value #217
            }, #218
            'LookDown_10deg': { #219
                'roll': self.get_parameter('PuppyPose_LookDown_10deg_roll').get_parameter_value().double_value, #220
                'pitch': self.get_parameter('PuppyPose_LookDown_10deg_pitch').get_parameter_value().double_value, #221
                'yaw': self.get_parameter('PuppyPose_LookDown_10deg_yaw').get_parameter_value().double_value, #222
                'height': self.get_parameter('PuppyPose_LookDown_10deg_height').get_parameter_value().double_value, #223
                'x_shift': self.get_parameter('PuppyPose_LookDown_10deg_x_shift').get_parameter_value().double_value, #224
                'stance_x': self.get_parameter('PuppyPose_LookDown_10deg_stance_x').get_parameter_value().integer_value, #225
                'stance_y': self.get_parameter('PuppyPose_LookDown_10deg_stance_y').get_parameter_value().integer_value #226
            }, #227
            'LookDown_20deg': { #228
                'roll': self.get_parameter('PuppyPose_LookDown_20deg_roll').get_parameter_value().double_value, #229
                'pitch': self.get_parameter('PuppyPose_LookDown_20deg_pitch').get_parameter_value().double_value, #230
                'yaw': self.get_parameter('PuppyPose_LookDown_20deg_yaw').get_parameter_value().double_value, #231
                'height': self.get_parameter('PuppyPose_LookDown_20deg_height').get_parameter_value().double_value, #232
                'x_shift': self.get_parameter('PuppyPose_LookDown_20deg_x_shift').get_parameter_value().double_value, #233
                'stance_x': self.get_parameter('PuppyPose_LookDown_20deg_stance_x').get_parameter_value().integer_value, #234
                'stance_y': self.get_parameter('PuppyPose_LookDown_20deg_stance_y').get_parameter_value().integer_value #235
            }, #236
            'LookDown_30deg': { #237
                'roll': self.get_parameter('PuppyPose_LookDown_30deg_roll').get_parameter_value().double_value, #238
                'pitch': self.get_parameter('PuppyPose_LookDown_30deg_pitch').get_parameter_value().double_value, #239
                'yaw': self.get_parameter('PuppyPose_LookDown_30deg_yaw').get_parameter_value().double_value, #240
                'height': self.get_parameter('PuppyPose_LookDown_30deg_height').get_parameter_value().double_value, #241
                'x_shift': self.get_parameter('PuppyPose_LookDown_30deg_x_shift').get_parameter_value().double_value, #242
                'stance_x': self.get_parameter('PuppyPose_LookDown_30deg_stance_x').get_parameter_value().integer_value, #243
                'stance_y': self.get_parameter('PuppyPose_LookDown_30deg_stance_y').get_parameter_value().integer_value #244
            }, #245
            'StandLow': { #246
                'roll': self.get_parameter('PuppyPose_StandLow_roll').get_parameter_value().double_value, #247
                'pitch': self.get_parameter('PuppyPose_StandLow_pitch').get_parameter_value().double_value, #248
                'yaw': self.get_parameter('PuppyPose_StandLow_yaw').get_parameter_value().double_value, #249
                'height': self.get_parameter('PuppyPose_StandLow_height').get_parameter_value().double_value, #250
                'x_shift': self.get_parameter('PuppyPose_StandLow_x_shift').get_parameter_value().double_value, #251
                'stance_x': self.get_parameter('PuppyPose_StandLow_stance_x').get_parameter_value().integer_value, #252
                'stance_y': self.get_parameter('PuppyPose_StandLow_stance_y').get_parameter_value().integer_value #253
            } #254
        } #255

        self.GaitConfig = { #257
            'Fast': { #258
                'overlap_time': self.get_parameter('GaitConfigFast_overlap_time').get_parameter_value().double_value, #259
                'swing_time': self.get_parameter('GaitConfigFast_swing_time').get_parameter_value().double_value, #260
                'clearance_time': self.get_parameter('GaitConfigFast_clearance_time').get_parameter_value().double_value, #261
                'z_clearance': self.get_parameter('GaitConfigFast_z_clearance').get_parameter_value().double_value #262
            }, #263
            'Slow': { #264
                'overlap_time': self.get_parameter('GaitConfigSlow_overlap_time').get_parameter_value().double_value, #265
                'swing_time': self.get_parameter('GaitConfigSlow_swing_time').get_parameter_value().double_value, #266
                'clearance_time': self.get_parameter('GaitConfigSlow_clearance_time').get_parameter_value().double_value, #267
                'z_clearance': self.get_parameter('GaitConfigSlow_z_clearance').get_parameter_value().double_value #268
            }, #269
            'MarkTime': { #270
                'overlap_time': self.get_parameter('GaitConfigMarkTime_overlap_time').get_parameter_value().double_value, #271
                'swing_time': self.get_parameter('GaitConfigMarkTime_swing_time').get_parameter_value().double_value, #272
                'clearance_time': self.get_parameter('GaitConfigMarkTime_clearance_time').get_parameter_value().double_value, #273
                'z_clearance': self.get_parameter('GaitConfigMarkTime_z_clearance').get_parameter_value().double_value #274
            }, #275
            'current': { #276
                'overlap_time': self.get_parameter('GaitConfig_current_overlap_time').get_parameter_value().double_value, #277
                'swing_time': self.get_parameter('GaitConfig_current_swing_time').get_parameter_value().double_value, #278
                'clearance_time': self.get_parameter('GaitConfig_current_clearance_time').get_parameter_value().double_value, #279
                'z_clearance': self.get_parameter('GaitConfig_current_z_clearance').get_parameter_value().double_value #280
            } #281
        } #282

        # 初始化HiwonderPuppy #284
        self.puppy = HiwonderPuppy(setServoPulse=self.setServoPulse, servoParams=PWMServoParams(), dof='8') #285
        self.mpu = MPU6050(self) #286
        self.puppy.imu = None  # 初始不使用IMU #287

        # 配置初始姿态和步态（使用蹲姿StandLow） #289
        initial_pose = self.PuppyPose['LieDown'] #290
        self.puppy.stance_config( #291
            self.stance( #292
                initial_pose['stance_x'], #293
                initial_pose['stance_y'], #294
                initial_pose['height'], #295
                initial_pose['x_shift'] #296
            ), #297
            initial_pose['pitch'], #298
            initial_pose['roll'] #299
        ) #300
        self.puppy.gait_config( #301
            overlap_time=self.GaitConfig['current']['overlap_time'], #302
            swing_time=self.GaitConfig['current']['swing_time'], #303
            clearance_time=self.GaitConfig['current']['clearance_time'], #304
            z_clearance=self.GaitConfig['current']['z_clearance'] #305
        ) #306

        self.puppy.start() #308
        self.puppy.move_stop(servo_run_time=500) #309
        self.ak = ArmIK() #310
        self.ak.setPitchRangeMoving((8.51, 0, 3.3), 500) #311
        self.get_clock().sleep_for(rclpy.duration.Duration(seconds=0.5)) #312
        setServoPulse(9, 1500, 300) #313
        self.get_clock().sleep_for(rclpy.duration.Duration(seconds=0.3)) #314

        # 创建服务 #316
        self.create_service(SetBool, f'/{ROS_NODE_NAME}/set_running', self.set_running) #317
        self.create_service(Empty, f'/{ROS_NODE_NAME}/go_home', self.go_home) #318
        self.create_service(SetBool, f'/{ROS_NODE_NAME}/set_self_balancing', self.set_self_balancing) #319
        self.create_service(SetRunActionName, f'/{ROS_NODE_NAME}/runActionGroup', self.runActionGroupFun) #320
        self.create_service(SetBool, f'/{ROS_NODE_NAME}/set_mark_time', self.set_mark_time) #321

        # 创建订阅者 #323
        self.create_subscription(Gait, f'/{ROS_NODE_NAME}/gait', self.GaitFun, 10) #324
        self.create_subscription(Velocity, f'/{ROS_NODE_NAME}/velocity', self.VelocityFun, 10) #325
        self.create_subscription(Velocity, f'/{ROS_NODE_NAME}/velocity_move', self.VelocityMoveFun, 10) #326
        self.create_subscription(Velocity, f'/{ROS_NODE_NAME}/velocity/autogait', self.VelocityAutogaitFun, 10) #327
        self.create_subscription(Twist, '/cmd_vel', self.Cmd_velFun, 10) #328
        self.create_subscription(Twist, '/cmd_vel_nav', self.Cmd_vel_nav_Fun, 10) #329
        self.create_subscription(Pose, f'/{ROS_NODE_NAME}/pose', self.PoseFun, 10) #330
        self.create_subscription(Polygon, f'/{ROS_NODE_NAME}/fourLegsRelativeCoordControl', self.fourLegsRelativeCoordControlFun, 10) #331
        self.create_subscription(Float32MultiArray, f'/{ROS_NODE_NAME}/gait/pc', self.GaitPCFun, 10) #332
        self.create_subscription(SetServo, f'/{ROS_NODE_NAME}/setServo', self.SetServo_Fun, 10) #333

        # 创建发布者 #335
        self.legs_coord_pub = self.create_publisher(Polygon, f'/{ROS_NODE_NAME}/legs_coord', 10) #336
        self.joint_state_pub = self.create_publisher(JointState, '/joint_states', 10) #337
        self.joint_state = JointState() #338
        self.joint_state.name = ['rf_joint1', 'lf_joint1', 'rb_joint1', 'lb_joint1', #339
                                 'rf_joint2', 'lf_joint2', 'rb_joint2', 'lb_joint2'] #340
        command_topics = ["/puppy/joint1_position_controller/command", #341
                          "/puppy/joint2_position_controller/command", #342
                          "/puppy/joint3_position_controller/command", #343
                          "/puppy/joint4_position_controller/command", #344
                          "/puppy/joint5_position_controller/command", #345
                          "/puppy/joint6_position_controller/command", #346
                          "/puppy/joint7_position_controller/command", #347
                          "/puppy/joint8_position_controller/command"] #348

        self.joint_controller_publishers = [] #350
        for topic in command_topics: #351
            self.joint_controller_publishers.append(self.create_publisher(Float64, topic, 10)) #352

        # 创建buzzer发布者 #354
        self.buzzer_pub = self.create_publisher(BuzzerState, '/ros_robot_controller/set_buzzer', 10) #355
        self.get_clock().sleep_for(rclpy.duration.Duration(seconds=0.2)) #356
        buzzer_msg = BuzzerState() #357
        buzzer_msg.freq = 1900 #358
        buzzer_msg.on_time = 0.1 #359
        buzzer_msg.off_time = 0.9 #360
        buzzer_msg.repeat = 1 #361
        self.buzzer_pub.publish(buzzer_msg) #362

        # 创建定时器 #364
        self.timer = self.create_timer(0.01, self.pub)  # 100Hz #365
        self.times = 0 #366

        # 读取joint_state_pub_topic和joint_state_controller_pub_topic参数 #368
        self.joint_state_pub_topic = self.get_parameter('joint_state_pub_topic').get_parameter_value().string_value #369
        self.joint_state_controller_pub_topic = self.get_parameter('joint_state_controller_pub_topic').get_parameter_value().string_value #370

    def setServoPulse(self, ids, pulse, use_time): #372

        # self.get_logger().info(str(ids) + ' '+ str(pulse)) #374
        
        # if ids == 8: #376
            # self.get_logger().info('\n') #377
        psc.setPulse(ids, pulse, use_time) #378

    def stance(self, x=0, y=0, z=-11, x_shift=2): #380
        return np.array([ #381
            [x + x_shift, x + x_shift, -x + x_shift, -x + x_shift], #382
            [y, y, y, y], #383
            [z, z, z, z], #384
        ])  # 此array的组合方式不要去改变 #385

    def SetServo_Fun(self, msg): #387
        pulse = max(500, min(msg.pulse, 2500)) #388
        time = max(0, min(msg.time, 30000)) #389
        setServoPulse(msg.id, pulse, time) #390

    def GaitFun(self, msg): #392
        global GaitConfig #393
        self.get_logger().debug(str(msg)) #394
        GaitConfig = { #395
            'overlap_time': msg.overlap_time, #396
            'swing_time': msg.swing_time, #397
            'clearance_time': msg.clearance_time, #398
            'z_clearance': msg.z_clearance #399
        } #400
        self.puppy.gait_config( #401
            overlap_time=GaitConfig['overlap_time'], #402
            swing_time=GaitConfig['swing_time'], #403
            clearance_time=GaitConfig['clearance_time'], #404
            z_clearance=GaitConfig['z_clearance'] #405
        ) #406

    def GaitPCFun(self, msg): #408
        global GaitConfig #409
        self.get_logger().debug(str(msg)) #410
        if msg.data[0] == 0: #411
            self.puppy.move_stop(servo_run_time=100) #412
            self.puppy.stance_config( #413
                self.stance( #414
                    PuppyPose['stance_x'], #415
                    PuppyPose['stance_y'], #416
                    PuppyPose['height'], #417
                    PuppyPose['x_shift'] #418
                ), #419
                PuppyPose['pitch'], #420
                PuppyPose['roll'] #421
            ) #422
        else: #423
            gait_type = msg.data[0] #424
            if gait_type == 1:  # Trot #425
                GaitConfig['overlap_time'] = msg.data[2] / 4 #426
                GaitConfig['swing_time'] = msg.data[2] / 4 #427
                GaitConfig['clearance_time'] = 0 #428
            elif gait_type == 2:  # Amble #429
                GaitConfig['overlap_time'] = msg.data[2] / 5 #430
                GaitConfig['swing_time'] = msg.data[2] / 5 #431
                GaitConfig['clearance_time'] = msg.data[2] / 10 #432
            elif gait_type == 3:  # Walk #433
                GaitConfig['overlap_time'] = msg.data[2] / 6 #434
                GaitConfig['swing_time'] = msg.data[2] / 6 #435
                GaitConfig['clearance_time'] = msg.data[2] / 6 #436

            GaitConfig['z_clearance'] = msg.data[1] #438
            self.puppy.gait_config( #439
                overlap_time=GaitConfig['overlap_time'], #440
                swing_time=GaitConfig['swing_time'], #441
                clearance_time=GaitConfig['clearance_time'], #442
                z_clearance=GaitConfig['z_clearance'] #443
            ) #444
            self.VelocityFun(Velocity(x=msg.data[3], y=msg.data[4], yaw_rate=msg.data[5])) #445

    def Cmd_velFun(self, msg): #447
        global PuppyPose #448
        self.get_logger().debug(str(msg)) #449

        if abs(msg.linear.x) > 0.5 or abs(msg.angular.z) > 0.5: #451
            PuppyPose = self.PuppyPose['Stand'].copy() #452
            self.puppy.stance_config( #453
                self.stance( #454
                    PuppyPose['stance_x'], #455
                    PuppyPose['stance_y'], #456
                    PuppyPose['height'], #457
                    PuppyPose['x_shift'] #458
                ), #459
                PuppyPose['pitch'], #460
                PuppyPose['roll'] #461
            ) #462

            if abs(msg.linear.x) > abs(msg.angular.z): #464
                self.VelocityFun(Velocity(x=16 * np.sign(msg.linear.x), y=0.0, yaw_rate=0.0)) #465
            else: #466
                self.VelocityFun(Velocity(x=0, y=0, yaw_rate=np.radians(25) * np.sign(msg.angular.z))) #467
        elif msg.linear.x == 0 and msg.angular.z == 0: #468
            self.VelocityFun(Velocity(x=0.0, y=0.0, yaw_rate=0.0)) #469

    def Cmd_vel_nav_Fun(self, msg): #471
        global PuppyPose #472
        PuppyPose = self.PuppyPose['Stand'].copy() #473
        self.puppy.stance_config( #474
            self.stance( #475
                PuppyPose['stance_x'], #476
                PuppyPose['stance_y'], #477
                PuppyPose['height'], #478
                PuppyPose['x_shift'] #479
            ), #480
            PuppyPose['pitch'], #481
            PuppyPose['roll'] #482
        ) #483
        self.VelocityFun(Velocity(x=msg.linear.x * 100, y=0.0, yaw_rate=msg.angular.z)) #484

    def VelocityMoveFun(self, msg): #486
        self.get_logger().debug(str(msg)) #487
        if msg.x == 0 and msg.y == 0 and msg.yaw_rate == 0: #488
            self.puppy.move_stop(servo_run_time=100) #489
            self.puppy.stance_config( #490
                self.stance( #491
                    PuppyPose['stance_x'], #492
                    PuppyPose['stance_y'], #493
                    PuppyPose['height'], #494
                    PuppyPose['x_shift'] #495
                ), #496
                PuppyPose['pitch'], #497
                PuppyPose['roll'] #498
            ) #499
        else: #500
            self.puppy.move(x=msg.x, y=msg.y, yaw_rate=msg.yaw_rate) #501

    def VelocityFun(self, msg): #503
        self.get_logger().debug(str(msg)) #504
        if msg.x == -999: #505
            self.puppy.move(x=0.0, y=0.0, yaw_rate=0.0) #506
            self.puppy.stance_config( #507
                self.stance( #508
                    PuppyPose['stance_x'], #509
                    PuppyPose['stance_y'], #510
                    PuppyPose['height'], #511
                    PuppyPose['x_shift'] #512
                ), #513
                PuppyPose['pitch'], #514
                PuppyPose['roll'] #515
            ) #516
        elif msg.x == 0 and msg.y == 0 and msg.yaw_rate == 0: #517
            self.puppy.move_stop(servo_run_time=100) #518
            self.puppy.stance_config( #519
                self.stance( #520
                    PuppyPose['stance_x'], #521
                    PuppyPose['stance_y'], #522
                    PuppyPose['height'], #523
                    PuppyPose['x_shift'] #524
                ), #525
                PuppyPose['pitch'], #526
                PuppyPose['roll'] #527
            ) #528
        elif abs(msg.x) <= 35 and abs(msg.y) == 0 and abs(msg.yaw_rate) <= np.radians(51): #529
            if msg.x > 0: #530
                self.puppy.stance_config( #531
                    self.stance( #532
                        PuppyPose['stance_x'], #533
                        PuppyPose['stance_y'], #534
                        PuppyPose['height'], #535
                        PuppyPose['x_shift'] - 0.8 #536
                    ), #537
                    PuppyPose['pitch'], #538
                    PuppyPose['roll'] #539
                ) #540
            else: #541
                self.puppy.stance_config( #542
                    self.stance( #543
                        PuppyPose['stance_x'], #544
                        PuppyPose['stance_y'], #545
                        PuppyPose['height'], #546
                        PuppyPose['x_shift'] + 0.8 #547
                    ), #548
                    PuppyPose['pitch'], #549
                    PuppyPose['roll'] #550
                ) #551
            self.puppy.move(x=msg.x, y=msg.y, yaw_rate=msg.yaw_rate) #552

    def VelocityAutogaitFun(self, msg): #554
        self.get_logger().debug(str(msg)) #555
        if msg.x == 0 and msg.y == 0 and msg.yaw_rate == 0: #556
            self.puppy.move_stop(servo_run_time=100) #557
            self.puppy.stance_config( #558
                self.stance( #559
                    PuppyPose['stance_x'], #560
                    PuppyPose['stance_y'], #561
                    PuppyPose['height'], #562
                    PuppyPose['x_shift'] #563
                ), #564
                PuppyPose['pitch'], #565
                PuppyPose['roll'] #566
            ) #567
        elif abs(msg.x) <= 35 and abs(msg.y) == 0 and abs(msg.yaw_rate) <= np.radians(51): #568
            # 计算步态参数 #569
            if abs(msg.x) <= 10: #570
                overlap_time_x = 0.45 - abs(msg.x) * 0.023 #571
                swing_time_x = 0.38 - abs(msg.x) * 0.0154 #572
                clearance_time_x = swing_time_x - 0.04 #573
            elif abs(msg.x) <= 15: #574
                overlap_time_x = 0.45 - abs(msg.x) * 0.023 #575
                swing_time_x = 0.38 - abs(msg.x) * 0.0154 #576
                clearance_time_x = 0 #577
            else: #578
                overlap_time_x = 0.1 #579
                swing_time_x = 0.15 #580
                clearance_time_x = 0 #581

            if abs(msg.yaw_rate) <= np.radians(10): #583
                overlap_time_yaw_rate = 0.23 - abs(msg.yaw_rate) * 0.37 #584
                swing_time_yaw_rate = 0.36 - abs(msg.yaw_rate) * 0.74 #585
                clearance_time_yaw_rate = swing_time_yaw_rate - 0.04 #586
            elif abs(msg.yaw_rate) <= np.radians(20): #587
                overlap_time_yaw_rate = 0.23 - abs(msg.yaw_rate) * 0.37 #588
                swing_time_yaw_rate = 0.41 - abs(msg.yaw_rate) * 0.74 #589
                clearance_time_yaw_rate = 0 #590
            else: #591
                overlap_time_yaw_rate = 0.1 #592
                swing_time_yaw_rate = 0.15 #593
                clearance_time_yaw_rate = 0 #594

            GaitConfig['overlap_time'] = min(overlap_time_x, overlap_time_yaw_rate) #596
            GaitConfig['swing_time'] = min(swing_time_x, swing_time_yaw_rate) #597
            GaitConfig['clearance_time'] = min(clearance_time_x, clearance_time_yaw_rate) #598

            self.puppy.gait_config( #600
                overlap_time=GaitConfig['overlap_time'], #601
                swing_time=GaitConfig['swing_time'], #602
                clearance_time=GaitConfig['clearance_time'], #603
                z_clearance=GaitConfig['z_clearance'] #604
            ) #605

            if msg.x > 0: #607
                self.puppy.stance_config( #608
                    self.stance( #609
                        PuppyPose['stance_x'], #610
                        PuppyPose['stance_y'], #611
                        PuppyPose['height'], #612
                        PuppyPose['x_shift'] - 0.8 #613
                    ), #614
                    PuppyPose['pitch'], #615
                    PuppyPose['roll'] #616
                ) #617
            else: #618
                self.puppy.stance_config( #619
                    self.stance( #620
                        PuppyPose['stance_x'], #621
                        PuppyPose['stance_y'], #622
                        PuppyPose['height'], #623
                        PuppyPose['x_shift'] + 0.8 #624
                    ), #625
                    PuppyPose['pitch'], #626
                    PuppyPose['roll'] #627
                ) #628

            self.puppy.move(x=msg.x, y=msg.y, yaw_rate=msg.yaw_rate) #630

    def PoseFun(self, msg): #632
        global PuppyPose #633
        self.get_logger().debug(str(msg)) #634
        if (abs(msg.roll) <= math.radians(31) and abs(msg.pitch) <= math.radians(31) #635
                and abs(msg.yaw) == 0 and -15 <= msg.height <= -5 #636
                and abs(msg.stance_x) <= 5 and abs(msg.stance_y) <= 5 #637
                and abs(msg.x_shift) <= 10): #638

            if msg.run_time != 0: #640
                self.puppy.move_stop(servo_run_time=msg.run_time) #641
                self.get_clock().sleep_for(rclpy.duration.Duration(seconds=0.01)) #642
                self.puppy.servo_force_run() #643

            PuppyPose = { #645
                'roll': msg.roll, #646
                'pitch': msg.pitch, #647
                'yaw': msg.yaw, #648
                'height': msg.height, #649
                'x_shift': msg.x_shift, #650
                'stance_x': msg.stance_x, #651
                'stance_y': msg.stance_y #652
            } #653
            self.puppy.stance_config( #654
                self.stance( #655
                    PuppyPose['stance_x'], #656
                    PuppyPose['stance_y'], #657
                    PuppyPose['height'], #658
                    PuppyPose['x_shift'] #659
                ), #660
                PuppyPose['pitch'], #661
                PuppyPose['roll'] #662
            ) #663

    def fourLegsRelativeCoordControlFun(self, msg): #665
        self.get_logger().debug(str(msg)) #666
        rotated_foot_locations = np.zeros((3, 4)) #667
        for idx, p in enumerate(msg.points): #668
            rotated_foot_locations[:, idx] = [p.x, p.y, p.z] #669

        joint_angles = self.puppy.fourLegsRelativeCoordControl(rotated_foot_locations) #671
        self.puppy.sendServoAngle(joint_angles) #672

    def runActionGroupFun(self, request, response): #674
        self.get_logger().debug(str(request)) #675
        runActionGroup(request.name, request.wait) #676
        response.success = True #677
        response.message = request.name #678
        return response #679

    def pub(self): #681
        # 定义日志文件的目录和路径 #682
        # log_dir = '/home/ubuntu/share/tmp/' #683
        # log_file_path = os.path.join(log_dir, 'joint_angles_log.txt') #684

        # 检查目录是否存在，不存在则创建 #686
        # if not os.path.exists(log_dir): #687
            # os.makedirs(log_dir) #688
            # print(f"目录 {log_dir} 不存在，已创建。") #689

        # 添加标志位，确保日志路径只打印一次 #691
        # if not hasattr(self, 'log_printed'): #692
            # self.log_printed = False #693

        coord = self.puppy.get_coord() #695

        if self.times >= 100: #697
            self.times = 0 #698
            msg = Polygon() #699
            for i in range(4): #700
                point = Point32() #701
                point.x = float(coord[0, i]) #702
                point.y = float(coord[1, i]) #703
                point.z = float(coord[2, i]) #704
                msg.points.append(point) #705
            self.legs_coord_pub.publish(msg) #706
            self.get_clock().sleep_for(rclpy.duration.Duration(seconds=0.002)) #707

            # 更新参数 #709
            self.joint_state_pub_topic = self.get_parameter('joint_state_pub_topic').get_parameter_value().string_value #710
            self.joint_state_controller_pub_topic = self.get_parameter('joint_state_controller_pub_topic').get_parameter_value().string_value #711

        self.times += 1 #713

        if self.joint_state_pub_topic.lower() == 'true' or self.joint_state_controller_pub_topic.lower() == 'true': #715
            # 获取舵机角度 #716
            joint_angles = self.puppy.fourLegsRelativeCoordControl(coord / 100) #717

            # 转换角度为度数并打印 #719
            joint_angles_in_degrees = joint_angles * 57.3 #720
            # self.get_logger().info('\n' + str(joint_angles_in_degrees)) #721
            # 获取当前时间，并计算相对时间 #722
            current_time = time.time() #723
            # self.get_logger().info(str(time.time() - self.start_time)) #724
            self.start_time = time.time() #725
            relative_time = current_time - self.start_time #726

            # 记录到文件 #728
            # try: #729
                # with open(log_file_path, 'a') as f: #730
                    # f.write(f"{relative_time:.2f}s - 舵机角度 (角度): {joint_angles_in_degrees}\n") #731
                # if not self.log_printed: #732
                    # print(f"Joint angles logged to {log_file_path}") #733
                    # self.log_printed = True  # 设置标志位，确保日志路径只打印一次 #734
            # except Exception as e: #735
                # print(f"写入日志文件失败: {e}") #736

            data = sum([list(joint_angles[1, :]), list(joint_angles[2, :])], []) #738
            self.joint_state.header.stamp = self.get_clock().now().to_msg() #739

            for i in range(len(data)): #741
                if i > 3: #742
                    data[i] = 0.0695044662 * data[i] ** 3 - 0.0249173454 * data[i] ** 2 - 0.786456081 * data[i] + 1.5443387652 - math.pi / 2 #743

                # 正确初始化Float64消息 #745
                float64_msg = Float64(data=data[i]) #746
                if self.joint_state_controller_pub_topic.lower() == 'true': #747
                    self.joint_controller_publishers[i].publish(float64_msg) #748

            if self.joint_state_pub_topic.lower() == 'true': #750
                self.joint_state.position = data #751
                self.joint_state_pub.publish(self.joint_state) #752


    def set_running(self, request, response): #755
        self.get_logger().debug(str(request)) #756
        if request.data: #757
            self.puppy.move_stop(servo_run_time=500) #758
            self.puppy.start() #759
        else: #760
            self.puppy.move_stop(servo_run_time=500) #761
            self.puppy.end() #762
        response.success = True #763
        response.message = 'set_running' #764
        return response #765

    def set_self_balancing(self, request, response): #767
        self.get_logger().debug(str(request)) #768
        if request.data: #769
            global PuppyPose #770
            PuppyPose = self.PuppyPose['StandLow'].copy() #771
            self.puppy.stance_config( #772
                self.stance( #773
                    PuppyPose['stance_x'], #774
                    PuppyPose['stance_y'], #775
                    PuppyPose['height'], #776
                    PuppyPose['x_shift'] #777
                ), #778
                PuppyPose['pitch'], #779
                PuppyPose['roll'] #780
            ) #781

            self.puppy.move_stop(servo_run_time=500) #783
            self.get_clock().sleep_for(rclpy.duration.Duration(seconds=0.01)) #784
            self.puppy.servo_force_run() #785
            self.get_clock().sleep_for(rclpy.duration.Duration(seconds=0.5)) #786
            self.puppy.move_stop(servo_run_time=0) #787
            self.puppy.imu = self.mpu #788
        else: #789
            self.puppy.imu = None #790
        response.success = True #791
        response.message = 'set_self_balancing' #792
        return response #793

    def set_mark_time(self, request, response): #795
        self.get_logger().debug(str(request)) #796
        if request.data: #797
            self.go_home() #798
            GaitConfig['overlap_time'] = self.get_parameter('GaitConfigMarkTime_overlap_time').get_parameter_value().double_value #799
            GaitConfig['swing_time'] = self.get_parameter('GaitConfigMarkTime_swing_time').get_parameter_value().double_value #800
            GaitConfig['clearance_time'] = self.get_parameter('GaitConfigMarkTime_clearance_time').get_parameter_value().double_value #801
            GaitConfig['z_clearance'] = self.get_parameter('GaitConfigMarkTime_z_clearance').get_parameter_value().double_value #802
            self.puppy.gait_config( #803
                overlap_time=GaitConfig['overlap_time'], #804
                swing_time=GaitConfig['swing_time'], #805
                clearance_time=GaitConfig['clearance_time'], #806
                z_clearance=GaitConfig['z_clearance'] #807
            ) #808
            self.puppy.move(x=0, y=0, yaw_rate=0) #809
        response.success = True #810
        response.message = 'set_mark_time' #811
        return response #812

    def go_home(self, request=None, response=None): #814
        global PuppyPose #815
        self.get_logger().debug('go_home') #816
        PuppyPose = self.PuppyPose['Stand'].copy() #817
        self.puppy.stance_config( #818
            self.stance( #819
                PuppyPose['stance_x'], #820
                PuppyPose['stance_y'], #821
                PuppyPose['height'], #822
                PuppyPose['x_shift'] #823
            ), #824
            PuppyPose['pitch'], #825
            PuppyPose['roll'] #826
        ) #827

        self.puppy.move_stop(servo_run_time=500) #829
        self.get_clock().sleep_for(rclpy.duration.Duration(seconds=0.01)) #830
        self.puppy.servo_force_run() #831
        self.get_clock().sleep_for(rclpy.duration.Duration(seconds=0.5)) #832
        self.puppy.move_stop(servo_run_time=0) #833
        return Empty.Response() #834

def main(args=None): #836
    rclpy.init(args=args) #837
    puppy = PUPPY() #838
    try: #839
        rclpy.spin(puppy) #840
    except KeyboardInterrupt: #841
        pass #842
    finally: #843
        puppy.destroy_node() #844
        rclpy.shutdown() #845

if __name__ == '__main__': #847
    main() #848



