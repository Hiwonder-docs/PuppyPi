#!/usr/bin/env python3 #1
# -*- coding: utf-8 -*- #2

import rclpy #4
from rclpy.node import Node #5
from puppy_control_msgs.srv import SetRunActionName #6

class PuppyArmController(Node): #8
    def __init__(self): #9
        super().__init__('puppy_arm_controller') #10
        self.client = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #11
        
        while not self.client.wait_for_service(timeout_sec=1.0): #13
            self.get_logger().info('Service not available, waiting...') #14
        
        self.send_request() #16

    def send_request(self): #18
        request = SetRunActionName.Request() #19
        request.name = 'arm_test.d6a' #20
        
        if hasattr(request, 'blocking'): #22
            request.blocking = True   #23
        
        self.get_logger().info(f'Sending request: {request}') #25
        future = self.client.call_async(request) #26
        future.add_done_callback(self.response_callback) #27

    def response_callback(self, future): #29
        try: #30
            response = future.result() #31
            self.get_logger().info( #32
                f'Service call succeeded. Success: {response.success}' #33
                f', Message: {response.message if hasattr(response, "message") else "None"}' #34
            ) #35
        except Exception as e: #36
            self.get_logger().error(f'Service call failed: {str(e)}') #37
        finally: #38
            rclpy.shutdown() #39

def main(args=None): #41
    rclpy.init(args=args) #42
    controller = PuppyArmController() #43
    rclpy.spin(controller) #44
    controller.destroy_node() #45

if __name__ == "__main__": #47
    main() #48
