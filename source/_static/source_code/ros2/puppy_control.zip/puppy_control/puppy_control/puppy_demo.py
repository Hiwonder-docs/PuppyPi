#!/usr/bin/env python3 #1
# coding=utf8 #2

import sys #4
import math #5
import rclpy #6
from rclpy.node import Node #7
from std_srvs.srv import SetBool #8
from puppy_control_msgs.msg import Velocity, Pose, Gait #9

ROS_NODE_NAME = 'puppy_demo' #11

PuppyMove = {'x': 6.0, 'y': 0.0, 'yaw_rate': 0.0} #13
# x:直行控制，  前进方向为正方向，单位cm/s(straightforward control, with the forward direction as the positive direction, measured in cm/s) #14
# y:侧移控制，左侧方向为正方向，单位cm/s，目前无此功能(lateral movement control, with the left direction as the positive direction, measured in cm/s. currently, this feature is bot available) #15
# yaw_rate：转弯控制，逆时针方向为正方向，单位rad/s(turning control, with counterclockwise direction as the positive direction, measured in rad/s) #16
PuppyPose = {'roll': math.radians(0), 'pitch': math.radians(0), 'yaw': 0.000, 'height': -10.0, 'x_shift': 0.5, 'stance_x': 0.0, 'stance_y': 0.0} #17
# PuppyPose = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #18
# stance_x：4条腿在x轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the X-axis, measured in centimeters) #19
# stance_y：4条腿在y轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the Y-axis, measured in centimeters) #20
# x_shift: 4条腿在x轴上同向移动的距离，越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡，单位cm(the distance traveled by the four legs along the x-axis determines the degree of forward or backward tilt during walking: smaller distances lead to more forward tilt, while larger distances result in more backward tilt. Adjusting the x_shift parameter can help maintain balance during the dog's movement, measured in centimeters) #21
# height： 狗的高度，脚尖到大腿转动轴的垂直距离，单位cm(the height of the dog, measured from the toe to the axis  of rotation of the thigh, is in centimeters) #22
# pitch： 狗身体的俯仰角，单位弧度(the pitch angle of the dog's body, measured in radians) #23

gait = 'Trot' #25
# overlap_time:4脚全部着地的时间，单位秒(the time when all four legs touch the ground, measured in seconds) #26
# swing_time：单脚离地时间，单位秒(the time duration when a single leg is off the ground, measured in second) #27
# clearance_time：前后交叉脚相位间隔时间，单位秒(the time interval between the phases when the front and rear legs cross each other, measured in seconds) #28
# z_clearance：走路时，脚尖要抬高的距离，单位cm(the distance the paw needs to be raised during walking, measured in centimeters) #29
if gait == 'Trot': #30
    GaitConfig = {'overlap_time': 0.2, 'swing_time': 0.3, 'clearance_time': 0.0, 'z_clearance': 5.0} #31
    PuppyPose['x_shift'] = -0.6 #32
    # Trot步态 clearance_time = 0(Trot gait clearance_time = 0) #33
elif gait == 'Amble': #34
    GaitConfig = {'overlap_time': 0.1, 'swing_time': 0.2, 'clearance_time': 0.1, 'z_clearance': 5.0} #35
    PuppyPose['x_shift'] = -0.9 #36
     # Amble步态 0 ＜ clearance_time ＜ swing_time( Amble gait 0 ＜ clearance_time ＜ swing_time) #37
elif gait == 'Walk': #38
    GaitConfig = {'overlap_time': 0.1, 'swing_time': 0.2, 'clearance_time': 0.3, 'z_clearance': 5.0} #39
    PuppyPose['x_shift'] = -0.65 #40
     # Walk步态   swing_time ≤ clearance_time(Walk gait   swing_time ≤ clearance_time) #41

class PuppyDemoNode(Node): #43
    def __init__(self): #44
        super().__init__(ROS_NODE_NAME) #45
        self.PuppyPosePub = self.create_publisher(Pose, '/puppy_control/pose', 10) #46
        self.PuppyGaitConfigPub = self.create_publisher(Gait, '/puppy_control/gait', 10) #47
        self.PuppyVelocityPub = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #48
        self.set_mark_time_client = self.create_client(SetBool, '/puppy_control/set_mark_time') #49
        self.timer = self.create_timer(0.05, self.timer_callback) #50
        self.publish_initial_commands() #51
        # 原地踏步服务(stepping in place service) #52

    def publish_initial_commands(self): #54
        self.PuppyPosePub.publish(Pose(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #55
                                       height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time=500)) #56
        self.PuppyGaitConfigPub.publish(Gait(overlap_time=GaitConfig['overlap_time'], swing_time=GaitConfig['swing_time'], #57
                                             clearance_time=GaitConfig['clearance_time'], z_clearance=GaitConfig['z_clearance'])) #58
        self.PuppyVelocityPub.publish(Velocity(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate'])) #59
        ## 如果原地踏步期间，小狗仍然在缓慢的向前或向后，那就需要重新调整小狗重心，微调PuppyPose['x_shift']即可(if the dog continues to move slowly forward on backward while stepping in place, it is necessary to readjust the dog's center of gravity. simply fine-tune 'x_shift' in PuppyPose) #60

        while not self.set_mark_time_client.wait_for_service(timeout_sec=0.0): #62
            self.get_logger().info('service not available, waiting again...') #63

        future = self.set_mark_time_client.call_async(SetBool.Request(data=False)) #65
        rclpy.spin_until_future_complete(self, future) #66
        if future.result() is not None: #67
            self.get_logger().info('Service call succeeded') #68
        else: #69
            self.get_logger().info('Service call failed') #70

    def timer_callback(self): #72
        if rclpy.ok(): #73
            pass   #74
        else: #75
            sys.exit(0) #76


def main(args=None): #79
    rclpy.init(args=args) #80
    puppy_demo_node = PuppyDemoNode() #81
    
    try: #83
        rclpy.spin(puppy_demo_node) #84
    except KeyboardInterrupt: #85
        pass #86
    finally: #87
        puppy_demo_node.destroy_node() #88
        rclpy.shutdown() #89


if __name__ == '__main__': #92
    main() #93

