#!/usr/bin/python3 #1
# coding=utf8 #2
# Author:hiwonder #3

import os, sys, time #5
import numpy as np #6

sys.path.append('/home/ubuntu/software/puppypi_control/') #8
from servo_controller import setServoPulse #9
from puppy_kinematics import HiwonderPuppy, PWMServoParams #10


puppy = HiwonderPuppy(setServoPulse = setServoPulse, servoParams = PWMServoParams(), dof = '8') #13

# print(dir(puppy)) #15
# print("Attributes:", dir(puppy._HiwonderPuppy__config)) #16
# print("Attributes:", dir(puppy._HiwonderPuppy__Configuration)) #17
# print("DOF", puppy._HiwonderPuppy__config.dof) #18
# print("LEG_FB:", puppy._HiwonderPuppy__config.LEG_FB) #19
# print("LEG_LR:", puppy._HiwonderPuppy__config.LEG_LR) #20
# print("LEG_L2:", puppy._HiwonderPuppy__config.LEG_L2) #21
# print("LEG_L1:", puppy._HiwonderPuppy__config.LEG_L1) #22
# print("ABDUCTION_OFFSET:", puppy._HiwonderPuppy__config.ABDUCTION_OFFSET) #23
# print("FOOT_RADIUS:", puppy._HiwonderPuppy__config.FOOT_RADIUS) #24
# print("LEG_L3:", puppy._HiwonderPuppy__config.LEG_L3) #25
# print("LEG_L4:", puppy._HiwonderPuppy__config.LEG_L4) #26
# print("LEG_L5:", puppy._HiwonderPuppy__config.LEG_L5) #27
# print("LEG_L6:", puppy._HiwonderPuppy__config.LEG_L6) #28
# print("LEG_L7:", puppy._HiwonderPuppy__config.LEG_L7) #29
# print("LEG_L8:", puppy._HiwonderPuppy__config.LEG_L8) #30
# print("ANGLE_DAE_ANGLE:", puppy._HiwonderPuppy__config.ANGLE_DAE_ANGLE) #31
# print("ANGLE_DOF_ANGLE:", puppy._HiwonderPuppy__config.ANGLE_DOF_ANGLE) #32
# print("ANGLE_GDO_ANGLE:", puppy._HiwonderPuppy__config.ANGLE_GDO_ANGLE) #33
# for i in dir(puppy._HiwonderPuppy__config): #34
	# attr = getattr(puppy._HiwonderPuppy__config, i) #35
	# if not callable(attr) and not i.startswith("__"): #36
            # print(f"Variable: {i}, Value: {attr}") #37

for i in dir(puppy._HiwonderPuppy__controller): #39
    attr = getattr(puppy._HiwonderPuppy__controller, i) #40
    if not callable(attr) and not i.startswith("__"): #41
            print(f"Variable: {i}, Value: {attr}") #42

# for i in dir(puppy.state): #44
	# attr = getattr(puppy.state, i) #45
	# if not callable(attr) and not i.startswith("__"): #46
            # print(f"Variable: {i}, Value: {attr}") #47

# for i in dir(puppy.command): #49
	# attr = getattr(puppy.command, i) #50
	# if not callable(attr) and not i.startswith("__"): #51
            # print(f"Variable: {i}, Value: {attr}") #52
