#!/usr/bin/python3 #1
# coding=utf8 #2
# Author: hiwonder #3
import os, sys, time #4
import numpy as np #5

sys.path.append('/home/ubuntu/software/puppypi_control/') #7
from servo_controller import setServoPulse #8
from puppy_kinematics import HiwonderPuppy, PWMServoParams #9
puppy = HiwonderPuppy(setServoPulse=None, servoParams=PWMServoParams(), dof='8') #10

foot_locations = np.array([ [-1,  -1,  -1,   -1], # X #12
                            [ 0,    0,   0,    0], # Y #13
                            [-10,   -10,  -10,   -10]  # Z #14
                            ]) #15


foot_locations = foot_locations / 100 #18

joint_angles = puppy.fourLegsRelativeCoordControl(foot_locations) #20


print("Servo angles (in degrees):") #23
print(joint_angles * 57.3) #24


while True: #27
    time.sleep(0.001) #28

