#!/usr/bin/python3 #1
# coding=utf8 #2
# Author:hiwonder #3

import os, sys, time #5
import numpy as np #6

sys.path.append('/home/ubuntu/software/puppypi_control/') #8
from servo_controller import setServoPulse #9
from puppy_kinematics import HiwonderPuppy, PWMServoParams #10


puppy = HiwonderPuppy(setServoPulse = setServoPulse, servoParams = PWMServoParams(), dof = '8') #13
                            # FR    FL    BR     BL #14
foot_locations = np.array([ [ -1.,  -1.,  -1.,   -1.], # X #15
                            [ 0.,    0.,   0.,    0.], # Y #16
                            [-10,   -10,  -10,   -10,] # Z #17
                            ]) #18
# 相对4条腿各自坐标系的坐标值，单位cm(coordinates relative to the coordinate system of each of the four legs, measured in centimeters) #19


foot_locations = foot_locations/100 # 换算成以米为单位(coordinates converted to meters as the unit of measurement) #22

joint_angles = puppy.fourLegsRelativeCoordControl(foot_locations) #24
# 输入坐标，通过逆运动学计算得到各个舵机的角度值(input coordinates to calculate the angle values of each servo motor through inverse kinematics) #25
print(joint_angles*57.3) #26

puppy.servo_force_run() #28
# 强制执行舵机角度转动，没有这句舵机有时候不会转动(enforce servo angle rotation, without this command, servos may not always rotate) #29

puppy.sendServoAngle(joint_angles, time = 500) #31
#将舵机角度发送到舵机，(send the servo angles to the servo motors) #32


while True: #35
    time.sleep(0.001) #36
