import os #1
from ament_index_python.packages import get_package_share_directory #2

from launch_ros.actions import PushRosNamespace #4
from launch import LaunchDescription, LaunchService #5
from launch.substitutions import LaunchConfiguration #6
from launch.launch_description_sources import PythonLaunchDescriptionSource #7
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, GroupAction, OpaqueFunction, TimerAction #8

def launch_setup(context): #10
    compiled = os.environ['need_compile'] #11
    enable_save = LaunchConfiguration('enable_save', default='true').perform(context) #12
    slam_method = LaunchConfiguration('slam_method', default='slam_toolbox').perform(context) #13
    sim = LaunchConfiguration('sim', default='false').perform(context) #14
    master_name = LaunchConfiguration('master_name', default=os.environ['MASTER']).perform(context) #15
    robot_name = LaunchConfiguration('robot_name', default=os.environ['HOST']).perform(context) #16

    enable_save_arg = DeclareLaunchArgument('enable_save', default_value=enable_save) #18
    slam_method_arg = DeclareLaunchArgument('slam_method', default_value=slam_method) #19
    sim_arg = DeclareLaunchArgument('sim', default_value=sim) #20
    master_name_arg = DeclareLaunchArgument('master_name', default_value=master_name) #21
    robot_name_arg = DeclareLaunchArgument('robot_name', default_value=robot_name) #22

    frame_prefix = '' if robot_name == '/' else '%s/'%robot_name #24
    use_sim_time = 'true' if sim == 'true' else 'false' #25
    map_frame = '{}map'.format(frame_prefix) #26
    odom_frame = '{}odom'.format(frame_prefix) #27
    base_frame = '{}base_footprint'.format(frame_prefix) #28

    if compiled == 'True': #30
        slam_package_path = get_package_share_directory('slam') #31
    else: #32
        slam_package_path = '/home/ubuntu/ros2_ws/src/slam' #33

    base_launch = IncludeLaunchDescription( #35
        PythonLaunchDescriptionSource( #36
            os.path.join(slam_package_path, 'launch/include/robot.launch.py')), #37
        launch_arguments={ #38
            'sim': sim, #39
            'master_name': master_name, #40
            'robot_name': robot_name #41
        }.items(), #42
    ) #43

    slam_launch = IncludeLaunchDescription( #45
        PythonLaunchDescriptionSource( #46
            os.path.join(slam_package_path, 'launch/include/slam_base.launch.py')), #47
        launch_arguments={ #48
            'use_sim_time': use_sim_time, #49
            'map_frame': map_frame, #50
            'odom_frame': odom_frame, #51
            'base_frame': base_frame, #52
            'scan_topic': '{}/scan'.format(frame_prefix), #53
            'enable_save': enable_save #54
        }.items(), #55
    ) #56

    if slam_method == 'slam_toolbox': #58
        bringup_launch = GroupAction( #59
         actions=[ #60
             PushRosNamespace(robot_name), #61
             base_launch, #62
             TimerAction( #63
                 period=6.0,  #64
                 actions=[slam_launch], #65
             ), #66
          ] #67
        ) #68

    return [sim_arg, master_name_arg, robot_name_arg, slam_method_arg, bringup_launch] #70

def generate_launch_description(): #72
    return LaunchDescription([ #73
        OpaqueFunction(function = launch_setup) #74
    ]) #75

if __name__ == '__main__': #77
    ld = generate_launch_description() #78

    ls = LaunchService() #80
    ls.include_launch_description(ld) #81
    ls.run() #82

