#!/usr/bin/python3 #1
# coding=utf8 #2
import cv2 #3
import math #4
import yaml #5
import queue #6
import rclpy #7
import threading #8
import numpy as np #9
import apriltag #10
from rclpy.node import Node #11
from cv_bridge import CvBridge #12
from sensor_msgs.msg import Image #13

bridge = CvBridge() #15

class ApriltagNode(Node): #17
    def __init__(self): #18
        super().__init__('apriltag_detect_demo') #19
        self.image_sub = self.create_subscription(Image, 'image_raw', self.image_callback, 10) #20
        self.image_pub = self.create_publisher(Image, '/apriltag_detect_demo/image_result', 1) #21
        self.image_queue = queue.Queue(2) #22
        
        # Initialize variables as instance variables #24
        self.coordinate = None #25
        self.tag_id = None #26
        self.haved_detect = False #27
        self.times = 0 #28
        
        # AprilTag detector #30
        self.detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #31
        self.camera_intrinsic = np.matrix([ #32
            [619.063979, 0, 302.560920], #33
            [0, 613.745352, 237.714934], #34
            [0, 0, 1] #35
        ]) #36
    
    def apriltagDetect(self, img):   #38
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) #39
        detections = self.detector.detect(gray, return_image=False) #40
        
        if len(detections) != 0: #42
            for detection in detections: #43
                M, e0, e1 = self.detector.detection_pose( #44
                    detection, #45
                    [self.camera_intrinsic.item(0,0), self.camera_intrinsic.item(1,1), #46
                     self.camera_intrinsic.item(0,2), self.camera_intrinsic.item(1,2)], #47
                    0.033 #48
                )                 #49
                P = M[:3,:4] #50
                self.coordinate = np.matmul(P, np.array([[0],[0],[0],[1]])).flatten() #51
                
                # ROS2 print for coordinate #53
                self.get_logger().info(f'坐标 = {self.coordinate}') #54
                
                corners = np.rint(detection.corners) #56
                cv2.drawContours(img, [np.array(corners, int)], -1, (0, 255, 255), 5, cv2.LINE_AA) #57
                tag_family = str(detection.tag_family, encoding='utf-8') #58
                
                self.times = 0 #60
                if tag_family == 'tag36h11': #61
                    self.tag_id = str(detection.tag_id) #62
                    # ROS2 print for tag ID #63
                    self.get_logger().info(f'标签ID = {self.tag_id}') #64
                    return self.tag_id #65
                else: #66
                    return None #67
        else: #68
            self.times += 1 #69
            if self.times >= 3: #70
                self.coordinate = None #71
            return None #72
    
    def run(self, img): #74
        self.tag_id = self.apriltagDetect(img) #75
        if self.tag_id is not None and not self.haved_detect: #76
            self.haved_detect = True #77
        
        if self.tag_id is not None: #79
            cv2.putText(img, self.tag_id, (10, img.shape[0] - 20),  #80
                       cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 255), 1) #81
        return img #82
    
    def image_callback(self, ros_image): #84
        try: #85
            cv_image = bridge.imgmsg_to_cv2(ros_image, "bgr8") #86
            bgr_image = np.array(cv_image, dtype=np.uint8) #87
            
            if self.image_queue.full(): #89
                self.image_queue.get() #90
            self.image_queue.put(bgr_image) #91
            
            cv2_img = self.image_queue.get(block=True, timeout=1) #93
            frame = cv2_img.copy() #94
            frame_result = self.run(frame) #95
            
            # Publish the result image #97
            result_msg = bridge.cv2_to_imgmsg(frame_result, "bgr8") #98
            self.image_pub.publish(result_msg) #99
            
            cv2.imshow('AprilTag Detection', frame_result) #101
            cv2.waitKey(1) #102
            
        except Exception as e: #104
            self.get_logger().error(f'Error in image processing: {str(e)}') #105

def main(args=None): #107
    rclpy.init(args=args) #108
    apriltag_node = ApriltagNode() #109
    try: #110
        rclpy.spin(apriltag_node) #111
    except KeyboardInterrupt: #112
        pass #113
    finally: #114
        apriltag_node.destroy_node() #115
        rclpy.shutdown() #116

if __name__ == '__main__': #118
    main() #119
