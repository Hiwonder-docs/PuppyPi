import cv2 #1
import numpy as np #2
import rclpy #3
import threading #4
import queue #5
from cv_bridge import CvBridge #6
from sensor_msgs.msg import Image #7
from rclpy.node import Node #8
import sdk.common as common #9

bridge = CvBridge() #11
range_rgb = { #12
    'red': (0, 0, 255), #13
    'blue': (255, 0, 0), #14
    'green': (0, 255, 0), #15
    'black': (0, 0, 0), #16
    'white': (255, 255, 255), #17
} #18
lab_data = common.get_yaml_data("/home/ubuntu/software/lab_tool/lab_config.yaml") #19

color_list = [] #21
detect_color = 'None' #22
draw_color = range_rgb["black"] #23
size = (320, 240) #24


class ColorDetectNode(Node): #27
    def __init__(self): #28
        super().__init__('color_detect_node') #29
        self.image_queue = queue.Queue(maxsize=10)   #30
        self.image_subscription = self.create_subscription( #31
            Image, #32
            'image_raw', #33
            self.image_callback, #34
            10 #35
        ) #36
        self.get_logger().info("Color Detect Node 已启动！") #37

    def image_callback(self, ros_image): #39
        try: #40
            cv_image = bridge.imgmsg_to_cv2(ros_image, "bgr8") #41
            if self.image_queue.full(): #42
                # 丢弃队列中最旧的一帧，保持队列大小 #43
                try: #44
                    _ = self.image_queue.get_nowait() #45
                except queue.Empty: #46
                    pass #47
            self.image_queue.put(cv_image) #48
        except Exception as e: #49
            self.get_logger().error(f"转换图像失败: {e}") #50

    def run(self): #52
        while rclpy.ok(): #53
            try: #54
                # 尽可能取最新的一帧，丢弃旧帧 #55
                while self.image_queue.qsize() > 1: #56
                    _ = self.image_queue.get_nowait() #57
                image = self.image_queue.get(timeout=0.1) #58
                processed_image = self.color_detect(image) #59
                cv2.imshow('Color Detection', processed_image) #60
                if cv2.waitKey(1) & 0xFF == ord('q'): #61
                    break #62
            except queue.Empty: #63
                # 没有图像时可稍作等待 #64
                continue #65

    def color_detect(self, img): #67
        global detect_color, draw_color, color_list #68

        img_copy = img.copy() #70
        img_h, img_w = img.shape[:2] #71
        frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #72
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #73
        frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #74

        max_area = 0 #76
        color_area_max = None #77
        areaMaxContour_max = 0 #78

        for color_name in ['red', 'green', 'blue']: #80
            frame_mask = cv2.inRange(frame_lab, tuple(lab_data['color_range_list'][color_name]['min']), tuple(lab_data['color_range_list'][color_name]['max'])) #81
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #82
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #83
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2] #84
            areaMaxContour, area_max = common.get_area_max_contour(contours, 0) #85
            if areaMaxContour is not None and area_max > max_area: #86
                max_area = area_max #87
                color_area_max = color_name #88
                areaMaxContour_max = areaMaxContour #89

        if max_area > 200: #91
            ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max) #92
            centerX = int(common.val_map(centerX, 0, size[0], 0, img_w)) #93
            centerY = int(common.val_map(centerY, 0, size[1], 0, img_h)) #94
            radius = int(common.val_map(radius, 0, size[0], 0, img_w)) #95
            cv2.circle(img, (centerX, centerY), radius, range_rgb[color_area_max], 2) #96

            color_value = {'red': 1, 'green': 2, 'blue': 3}.get(color_area_max, 0) #98
            color_list.append(color_value) #99

            if len(color_list) == 3: #101
                color_avg = int(round(np.mean(np.array(color_list)))) #102
                color_list.clear() #103
                if color_avg == 1: #104
                    detect_color = 'red' #105
                    draw_color = range_rgb['red'] #106
                elif color_avg == 2: #107
                    detect_color = 'green' #108
                    draw_color = range_rgb['green'] #109
                elif color_avg == 3: #110
                    detect_color = 'blue' #111
                    draw_color = range_rgb['blue'] #112
                else: #113
                    detect_color = 'None' #114
                    draw_color = range_rgb['black'] #115
        else: #116
            detect_color = 'None' #117
            draw_color = range_rgb['black'] #118

        cv2.putText(img, "Color: " + detect_color, (10, img.shape[0] - 10), #120
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, draw_color, 2) #121
        return img #122


def main(): #125
    rclpy.init() #126
    node = ColorDetectNode() #127
    threading.Thread(target=node.run, daemon=True).start() #128
    rclpy.spin(node) #129
    rclpy.shutdown() #130
    cv2.destroyAllWindows() #131
