#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2024/09/13 #3
# Author:liuyuan #4
# 第7课 标签坐标定位实验/第8课 标签追踪实验 #5
# 通过 ROS 2 参数 --model 0/1 切换功能（默认是0） #6
import sys #7
import rclpy #8
from rclpy.node import Node #9
import cv2 #10
import math #11
import threading #12
import numpy as np #13
import apriltag #14
import signal #15
import queue #16
import time #17
from threading import RLock #18
from std_srvs.srv import SetBool #19
from sensor_msgs.msg import Image #20
from cv_bridge import CvBridge #21
from puppy_control_msgs.msg import Velocity, Pose, Gait #22

class AprilTagTrackingDemo(Node): #24
    def __init__(self): #25
        super().__init__('apriltag_tracking') #26
        
        # 声明 model 参数，默认为 0 #28
        self.declare_parameter('model', 0) #29
        self.model = self.get_parameter('model').get_parameter_value().integer_value #30
        if self.model not in [0, 1]: #31
            self.get_logger().warn(f"无效的模型值 {self.model}，默认设置为 0") #32
            self.model = 0 #33
        self.get_logger().info(f"启动 AprilTag 跟踪，模型：{self.model}") #34

        # 声明变量 #36
        self.lock = RLock() #37
        self.__isRunning = False #38
        self.org_image_sub_ed = False #39
        self.times = 0 #40
        self.tag_id = None #41
        self.coordinate = None  # 标签距离摄像头的坐标 [x, y, z]，单位米 #42
        self.bridge = CvBridge() #43
        self.image_queue = queue.Queue(maxsize=2) #44
        self.haved_detect = False #45
        self.detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #46
        self.camera_intrinsic = np.matrix([ #47
            [619.063979, 0, 302.560920], #48
            [0, 613.745352, 237.714934], #49
            [0, 0, 1] #50
        ]) #51
        self.image_size = (320, 240)  # 优化：降低图像分辨率 #52
        self.last_detect_time = 0  # 控制检测频率 #53
        self.detect_interval = 0.1  # 每 100ms 检测一次 #54

        signal.signal(signal.SIGINT, self.stop) #56
        self.pose_publisher = self.create_publisher(Pose, '/puppy_control/pose', 10) #57
        self.gait_publisher = self.create_publisher(Gait, '/puppy_control/gait', 10) #58
        self.velocity_publisher = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #59
        self.puppy_set_running_srv = self.create_client(SetBool, '/puppy_control/set_running') #60

        # 如果 model=1，启动运动控制线程 #62
        if self.model == 1: #63
            th = threading.Thread(target=self.move, daemon=True) #64
            th.start() #65

        # 进入主程序 #67
        self.debug = True #68
        if self.debug: #69
            self.enter_func(1) #70
            self.start_running() #71

    def enter_func(self, msg): #73
        self.get_logger().info("进入 AprilTag 跟踪模式") #74
        self.init() #75
        with self.lock: #76
            if not self.org_image_sub_ed: #77
                self.org_image_sub_ed = True #78
                self.image_sub = self.create_subscription(Image, 'image_raw', self.image_callback, 10) #79
        return [True, '进入'] #80

    def exit_func(self, msg): #82
        self.get_logger().info("退出 AprilTag 跟踪模式") #83
        with self.lock: #84
            self.__isRunning = False #85
            self.reset() #86
            try: #87
                if self.org_image_sub_ed: #88
                    self.org_image_sub_ed = False #89
            except BaseException as e: #90
                self.get_logger().error(f"退出时发生错误：{str(e)}") #91
        return [True, '退出'] #92

    def start_running(self): #94
        self.get_logger().info("开始运行 AprilTag 跟踪") #95
        with self.lock: #96
            self.__isRunning = True #97

    def init(self): #99
        self.get_logger().info("AprilTag 检测初始化完成") #100
        self.set_pose() #101
        self.set_gait() #102

    def image_callback(self, ros_image): #104
        try: #105
            cv_image = self.bridge.imgmsg_to_cv2(ros_image, "bgr8") #106
            # 优化：缩放图像以减少处理负担 #107
            bgr_image = cv2.resize(cv_image, self.image_size, interpolation=cv2.INTER_NEAREST) #108
            with self.lock: #109
                if self.image_queue.full(): #110
                    self.image_queue.get()  # 丢弃旧帧 #111
                self.image_queue.put(bgr_image) #112
        except Exception as e: #113
            self.get_logger().error(f"图像转换失败：{str(e)}") #114
            return #115

        try: #117
            image = self.image_queue.get(block=True, timeout=0.1) #118
            frame = image.copy() #119
            frame_result = frame #120
            with self.lock: #121
                if self.__isRunning: #122
                    frame_result = self.run(frame) #123
            cv2.imshow('image', frame_result) #124
            cv2.waitKey(1) #125
        except queue.Empty: #126
            self.get_logger().warn("图像队列超时") #127
        except Exception as e: #128
            self.get_logger().error(f"图像处理失败：{str(e)}") #129

    def run(self, img): #131
        if not self.__isRunning: #132
            return img #133

        # 优化：控制检测频率 #135
        current_time = time.time() #136
        if current_time - self.last_detect_time >= self.detect_interval: #137
            self.tag_id = self.apriltagDetect(img) #138
            self.last_detect_time = current_time #139
            if self.tag_id is not None and not self.haved_detect: #140
                self.haved_detect = True #141

        # 显示 tag_id #143
        cv2.putText(img, str(self.tag_id) if self.tag_id else "无标签", (10, img.shape[0] - 20), #144
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2) #145
        return img #146

    def apriltagDetect(self, img): #148
        try: #149
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #150
            detections = self.detector.detect(gray, return_image=False) #151
            if len(detections) != 0: #152
                for detection in detections: #153
                    M, e0, e1 = self.detector.detection_pose(detection, [ #154
                        self.camera_intrinsic.item(0, 0), self.camera_intrinsic.item(1, 1), #155
                        self.camera_intrinsic.item(0, 2), self.camera_intrinsic.item(1, 2) #156
                    ], 0.033) #157
                    P = M[:3, :4] #158
                    self.coordinate = np.matmul(P, np.array([[0], [0], [0], [1]])).flatten() #159
                    self.get_logger().info(f"标签坐标: {self.coordinate}") #160
                    tag_family = str(detection.tag_family, encoding='utf-8') #161
                    self.times = 0 #162
                    if tag_family == 'tag36h11': #163
                        tag_id = str(detection.tag_id) #164
                        self.get_logger().info(f"检测到标签 ID: {tag_id}") #165
                        return tag_id #166
                    else: #167
                        return None #168
            else: #169
                self.times += 1 #170
                if self.times >= 3: #171
                    self.coordinate = None #172
                return None #173
        except Exception as e: #174
            self.get_logger().error(f"AprilTag 检测失败：{str(e)}") #175
            return None #176

    def move(self): #178
        while True: #179
            if self.__isRunning: #180
                with self.lock: #181
                    if self.coordinate is None: #182
                        self.set_move() #183
                    else: #184
                        if self.coordinate[2] > 0.22: #185
                            self.set_move(x=5.0) #186
                            self.get_logger().info("向前移动：z > 0.22") #187
                        elif self.coordinate[2] < 0.18: #188
                            self.set_move(x=-5.0) #189
                            self.get_logger().info("向后移动：z < 0.18") #190
                        else: #191
                            self.set_move(x=0.0, y=0.0, yaw_rate=0.0) #192
                            self.get_logger().info("停止移动：z 在范围内") #193
            time.sleep(0.05)  # #194

    def stop(self, signum=None, frame=None): #196
        self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.0)) #197
        self.set_move() #198
        self.get_logger().info("程序关闭") #199
        cv2.destroyAllWindows() #200
        sys.exit(0) #201

    def reset(self): #203
        self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.0)) #204
        self.set_move() #205
        self.get_logger().info("重置速度") #206

    def set_pose(self, roll=math.radians(0), pitch=math.radians(0), yaw=0.000, height=-10.0, x_shift=0.5, stance_x=0.0, stance_y=0.0, run_time=500): #208
        self.pose_publisher.publish(Pose(stance_x=stance_x, stance_y=stance_y, x_shift=x_shift, #209
                                        height=height, roll=roll, pitch=pitch, yaw=yaw, run_time=500)) #210
        self.get_logger().info("设置姿态") #211

    def set_gait(self, overlap_time=0.2, swing_time=0.15, clearance_time=0.0, z_clearance=4.0): #213
        self.gait_publisher.publish(Gait(overlap_time=overlap_time, swing_time=swing_time, #214
                                        clearance_time=clearance_time, z_clearance=z_clearance)) #215
        self.get_logger().info("设置步态") #216

    def set_move(self, x=0.00, y=0.0, yaw_rate=0.0): #218
        self.velocity_publisher.publish(Velocity(x=x, y=y, yaw_rate=yaw_rate)) #219
        self.get_logger().info(f"设置速度：x={x}, y={y}, yaw_rate={yaw_rate}") #220

def main(args=None): #222
    rclpy.init(args=args) #223
    node = AprilTagTrackingDemo() #224
    try: #225
        rclpy.spin(node) #226
    except KeyboardInterrupt: #227
        node.get_logger().info("接收到键盘中断") #228
    finally: #229
        node.stop() #230
        node.destroy_node() #231
        rclpy.shutdown() #232

if __name__ == '__main__': #234
    main() #235
