#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2024/09/13 #3
# Author:liuyuan #4

# 第5课 色块定位实验/第6课 颜色追踪实验 #6
# 通过 ROS 2 参数 --model 0/1 切换功能（默认是0） #7
import sys #8
import cv2 #9
import math #10
import rclpy #11
from rclpy.node import Node #12
import numpy as np #13
from threading import RLock, Timer #14
import sdk.common as common #15
import time #16
import queue #17
import signal #18
import sdk.PID as pid #19
from std_srvs.srv import SetBool #20
from sensor_msgs.msg import Image #21
from ros_robot_controller_msgs.msg import RGBState, RGBsState #22
from cv_bridge import CvBridge #23
from puppy_control_msgs.srv import SetRunActionName #24
from puppy_control_msgs.msg import Velocity, Pose, Gait #25

class ColorTrackingNode(Node): #27
    def __init__(self): #28
        super().__init__('color_tracking') #29
        signal.signal(signal.SIGINT, self.stop) #30

        # 声明 model 参数，默认为 0 #32
        self.declare_parameter('model', 0) #33
        self.model = self.get_parameter('model').get_parameter_value().integer_value #34
        if self.model not in [0, 1]: #35
            self.get_logger().warn(f"Invalid model value {self.model}, defaulting to 0") #36
            self.model = 0 #37
        self.get_logger().info(f"Starting color tracking with model: {self.model}") #38

        # 声明变量 #40
        self.lock = RLock() #41
        self.range_rgb = { #42
            'red': (0, 0, 255), #43
            'blue': (255, 0, 0), #44
            'green': (0, 255, 0), #45
            'black': (0, 0, 0), #46
            'white': (255, 255, 255), #47
        } #48
        self.color_range = None #49
        self.x_pid = pid.PID(P=0.06, I=0.0005, D=0.00)  # PID 初始化 #50
        self.y_pid = pid.PID(P=0.00001, I=0.0000, D=0.0000) #51
        self.z_pid = pid.PID(P=0.003, I=0.0000, D=0.0000) #52

        self.__isRunning = False #54
        self.start_move = True #55
        self.image_sub = None #56
        self.__target_color = None #57
        self.org_image_sub_ed = False #58
        self.bridge = CvBridge() #59
        self.size = (320, 240) #60
        self.image_queue = queue.Queue(2) #61

        self.pose_publisher = self.create_publisher(Pose, '/puppy_control/pose', 10) #63
        self.gait_publisher = self.create_publisher(Gait, '/puppy_control/gait', 10) #64
        self.velocity_publisher = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #65
        self.rgb_pub = self.create_publisher(RGBsState, '/ros_robot_controller/set_rgb', 10) #66
        self.run_action_group_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #67
        self.puppy_set_running_srv = self.create_client(SetBool, '/puppy_control/set_running') #68

        self.debug = True #70

        # 进入主程序 #72
        if self.debug: #73
            self.set_target('red') #74
            self.enter_func(1) #75
            self.start_running() #76

    # 控制 RGB #78
    def set_rgb(self, r, g, b): #79
        rgb1 = RGBState() #80
        rgb1.id = 1 #81
        rgb1.r = r #82
        rgb1.g = g #83
        rgb1.b = b #84
        rgb2 = RGBState() #85
        rgb2.id = 2 #86
        rgb2.r = r #87
        rgb2.g = g #88
        rgb2.b = b #89
        msg = RGBsState() #90
        msg.data = [rgb1, rgb2] #91
        self.rgb_pub.publish(msg) #92

    def enter_func(self, msg): #94
        self.get_logger().info("Entering object tracking") #95
        self.init() #96
        with self.lock: #97
            if not self.org_image_sub_ed: #98
                self.org_image_sub_ed = True #99
                self.image_sub = self.create_subscription(Image, 'image_raw', self.image_callback, 10) #100
        return [True, 'enter'] #101

    def exit_func(self, msg): #103
        self.get_logger().info("Exiting object tracking") #104
        with self.lock: #105
            self.__isRunning = False #106
            self.reset() #107
            try: #108
                if self.org_image_sub_ed: #109
                    self.org_image_sub_ed = False #110
            except BaseException as e: #111
                self.get_logger().error(f"Error during exit: {str(e)}") #112
        return [True, 'exit'] #113

    # 初始化 #115
    def init(self): #116
        # 执行站立动作组 #117
        msg = SetRunActionName.Request() #118
        msg.name = 'sit.d6ac' #119
        msg.wait = True #120
        self.run_action_group_srv.call_async(msg) #121
        
        self.color_range = common.get_yaml_data("/home/ubuntu/software/lab_tool/lab_config.yaml") #123
        self.get_logger().info("Object tracking initialized") #124

    def start_running(self): #126
        self.get_logger().info("Starting object tracking") #127
        with self.lock: #128
            self.__isRunning = True #129

    def stop_running(self): #131
        self.get_logger().info("Stopping object tracking") #132
        with self.lock: #133
            self.__isRunning = False #134

    def set_running(self, msg): #136
        if msg.data: #137
            self.start_running() #138
        else: #139
            self.stop_running() #140
        return [True, 'set_running'] #141

    # 设置目标颜色 #143
    def set_target(self, color): #144
        with self.lock: #145
            self.__target_color = color #146
            self.set_rgb(self.range_rgb[self.__target_color][2], self.range_rgb[self.__target_color][1], self.range_rgb[self.__target_color][0]) #147

    # 退出程序，关闭 RGB #149
    def stop(self, signum=None, frame=None): #150
        self.set_rgb(0, 0, 0) #151
        self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.0)) #152
        self.get_logger().info("Shutdown signal received") #153

    # 重置函数 #155
    def reset(self): #156
        self.set_rgb(0, 0, 0) #157
        self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.0)) #158

    # 图像回调函数 #160
    def image_callback(self, ros_image): #161
        cv_image = self.bridge.imgmsg_to_cv2(ros_image, "bgr8") #162
        bgr_image = np.array(cv_image, dtype=np.uint8) #163
        if self.image_queue.full(): #164
            self.image_queue.get() #165
        self.image_queue.put(bgr_image) #166
        try: #167
            image = self.image_queue.get(block=True, timeout=1) #168
            frame = image.copy() #169
            frame_result = frame #170
            with self.lock: #171
                if self.__isRunning: #172
                    frame_result = self.run(frame) #173
                    cv2.imshow('Frame', frame_result) #174
                    cv2.waitKey(1) #175
        except queue.Empty: #176
            self.get_logger().warn("Image queue timeout") #177

    # 主程序 #179
    def run(self, img): #180
        img_copy = img.copy() #181
        img_h, img_w = img.shape[:2] #182

        cv2.line(img, (int(img_w / 2 - 10), int(img_h / 2)), (int(img_w / 2 + 10), int(img_h / 2)), (0, 255, 255), 2) #184
        cv2.line(img, (int(img_w / 2), int(img_h / 2 - 10)), (int(img_w / 2), int(img_h / 2 + 10)), (0, 255, 255), 2) #185

        frame_resize = cv2.resize(img_copy, self.size, interpolation=cv2.INTER_NEAREST) #187
        frame_lab = cv2.cvtColor(frame_resize, cv2.COLOR_BGR2LAB) #188

        area_max = 0 #190
        area_max_contour = 0 #191

        if self.__target_color in list(self.color_range['color_range_list'].keys()): #193
            target_color_range = self.color_range['color_range_list'][self.__target_color] #194
            frame_mask = cv2.inRange(frame_lab, tuple(target_color_range['min']), tuple(target_color_range['max'])) #195
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #196
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #197
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2] #198
            area_max_contour, area_max = common.get_area_max_contour(contours, 500) #199

        if area_max > 100: #201
            if area_max_contour is not None and len(area_max_contour) > 0: #202
                (center_x, center_y), radius = cv2.minEnclosingCircle(area_max_contour) #203
            else: #204
                return img #205

            center_x = int(common.val_map(center_x, 0, self.size[0], 0, img_w)) #207
            center_y = int(common.val_map(center_y, 0, self.size[1], 0, img_h)) #208
            radius = int(common.val_map(radius, 0, self.size[0], 0, img_w)) #209
            if radius > 100: #210
                return img #211

            self.get_logger().info(f"Center: x={int(center_x)}, y={int(center_y)}") #213
            cv2.circle(img, (int(center_x), int(center_y)), int(radius), (0, 0, 255), 2) #214

            if self.start_move and self.model == 1: #216
                self.x_pid.Kp = 0.003 #217
                self.x_pid.Ki = 0.00 #218
                self.x_pid.Kd = 0.00 #219

                self.x_pid.SetPoint = img_w / 2.0 #221
                if abs(self.x_pid.SetPoint - center_x) > 230: #222
                    self.x_pid.Kp = 0.004 #223
                self.x_pid.update(center_x) #224
                self.x_dis = self.x_pid.output #225
                self.x_dis = np.radians(30) if self.x_dis > np.radians(30) else self.x_dis #226
                self.x_dis = np.radians(-30) if self.x_dis < np.radians(-30) else self.x_dis #227

                self.z_pid.Kp = 0.0015 #229
                self.z_pid.Ki = 0.0000 #230
                self.z_pid.Kd = 0.0000 #231

                self.z_pid.SetPoint = img_h / 2.0 #233
                if abs(self.z_pid.SetPoint - center_y) > 180: #234
                    self.z_pid.Kp = 0.002 #235
                self.z_pid.update(center_y) #236
                self.z_dis = self.z_pid.output #237
                self.z_dis = np.radians(30) if self.z_dis > np.radians(30) else self.z_dis #238
                self.z_dis = np.radians(-20) if self.z_dis < np.radians(-20) else self.z_dis #239

                if abs(area_max - 900) < 150: #241
                    self.y_dis = 0.0 #242
                elif area_max - 900 < -150: #243
                    self.y_dis = 10.0 #244
                elif area_max - 900 > 150: #245
                    self.y_dis = -7.0 #246

                self.set_pose(roll=self.x_dis, pitch=self.z_dis, run_time=30) #248
                self.get_logger().info(f"y_dis: {self.y_dis}") #249

        return img #251

    def set_pose(self, roll=math.radians(0), pitch=math.radians(0), yaw=0.000, height=-10.0, x_shift=0.5, stance_x=0.0, stance_y=0.0, run_time=500): #253
        self.pose_publisher.publish(Pose(stance_x=stance_x, stance_y=stance_y, x_shift=x_shift, #254
                                        height=height, roll=roll, pitch=pitch, yaw=yaw, run_time=run_time)) #255

def main(args=None): #257
    rclpy.init(args=args) #258
    color_tracker = ColorTrackingNode() #259

    try: #261
        rclpy.spin(color_tracker) #262
    except KeyboardInterrupt: #263
        color_tracker.get_logger().info("Keyboard interrupt received") #264
    finally: #265
        color_tracker.destroy_node() #266
        rclpy.shutdown() #267

if __name__ == '__main__': #269
    main() #270
