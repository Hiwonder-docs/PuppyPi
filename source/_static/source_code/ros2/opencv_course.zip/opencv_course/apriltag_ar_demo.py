#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2024/09/03 #3
# Author:liuyuan #4
# AR视觉 #5
import os #6
import cv2 #7
import math #8
import numpy as np #9
import threading #10
import argparse #11
import sys #12
import apriltag  # 使用标准 apriltag 模块 #13
import rclpy #14
from rclpy.node import Node #15
from sdk.objloader_simple import OBJ as obj_load #16
from sensor_msgs.msg import CameraInfo, Image #17
from cv_bridge import CvBridge #18
from scipy.spatial.transform import Rotation as R #19

bridge = CvBridge() #21
ROS_NODE_NAME = 'apriltag_ar_demo' #22
MODEL_PATH = '/home/ubuntu/ros2_ws/src/example/example/opencv_course/models' #23

# 对象内部控制点坐标 #25
objp = np.array([[-1, -1,  0], #26
                 [ 1, -1,  0], #27
                 [-1,  1,  0], #28
                 [ 1,  1,  0], #29
                 [ 0,  0,  0]], dtype=np.float32) #30
# 世界坐标系参考点 #31
axis = np.float32([[-1, -1, 0],  #32
                   [-1,  1, 0],  #33
                   [ 1,  1, 0],  #34
                   [ 1, -1, 0], #35
                   [-1, -1, 2], #36
                   [-1,  1, 2], #37
                   [ 1,  1, 2], #38
                   [ 1, -1, 2]]) #39
# 不同物体模型在真实世界的缩放尺度                    #40
models_scale = { #41
                'bicycle': 50,  #42
                'fox': 4,  #43
                'chair': 400,  #44
                'cow': 0.4, #45
                'wolf': 0.6, #46
                } #47

def draw(img, corners, imgpts): #49
    imgpts = np.int32(imgpts).reshape(-1,2) #50
    cv2.drawContours(img, [imgpts[:4]],-1,(0, 255, 0),-3) #51
    for i,j in zip(range(4),range(4,8)): #52
        cv2.line(img, tuple(imgpts[i]), tuple(imgpts[j]),(255),3) #53
    cv2.drawContours(img, [imgpts[4:]],-1,(0, 0, 255),3) #54
    return img #55

class ARNode(Node): #57
    def __init__(self, name): #58
        super().__init__(name) #59
        self.model_path = self.declare_parameter('model_path', MODEL_PATH).value #60
        self.name = name #61
        self.camera_intrinsic = np.matrix([[619.063979, 0, 302.560920], #62
                                           [0, 613.745352, 237.714934], #63
                                           [0, 0, 1]]) #64
        self.dist_coeffs = np.array([0.103085, -0.175586, -0.001190, -0.007046, 0.000000]) #65
        self.obj = None #66
        self.target_model = None #67
        try: #68
            self.tag_detector = apriltag.Detector()  # 标准 Detector 初始化 #69
            self.get_logger().info("AprilTag detector initialized") #70
        except Exception as e: #71
            self.get_logger().error(f"Failed to initialize AprilTag detector: {str(e)}") #72
            raise #73

        self.lock = threading.RLock() #75
        self.bridge = CvBridge() #76
        self.image_sub = None #77
        self.camera_info_sub = None #78

        # 初始化时记录 apriltag 模块路径 #80
        self.get_logger().info(f"AprilTag module path: {apriltag.__file__}") #81

    def enter_srv_callback(self,_): #83
        self.get_logger().info("Entering AR demo") #84
        try: #85
            if self.image_sub: #86
                self.image_sub.destroy() #87
        except Exception as e: #88
            self.get_logger().error(f"Error destroying subscription: {str(e)}") #89

        with self.lock: #91
            self.obj = None #92
            self.target_model = None #93
            self.image_sub = self.create_subscription(Image, '/image_raw', self.image_callback, 10) #94

    def exit_srv_callback(self, request, response): #96
        self.get_logger().info("Exiting AR demo") #97
        try: #98
            if self.image_sub: #99
                self.image_sub.destroy() #100
        except Exception as e: #101
            self.get_logger().error(f"Error destroying subscription: {str(e)}") #102

        response.success = True #104
        return response #105

    def set_model_srv_callback(self, model): #107
        with self.lock: #108
            if model == "": #109
                self.target_model = None #110
                self.get_logger().info("Model cleared") #111
            else: #112
                self.target_model = model #113
                self.get_logger().info(f"Setting model: {model}") #114
                if self.target_model != 'rectangle': #115
                    try: #116
                        obj = obj_load(os.path.join(self.model_path, self.target_model + '.obj'), swapyz=True) #117
                        obj.faces = obj.faces[::-1] #118
                        new_faces = [] #119
                        for face in obj.faces: #120
                            face_vertices = face[0] #121
                            points = [] #122
                            colors = [] #123
                            for vertex in face_vertices: #124
                                data = obj.vertices[vertex - 1] #125
                                points.append(data[:3]) #126
                                if self.target_model != 'cow' and self.target_model != 'wolf': #127
                                    colors.append(data[3:]) #128
                            scale_matrix = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]]) * models_scale[self.target_model] #129
                            points = np.dot(np.array(points), scale_matrix) #130
                            if self.target_model == 'bicycle': #131
                                points = np.array([[p[0] - 670, p[1] - 350, p[2]] for p in points]) #132
                                points = R.from_euler('xyz', (0, 0, 180), degrees=True).apply(points) #133
                            elif self.target_model == 'fox': #134
                                points = np.array([[p[0], p[1], p[2]] for p in points]) #135
                                points = R.from_euler('xyz', (0, 0, -90), degrees=True).apply(points) #136
                            elif self.target_model == 'chair': #137
                                points = np.array([[p[0], p[1], p[2]] for p in points]) #138
                                points = R.from_euler('xyz', (0, 0, -90), degrees=True).apply(points) #139
                            else: #140
                                points = np.array([[p[0], p[1], p[2]] for p in points]) #141
                            if len(colors) > 0: #142
                                color = tuple(255 * np.array(colors[0])) #143
                            else: #144
                                color = None #145
                            new_faces.append((points, color)) #146

                        self.obj = new_faces #148
                    except Exception as e: #149
                        self.get_logger().error(f"Failed to load model {model}: {str(e)}") #150

    def camera_info_callback(self, msg): #152
        with self.lock: #153
            pass #154

    def image_callback(self, ros_image): #156
        self.get_logger().info("Image received") #157
        rgb_image = self.bridge.imgmsg_to_cv2(ros_image, desired_encoding='rgb8') #158
        result_image = np.copy(rgb_image) #159

        with self.lock: #161
            try: #162
                result_image = self.image_proc(rgb_image, result_image) #163
            except Exception as e: #164
                self.get_logger().error(f"Image processing error: {str(e)}") #165

        cv2.imshow('image', cv2.cvtColor(result_image, cv2.COLOR_RGB2BGR)) #167
        cv2.waitKey(1) #168

    def image_proc(self, rgb_image, result_image): #170
        if self.target_model is not None: #171
            gray = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2GRAY) #172
            detections = self.tag_detector.detect(gray) #173
            if detections: #174
                for detection in detections: #175
                    M, e0, e1 = self.tag_detector.detection_pose(detection,  #176
                                                                 [self.camera_intrinsic.item(0, 0), self.camera_intrinsic.item(1, 1), #177
                                                                  self.camera_intrinsic.item(0, 2), self.camera_intrinsic.item(1, 2)], #178
                                                                 0.033) #179
                    P = M[:3, :4] #180
                    coordinate = np.matmul(P, np.array([[0], [0], [0], [1]])) #181
                    self.get_logger().info(f"Tag coordinate: {coordinate.flatten()}") #182

                    tag_id = detection.tag_id #184
                    tag_center = detection.center #185
                    tag_corners = detection.corners #186

                    self.get_logger().info(f"Detected tag ID: {tag_id}") #188

                    lb = tag_corners[0] #190
                    rb = tag_corners[1] #191
                    rt = tag_corners[2] #192
                    lt = tag_corners[3] #193
                    cv2.circle(result_image, (int(lb[0]), int(lb[1])), 2, (0, 255, 255), -1) #194
                    cv2.circle(result_image, (int(lt[0]), int(lt[1])), 2, (0, 255, 255), -1) #195
                    cv2.circle(result_image, (int(rb[0]), int(rb[1])), 2, (0, 255, 255), -1) #196
                    cv2.circle(result_image, (int(rt[0]), int(rt[1])), 2, (0, 255, 255), -1) #197

                    corners = np.array([lb, rb, lt, rt, tag_center]).reshape(5, -1) #199
                    ret, rvecs, tvecs = cv2.solvePnP(objp, corners, self.camera_intrinsic, self.dist_coeffs) #200
                    if self.target_model == 'rectangle': #201
                        imgpts, jac = cv2.projectPoints(axis, rvecs, tvecs, self.camera_intrinsic, self.dist_coeffs) #202
                        result_image = draw(result_image, corners, imgpts) #203
                    else: #204
                        for points, color in self.obj: #205
                            dst, jac = cv2.projectPoints(points.reshape(-1, 1, 3) / 100.0, rvecs, tvecs, self.camera_intrinsic, self.dist_coeffs) #206
                            imgpts = dst.astype(int) #207
                            if self.target_model == 'cow': #208
                                cv2.fillConvexPoly(result_image, imgpts, (0, 255, 255)) #209
                            elif self.target_model == 'wolf': #210
                                cv2.fillConvexPoly(result_image, imgpts, (255, 255, 0)) #211
                            else: #212
                                cv2.fillConvexPoly(result_image, imgpts, color) #213
        return result_image #214

def main(args=None): #216
    parser = argparse.ArgumentParser(description='AprilTag AR Demo') #217
    parser.add_argument('--model', type=str, default='bicycle', help='Model to use (e.g., 1 for bicycle, 2 for fox, etc.)') #218
    
    # 过滤 ROS 2 参数 #220
    filtered_argv = [] #221
    skip_next = False #222
    for arg in sys.argv[1:]: #223
        if arg == '--ros-args': #224
            skip_next = True #225
            continue #226
        if skip_next and arg.startswith('-r'): #227
            continue #228
        if not arg.startswith('__node:='): #229
            filtered_argv.append(arg) #230
    
    parsed_args = parser.parse_args(filtered_argv) #232
    model_mapping = { #233
        '1': 'bicycle',    # 自行车模型 #234
        '2': 'fox',        # 狐狸模型 #235
        '3': 'chair',      # 椅子模型 #236
        '4': 'cow',        # 奶牛模型 #237
        '5': 'wolf',       # 狼模型 #238
        '6': 'rectangle'   # 矩形模型 #239
    } #240
    selected_model = model_mapping.get(parsed_args.model, parsed_args.model) #241

    rclpy.init(args=args) #243
    ar_app_node = ARNode(ROS_NODE_NAME) #244
    ar_app_node.get_logger().info(f"Starting AR demo with model: {selected_model}") #245
    ar_app_node.enter_srv_callback(1) #246
    ar_app_node.set_model_srv_callback(selected_model) #247

    try: #249
        rclpy.spin(ar_app_node) #250
    except Exception as e: #251
        ar_app_node.get_logger().error(f"Runtime error: {str(e)}") #252
        ar_app_node.get_logger().info("Shutting down") #253
    finally: #254
        ar_app_node.destroy_node() #255
        rclpy.shutdown() #256

if __name__ == '__main__': #258
    main() #259
