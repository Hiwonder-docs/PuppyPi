import os #1
from launch_ros.actions import Node #2
from launch import LaunchService #3

from launch import LaunchDescription #5
from launch.actions import IncludeLaunchDescription, GroupAction #6
from launch.launch_description_sources import PythonLaunchDescriptionSource #7

def launch_setup(context): #9
    puppy_control_package_path = '/home/ubuntu/ros2_ws/src/driver/puppy_control' #10
    peripherals_package_path = '/home/ubuntu/ros2_ws/src/peripherals' #11

    puppy_control_node = GroupAction([  #13
        IncludeLaunchDescription( #14
            PythonLaunchDescriptionSource( #15
                os.path.join(puppy_control_package_path, 'launch/puppy_control.launch.py'))), #16
        IncludeLaunchDescription( #17
            PythonLaunchDescriptionSource( #18
                os.path.join(peripherals_package_path, 'launch/usb_cam.launch.py'))), #19

        Node( #21
            package='example', #22
            executable='apriltag_detect_demo', #23
            name='apriltag_detect_node', #24
            output='screen', #25
        ), #26
    ])  #27
    
    # 返回 LaunchDescription 对象 #29
    return LaunchDescription([ #30
        puppy_control_node #31
    ]) #32

def generate_launch_description(): #34
    return launch_setup(None) #35

if __name__ == '__main__': #37
    ld = generate_launch_description() #38
    
    ls = LaunchService() #40
    ls.include_launch_description(ld) #41
    ls.run() #42
