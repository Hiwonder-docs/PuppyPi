#!/usr/bin/env python3 #1
# coding=utf8 #2
# 第7课 MP3模块实验 #3
import math #4
import rclpy #5
import time #6
import signal #7
import os #8
import subprocess #9
from rclpy.node import Node #10
from speech import speech #11
from puppy_control_msgs.srv import SetRunActionName #12
from puppy_control_msgs.msg import Velocity, Pose, Gait #13
speech.set_volume(70) #14
print(''' #15
********************************************************** #16
******************功能: MP3模块例程************************* #17
********************************************************** #18
---------------------------------------------------------- #19
Official website: https://www.hiwonder.com #20
Online mall: https://hiwonder.tmall.com #21
---------------------------------------------------------- #22
Tips: #23
 * 按下Ctrl+C可安全关闭程序！(Press Ctrl+C to safely close the program) #24
---------------------------------------------------------- #25
''') #26

class Mp3MoonwalkDemo(Node): #28
    def __init__(self): #29
        super().__init__('mp3_moonwalk_demo') #30
        # 初始化信号处理 #31
        signal.signal(signal.SIGINT, self.signal_handler) #32
        signal.signal(signal.SIGTERM, self.signal_handler) #33

        self.MP3_DIR = "./MP3" #35
        self.mpg123_process = None  # 用于跟踪音频播放进程 #36
        self.timer = None  # 定时器 #37

        # 创建发布者和客户端 #39
        self.pose_publisher = self.create_publisher(Pose, '/puppy_control/pose', 10) #40
        self.gait_publisher = self.create_publisher(Gait, '/puppy_control/gait', 10) #41
        self.velocity_publisher = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #42
        self.run_action_group_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup') #43

        # 获取 MP3 文件 #45
        self.get_mp3_files() #46

        # 初始化姿态和步态 #48
        self.set_pose() #49
        self.set_gait() #50

        # 创建定时器 #52
        self.timer = self.create_timer(0.1, self.mp3_moon_callback) #53
        self.get_logger().info("节点初始化完成") #54

    def get_mp3_files(self): #56
        """从目录中读取所有 MP3 文件""" #57
        try: #58
            files = [f for f in os.listdir(self.MP3_DIR) if f.endswith(".mp3")] #59
            self.mp3_files = {i + 1: os.path.join(self.MP3_DIR, f) for i, f in enumerate(files)} #60
            if not self.mp3_files: #61
                self.get_logger().error(f"目录 {self.MP3_DIR} 中没有找到 MP3 文件，请检查目录内容。") #62
                raise FileNotFoundError("No MP3 files found") #63
            
            self.get_logger().info("可用歌曲列表:") #65
            for num, path in self.mp3_files.items(): #66
                self.get_logger().info(f"{num}: {os.path.basename(path)}") #67
        except Exception as e: #68
            self.get_logger().error(f"获取 MP3 文件失败: {str(e)}") #69
            raise #70

    def play_audio(self, file_path): #72
        """播放音频文件""" #73
        if not os.path.exists(file_path): #74
            self.get_logger().error(f"文件不存在: {file_path}") #75
            return #76
        try: #77
            self.mpg123_process = subprocess.Popen( #78
                ["mpg123", file_path], #79
                stdout=subprocess.DEVNULL, #80
                stderr=subprocess.DEVNULL #81
            ) #82
            self.get_logger().info(f"正在播放音乐: {file_path}") #83
        except Exception as e: #84
            self.get_logger().error(f"播放音频失败: {str(e)}") #85

    def mp3_moon_callback(self): #87
        """定时器回调函数，执行动作序列""" #88
        try: #89
            # 原地踏步 #90
            self.set_move(x=0.01) #91
            time.sleep(3) #92
            self.set_move(x=0.0) #93
            time.sleep(1) #94

            # 多轴联动 #96
            self.linkage(2) #97

            # 机器狗站立 #99
            self.set_pose() #100

            # 向前走 #102
            self.set_move(x=5.0) #103
            time.sleep(3) #104
            # 向后走 #105
            self.set_move(x=-5.0) #106
            time.sleep(2) #107
            # 停止 #108
            self.set_move(x=0.0) #109
            time.sleep(1) #110

            # 执行滑步动作组 #112
            msg = SetRunActionName.Request() #113
            msg.name = 'moonwalk.d6ac' #114
            msg.wait = True #115
            self.run_action_group_srv.call_async(msg) #116
            time.sleep(0.1) #117
            self.run_action_group_srv.call_async(msg) #118
            time.sleep(0.1) #119

            # 机器狗站立 #121
            self.set_pose() #122
            time.sleep(0.5) #123

            # 向前走 #125
            self.set_move(x=5.0) #126
            time.sleep(3) #127
            # 向后走 #128
            self.set_move(x=-5.0) #129
            time.sleep(2) #130
            # 停止 #131
            self.set_move() #132
            time.sleep(1) #133
        except Exception as e: #134
            self.get_logger().error(f"执行动作序列时出错: {str(e)}") #135

    def linkage(self, times=1): #137
        """多轴联动""" #138
        try: #139
            for i in range(0, 15, 1): #140
                self.set_pose(roll=math.radians(i), run_time=30) #141
                time.sleep(0.03) #142
            for i in range(0, 15, 1): #143
                self.set_pose(pitch=math.radians(i), run_time=30) #144
                time.sleep(0.03) #145

            for _ in range(times): #147
                for i in range(15, -15, -1): #148
                    self.set_pose(roll=math.radians(i), pitch=math.radians(15), run_time=30) #149
                    time.sleep(0.03) #150
                for i in range(15, -15, -1): #151
                    self.set_pose(roll=math.radians(-15), pitch=math.radians(i), run_time=30) #152
                    time.sleep(0.03) #153
                for i in range(-15, 15, 1): #154
                    self.set_pose(roll=math.radians(i), pitch=math.radians(-15), run_time=30) #155
                    time.sleep(0.03) #156
                for i in range(-15, 15, 1): #157
                    self.set_pose(roll=math.radians(15), pitch=math.radians(i), run_time=30) #158
                    time.sleep(0.03) #159
        except Exception as e: #160
            self.get_logger().error(f"多轴联动出错: {str(e)}") #161

    def set_pose(self, roll=math.radians(0), pitch=math.radians(0), yaw=0.000, height=-10.0, #163
                 x_shift=0.5, stance_x=0.0, stance_y=0.0, run_time=500): #164
        """设置机器狗姿态""" #165
        try: #166
            self.pose_publisher.publish(Pose( #167
                stance_x=stance_x, stance_y=stance_y, x_shift=x_shift, #168
                height=height, roll=roll, pitch=pitch, yaw=yaw, run_time=run_time #169
            )) #170
        except Exception as e: #171
            self.get_logger().error(f"设置姿态失败: {str(e)}") #172

    def set_gait(self, overlap_time=0.3, swing_time=0.2, clearance_time=0.0, z_clearance=5.0): #174
        """设置步态""" #175
        try: #176
            self.gait_publisher.publish(Gait( #177
                overlap_time=overlap_time, swing_time=swing_time, #178
                clearance_time=clearance_time, z_clearance=z_clearance #179
            )) #180
        except Exception as e: #181
            self.get_logger().error(f"设置步态失败: {str(e)}") #182

    def set_move(self, x=0.00, y=0.0, yaw_rate=0.0): #184
        """设置移动速度""" #185
        try: #186
            self.velocity_publisher.publish(Velocity(x=x, y=y, yaw_rate=yaw_rate)) #187
        except Exception as e: #188
            self.get_logger().error(f"设置移动速度失败: {str(e)}") #189

    def signal_handler(self, sig, frame): #191
        """处理信号（Ctrl+C 或终止信号）""" #192
        self.get_logger().info("收到终止信号，正在清理资源...") #193
        self.cleanup() #194
        rclpy.shutdown() #195
        self.get_logger().info("程序已安全退出") #196
        exit(0) #197

    def cleanup(self): #199
        """清理资源""" #200
        self.get_logger().info("开始清理资源...") #201
        try: #202
            # 停止移动 #203
            self.set_move(x=0.0, y=0.0, yaw_rate=0.0) #204
            self.get_logger().info("停止移动: 完成") #205

            # 终止音频播放进程 #207
            if self.mpg123_process and self.mpg123_process.poll() is None: #208
                self.mpg123_process.terminate() #209
                try: #210
                    self.mpg123_process.wait(timeout=2) #211
                except subprocess.TimeoutExpired: #212
                    self.mpg123_process.kill()  # 强制终止 #213
                    self.get_logger().warning("音频进程未正常终止，已强制关闭") #214
                self.get_logger().info("终止音频进程: 完成") #215
            
            # 销毁定时器 #217
            if self.timer: #218
                self.timer.cancel() #219
                self.get_logger().info("销毁定时器: 完成") #220
            
            # 销毁发布者和客户端 #222
            self.pose_publisher.destroy() #223
            self.gait_publisher.destroy() #224
            self.velocity_publisher.destroy() #225
            self.run_action_group_srv.destroy() #226
            self.get_logger().info("销毁发布者和客户端: 完成") #227

            # 销毁节点 #229
            self.destroy_node() #230
            self.get_logger().info("销毁节点: 完成") #231
        except Exception as e: #232
            self.get_logger().error(f"清理资源时出错: {str(e)}") #233
        finally: #234
            self.get_logger().info("资源清理完成") #235

def main(args=None): #237
    rclpy.init(args=args) #238
    node = None #239
    try: #240
        node = Mp3MoonwalkDemo() #241
        song_number = int(input("请输入要播放的歌曲编号: ")) #242
        if song_number in node.mp3_files: #243
            node.play_audio(node.mp3_files[song_number]) #244
        else: #245
            node.get_logger().error("输入的编号无效，请重试。") #246
            return #247
        
        # 使用 spin_once 替代 spin，增加控制 #249
        while rclpy.ok(): #250
            rclpy.spin_once(node, timeout_sec=0.1) #251
    except ValueError: #252
        if node: #253
            node.get_logger().error("输入无效，请输入数字编号。") #254
    except KeyboardInterrupt: #255
        if node: #256
            node.get_logger().info("用户中断程序") #257
    except Exception as e: #258
        if node: #259
            node.get_logger().error(f"程序运行出错: {str(e)}") #260
    finally: #261
        if node: #262
            node.cleanup() #263
        rclpy.shutdown() #264
        print("程序已完全退出") #265

if __name__ == '__main__': #267
    main() #268
