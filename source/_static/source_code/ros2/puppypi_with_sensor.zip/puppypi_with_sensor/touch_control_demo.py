#!/usr/bin/python3 #1
#coding=utf8 #2
# 第6课 触摸检测感应 #3
import os #4
import sys #5
import time #6
import math #7
import rclpy #8
import gpiod #9
import signal #10
from rclpy.node import Node #11
from std_msgs.msg import * #12
from puppy_control_msgs.msg import Velocity, Pose, Gait #13

print(''' #15
********************************************************** #16
******************功能:触摸控制例程(function: touch control routine)************************* #17
********************************************************** #18
---------------------------------------------------------- #19
Official website:https://www.hiwonder.com #20
Online mall:https://hiwonder.tmall.com #21
---------------------------------------------------------- #22
Tips: #23
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #24
---------------------------------------------------------- #25
''') #26

# 触摸模块接扩展板上的IO22、IO24接口(connect the touch module to the IO22 and IO24 interfaces on expansion board) #28




GaitConfig = {'overlap_time':0.2, 'swing_time':0.2, 'clearance_time':0.0, 'z_clearance':3.0} #33
# overlap_time:4脚全部着地的时间，单位秒(the time when all four legs touch the ground, measured in seconds) #34
# swing_time：2脚离地时间，单位秒(the time duration when legs are off the ground, measured in second) #35
# clearance_time：前后脚间隔时间，单位秒(the time interval between the front and rear legs, measured in seconds) #36
# z_clearance：走路时，脚抬高的距离，单位cm(the distance the paw needs to be raised during walking, measured in centimeters) #37


# 触摸模块接扩展板上的IO22、IO24接口(connect the touch module to the IO22 and IO24 interfaces on the expansion board) #40
touch_pin = 22 #41
chip = gpiod.chip("gpiochip0") #42
    
touch = chip.get_line(touch_pin) #44
config = gpiod.line_request() #45
config.consumer = "touch" #46
config.request_type = gpiod.line_request.DIRECTION_INPUT #47
config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #48
touch.request(config) #49


class TouchControl(Node): #52
    def __init__(self): #53
        super().__init__('touch_control_demo') #54
        signal.signal(signal.SIGINT, self.stop) #55
        self.squat = True    #56
        self.click = 0    #57
        self.pose_publisher = self.create_publisher(Pose, '/puppy_control/pose',10) #58
        self.gait_publisher = self.create_publisher(Gait, '/puppy_control/gait', 10) #59
        self.velocity_publisher = self.create_publisher(Velocity, '/puppy_control/velocity',10) #60
        
        self.PuppyPose = {'roll':math.radians(4), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10.0, 'x_shift':-0.5, 'stance_x':0.0, 'stance_y':0.0} #62
        # stance_x：4条腿在x轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the X-axis, measured in centimeters) #63
        # stance_y：4条腿在y轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the Y-axis, measured in centimeters) #64
        # x_shift: 4条腿在x轴上同向移动的距离，越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡，单位cm(the distance traveled by the four legs along the x-axis determines the degree of forward or backward tilt during walking: smaller distances lead to more forward tilt, while larger distances result in more backward tilt. Adjusting the x_shift parameter can help maintain balance during the dog's movement, measured in centimeters) #65
        # height： 狗的高度，脚尖到大腿转动轴的垂直距离，单位cm(the height of the dog, measured from the toe to the axis  of rotation of the thigh, is in centimeters) #66
        # pitch： 狗身体的俯仰角，单位弧度(the pitch angle of the dog's body, measured in radians) #67
        
        
        self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #70
                                       height=self.PuppyPose['height'], roll=self.PuppyPose['roll'], pitch=self.PuppyPose['pitch'], yaw=self.PuppyPose['yaw'], run_time=500)) #71
        
        self.gait_publisher.publish(Gait(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #73
                    , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']))    #74
                  
             
        self.timer = self.create_timer(0.1, self.touch_callback)   #77
     
    def touch_callback(self): #79
        self.state = touch.get_value() #80
        if not self.state: #81
            detect_time = time.time()+1 #82
            while time.time() < detect_time: #83
                self.state = touch.get_value()  #84
                time.sleep(0.1) #85
                if not self.state: #86
                   self.click += 1 #87
                   time.sleep(0.2)                      #88
            if self.click == 1: #89
                self.click =0 #90
                if self.squat: #91
                    # 机器狗下蹲(the robot dog crouches down) #92
                    self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #93
                                       height=self.PuppyPose['height'] + 3.0, roll=self.PuppyPose['roll'], pitch=self.PuppyPose['pitch'], yaw=self.PuppyPose['yaw'], run_time=500)) #94
                    time.sleep(1) #95
                    self.squat = False #96
                elif not self.squat:                 #97
                    self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #98
                                       height=self.PuppyPose['height'], roll=self.PuppyPose['roll'], pitch=self.PuppyPose['pitch'], yaw=self.PuppyPose['yaw'], run_time=500)) #99
                    time.sleep(1) #100
                    self.squat = True #101
                    
            elif self.click == 2: #103
                self.click = 0 #104
                # 机器狗抖一抖(the robot dog shakes a little) #105
                for i in  range(5): #106
                    self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #107
                        height=self.PuppyPose['height'], roll=math.radians(3.5), pitch=self.PuppyPose['pitch'], yaw=self.PuppyPose['yaw'], run_time = 50)) #108
                    time.sleep(0.13) #109
                    self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #110
                    height=self.PuppyPose['height'], roll=math.radians(-3.5), pitch=self.PuppyPose['pitch'], yaw=self.PuppyPose['yaw'], run_time = 300)) #111
                    time.sleep(1)  #112
                
    def send_request(self, client, msg): #114
        future = client.call_async(msg) #115
        while rclpy.ok(): #116
            if future.done() and future.result(): #117
                return future.result() #118
                        
    def stop(self): #120
        self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.0)) #121
        self.get_logger().info('Shutting down...') #122

        
def main(args=None): #125
    rclpy.init(args=args) #126
    node = TouchControl() #127

    try: #129
        rclpy.spin(node) #130
    except KeyboardInterrupt: #131
        print("intteruprt------------") #132
        pass #133

    finally: #135
        node.stop() #136
        node.destroy_node() #137
        rclpy.shutdown() #138
 

if __name__ == '__main__': #141
    main() #142
