#!/usr/bin/env python3 #1
# coding=utf8 #2
# 第8课 机器狗语音识别交互(Lesson 8 Robot Dog Voice Recognition and Interaction) #3
import os #4
import sys #5
import rclpy #6
import math #7
import signal #8
import serial #9
import time #10
from rclpy.node import Node #11
from puppy_control_msgs.msg import Velocity, Pose, Gait #12

print(''' #14
********************************************************** #15
******************功能:语音交互例程(function: voice interaction routine)************************* #16
********************************************************** #17
---------------------------------------------------------- #18
Official website:https://www.hiwonder.com #19
Online mall:https://hiwonder.tmall.com #20
---------------------------------------------------------- #21
Tips: #22
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #23
---------------------------------------------------------- #24
''') #25

GaitConfig = {'overlap_time':0.2, 'swing_time':0.2, 'clearance_time':0.0, 'z_clearance':3.0} #27
# overlap_time:4脚全部着地的时间，单位秒(the time when all four legs touch the ground, measured in seconds) #28
# swing_time：2脚离地时间，单位秒(the time duration when legs are off the ground, measured in second) #29
# clearance_time：前后脚间隔时间，单位秒(the time interval between the front and rear legs, measured in seconds) #30
# z_clearance：走路时，脚抬高的距离，单位cm(the distance the paw needs to be raised during walking, measured in centimeters) #31



class VoiceInteractionDemo(Node): #35
    def __init__(self): #36
        super().__init__('voice_interaction_demo') #37
        signal.signal(signal.SIGINT, self.stop) #38
    
        self.ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)   #40
        self.pose_publisher = self.create_publisher(Pose, '/puppy_control/pose',10) #41
        self.gait_publisher = self.create_publisher(Gait, '/puppy_control/gait', 10) #42
        self.velocity_publisher = self.create_publisher(Velocity, '/puppy_control/velocity',10) #43
        
        self.PuppyPose = {'roll':math.radians(4), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10.0, 'x_shift':-0.5, 'stance_x':0.0, 'stance_y':0.0} #45
        # stance_x：4条腿在x轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the X-axis, measured in centimeters) #46
        # stance_y：4条腿在y轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the Y-axis, measured in centimeters) #47
        # x_shift: 4条腿在x轴上同向移动的距离，越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡，单位cm(the distance traveled by the four legs along the x-axis determines the degree of forward or backward tilt during walking: smaller distances lead to more forward tilt, while larger distances result in more backward tilt. Adjusting the x_shift parameter can help maintain balance during the dog's movement, measured in centimeters) #48
        # height： 狗的高度，脚尖到大腿转动轴的垂直距离，单位cm(the height of the dog, measured from the toe to the axis  of rotation of the thigh, is in centimeters) #49
        # pitch： 狗身体的俯仰角，单位弧度(the pitch angle of the dog's body, measured in radians) #50
        
        
        self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #53
                                       height=self.PuppyPose['height'], roll=self.PuppyPose['roll'], pitch=self.PuppyPose['pitch'], yaw=self.PuppyPose['yaw'], run_time=500)) #54
        
        self.gait_publisher.publish(Gait(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #56
                    , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']))  #57
                                
        self.timer = self.create_timer(0.1, self.asr_callback) #59


    def asr_callback(self): #62
         
        if self.ser.in_waiting > 0:         #64
            data = self.ser.read(5)  #65
            hex_data = ' '.join(format(byte, '02X') for byte in data)            #66
            self.get_logger().info(f"Received data: {hex_data}") #67
            
            if hex_data == "AA 55 00 8D FB": # 抬头(raise the head)                #69
                self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #70
                                       height=self.PuppyPose['height'], roll=self.PuppyPose['roll'], pitch=math.radians(20), yaw=self.PuppyPose['yaw'], run_time=500)) #71
            elif hex_data == "AA 55 00 0B FB":# 趴下(lie down) #72
                self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #73
                                       height=self.PuppyPose['height'] + 4, roll=self.PuppyPose['roll'], pitch=self.PuppyPose['pitch'], yaw=self.PuppyPose['yaw'], run_time=500)) #74
            elif hex_data == "AA 55 00 0A FB":# 立正(stand at attention) #75
                self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #76
                                       height=self.PuppyPose['height'], roll=self.PuppyPose['roll'], pitch=self.PuppyPose['pitch'], yaw=self.PuppyPose['yaw'], run_time=500)) #77
            elif hex_data == "AA 55 00 76 FB":# 原地踏步(stepping in the place) #78
                self.pose_publisher.publish(Pose(stance_x=self.PuppyPose['stance_x'], stance_y=self.PuppyPose['stance_y'], x_shift=self.PuppyPose['x_shift'], #79
                                       height=self.PuppyPose['height'], roll=self.PuppyPose['roll'], pitch=self.PuppyPose['pitch'], yaw=self.PuppyPose['yaw'], run_time=500)) #80
                time.sleep(0.5) #81
                self.velocity_publisher.publish(Velocity(x=0.1, y=0.0, yaw_rate=0.0)) #82
                time.sleep(2) #83
                self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.0)) #84
            elif hex_data == "AA 55 02 00 FB":  #85
                self.get_logger().info('restart wakeup!!!!!!!!!!!!!!!!!!') #86
            else: #87
                time.sleep(0.02) #88
                                       
        else: #90
            time.sleep(0.02) #91
            
    # 关闭检测函数(turn off detection function)        #93
    def stop(self): #94
        self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.0)) #95
        self.get_logger().info('Shutting down...') #96
   

def main(args=None): #99
    rclpy.init(args=args) #100
    node = VoiceInteractionDemo() #101

    try: #103
        rclpy.spin(node) #104
    except KeyboardInterrupt: #105
        pass #106
    finally: #107
        node.stop() #108
        node.destroy_node() #109
        rclpy.shutdown() #110

if __name__ == '__main__': #112
    main() #113
