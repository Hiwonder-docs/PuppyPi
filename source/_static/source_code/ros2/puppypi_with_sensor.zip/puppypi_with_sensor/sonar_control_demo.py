#!/usr/bin/python3 #1
# coding=utf8 #2
# 第1课 发光超声波控制 #3

import os #5
import sys #6
import time #7
import signal #8
import rclpy #9
from rclpy.node import Node #10
import sdk.sonar as sonar #11

class SonarControlDemo(Node): #13
    def __init__(self): #14
        super().__init__('sonar_control_demo') #15
        self.get_logger().info(''' #16
********************************************************** #17
*******************功能:超声波控制例程********************** #18
********************************************************** #19
Official website: https://www.hiwonder.com #20
Online mall: https://hiwonder.tmall.com #21
----------------------------------------------------------  #22
Tips: 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！ #23
----------------------------------------------------------''') #24

        if sys.version_info.major == 2: #26
            self.get_logger().error('Please run this program with Python 3!') #27
            rclpy.shutdown() #28
            sys.exit(0) #29

        # 初始化超声波传感器 #31
        self.sonar = sonar.Sonar() #32
        self.sonar.setRGBMode(0)  # 0:彩灯模块, 1:呼吸灯模式 #33
        self.sonar.setRGB(1, (0, 0, 0))  # 关闭RGB灯 #34
        self.sonar.setRGB(0, (0, 0, 0)) #35

        # 设置信号处理 #37
        signal.signal(signal.SIGINT, self.stop) #38

        # 创建定时器，周期性检查距离 #40
        self.timer = self.create_timer(0.1, self.sonar_callback) #41
        self.running = True #42

    def sonar_callback(self): #44
        if not self.running: #45
            return #46

        try: #48
            distance = self.sonar.getDistance()  # 获得检测距离 #49
            self.get_logger().info(f'distance: {distance} (mm)') #50

            if distance <= 300:  # 距离小于300mm #52
                self.sonar.setRGB(1, (255, 0, 0))  # 红色 #53
                self.sonar.setRGB(0, (255, 0, 0)) #54
            elif 300 < distance < 500: #55
                self.sonar.setRGB(1, (0, 255, 0))  # 绿色 #56
                self.sonar.setRGB(0, (0, 255, 0)) #57
            else: #58
                self.sonar.setRGB(1, (0, 0, 255))  # 蓝色 #59
                self.sonar.setRGB(0, (0, 0, 255)) #60

        except Exception as e: #62
            self.get_logger().error(f'Error in sonar_callback: {str(e)}') #63

    def stop(self, signum, frame): #65
        self.running = False #66
        self.sonar.setRGB(1, (0, 0, 0)) #67
        self.sonar.setRGB(0, (0, 0, 0)) #68
        self.get_logger().info('Shutting down...') #69
        self.destroy_timer(self.timer) #70
        rclpy.shutdown() #71

def main(args=None): #73
    rclpy.init(args=args) #74
    node = SonarControlDemo() #75
    try: #76
        rclpy.spin(node) #77
    except KeyboardInterrupt: #78
        node.get_logger().info('Node interrupted by user') #79
    finally: #80
        node.stop(0, None) #81
        node.destroy_node() #82
        rclpy.shutdown() #83

if __name__ == '__main__': #85
    main() #86
