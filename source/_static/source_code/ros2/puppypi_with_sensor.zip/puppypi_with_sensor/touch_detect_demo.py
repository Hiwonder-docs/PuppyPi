#!/usr/bin/python3 #1
#coding=utf8 #2
# 第3课 触摸传感器检测(Lesson 3 Touch Sensor Detection) #3
import os #4
import sys #5
import rclpy #6
import gpiod #7
import signal #8
from rclpy.node import Node #9
from ros_robot_controller_msgs.msg import BuzzerState #10


print(''' #13
********************************************************** #14
*******************功能:触摸检测例程(function: touch detection routine)************************ #15
********************************************************** #16
---------------------------------------------------------- #17
Official website:https://www.hiwonder.com #18
Online mall:https://hiwonder.tmall.com #19
---------------------------------------------------------- #20
Tips: #21
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #22
---------------------------------------------------------- #23
''') #24

# 触摸模块接扩展板上的IO22、IO24接口(connect the touch module to the IO22 and IO24 interfaces on the expansion board) #26
# 注册gpio引脚 #27
touch_pin = 22 #28
chip = gpiod.chip("gpiochip0")     #29
touch = chip.get_line(touch_pin) #30
config = gpiod.line_request() #31
# 配置为上拉输入 #32
config.consumer = "touch" #33
config.request_type = gpiod.line_request.DIRECTION_INPUT #34
config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #35
touch.request(config) #36


class TouchNode(Node): #39
    def __init__(self): #40
        # 初始化节点(initialization node) #41
        super().__init__('touch_control_buzzer') #42
        signal.signal(signal.SIGINT, self.stop) #43
        self.buzzer_pub = self.create_publisher(BuzzerState, '/ros_robot_controller/set_buzzer', 10) #44
        self.timer = self.create_timer(0.1, self.timer_callback)  #45
        self.st = 0 #46

    def stop(self): #48
        self.get_logger().info('Shutting down...') #49
        self.buzzer_pub.publish(0) #50
      
    def timer_callback(self): #52
        state = touch.get_value() #53
        if not state: #54
            if self.st == 1: #这里做一个判断，防止反复响(implement a check here to prevent repeated responses) #55
                self.st = 0 #56
                msg = BuzzerState() #57
                msg.freq = 1900  #58
                msg.on_time = 0.5 #59
                msg.off_time = 0.5 #60
                msg.repeat = 1 #61
                self.buzzer_pub.publish(msg)# 蜂鸣器响0.5秒(buzzer emits for 0.5 second) #62
                self.get_logger().info("Buzzer on") #63
        else: #64
            self.st = 1  #65
            self.get_logger().info("Buzzer off") #66

        
def main(args=None): #69
    rclpy.init(args=args) #70
    node = TouchNode() #71

    try: #73
        rclpy.spin(node) #74
    except KeyboardInterrupt: #75
        print("intteruprt------------") #76
        pass #77
    finally: #78
        node.destroy_node() #79
        rclpy.shutdown() #80
 

if __name__ == '__main__': #83
    main() #84
