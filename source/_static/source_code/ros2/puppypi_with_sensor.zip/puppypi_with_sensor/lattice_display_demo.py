#!/usr/bin/env python3 #1
import rclpy #2
from rclpy.node import Node #3
import time #4
from sdk import dot_matrix_sensor   #5

class DotMatrixDisplayNode(Node): #7
    def __init__(self): #8
        super().__init__('dot_matrix_display_node') #9
        self.get_logger().info('点阵显示节点已启动') #10

        # 初始化点阵模块，连接到 IO7 和 IO8 #12
        try: #13
            self.dms = dot_matrix_sensor.TM1640(dio=7, clk=8) #14
        except Exception as e: #15
            self.get_logger().error(f'点阵模块初始化失败: {e}') #16
            return #17

        # 定时器，每5秒更新一次显示 #19
        self.timer = self.create_timer(5.0, self.display_callback) #20

    def display_callback(self): #22
        try: #23

            self.dms.display_buf = ( #25
                0x7f, 0x08, 0x7f, 0x00,  # H #26
                0x7c, 0x54, 0x5c, 0x00,  # e #27
                0x7c, 0x40, 0x00,        # l #28
                0x7c, 0x40,              # l #29
                0x38, 0x44, 0x38         # o #30
            ) #31
            self.dms.update_display() #32
            self.get_logger().info('显示: Hello') #33

        except Exception as e: #35
            self.get_logger().error(f'显示更新失败: {e}') #36

    def shutdown(self): #38

        self.dms.display_buf = [0] * 16 #40
        self.dms.update_display() #41
        self.get_logger().info('点阵显示已关闭') #42

def main(args=None): #44
    rclpy.init(args=args) #45
    node = DotMatrixDisplayNode() #46
    try: #47
        rclpy.spin(node) #48
    except KeyboardInterrupt: #49
        node.shutdown() #50
    finally: #51
        node.destroy_node() #52
        rclpy.shutdown() #53

if __name__ == '__main__': #55
    main() #56
