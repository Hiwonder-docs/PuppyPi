#!/usr/bin/python3 #1
#coding=utf8 #2
# 第5课 语音识别传感器实验(Lesson 5 Voice Recognition Sensor) #3
import os #4
import sys #5
import rclpy #6
import serial #7
import binascii #8
import signal #9
from rclpy.node import Node #10
from ros_robot_controller_msgs.msg import RGBState, RGBsState #11


print(''' #14
********************************************************** #15
*******************功能:语音识别例程(function: voice recognition routine)************************ #16
********************************************************** #17
---------------------------------------------------------- #18
Official website:https://www.hiwonder.com #19
Online mall:https://hiwonder.tmall.com #20
---------------------------------------------------------- #21
Tips: #22
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close the program, please try multiple times if fail) #23
---------------------------------------------------------- #24
''') #25


class ASRDetectDemo(Node): #28
    def __init__(self): #29
        super().__init__('asr_detect_demo') #30
        signal.signal(signal.SIGINT, self.stop)        #31
        self.ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)                              #32
        self.rgb_pub = self.create_publisher(RGBsState, '/ros_robot_controller/set_rgb', 10) #33
        self.timer = self.create_timer(0.1, self.asr_callback) #34


    def asr_callback(self): #37
        if self.ser.in_waiting > 0: #38
            data = self.ser.read(5)   #39
            self.parse_serial_data(data) #40
            
            
    def parse_serial_data(self, data): #43
        hex_data = ' '.join(format(byte, '02X') for byte in data) #44
        self.get_logger().info(f"Received data: {hex_data}") #45
        if hex_data == "AA 55 00 8A FB":  #46
            self.set_rgb_show(255, 0, 0) #47
        elif hex_data == "AA 55 00 8B FB": #48
            self.set_rgb_show(0, 255, 0) #49
        elif hex_data == "AA 55 00 8C FB": #50
            self.set_rgb_show(0, 0, 255) #51
        elif hex_data == "AA 55 00 09 FB":  #52
            self.turn_off_rgb() #53
        elif hex_data == "AA 55 02 00 FB":  #54
            self.get_logger().info('restart wakeup!!!!!!!!!!!!!!!!!!') #55
            
    # 关闭检测函数(turn off detection function)        #57
    def stop(self): #58
        self.turn_off_rgb() #59
        self.get_logger().info('Shutting down...') #60
    # 关闭RGB彩灯(turn off color light)     #61
    def turn_off_rgb(self): #62
        led1 = RGBState() #63
        led1.id = 1 #64
        led1.r = 0 #65
        led1.g = 0 #66
        led1.b = 0 #67
        
        led2 = RGBState() #69
        led2.id = 2 #70
        led2.r = 0 #71
        led2.g = 0 #72
        led2.b = 0 #73
        
        msg = RGBsState() #75
        msg.data = [led1,led2] #76
        self.rgb_pub.publish(msg) #77
    # 设置RGB彩灯显示(set the RGB color light to display)     #78
    def set_rgb_show(self,r, g, b): #79
        led1 = RGBState() #80
        led1.id = 1 #81
        led1.r = r #82
        led1.g = g #83
        led1.b = b        #84
        led2 = RGBState() #85
        led2.id = 2 #86
        led2.r = r #87
        led2.g = g #88
        led2.b = b #89
        msg = RGBsState() #90
        msg.data = [led1,led2] #91
        self.rgb_pub.publish(msg)        #92
               


def main(args=None): #96
    rclpy.init(args=args) #97
    node = ASRDetectDemo() #98

    try: #100
        rclpy.spin(node) #101
    except KeyboardInterrupt: #102
        pass #103
    finally: #104
        node.stop() #105
        node.destroy_node() #106
        rclpy.shutdown() #107

if __name__ == '__main__': #109
    main() #110

        
           
