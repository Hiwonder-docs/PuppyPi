#!/usr/bin/env python3 #1
# 第2课 机器狗超声波测距避障 #2
import os #3
import sys #4
import math #5
import rclpy #6
import signal #7
import time #8
from rclpy.node import Node #9
import sdk.sonar as sonar #10
from puppy_control_msgs.msg import Velocity, Pose, Gait #11
from std_srvs.srv import Empty #12

class SonarAvoidance(Node): #14
    def __init__(self): #15
        super().__init__('sonar_avoidance') #16
        self.get_logger().info(''' #17
********************************************************** #18
********************功能:超声波避障例程********************** #19
********************************************************** #20
Official website: https://www.hiwonder.com #21
Online mall: https://hiwonder.tmall.com #22
----------------------------------------------------------  #23
Tips: 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！ #24
----------------------------------------------------------''') #25

        if sys.version_info.major == 2: #27
            self.get_logger().error('Please run this program with Python 3!') #28
            rclpy.shutdown() #29
            sys.exit(0) #30

        signal.signal(signal.SIGINT, self.stop) #32
        
        # 初始化超声波传感器 #34
        try: #35
            self.s = sonar.Sonar() #36
            self.s.setRGBMode(0)  # 0:彩灯模块 #37
            self.s.setRGB(1, (0, 0, 0))  # 关闭RGB灯 #38
            self.s.setRGB(0, (0, 0, 0)) #39
            self.get_logger().info('Sonar initialized successfully') #40
        except Exception as e: #41
            self.get_logger().error(f'Failed to initialize sonar: {str(e)}') #42
            rclpy.shutdown() #43
            return #44

        self.forward = True        #46
        self.pose_publisher = self.create_publisher(Pose, '/puppy_control/pose', 10) #47
        self.gait_publisher = self.create_publisher(Gait, '/puppy_control/gait', 10) #48
        self.velocity_publisher = self.create_publisher(Velocity, '/puppy_control/velocity', 10) #49
        self.go_home_client = self.create_client(Empty, '/puppy_control/go_home') #50

        # 发布初始姿态和步态 #52
        PuppyPose = { #53
            'roll': math.radians(0), 'pitch': math.radians(0), 'yaw': 0.000, #54
            'height': -10.0, 'x_shift': 0.0, 'stance_x': 0.0, 'stance_y': 0.0 #55
        } #56
        GaitConfig = { #57
            'overlap_time': 0.15, 'swing_time': 0.2, #58
            'clearance_time': 0.0, 'z_clearance': 3.0 #59
        } #60
        self.pose_publisher.publish(Pose( #61
            stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], #62
            x_shift=PuppyPose['x_shift'], height=PuppyPose['height'], #63
            roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], #64
            run_time=500 #65
        )) #66
        self.gait_publisher.publish(Gait( #67
            overlap_time=GaitConfig['overlap_time'], swing_time=GaitConfig['swing_time'], #68
            clearance_time=GaitConfig['clearance_time'], z_clearance=GaitConfig['z_clearance'] #69
        )) #70

        # 调用 go_home 服务 #72
        self.call_go_home_service() #73
        
        self.timer = self.create_timer(0.1, self.sonar_callback) #75
     
    def sonar_callback(self): #77
        try: #78
            distance = self.s.getDistance()  # 获得检测距离 #79
            if distance is None or distance < 0: #80
                self.get_logger().warn('Invalid distance reading') #81
                return #82
            self.get_logger().info(f'distance: {distance} (mm)') #83
            
            if distance <= 300: #85
                if not self.forward: #86
                    self.forward = True #87
                    self.s.setRGB(1, (255, 0, 0))  # 红色 #88
                    self.s.setRGB(0, (255, 0, 0)) #89
                    self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.3))  # 左转 #90
                    self.get_logger().info('Turning left') #91
            else: #92
                if self.forward: #93
                    self.forward = False #94
                    self.s.setRGB(1, (0, 0, 255))  # 蓝色 #95
                    self.s.setRGB(0, (0, 0, 255)) #96
                    self.velocity_publisher.publish(Velocity(x=15.0, y=0.0, yaw_rate=0.0))  # 前进 #97
                    self.get_logger().info('Moving forward') #98
        except Exception as e: #99
            self.get_logger().error(f'Error in sonar_callback: {str(e)}') #100

    def call_go_home_service(self): #102
        if not self.go_home_client.wait_for_service(timeout_sec=5.0): #103
            self.get_logger().error('Go home service not available') #104
            return #105
        request = Empty.Request() #106
        future = self.go_home_client.call_async(request) #107
        future.add_done_callback(self.go_home_callback) #108

    def go_home_callback(self, future): #110
        try: #111
            future.result() #112
            self.get_logger().info('Go home service called successfully') #113
        except Exception as e: #114
            self.get_logger().error(f'Go home service call failed: {str(e)}') #115

    def stop(self, *args): #117
        self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.0)) #118
        if hasattr(self, 's'): #119
            self.s.setRGB(1, (0, 0, 0)) #120
            self.s.setRGB(0, (0, 0, 0)) #121
        self.get_logger().info('Shutting down...') #122
        self.destroy_timer(self.timer) #123
        rclpy.shutdown() #124

def main(args=None): #126
    rclpy.init(args=args) #127
    node = SonarAvoidance() #128
    try: #129
        rclpy.spin(node) #130
    except KeyboardInterrupt: #131
        node.get_logger().info('Node interrupted by user') #132
    finally: #133
        node.stop() #134
        node.destroy_node() #135
        rclpy.shutdown() #136

if __name__ == '__main__': #138
    main() #139
