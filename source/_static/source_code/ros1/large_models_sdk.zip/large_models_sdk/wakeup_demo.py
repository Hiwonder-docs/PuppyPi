#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/11/27 #4
import os #5
import time #6
from speech import awake #7

port = '/dev/ttyUSB0' #9
kws = awake.WonderEchoPro(port) #10
# kws = awake.CircleMic(port) #11

try:  # If a fan is present, it's recommended to turn it off before detection to reduce interference(如果有风扇，检测前推荐关掉减少干扰) #13
    os.system('pinctrl FAN_PWM op dh') #14
except: #15
    pass #16

kws.start() # Start detection(开始检测) #18
print('start...') #19
while True: #20
    try: #21
        if kws.wakeup(): # Wake-up detected(检测到唤醒) #22
            print('hello hiwonder') #23
        time.sleep(0.02) #24
    except KeyboardInterrupt: #25
        kws.exit() # Cancel processing (关闭处理) #26
        try: #27
            os.system('pinctrl FAN_PWM a0') #28
        except: #29
            pass #30
        break #31

