#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/02/28 #4
import cv2 #5
from config import * #6
from speech import speech #7

client = speech.OpenAIAPI(llm_api_key, llm_base_url) #9

image = cv2.imread('./resources/pictures/hello_world.jpg') #11
print(client.vllm('Recognize text in images, do not answer anything else', image, prompt='', model='gpt-4o-mini')) #12
while True: #13
    try: #14
        cv2.imshow('image', image) #15
        key = cv2.waitKey(1) #16
        if key != -1: #17
            break #18
    except KeyboardInterrupt: #19
        cv2.destroyAllWindows() #20
        break #21
