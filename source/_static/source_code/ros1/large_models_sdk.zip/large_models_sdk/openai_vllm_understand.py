#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/02/28 #4
import cv2 #5
import base64 #6
from config import * #7
from speech import speech #8

client = speech.OpenAIAPI(llm_api_key, llm_base_url) #10

image = cv2.imread('./resources/pictures/test_image_understand.jpeg') #12

# _, buffer = cv2.imencode('.jpg', image) #14
# params = {"model": 'gpt-4o-mini', #15
          # "messages": [ #16
            # { #17
                # "role": "user", #18
                # "content": [ #19
                    # { #20
                        # "type": "text", #21
                        # "text": "Describe the image" #22
                    # }, #23
                    # { #24
                        # "type": "image_url", #25
                        # "image_url": { #26
                            # "url": 'data:image/jpeg;base64,' + base64.b64encode(buffer).decode('utf-8'), #27
                            # "detail": "high" #28
                        # } #29
                    # } #30
                # ] #31
            # }, #32
            # ], #33
          # "stream": True} #34
# stream = client.vllm_origin(params) #35
# for event in stream: #36
    # print(event.choices[0].delta.content) #37

print(client.vllm('Describe the image', image, prompt='', model='gpt-4o-mini')) #39
while True: #40
    try: #41
        cv2.imshow('image', image) #42
        key = cv2.waitKey(1) #43
        if key != -1: #44
            break #45
    except KeyboardInterrupt: #46
        cv2.destroyAllWindows() #47
        break #48
