import os #1
import dashscope #2
from openai import OpenAI #3

###Chinese #5
api_key = '' #6
base_url = 'https://dashscope.aliyuncs.com/compatible-mode/v1' #7
dashscope.api_key = api_key #8

###English #10
llm_api_key = ''  #11
llm_base_url = 'https://api.openai.com/v1' #12
os.environ["OPENAI_API_KEY"] = llm_api_key #13
vllm_api_key = '' #14
vllm_base_url = 'https://openrouter.ai/api/v1' #15
