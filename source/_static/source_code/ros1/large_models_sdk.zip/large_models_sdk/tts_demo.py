#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/02/28 #4
import os #5
from config import * #6
from speech import speech #7

speech.set_volume(80) #9
tts = speech.RealTimeTTS() #10
# tts = speech.RealTimeTTS(samplerate=16000, channels=1, device=0) #11

model = 'sambert-zhinan-v1' #13
# save_path = '' #14
# tts.tts('准备就绪', model=model, save_path=os.path.join(save_path, 'start_audio.wav'), play=True) #15
# tts.tts('我在', model=model, save_path=os.path.join(save_path, 'wakeup.wav'), play=True) #16
# tts.tts('我还在学习中', model=model, save_path=os.path.join(save_path, 'error.wav', play=True) #17
# tts.tts('小幻没有听清楚，请再说一遍', model=model, save_path=os.path.join(save_path, 'no_voice.wav', play=True) #18
# tts.tts('我记住了', model=model, save_path=os.path.join(save_path, 'record_finish.wav', play=True) #19
# tts.tts('开始追踪', model=model, save_path=os.path.join(save_path, 'start_track.wav', play=True) #20
# tts.tts('获取目标失败', model=model, save_path=os.path.join(save_path, 'track_fail.wav', play=True) #21
tts.tts('你好，请问有什么可以帮到您') #22
# 此处以sambert-zhiming-v1例，可按需更换模型名称。模型列表：https://help.aliyun.com/zh/model-studio/getting-started/models #23
# tts.tts('你好，请问有什么可以帮到您', model='cosyvoice-v1', voice='longcheng', block=True) #24
# tts.tts('你好，请问有什么可以帮到您', model='cosyvoice-v2', voice='longcheng_v2', block=True) #25
# tts.tts('你好，请问有什么可以帮到您', model='sambert-zhiming-v1', save_path='./resources/audio/tts_audio.wav', play=False) #26

