#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/02/28 #4
import cv2 #5
from config import * #6
from speech import speech #7

client = speech.OpenAIAPI(api_key, base_url) #9

image = cv2.imread('./resources/pictures/ocr.jpeg') #11
print(client.vllm('识别图中的文字', image, prompt='', model='qwen-vl-max-latest')) #12
while True: #13
    try: #14
        cv2.imshow('image', image) #15
        key = cv2.waitKey(1) #16
        if key != -1: #17
            break #18
    except KeyboardInterrupt: #19
        cv2.destroyAllWindows() #20
        break #21
