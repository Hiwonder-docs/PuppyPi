#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/02/28 #4
from config import * #5
from speech import speech #6

client = speech.OpenAIAPI(llm_api_key, llm_base_url) #8

# streaming #10
# params = {"model": 'gpt-4o-mini',  #11
          # "messages": [ #12
            # { #13
                # "role": "user", #14
                # "content": 'Write a 50-word article about changing life with technology' #15
            # }, #16
          # ], #17
          # "stream": True} #18
# stream = client.llm_origin(params) #19
# for event in stream: #20
    # print(event.choices[0].delta.content) #21

# web search #23
# params = {"model": 'gpt-4o-search-preview',  #24
          # "web_search_options": {},  #25
          # "messages": [ #26
            # { #27
                # "role": "user", #28
                # "content": 'What was a positive news story from today?' #29
            # }, #30
          # ], #31
          # } #32
# completion  = client.llm_origin(params) #33
# print(completion.choices[0].message.content) #34

print(client.llm('Write a 50-word article about changing life with technology', prompt='', model='gpt-4o-mini')) # https://platform.openai.com/docs/models #36
