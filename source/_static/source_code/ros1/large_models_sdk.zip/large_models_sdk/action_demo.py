#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/11/05 #4

def forward(): #6
    print('forward') #7

def back(): #9
    print('back') #10

def turn_left(): #12
    print('turn_left') #13

def turn_right(): #15
    print('turn_right') #16

def track(color): #18
    print(color) #19

