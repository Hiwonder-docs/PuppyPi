#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/03/05 #4
import os #5
import time #6
from config import * #7
from speech import awake #8
from speech import speech #9

wakeup_audio_path = './resources/audio/wakeup.wav' #11
start_audio_path = './resources/audio/start_audio.wav' #12
no_voice_audio_path = './resources/audio/no_voice.wav' #13

port = '/dev/ttyUSB0' #15
kws = awake.WonderEchoPro(port) #16
# kws = awake.CircleMic(port) #17

asr = speech.RealTimeASR() #19
tts = speech.RealTimeTTS() #20
client = speech.OpenAIAPI(api_key, base_url) #21

try: #23
    os.system('pinctrl FAN_PWM op dh') #24
except: #25
    pass #26

speech.set_volume(80) #28
speech.play_audio(start_audio_path) #29
print('start...') #30

def main(): #32
    kws.start() #33
    while True: #34
        try: #35
            if kws.wakeup(): # Wake word detected(检测到唤醒词) #36
                speech.play_audio(wakeup_audio_path)  # Play wake-up sound(唤醒播放) #37
                asr_result = asr.asr() # Start voice recognition(开启录音识别) #38
                print('asr_result:', asr_result) #39
                if asr_result: #40
                    # Send the recognition result to the agent for a response(将识别结果传给智能体让他来回答) #41
                    params = {"model": 'qwen-max',  #42
                      "messages": [ #43
                        { #44
                            "role": "user", #45
                            "content": asr_result #46
                        }, #47
                      ], #48
                      "extra_body": { #49
                      "enable_search": True #50
                      } #51
                    } #52
                    response = client.llm_origin(params).choices[0].message.content.strip() #53
                    print('llm response:', response) #54
                    tts.tts(response) #55
                else: #56
                    speech.play_audio(no_voice_audio_path) #57
            else: #58
                time.sleep(0.02) #59
        except KeyboardInterrupt: #60
            kws.exit()  #61
            try: #62
                os.system('pinctrl FAN_PWM a0') #63
            except: #64
                pass #65
            break #66
        except BaseException as e: #67
            print(e) #68

if __name__ == '__main__': #70
    main() #71
