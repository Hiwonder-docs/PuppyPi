#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2021/09/27 #3
# Author:hiwonder #4

import math #6
import time #7
import rospy #8
from threading import RLock, Timer #9
import numpy as np #10
from std_msgs.msg import Float32 #11
import geometry_msgs.msg as geo_msg #12
import sensor_msgs.msg as sensor_msg #13
from std_srvs.srv import SetBool, SetBoolRequest, SetBoolResponse #14
from std_srvs.srv import Empty, Trigger, TriggerRequest, TriggerResponse #15
from puppy_control.srv import SetInt64, SetInt64Request, SetInt64Response #16
from puppy_control.srv import SetFloat64List, SetFloat64ListRequest, SetFloat64ListResponse #17


ROS_NODE_NAME = 'lidar_app' #20

MAX_SCAN_ANGLE = 360 # 激光的扫描角度,去掉总是被遮挡的部分degree(the scanning angle of the laser, excluding the constantly obstructed part, in degrees) #22





def reset_value(): #28
    node.running_mode = 0 #29
    node.threshold = 0.3 #30
    node.speed = 0.12 #31
    node.scan_angle = math.radians(90) #32

    try: #34
        if node.lidar_sub is not None: #35
            node.lidar_sub.unregister() #36
    except Exception as e: #37
        rospy.logerr(str(e)) #38

def enter_func(msg): #40
    rospy.loginfo("lidar enter") #41
    reset_value() #42
    # start_scan() #43
    rospy.ServiceProxy('/puppy_control/go_home', Empty)() #44
    node.lidar_sub = rospy.Subscriber('/scan', sensor_msg.LaserScan, node.lidar_callback)  #45
    return TriggerResponse(success=True) #46

heartbeat_timer = None #48
def exit_func(msg): #49
    global heartbeat_timer #50
    rospy.loginfo('lidar exit') #51
    reset_value() #52
    heartbeat_timer.cancel() #53
    return TriggerResponse(success=True) #54

def heartbeat_srv_cb(msg): #56
    global heartbeat_timer #57
    
    if isinstance(heartbeat_timer, Timer): #59
        heartbeat_timer.cancel() #60
    if msg.data: #61
        heartbeat_timer = Timer(5, rospy.ServiceProxy('/%s/exit'%ROS_NODE_NAME, Trigger)) #62
        heartbeat_timer.start() #63
    rsp = SetBoolResponse() #64
    rsp.success = msg.data #65

    return rsp #67

class LidarController: #69
    def __init__(self, name): #70
        rospy.init_node(name, anonymous=True,log_level=rospy.DEBUG) #71
        # rospy.on_shutdown(self.cleanup) #72
        self.name = name #73
        self.running_mode = 0 # 1：雷达避障模式  2：雷达警卫模式，(1: Radar obstacle avoidance mode 2: Radar guard mode) #74
        self.threshold = 0.3 # meters  距离阈值(distance threshold) #75
        self.scan_angle = math.radians(90)  # radians  向前的扫描角度(the forward scanning angle) #76
        self.speed = 0.12 # 单位米，避障模式的速度(the speed in meters per second for obstacle avoidance mode) #77
        self.last_act = 0 #78
        self.timestamp = 0 #79
        self.lock = RLock() #80
        self.lidar_sub = None #81
        self.velocity_pub = rospy.Publisher('/cmd_vel_nav', geo_msg.Twist, queue_size=1) #82
        self.velocity_pub.publish(geo_msg.Twist()) #83
        # self.lidar_sub = rospy.Subscriber('/scan', sensor_msg.LaserScan, self.lidar_callback)  #84

    def lidar_callback(self, lidar_data:sensor_msg.LaserScan): #86
        ranges = list(lidar_data.ranges) #87
        ranges = list(9999 if r < 0.05 else r for r in ranges) # 小于5cm当作无限远(treat distances less than 5cm as infinity) #88
        twist = geo_msg.Twist() #89

        with self.lock: #91
            min_index = np.nanargmin(np.array(ranges)) # 找出距离最小值(find out the minimum value of distance) #92
            dist = ranges[min_index] #93
            angle = lidar_data.angle_min + lidar_data.angle_increment * min_index # 计算最小值对应的角度(calculate the angle corresponding to the minimum value) #94
            #雷达朝狗的正前方为0度，然后逆时针旋转角度递增，直到360度(与0度重合)(the radar facing directly towards the dog is at 0 degrees, and then the angle increases in a counterclockwise direction until reaching 360 degrees (coinciding with 0 degrees again)) #95
            angle = angle if angle < math.pi else angle - math.pi*2  #96
            #将0~360处理成：狗的左边为0~正180度，右边为0~负180度(transforming 0 to 360 degrees: 0 to positive 180 degrees represents the left side of the dog, while 0 to negative 180 degrees represents the right side) #97
            
            #避障(obstacle avoidance) #99
            if self.running_mode == 1 and self.timestamp <= time.time(): #100
                if abs(angle) < self.scan_angle/2 and dist < self.threshold: #101
                    twist.linear.x = self.speed / 6 #102
                    twist.angular.z = self.speed * 3 * -np.sign(angle) #103
                    self.timestamp = time.time() + 0.8 #104

                else: #106
                    twist.linear.x = self.speed #107
                    twist.angular.z = 0 #108
                self.velocity_pub.publish(twist) #109
 
            # 追踪(tracking) #111
            elif self.running_mode == 2 and self.timestamp <= time.time(): #112

                if abs(angle) < self.scan_angle/2: #114
                    if dist < self.threshold and abs(math.degrees(angle)) > 10: # 控制左右(control the left and the right) #115
                        twist.linear.x = 0.01 # x方向的校正(correction in the x-direction) #116
                        twist.angular.z = self.speed * 3 * np.sign(angle) #117
                        self.timestamp = time.time() + 0.4 #118
                    else: #119
                        if dist < self.threshold and dist > 0.35: #120
                            twist.linear.x = self.speed #121
                            twist.angular.z = 0 #122
                            self.timestamp = time.time() + 0.4 #123
                        else: #124
                            twist.linear.x = 0 #125
                            twist.angular.z = 0 #126
                else: #127
                    twist.linear.x = 0 #128
                    twist.angular.z = 0 #129
                self.velocity_pub.publish(twist) #130
            
            # 警卫看守(guard duty) #132
            elif self.running_mode == 3 and self.timestamp <= time.time(): #133

                if dist < self.threshold and abs(math.degrees(angle)) > 10 : #135
                    #and abs(angle) < self.scan_angle/2: # 控制左右(control the left and the right) #136
                    twist.linear.x = 0.01 # x方向的校正(correction in the x-direction) #137
                    twist.angular.z = self.speed * 3 * np.sign(angle) #138
                    self.timestamp = time.time() + 0.4 #139
                else: #140
                    twist.linear.x = 0 #141
                    twist.angular.z = 0 #142
                self.velocity_pub.publish(twist) #143


# 设置运行模式(set the running mode) #146
def set_running_srv_callback(req: SetInt64Request): #147
    rsp =SetInt64Response(success=True) #148
    new_running_mode = req.data #149
    rospy.loginfo("set_running " + str(new_running_mode)) #150
    if not 0 <= new_running_mode <= 3: #151
        rsp.success = False #152
        rsp.message = "Invalid running mode {}".format(new_running_mode) #153
    else: #154
        # with self.lock: #155
        node.running_mode = new_running_mode #156
        # if node.running_mode == 0: #157
        #     node.jethexa.traveling(gait=-2) #158
    node.velocity_pub.publish(geo_msg.Twist()) #159
    return rsp #160

# 设置运行参数(set the running parameter) #162
def set_parameters_srv_callback(req: SetFloat64ListRequest): #163
    rsp = SetFloat64ListResponse(success=True) #164
    new_parameters = req.data #165
    new_threshold, new_scan_angle, new_speed = new_parameters #166
    rospy.loginfo("n_t:{:2f}, n_a:{:2f}, n_s:{:2f}".format(new_threshold, new_scan_angle, new_speed)) #167
    if not 0.3 <= new_threshold <= 1.5: #168
        rsp.success = False #169
        rsp.message = "New threshold ({:.2f}) is out of range (0.3 ~ 1.5)".format(new_threshold) #170
        return rsp #171
    """ #172
    if not 0 <= new_scan_angle <= 90: #173
        rsp.success = False #174
        rsp.message = "New scan angle ({:.2f}) is out of range (0 ~ 90)" #175
        return rsp #176
    """ #177
    if not new_speed > 0: #178
        rsp.success = False #179
        rsp.message = "Invalid speed" #180
        return rsp #181

    # with self.lock: #183
    node.threshold = new_threshold #184
    #self.scan_angle = math.radians(new_scan_angle) #185
    node.speed = new_speed * 0.002  #186
    
    return rsp #188
    
if __name__ == "__main__": #190
    node = LidarController(ROS_NODE_NAME) #191

    enter_srv = rospy.Service('/%s/enter'%ROS_NODE_NAME, Trigger, enter_func) #193
    exit_srv = rospy.Service('/%s/exit'%ROS_NODE_NAME, Trigger, exit_func) #194
    heartbeat_srv = rospy.Service('/%s/heartbeat'%ROS_NODE_NAME, SetBool, heartbeat_srv_cb) #195

    set_running_srv = rospy.Service("/%s/set_running"%ROS_NODE_NAME, SetInt64, set_running_srv_callback) #197
    set_parameters_srv = rospy.Service("/%s/set_parameters"%ROS_NODE_NAME, SetFloat64List, set_parameters_srv_callback) #198

    try: #200
        rospy.spin() #201
    except Exception as e: #202
        rospy.logerr(str(e)) #203

