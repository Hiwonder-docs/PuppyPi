#!/home/pi/venv/bin/python3 #1
# coding=utf8 #2

import sys #4
import cv2 #5
import math #6
import time #7
import rospy #8
from enum import Enum #9
import threading #10
import numpy as np #11
from arm_kinematics.ArmMoveIK import ArmIK #12
from common import Misc #13
from common import PID #14
from std_msgs.msg import Header #15
from sensor_msgs.msg import Image #16
from puppy_control.msg import Velocity, Pose, Gait,SetServo #17

from std_srvs.srv import * #19
from actionlib_msgs.msg import GoalStatusArray #20

from puppy_control.srv import SetRunActionName #22


sys.path.append('/home/ubuntu/software/puppypi_control/') #25
from servo_controller import setServoPulse #26

def cv2_image2ros(image, frame_id=''): #28
    image = image[:,:,::-1] #29
    ros_image = Image() #30
    header = Header(stamp=rospy.Time.now()) #31
    header.frame_id = frame_id #32
    ros_image.height = image.shape[:2][0] #33
    ros_image.width = image.shape[:2][1] #34
    ros_image.encoding = 'rgb8' #35
    ros_image.data = image.tostring() #36
    ros_image.header = header #37
    ros_image.step = ros_image.width * 3 #38

    return ros_image #40

# 找出面积最大的轮廓(find out the contour with the maximal area) #42
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #43
def getAreaMaxContour(contours): #44
    contour_area_temp = 0 #45
    contour_area_max = 0 #46
    area_max_contour = None #47

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #49
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #50
        if contour_area_temp > contour_area_max: #51
            contour_area_max = contour_area_temp #52
            if contour_area_temp >= 5:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than 300, the contour with the maximal area is valid to filter the interference) #53
                area_max_contour = c #54

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #56

Bend = {'roll':math.radians(0), 'pitch':math.radians(-17), 'yaw':0.000, 'height':-10, 'x_shift':0.5, 'stance_x':0, 'stance_y':0} #58
Stand = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-1, 'stance_x':0, 'stance_y':0} #59
GaitConfig = {'overlap_time':0.15, 'swing_time':0.15, 'clearance_time':0.0, 'z_clearance':3} #60
PuppyPose = Bend.copy() #61
PuppyMove = {'x':0, 'y':0, 'yaw_rate':0} #62

target_color = 'red' #64
nav_status = False   #65
is_running = False       #66
image = None         #67
block_center_point = (0,0) # 物块中心点坐标(block center point coordinates) #68

AK = ArmIK() #70

class PuppyStatus(Enum): #72
    START = 0 #73
    NORMAL = 1 # 正常前进中(moving forward normally) #74
    FOUND_TARGET = 2 # 已经发现目标物块(the target block has been found) #75
    PLACE = 3 # 已经发现目标物块(the target block has been found) #76
    STOP = 4 #77
    END = 5 #78

puppyStatus = PuppyStatus.START #80

size = (320, 240)     #82
img_centerx = 320 # 理论值是640/2 = 320具体值需要根据不同机器的实际运行情况微调一下(the theoretical value is 640/2 = 320. The specific value needs to be fine-tuned based on the actual operating conditions of different machines) #83

def move(): #85
    global block_center_point #86
    global PuppyPose,PuppyPosePub #87
    global puppyStatus #88
    while not rospy.is_shutdown(): #89
        if puppyStatus == PuppyStatus.START: #90
            
            PuppyPose = Bend.copy() #92
            PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #93
                    ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #94
            PuppyGaitConfigPub.publish(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #95
                    , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']) #96
            time.sleep(1) #97
            puppyStatus = PuppyStatus.NORMAL #98
        elif puppyStatus == PuppyStatus.NORMAL: #99
            if block_center_point[1] > 270  and abs(block_center_point[0] - img_centerx) < 70: # 已经发现目标物块,只有物块在线上才满足(target object detected; it is considered valid only if the object is on the line) #100
                
                rospy.ServiceProxy('/puppy_control/go_home', Empty)() #102
                time.sleep(0.1) #103
                runActionGroup_srv('place.d6a',True) # 执行动作组(perform action group) #104
                puppyStatus = PuppyStatus.STOP #105
            else: #106
                value = block_center_point[0] - img_centerx #107
                if block_center_point[1] <= 250: #108
                    PuppyMove['x'] = 10 #109
                    PuppyMove['yaw_rate'] = math.radians(0) #110
                elif abs(value) > 80: #111
                    PuppyMove['x'] = 5 #112
                    PuppyMove['yaw_rate'] = math.radians(-11 * np.sign(value)) #113
                elif abs(value) > 50: #114
                    PuppyMove['x'] = 5 #115
                    PuppyMove['yaw_rate'] = math.radians(-5 * np.sign(value)) #116
                elif block_center_point[1] <= 270: #117
                    PuppyMove['x'] = 8 #118
                    PuppyMove['yaw_rate'] = math.radians(0)     #119
                PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #120
        elif puppyStatus == PuppyStatus.STOP: #121
            AK.setPitchRangeMoving((8.51,0,3.3),500) #122
            time.sleep(0.5) #123
            PuppyPose = Stand.copy() #124
            PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #125
                    ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #126
            time.sleep(0.5) #127
th1 = threading.Thread(target=move,daemon=True) #128

def run(): #130
    global image #131
    global block_center_point #132

    while not rospy.is_shutdown(): #134
        if image is not None: #135
            img_copy = image.copy() #136
            img_h, img_w = image.shape[:2] #137
            frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #138
            frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)   #139
            bgr_image = cv2.cvtColor(frame_gb, cv2.COLOR_RGB2BGR)  #140
            frame_lab_all = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #141
            max_area = 0 #142
            areaMaxContour_max = 0 #143
            frame_mask = cv2.inRange(frame_lab_all, #144
                                            (color_range_list[target_color]['min'][0], #145
                                            color_range_list[target_color]['min'][1], #146
                                            color_range_list[target_color]['min'][2]), #147
                                            (color_range_list[target_color]['max'][0], #148
                                            color_range_list[target_color]['max'][1], #149
                                            color_range_list[target_color]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #150
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #151
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #152
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out contour) #153
            areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #154
            if areaMaxContour is not None: #155
                if area_max > max_area:#找最大面积(find the maximal area) #156
                    max_area = area_max #157
                    areaMaxContour_max = areaMaxContour #158
            if max_area > 200: #159
                ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max)  # 获取最小外接圆(obtain minimum circumcircle) #160
                centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #161
                centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #162
                radius = int(Misc.map(radius, 0, size[0], 0, img_w))   #163
                block_center_point = (centerX,centerY) #164
                #print(block_center_point) #165
                cv2.circle(bgr_image, (centerX, centerY), radius, (0,255,255), 2)#画圆(draw circle) #166
            result_publisher.publish(cv2_image2ros(cv2.resize(bgr_image, (640, 480)), 'navigation_status_listener')) #167

th = threading.Thread(target=run,daemon=True)      #169

def image_callback(ros_image): #171
    global image #172

    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, buffer=ros_image.data) # 原始 RGB 画面(original RGB image) #174

def goal_status_callback(msg): #176
    global nav_status #177
    
    if len(msg.status_list) > 0: #179
        status = msg.status_list[0].status #180
        if status == 3:  # 3表示目标已经到达(3 means the target has arrived) #181
            if not nav_status: #182
                rospy.loginfo("target")  #183
                th.start() #184
                th1.start() #185
            nav_status = True #186

if __name__ == '__main__': #188
   
    rospy.init_node('navigation_status_listener') #190
    color_range_list = rospy.get_param('/lab_config_manager/color_range_list', {}) #191
    PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #192
    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #193
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #194
    runActionGroup_srv = rospy.ServiceProxy('/puppy_control/runActionGroup', SetRunActionName) #195
    rospy.Subscriber('/move_base/status', GoalStatusArray, goal_status_callback) #196
    rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #197
    result_publisher = rospy.Publisher('~image_result', Image, queue_size=1)  # 图像处理结果发布,# 使用~可以自动加上前缀名称(image processing result published. use "~" to automatically add the prefix name) #198
    time.sleep(0.3) #199
    PuppyPose = Stand.copy() #200
    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #201
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #202
    time.sleep(0.5) #203
    
    AK.setPitchRangeMoving((8.51,0,3.3),500) #205
    time.sleep(0.5) #206
    Debug = False #207
    if Debug: #208
        time.sleep(0.5) #209
        th.start() #210
        th1.start() #211
       
    rospy.spin() #213

