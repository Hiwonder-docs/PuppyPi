#!/usr/bin/python3 #1
# coding=utf8 #2
# 第11章 ROS机器狗结合机械臂课程\第4课 自主识别夹取(11.ROS Robot Combine Robotic Arm Course\Lesson 4 Auto Recognition Gripping) #3
import sys #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9
from enum import Enum #10
from arm_kinematics.ArmMoveIK import ArmIK #11
from common import Misc #12
from common import Camera #13
from common import yaml_handle #14

import gpiod #16


sys.path.append('/home/ubuntu/software/puppypi_control/')  #19
from servo_controller import setServoPulse #20
from action_group_control import runActionGroup, stopActionGroup #21
from HiwonderPuppy import HiwonderPuppy, PWMServoParams #22

puppy = HiwonderPuppy(setServoPulse = setServoPulse, servoParams = PWMServoParams(), dof = '8') #24

Stand = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-1, 'stance_x':0, 'stance_y':0} #26
Bend = {'roll':math.radians(0), 'pitch':math.radians(-17), 'yaw':0.000, 'height':-10, 'x_shift':0.5, 'stance_x':0, 'stance_y':0} #27

PuppyPose = Stand.copy() #29
# stance_x：4条腿在x轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the X-axis, measured in centimeters) #30
# stance_y：4条腿在y轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the Y-axis, measured in centimeters) #31
# x_shift: 4条腿在x轴上同向移动的距离，越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡，单位cm(the distance traveled by the four legs along the x-axis determines the degree of forward or backward tilt during walking: smaller distances lead to more forward tilt, while larger distances result in more backward tilt. Adjusting the x_shift parameter can help maintain balance during the dog's movement, measured in centimeters) #32
# height： 狗的高度，脚尖到大腿转动轴的垂直距离，单位cm(the height of the dog, measured from the toe to the axis  of rotation of the thigh, is in centimeters) #33
# pitch： 狗身体的俯仰角，单位弧度(the pitch angle of the dog's body, measured in radians) #34


GaitConfig = {'overlap_time':0.15, 'swing_time':0.15, 'clearance_time':0.0, 'z_clearance':3} #37
# GaitConfig = GaitConfigFast.copy() #38
# overlap_time:4脚全部着地的时间，单位秒(the time when all four legs touch the ground, measured in seconds) #39
# swing_time：2脚离地时间，单位秒(the time duration when legs are off the ground, measured in second) #40
# clearance_time：前后脚间隔时间，单位秒(the time interval between the front and rear legs, measured in seconds) #41
# z_clearance：走路时，脚抬高的距离，单位cm(the distance the paw needs to be raised during walking, measured in centimeters) #42

PuppyMove = {'x':0, 'y':0, 'yaw_rate':0} #44
# x:直行控制，  前进方向为正方向，单位cm/s(straightforward control, with the forward direction as the positive direction, measured in centimeters per second) #45
# y:侧移控制，左侧方向为正方向，单位cm/s，目前无此功能(lateral movement control, with the left direction as the positive direction, measured in cm/s. currently, this function is not available) #46
# yaw_rate：转弯控制，逆时针方向为正方向，单位rad/s(turning control, with counterclockwise direction as the positive direction, measured in rad/s) #47


if sys.version_info.major == 2: #50
    print('Please run this program with python3!') #51
    sys.exit(0) #52

key1_pin = 25 # KEY1短按启动程序(KEY1 short press to start the program) #54
key2_pin = 23 # KEY2短按停止程序(KEY2 short press to stop the program) #55
chip = gpiod.chip("gpiochip0") #56

key1 = chip.get_line(key1_pin) #58
config = gpiod.line_request() #59
config.consumer = "key1" #60
config.request_type = gpiod.line_request.DIRECTION_INPUT #61
config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #62
key1.request(config) #63

key2 = chip.get_line(key2_pin) #65
config = gpiod.line_request() #66
config.consumer = "key2" #67
config.request_type = gpiod.line_request.DIRECTION_INPUT #68
config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #69
key2.request(config) #70

block_color = 'None' #72
block_center_point = (0,0) # 物块中心点坐标(block center point coordinates) #73
AK = ArmIK() #74
color_list = [] #75

class PuppyStatus(Enum): #77
    START = 0 #78
    NORMAL = 1 # 正常前进中(moving forward normally) #79
    FOUND_TARGET = 3 # 已经发现目标物块(target block detected) #80
    PLACE = 4 # 已经发现目标物块(target block has been found) #81
    STOP = 10 #82
    END = 20             #83

puppyStatus = PuppyStatus.STOP #85
puppyStatusLast = PuppyStatus.END #86


line_centerx = -1 # 线条中心坐标位置(line center coordinate position) #89
img_centerx = 320 # 理论值是640/2 = 320具体值需要根据不同机器的实际运行情况微调一下(the theoretical value is 640/2 = 320. The specific value needs to be fine-tuned based on the actual operation of different machines) #90
def move(): #91
    global line_centerx, puppyStatus, puppyStatusLast, block_center_point #92
    global block_color #93

    while True: #95
        while(puppyStatus == PuppyStatus.START) :  # 启动阶段，初始化姿态(startup stage, initialize the posture) #96
            
            puppy.move_stop(servo_run_time = 500) #98
            PuppyPose = Bend.copy() #99
            puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #100
            time.sleep(0.5) #101
            
            puppyStatus = PuppyStatus.NORMAL #103
            break #104

        while(puppyStatus == PuppyStatus.NORMAL) : #  #106
            
            if block_center_point[1] > 355 and block_center_point[1] < 370 and block_color == 'red' and abs(block_center_point[0] - img_centerx) < 50: # 已经发现目标物块,只有物块在线上才满足(target object has been found, it is considered valid only when the block is on the line) #108
                puppyStatus = PuppyStatus.FOUND_TARGET #109
                puppy.move_stop(servo_run_time = 500) #110
                time.sleep(0.5) #111
                break #112
            value = block_center_point[0] - img_centerx #113
            if block_center_point[1] <= 300: #114
                PuppyMove['x'] = 10 #115
                PuppyMove['yaw_rate'] = math.radians(0) #116
            elif abs(value) > 80: #117
                PuppyMove['x'] = 5 #118
                PuppyMove['yaw_rate'] = math.radians(-11 * np.sign(value)) #119
            elif abs(value) > 50: #120
                PuppyMove['x'] = 5 #121
                PuppyMove['yaw_rate'] = math.radians(-5 * np.sign(value)) #122
            elif block_center_point[1] <= 355: #123
                PuppyMove['x'] = 8 #124
                PuppyMove['yaw_rate'] = math.radians(0) #125
            elif block_center_point[1] >= 370: #126
                PuppyMove['x'] = -5 #127
                PuppyMove['yaw_rate'] = math.radians(0) #128
            puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #129
            break #130

        while(puppyStatus == PuppyStatus.FOUND_TARGET) : # 发现物块(find the block) #132
            
            runActionGroup('grab.d6a',True) # 执行动作组(perform action group) #134
            PuppyPose = Stand.copy() #135
            puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']+1), PuppyPose['pitch'], PuppyPose['roll']) #136
            time.sleep(0.5) #137

            PuppyMove['x'] = 10 #139
            PuppyMove['yaw_rate'] = math.radians(0) #140
            puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #141
            time.sleep(1) #142

            PuppyMove['x'] = 5 #144
            PuppyMove['yaw_rate'] = math.radians(20) #145
            puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #146
            time.sleep(3) #147

            puppy.move_stop(servo_run_time = 500) #149
            time.sleep(0.5) #150
            PuppyPose = Bend.copy() #151
            puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #152
            time.sleep(0.5) #153
            puppyStatus = PuppyStatus.PLACE #154
            break #155

        while(puppyStatus == PuppyStatus.PLACE) : # 放置物块(place block) #157
            
            if block_center_point[1] > 270  and block_color == 'red' and abs(block_center_point[0] - img_centerx) < 70: # 已经发现目标物块,只有物块在线上才满足(target object detected; it is considered valid only when the block is on the line) #159
                
                puppy.move_stop(servo_run_time = 100) #161
                time.sleep(0.1) #162
                runActionGroup('place.d6a',True) # 执行动作组(perform action group) #163
                puppyStatus = PuppyStatus.STOP #164
                break #165
            value = block_center_point[0] - img_centerx #166
            if block_center_point[1] <= 230: #167
                PuppyMove['x'] = 10 #168
                PuppyMove['yaw_rate'] = math.radians(0) #169
            elif abs(value) > 80: #170
                PuppyMove['x'] = 5 #171
                PuppyMove['yaw_rate'] = math.radians(-11 * np.sign(value)) #172
            elif abs(value) > 50: #173
                PuppyMove['x'] = 5 #174
                PuppyMove['yaw_rate'] = math.radians(-5 * np.sign(value)) #175
            elif block_center_point[1] <= 270: #176
                PuppyMove['x'] = 8 #177
                PuppyMove['yaw_rate'] = math.radians(0) #178
            
            puppy.move(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #180
            break #181
                
            

        while(puppyStatus == PuppyStatus.STOP) : #185
            puppy.move_stop(servo_run_time = 500) #186
            PuppyPose = Stand.copy() #187
            puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #188
            time.sleep(0.5) #189
            break #190
        

        time.sleep(0.02) #193

        if puppyStatusLast != puppyStatus: #195
            print('puppyStatus',puppyStatus) #196
        puppyStatusLast = puppyStatus #197
# 运行子线程(run sub-thread) #198
th = threading.Thread(target=move) #199
th.setDaemon(True) #200




size = (640, 480) #205

lab_data = None #207

def load_config(): #209
    global lab_data #210
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path)['color_range_list'] #211

load_config() #213

# 找出面积最大的轮廓(find out the contour with the maximal area) #215
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #216
def getAreaMaxContour(contours): #217
    contour_area_temp = 0 #218
    contour_area_max = 0 #219
    area_max_contour = None #220

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #222
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate the contour area) #223
        if contour_area_temp > contour_area_max: #224
            contour_area_max = contour_area_temp #225
            if contour_area_temp >= 5:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than 300, the contour with the maximal area is valid to filter the interference) #226
                area_max_contour = c #227

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #229

def run(img): #231
    
    global puppyStatus, block_center_point #233
    global block_color #234
    global color_list #235
    global Debug #236
    
    img_copy = img.copy() #238
    img_h, img_w = img.shape[:2] #239
    
    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #241
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #242
                       
    frame_lab_all = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #244
    max_area = 0 #245
    color_area_max = None     #246
    areaMaxContour_max = 0 #247

    for i in lab_data: #249
        if i in ['red']: #250
            frame_mask = cv2.inRange(frame_lab_all, #251
                                            (lab_data[i]['min'][0], #252
                                            lab_data[i]['min'][1], #253
                                            lab_data[i]['min'][2]), #254
                                            (lab_data[i]['max'][0], #255
                                            lab_data[i]['max'][1], #256
                                            lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #257
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #258
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #259
            
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out the contour) #261
            areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #262
            if areaMaxContour is not None: #263
                if area_max > max_area:#找最大面积(find the maximal area) #264
                    max_area = area_max #265
                    color_area_max = i #266
                    areaMaxContour_max = areaMaxContour #267
    if max_area > 200:  # 有找到最大面积(the maximal area is found) #268
        ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max)  # 获取最小外接圆(get the minimum circumcircle) #269
        centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #270
        centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #271
        radius = int(Misc.map(radius, 0, size[0], 0, img_w))   #272
        block_center_point = (centerX,centerY)    #273
        
        if Debug: #275
            print("block_center_x",block_center_point[0])    #276
            print("block_center_y",block_center_point[1])      #277
        cv2.circle(img, (centerX, centerY), radius, (0,255,255), 2)#画圆(draw circle) #278
        
        if color_area_max == 'red':  #红色最大(red is the maximal area) #280
            color = 1 #281
        elif color_area_max == 'green':  #绿色最大(green is the maximal area) #282
            color = 2 #283
        elif color_area_max == 'blue':  #蓝色最大(blue is the maximal area) #284
            color = 3 #285
        else: #286
            color = 0 #287
        color_list.append(color) #288

        if len(color_list) == 3:  #多次判断(multiple judgements) #290
            # 取平均值(take average value) #291
            color = int(round(np.mean(np.array(color_list)))) #292
            color_list = [] #293
            if color == 1: #294
                block_color = 'red' #295
                
            elif color == 2: #297
                block_color = 'green' #298
                
            elif color == 3: #300
                block_color = 'blue' #301
                
            else: #303
                block_color = 'None' #304
                
    else: #306
        block_color = 'None' #307

    return img #309

def stance(x = 0, y = 0, z = -11, x_shift = 2):# 单位cm(unit: cm) #311
    # x_shift越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡(the smaller the x_shift, the more forward-leaning the walk; the larger, the more backward-leaning. Adjusting x_shift can balance the robot dog's gait) #312
    return np.array([ #313
                        [x + x_shift, x + x_shift, -x + x_shift, -x + x_shift], #314
                        [y, y, y, y], #315
                        [z, z, z, z], #316
                    ])#此array的组合方式不要去改变(please refrain from altering the combination of this array) #317

if __name__ == '__main__': #319

    puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #321
    puppy.gait_config(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #322
                            , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']) #323
    # overlap_time:4脚全部着地的时间，swing_time：2脚离地时间，z_clearance：走路时，脚抬高的距离(overlap_time: The time when all four feet touch the ground, swing_time: The time when two feet are off the ground, z_clearance: The height at which the feet are lifted during walking) #324

    puppy.start() # 启动(start) #326
    puppy.move_stop(servo_run_time = 500) #327

    AK.setPitchRangeMoving((8.51,0,3.3),500) #329
    setServoPulse(9,1500,500) #330
    time.sleep(0.5) #331
    
    
    Debug = False #334
    
    if Debug: #336
        PuppyPose = Bend.copy() #337
        puppy.stance_config(stance(PuppyPose['stance_x'],PuppyPose['stance_y'],PuppyPose['height'],PuppyPose['x_shift']), PuppyPose['pitch'], PuppyPose['roll']) #338
        time.sleep(0.5) #339
        
    else: #341
        th.start()  #342
    #   开启机器狗移动线程(start the moving thread of robot dog) #343
    #   如果只是想看摄像头画面，调试画面，不想让机器人移动，可以把Debug设置为True，同时不要去按按钮(if you only want to view the camera feed and debug the image without moving the robot, you can set Debug to True, and avoid pressing any buttons) #344
    #   等调试完再把Debug设置为False，观察实际运行情况(once debugging is complete, set Debug to False, and observe the actual operation) #345

    my_camera = Camera.Camera() #347
    my_camera.camera_open() #348
    
    while True: #350
        img = my_camera.frame #351
        if img is not None: #352
            frame = img.copy() #353
            Frame = run(frame)            #354
            cv2.imshow('Frame', Frame) #355
            key = cv2.waitKey(1) #356
            if key == 27: #357
                break #358
        else: #359
            time.sleep(0.01) #360

        if key1.get_value() == 0: #362
            time.sleep(0.05) #363
            if key1.get_value() == 0: #364
                puppyStatus = PuppyStatus.START #365
        if key2.get_value() == 0: #366
            time.sleep(0.05) #367
            if key2.get_value() == 0: #368
                puppyStatus = PuppyStatus.STOP #369
                stopActionGroup() #370
    my_camera.camera_close() #371
    cv2.destroyAllWindows() #372

