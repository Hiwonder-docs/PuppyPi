#!/usr/bin/python3 #1
# coding=utf8 #2
# 第11章 ROS机器狗结合机械臂课程\第3课 颜色识别夹取(11.ROS Robot Combine Robotic Arm Course\Lesson 3 Color Recognition Gripping) #3
import sys #4
import cv2 #5
import math #6
import rospy #7
import time #8
import threading #9
import numpy as np #10
from threading import RLock, Timer #11
from ros_robot_controller.msg import BuzzerState #12
from std_srvs.srv import * #13
from std_msgs.msg import Float32,Header #14
from sensor_msgs.msg import Image #15
from puppy_control.srv import SetRunActionName #16
from common import Misc #17


ROS_NODE_NAME = 'color_detect_with_arm' #20

sys.path.append('/home/ubuntu/software/puppypi_control/') #22
from servo_controller import setServoPulse #23

color_range_list = {} #25
detect_color = 'None' #26
color_list = [] #27

action_finish = True #29


range_rgb = { #32
    'red': (0, 0, 255), #33
    'blue': (255, 0, 0), #34
    'green': (0, 255, 0), #35
    'black': (0, 0, 0), #36
    'yellow': (0, 255, 255), #37
    'white': (255, 255, 255), #38
} #39
draw_color = range_rgb["yellow"] #40

# 找出面积最大的轮廓(find out the contour with the maximal area) #42
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #43
def getAreaMaxContour(contours): #44
    contour_area_temp = 0 #45
    contour_area_max = 0 #46
    area_max_contour = None #47

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #49
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate the contour area) #50
        if contour_area_temp > contour_area_max: #51
            contour_area_max = contour_area_temp #52
            if contour_area_temp > 50:  # 只有在面积大于50时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than 50, the contour with the maximal area is valid to filter the interference) #53
                area_max_contour = c #54

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #56

# 初始位置(initial position) #58
def initMove(): #59
    runActionGroup_srv('look_down.d6a',True) #60
    
target_color = 'red' #62
def move(): #63
    global action_finish  #64
    global draw_color #65
    global detect_color #66
    global target_color #67
    
    while not rospy.is_shutdown(): #69
            
        if detect_color == target_color: #71
            msg = BuzzerState() #72
            msg.freq = 1900 #73
            msg.on_time = 0.1 #74
            msg.off_time = 0.9 #75
            msg.repeat = 1 #76
            buzzer_pub.publish(msg) #77
            action_finish = False #78
            rospy.sleep(0.8) #79
            runActionGroup_srv('grab.d6a', True) #80
            rospy.sleep(0.5) #81
            setServoPulse(9,1200,300) #82
            rospy.sleep(0.3) #83
            setServoPulse(9,1500,300) #84
            runActionGroup_srv('look_down.d6a', True) #85
                                
            rospy.sleep(0.8) #87
            detect_color = 'None' #88
            draw_color = range_rgb["yellow"] #89
        action_finish = True                 #90
        rospy.sleep(0.01)   #91
        
    runActionGroup_srv('stand_with_arm.d6a', True)  #93
    
  # 运行子线程(run sub-thread) #95
th = threading.Thread(target=move,daemon=True) #96
th.start()       #97
        

def run(img): #100
    global draw_color #101
    global color_list #102
    global detect_color #103
    global action_finish  #104
    global target_color #105
    
    size = (320, 240) #107

    img_copy = img.copy() #109
    img_h, img_w = img.shape[:2] #110

    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #112
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)       #113
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #114

    max_area = 0 #116
    color_area_max = None     #117
    areaMaxContour_max = 0 #118
    
    if action_finish: #120

        for i in color_range_list: #122
            if i in ['red', 'green', 'blue']: #123
                frame_mask = cv2.inRange(frame_lab, #124
                                                (color_range_list[i]['min'][0], #125
                                                color_range_list[i]['min'][1], #126
                                                color_range_list[i]['min'][2]), #127
                                                (color_range_list[i]['max'][0], #128
                                                color_range_list[i]['max'][1], #129
                                                color_range_list[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #130
                eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #131
                dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #132
                dilated[0:120,:] = 0 #133
                dilated[:,0:80] = 0 #134
                dilated[:,240:320] = 0 #135
                # cv2.imshow(i, dilated) #136
                contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out the contour) #137
                areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #138
                
                if areaMaxContour is not None: #140
                    if area_max > max_area:#找最大面积(find out the maximal area) #141
                        max_area = area_max #142
                        #print(max_area) #143
                        color_area_max = i #144
                        areaMaxContour_max = areaMaxContour #145
        if max_area > 4000:  # 有找到最大面积,面积取大一点，确保色块放入方块里的面积足够大(the largest ares has been found, to ensure that the color block fits well into the square, use a larger area) #146
            
            ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max)  # 获取最小外接圆(get the minimum circumcircle) #148
            centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #149
            centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #150
            radius = int(Misc.map(radius, 0, size[0], 0, img_w))             #151
            cv2.circle(img, (centerX, centerY), radius, range_rgb[color_area_max], 2)#画圆(draw circle) #152
            
            if color_area_max == 'red':  #红色最大(red is the maximal area) #154
                color = 1 #155
            elif color_area_max == 'green':  #绿色最大(green is the maximal area) #156
                color = 2 #157
            elif color_area_max == 'blue':  #蓝色最大(blue is the maximal area) #158
                color = 3 #159
            else: #160
                color = 0 #161
            color_list.append(color) #162

            if len(color_list) == 3:  #多次判断(multiple judgement) #164
                # 取平均值(take average value) #165
                color = int(round(np.mean(np.array(color_list)))) #166
                color_list = [] #167
                if color == 1: #168
                    detect_color = 'red' #169
                    draw_color = range_rgb["red"] #170
                elif color == 2: #171
                    detect_color = 'green' #172
                    draw_color = range_rgb["green"] #173
                elif color == 3: #174
                    detect_color = 'blue' #175
                    draw_color = range_rgb["blue"] #176
                else: #177
                    detect_color = 'None' #178
                    draw_color = range_rgb["yellow"]      #179
                print('detect_color is',detect_color)           #180
        else: #181
            detect_color = 'None' #182
            draw_color = range_rgb["yellow"] #183
    cv2.rectangle(img,(190,270),(450,480),(0,255,255),2) #184
    if detect_color == target_color: #185
        cv2.putText(img, "Target Color" , (225, 250), cv2.FONT_HERSHEY_SIMPLEX, 1, draw_color, 2)   #186
    else: #187
        cv2.putText(img, "Not Target Color" , (200, 250), cv2.FONT_HERSHEY_SIMPLEX, 1, draw_color, 2)       #188
    cv2.putText(img, "Color: " + detect_color, (225, 210), cv2.FONT_HERSHEY_SIMPLEX, 1, draw_color, 2) #189
    
    return img #191
    

def image_callback(ros_image): #194

    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, #196
                       buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customized image information to image) #197
    cv2_img = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #198
    cv2_img = cv2.flip(cv2_img, 1) #199
    frame = cv2_img.copy() #200
    frame_result = run(frame) #201
    cv2.imshow('Frame', frame_result) #202
    key = cv2.waitKey(1) #203
    

if __name__ == '__main__': #206
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.DEBUG) #207
    
    color_range_list = rospy.get_param('/lab_config_manager/color_range_list', {}) #209
    rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #210
    
    runActionGroup_srv = rospy.ServiceProxy('/puppy_control/runActionGroup', SetRunActionName) #212
    buzzer_pub = rospy.Publisher('/ros_robot_controller/set_buzzer', BuzzerState, queue_size=1) #213
    initMove() #214
    rospy.sleep(0.2) #215
    
    try: #217
        rospy.spin() #218
    except : #219
        rospy.loginfo("Shutting down") #220
    
