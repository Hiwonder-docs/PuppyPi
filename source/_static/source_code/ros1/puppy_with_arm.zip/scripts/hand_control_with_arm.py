#!/usr/bin/python3 #1
# coding=utf8 #2
# 第11章 ROS机器狗结合机械臂课程\第6课 手势控制机械臂(11.ROS Robot Dog Combine Robotic Arm\Lesson 6 Posture Control Robotic Arm) #3
import sys #4
import cv2 #5
import math #6
import time #7
import rospy #8
import mediapipe as mp #9
from collections import deque #10
import threading #11
import numpy as np #12
from common import Misc #13
from common import PID #14
from std_msgs.msg import Header #15
from sensor_msgs.msg import Image #16
from arm_kinematics.ArmMoveIK import ArmIK #17
from std_srvs.srv import * #18

sys.path.append('/home/ubuntu/software/puppypi_control/') #20
from servo_controller import setServoPulse #21
# from puppy_control.srv import SetRunActionName #22

def distance(point_1, point_2): #24
    """ #25
    计算两个点间的距离(calculate the distance between two points) #26
    :param point_1: 点1(point 1) #27
    :param point_2: 点2(point 2) #28
    :return: 两点间的距离(distance between two points) #29
    """ #30
    return math.sqrt((point_1[0] - point_2[0]) ** 2 + (point_1[1] - point_2[1]) ** 2) #31

def get_hand_landmarks(img, landmarks): #33
    """ #34
    将landmarks从medipipe的归一化输出转为像素坐标(convert the landmarks from mediapipe's normalized output to pixel coordinates) #35
    :param img: 像素坐标对应的图片(the image corresponding to the pixel coordinates) #36
    :param landmarks: 归一化的关键点(normalized key points) #37
    :return: #38
    """ #39
    h, w, _ = img.shape #40
    landmarks = [(lm.x * w, lm.y * h) for lm in landmarks] #41
    return np.array(landmarks) #42

def cv2_image2ros(image, frame_id=''): #44
    image = image[:,:,::-1] #45
    ros_image = Image() #46
    header = Header(stamp=rospy.Time.now()) #47
    header.frame_id = frame_id #48
    ros_image.height = image.shape[:2][0] #49
    ros_image.width = image.shape[:2][1] #50
    ros_image.encoding = 'rgb8' #51
    ros_image.data = image.tostring() #52
    ros_image.header = header #53
    ros_image.step = ros_image.width * 3 #54

    return ros_image #56

class HandControlWithArmNode: #58
    def __init__(self, name): #59
        rospy.init_node(name)  # launch里的name会覆盖此处的name，所以要修改name，需要修改launch里的name, 为了一致性此处name会和launch name保持一致(the "name" in the "launch" file will override the name here. To change "name", you need to modify it in the "launch" file. For consistency, the name here will match the name in the launch file) #60
        self.mpHands = mp.solutions.hands #61
        self.hands = self.mpHands.Hands(static_image_mode=False, #62
                        max_num_hands=1, #63
                        min_detection_confidence=0.7, #64
                        min_tracking_confidence=0.7) #65
        self.mpDraw = mp.solutions.drawing_utils #66
        self.ak = ArmIK() #67
        self.last_time = time.time() #68
        self.last_out = 0 #69
        

        self.frames = 0 #72
        
        self.window_size = 5  # 定义滑动窗口大小（滤波窗口大小）(define the size of slider window(filter window size)) #74
        self.distance_measurements = deque(maxlen=self.window_size) # 创建一个队列用于存储最近的距离测量数据(create a queue to store recent distance measurement data) #75
        
        self.filtered_distance = 0 #77
        self.th = threading.Thread(target=self.move,daemon=True) #78
        self.th.start() #79
        self.name = name #80
        self.image = None #81
        
        rospy.Subscriber('/usb_cam/image_raw', Image, self.image_callback) #83
        self.result_publisher = rospy.Publisher('~image_result', Image, queue_size=1)  # 图像处理结果发布,# 使用~可以自动加上前缀名称(image processing result publish, use "~" can automatically add the prefix name) #84
    
    def image_callback(self, ros_image): #86
        self.image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, buffer=ros_image.data) # 原始 RGB 画面(original RGB image) #87
    
    def init(self): #89
        setServoPulse(9,1500,300) #90
        setServoPulse(10,800,300) #91
        setServoPulse(11,850,300) #92
        time.sleep(0.3) #93
        
        
    
    def move(self): #97
        while not rospy.is_shutdown(): #98
            
            if self.filtered_distance > 0 and self.filtered_distance < 100: #100
                
                
                out = Misc.map(self.filtered_distance, 15, 90, 1500, 900) #103
                setServoPulse(9,int(out),0) #104
 
            else: #106
                rospy.sleep(0.001) #107

    def run(self): #109
        
        self.init() #111
        while not rospy.is_shutdown(): #112
            if self.image is not None: #113
                image_flip = cv2.flip(self.image, 1) #114
                image_re = cv2.resize(image_flip, (320,240), interpolation=cv2.INTER_NEAREST) #115
                self.image = None #116
                bgr_image = cv2.cvtColor(image_re, cv2.COLOR_RGB2BGR) #117
                try: #118
                    
                       
                    results = self.hands.process(image_re) #121
                    if results.multi_hand_landmarks: #122
                        
                        for hand_landmarks in results.multi_hand_landmarks: #124
                            ## mediapipe中首部关键结点的连线(lines connecting the key points at the beginning of the MediaPipe) #125
                            self.mpDraw.draw_landmarks(bgr_image, hand_landmarks, self.mpHands.HAND_CONNECTIONS) #126
                            landmarks = get_hand_landmarks(image_re, hand_landmarks.landmark) #127
                            
                            cv2.line(bgr_image, (int(landmarks[4][0]), int(landmarks[4][1])), (int(landmarks[8][0]), int(landmarks[8][1])), (0, 255, 255), 2) #129
                            cv2.circle(bgr_image, (int(landmarks[8][0]), int(landmarks[8][1])), 4, (0, 255, 255), -1) #130
                            cv2.circle(bgr_image, (int(landmarks[4][0]), int(landmarks[4][1])), 4, (0, 255, 255), -1) #131

                            distanceSum = distance(landmarks[8], landmarks[4]) #133
                           
                            distanceSum = max(15, min(distanceSum, 90)) #135
                            self.distance_measurements.append(distanceSum) #136
                            self.filtered_distance = np.mean(self.distance_measurements) #137
                            self.filtered_distance = round(self.filtered_distance,2) #138
                            cv2.putText(bgr_image,'DST: '+str(self.filtered_distance), (5,220), cv2.FONT_HERSHEY_PLAIN, 2, (255,0,255), 2) #139
                                
                                
                    self.frames +=1 #142
                    delta_time = time.time() - self.last_time #143
                    cur_fps = np.around(self.frames / delta_time, 1) #144
                    cv2.putText(bgr_image,'FPS: '+str(cur_fps), (5,30), cv2.FONT_HERSHEY_PLAIN, 2, (255,0,255), 2) #145
                except Exception as e: #146
                    print(e) #147
              
                
                self.result_publisher.publish(cv2_image2ros(cv2.resize(bgr_image, (640, 480)), self.name)) #150
                                               

if __name__ == '__main__': #153
    HandControlWithArmNode('hand_control').run() #154

