#!/usr/bin/env python #1
# encoding: utf-8 #2
import cv2 #3
import queue #4
import rospy #5
import threading #6
import numpy as np #7
import mediapipe as mp #8
from cv_bridge import CvBridge #9
from sensor_msgs.msg import Image #10

class FaceDetect: #12
    def __init__(self): #13
        rospy.init_node('face_detect_demo', anonymous=True) #14
        self.running = True #15
        self.bridge = CvBridge()  # cv_bridge is required in ROS1 for image conversion. （ROS1需要cv_bridge进行图像转换） #16
        
        # Initialize Mediapipe. （Mediapipe初始化） #18
        self.face = mp.solutions.face_detection #19
        self.face_detection = self.face.FaceDetection(min_detection_confidence=0.6) #20
        self.img_h, self.img_w = 0, 0 #21
        
        # Image queue and subscriber. （图像队列和订阅者） #23
        self.image_queue = queue.Queue(maxsize=2) #24
        self.image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, self.image_callback, queue_size=1) #25
        rospy.loginfo('\033[1;32m%s\033[0m' % 'start') #26
        
        # Start the processing thread. （启动处理线程） #28
        threading.Thread(target=self.main, daemon=True).start() #29

    def image_callback(self, ros_image): #31
        try: #32
            # Use cv_bridge to convert ROS image messages. （使用cv_bridge转换ROS图像消息） #33
            cv_image = self.bridge.imgmsg_to_cv2(ros_image, "bgr8") #34
        except Exception as e: #35
            rospy.logerr(e) #36
            return #37
        
        img_copy = cv_image.copy() #39
        self.img_h, self.img_w = cv_image.shape[:2] #40
        
        # Process using Mediapipe. （Mediapipe处理） #42
        imgRGB = cv2.cvtColor(img_copy, cv2.COLOR_BGR2RGB) #43
        results = self.face_detection.process(imgRGB) #44
        
        if results.detections: #46
            for detection in results.detections: #47
                bboxC = detection.location_data.relative_bounding_box #48
                bbox = (int(bboxC.xmin * self.img_w),  #49
                        int(bboxC.ymin * self.img_h), #50
                        int(bboxC.width * self.img_w),  #51
                        int(bboxC.height * self.img_h)) #52
                cv2.rectangle(cv_image, bbox, (0,255,0), 2) #53
        
        # Put into queue. （放入队列） #55
        if self.image_queue.full(): #56
            self.image_queue.get() #57
        self.image_queue.put(cv_image) #58

    def main(self): #60
        while self.running and not rospy.is_shutdown(): #61
            try: #62
                image = self.image_queue.get(block=True, timeout=1) #63
            except queue.Empty: #64
                continue #65
            
            # Display the processing results. （显示处理） #67
            display_image = cv2.flip(image, 1) #68
            cv2.imshow('MediaPipe Face Detect', display_image) #69
            
            key = cv2.waitKey(1) #71
            if key in [ord('q'), 27]:  # Exit by press ESC or 'q' key. （ESC或q键退出） #72
                self.running = False #73
                break #74
        
        cv2.destroyAllWindows() #76
        rospy.signal_shutdown("User requested shutdown") #77

if __name__ == "__main__": #79
    try: #80
        node = FaceDetect() #81
        rospy.spin()  # In ROS1, spin must be called manually. （ROS1需要主动调用spin） #82
    except Exception as e: #83
        rospy.logerr(e) #84
    finally: #85
        cv2.destroyAllWindows() #86
