#!/usr/bin/env python3 #1
# coding=utf8 #2
# 第8章 ROS机器狗拓展课程\3.空心杯舵机控制课程\第2课 控制空心杯舵机转动(8.ROS Robot Expanded Course\3.Hollow Cup Servo Control Course\Lesson 2 Control Hollow Cup Servo Rotation) #3
import sys #4
import time #5
import signal #6

sys.path.append('/home/ubuntu/software/puppypi_control') #8
from ros_robot_controller_sdk import Board #9
from pwm_servo_control import PWMServoControl #10

# 控制单个舵机(control single servo) #12

print(''' #14
********************************************************** #15
*****************功能:单个舵机控制例程(function: single servo control routine)*********************** #16
********************************************************** #17
---------------------------------------------------------- #18
Official website:https://www.hiwonder.com #19
Online mall:https://hiwonder.tmall.com #20
---------------------------------------------------------- #21
Tips: #22
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #23
---------------------------------------------------------- #24
''') #25

# 关闭检测函数(close detection function) #27
run_st = True #28
def Stop(signum, frame): #29
    global run_st #30
    run_st = False #31
    print('关闭中...') #32

signal.signal(signal.SIGINT, Stop) #34

if __name__ == '__main__': #36
    board = Board() #37
    servo = PWMServoControl(board) #38
    
    while run_st: #40
         servo.setPulse(1,1000,2000) # 驱动1号舵机(drive servo No.1) #41
         time.sleep(2) # 延时(delay) #42
         servo.setPulse(1,2000,2000) # 驱动1号舵机(drive servo No.1) #43
         time.sleep(2) # 延时(delay) #44
    
    servo.setPulse(1,1500,500) #46
    time.sleep(0.5) # 延时(delay) #47
