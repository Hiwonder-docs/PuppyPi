#!/usr/bin/env python3 #1
# 第8章 ROS机器狗拓展课程\4.传感器开发课程\第1课 发光超声波传感器控制(8.ROS Robot Expanded Course\4.Sensor Development Course\Lesson 1 Glowy Ultrasonic Sensor Control) #2
import os #3
import sys #4
import time #5
import signal #6
import sensor.Sonar as Sonar #7

print(''' #9
********************************************************** #10
*******************功能:超声波控制例程(function:ultrasonic control routine)********************** #11
********************************************************** #12
---------------------------------------------------------- #13
Official website:https://www.hiwonder.com #14
Online mall:https://hiwonder.tmall.com #15
---------------------------------------------------------- #16
Tips: #17
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #18
---------------------------------------------------------- #19
''') #20

if sys.version_info.major == 2: #22
    print('Please run this program with python3!') #23
    sys.exit(0) #24


# 关闭检测函数(close detection function) #27
run_st = True #28
def Stop(signum, frame): #29
    global run_st #30
    run_st = False #31
    print('关闭中...') #32

signal.signal(signal.SIGINT, Stop) #34

if __name__ == '__main__': #36
    s = Sonar.Sonar() #37
    s.setRGBMode(0) # 0:彩灯模块,1:呼吸灯模式(0:color light module, 1:breathing light mode) #38
    s.setRGB(1, (0, 0, 0)) # 关闭RGB灯(turn off RGB light) #39
    s.setRGB(0, (0, 0, 0)) #40
    while run_st: #41
        time.sleep(0.1) #42
        distance = s.getDistance() # 获得检测的距离(obtain detected distance) #43
        print('distance: {}(mm)'.format(distance)) #44
        if distance <= 300: # 距离小于300mm(the distance is less than 300mm) #45
            s.setRGB(1, (255, 0, 0)) # 设为红色(set to red color) #46
            s.setRGB(0, (255, 0, 0)) #47
            
        elif 300 < distance < 500:  #49
            s.setRGB(1, (0, 255, 0)) # 设为绿色(set to green color) #50
            s.setRGB(0, (0, 255, 0)) #51
            
        else: #53
            s.setRGB(1, (0, 0, 255)) # 设为蓝色(set to blue color) #54
            s.setRGB(0, (0, 0, 255)) #55
            
    s.setRGB(1, (0, 0, 0)) #57
    s.setRGB(0, (0, 0, 0)) #58
    
