#!/usr/bin/python3 #1
#coding=utf8 #2
# 第8章 ROS机器狗拓展课程\2.树莓派扩展板课程\第2课 控制RGB彩灯(8.ROS Robot Expanded Course\2.Raspberry Pi Expansion Board course\Lesson 2 Control RGB Color Light) #3
import os #4
import sys #5
import rospy #6
from std_msgs.msg import * #7
from ros_robot_controller.msg import RGBState, RGBsState #8


print(''' #11
********************************************************** #12
****************功能:RGB彩灯控制例程(function: RGB color light control routine)************************ #13
********************************************************** #14
---------------------------------------------------------- #15
Official website:https://www.hiwonder.com #16
Online mall:https://hiwonder.tmall.com #17
---------------------------------------------------------- #18
Tips: #19
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #20
---------------------------------------------------------- #21
''') #22

# 关闭RGB彩灯(turn off RGB color light) #24
def turn_off_rgb(): #25
    led1 = RGBState() #26
    led1.r = 0 #27
    led1.g = 0 #28
    led1.b = 0 #29
    led1.id = 1 #30

    led2 = RGBState() #32
    led2.r = 0 #33
    led2.g = 0 #34
    led2.b = 0 #35
    led2.id = 2 #36
    msg = RGBsState() #37
    msg.data = [led1,led2] #38
    rgb_pub.publish(msg) #39
    rospy.sleep(0.01) #40

# 设置RGB彩灯显示(set the display of RGB color light) #42
def set_rgb_show(r,g,b): #43
    led1 = RGBState() #44
    led1.r = r #45
    led1.g = g #46
    led1.b = b #47
    led1.id = 1 #48

    led2 = RGBState() #50
    led2.r = r #51
    led2.g = g #52
    led2.b = b #53
    led2.id = 2 #54
    msg = RGBsState() #55
    msg.data = [led1,led2] #56
    rgb_pub.publish(msg) #57
    rospy.sleep(0.01) #58

# 关闭检测函数(close detection function) #60
run_st = True #61
def Stop(): #62
    global run_st #63
    run_st = False #64
    turn_off_rgb() #65
    print('关闭中...') #66


if __name__ == '__main__': #69
    # 初始化节点(initialization node) #70
    rospy.init_node('rgb_control_demo') #71
    rospy.on_shutdown(Stop) #72
   
    rgb_pub = rospy.Publisher('/ros_robot_controller/set_rgb', RGBsState, queue_size=1) #74
    rospy.sleep(0.2) # 延时一会，等待订阅生效(delay for a moment for the subscription to take effect) #75
    
    while run_st: #77
        r,g,b = 0,0,0 #78
        for r in range(0,255,5): #红色渐亮(the red color gradually brightens) #79
            set_rgb_show(r,g,b) #80
            rospy.sleep(0.005) #81
            
        rospy.sleep(1) #83
        r,g,b = 0,0,0  #84
        for g in range(0,255,5): #绿色渐亮(the green color gradually brightens) #85
            set_rgb_show(r,g,b) #86
            rospy.sleep(0.005) #87
        
        rospy.sleep(1) #89
        r,g,b = 0,0,0  #90
        for b in range(0,255,5): #蓝色渐亮(the blue color gradually brightens) #91
            set_rgb_show(r,g,b) #92
            rospy.sleep(0.005) #93
        rospy.sleep(1) #94
        
        
    
