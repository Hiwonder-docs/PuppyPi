#!/usr/bin/env python #1
# encoding: utf-8 #2
import cv2 #3
import queue #4
import rospy #5
import threading #6
import sys #7
import numpy as np #8
import mediapipe as mp #9
from std_srvs.srv import SetBool, Trigger, Empty #10
from sensor_msgs.msg import Image #11
from cv_bridge import CvBridge, CvBridgeError #12
sys.path.append('/home/ubuntu/software/puppypi_control/') #13
from servo_controller import setServoPulse #14
from action_group_control import runActionGroup, stopActionGroup #15
from HiwonderPuppy import HiwonderPuppy, PWMServoParams #16
class SegmentationNode: #17
    def __init__(self, name): #18
        rospy.init_node(name) #19
        self.running = True #20
        self.mp_selfie_segmentation = mp.solutions.selfie_segmentation #21
        self.mp_drawing = mp.solutions.drawing_utils #22
        self.image_queue = queue.Queue(maxsize=2) #23
        self.BG_COLOR = (192, 192, 192)  # gray #24
        self.bridge = CvBridge() #25
        self.image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, self.image_callback) #26
        rospy.loginfo('\033[1;32m%s\033[0m' % 'start') #27
        self.cli = rospy.ServiceProxy('/puppy_control/go_home', Empty) #28
        self.cli() #29
        threading.Thread(target=self.main, daemon=True).start() #30

    def image_callback(self, ros_image): #32
        try: #33
            # Convert the ROS image message to a CV2 image #34
            rgb_image = self.bridge.imgmsg_to_cv2(ros_image, "bgr8") #35
            if self.image_queue.full(): #36
                # If the queue is full, discard the oldest image #37
                self.image_queue.get() #38
            # Put the image into the queue #39
            self.image_queue.put(rgb_image) #40
        except CvBridgeError as e: #41
            rospy.logerr(f"Error converting image: {e}") #42

    def main(self): #44
        with self.mp_selfie_segmentation.SelfieSegmentation(model_selection=1) as selfie_segmentation: #45
            bg_image = None #46
            while self.running: #47
                try: #48
                    image = self.image_queue.get(block=True, timeout=1) #49
                except queue.Empty: #50
                    if not self.running: #51
                        break #52
                    else: #53
                        continue #54
                # To improve performance, optionally mark the image as not writeable to #55
                # pass by reference. #56
                image.flags.writeable = False #57
                results = selfie_segmentation.process(image) #58
                image.flags.writeable = True #59
                # Since the input image is in RGB, directly use it #60
                condition = np.stack((results.segmentation_mask,) * 3, axis=-1) > 0.1 #61
                if bg_image is None: #62
                    bg_image = np.zeros(image.shape, dtype=np.uint8) #63
                    bg_image[:] = self.BG_COLOR #64
                output_image = np.where(condition, image, bg_image) #65
                # Display image (already in RGB) #66
                cv2.imshow('MediaPipe Selfie Segmentation', output_image) #67
                key = cv2.waitKey(1) #68
                if key == ord('q') or key == 27:  # Press q or esc to exit #69
                    break #70
            cv2.destroyAllWindows() #71

def main(): #73
    node = SegmentationNode('self_segmentation') #74
    try: #75
        rospy.spin() #76
    except KeyboardInterrupt: #77
        rospy.loginfo("Shutting down") #78
        cv2.destroyAllWindows() #79
        rospy.signal_shutdown('Shutdown') #80

if __name__ == "__main__": #82
    main() #83
