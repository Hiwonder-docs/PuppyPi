#!/usr/bin/env python3 #1
# coding=utf8 #2
import os #3
import math #4
import rospy #5
import signal #6
import subprocess #7
from std_msgs.msg import * #8
from puppy_control.srv import SetRunActionName #9
from puppy_control.msg import Velocity, Pose, Gait #10

print(''' #12
********************************************************** #13
******************功能:MP3模块例程(function: MP3 module routine)************************* #14
********************************************************** #15
---------------------------------------------------------- #16
Official website:https://www.hiwonder.com #17
Online mall:https://hiwonder.tmall.com #18
---------------------------------------------------------- #19
Tips: #20
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close the program, please try multiple times if fail) #21
---------------------------------------------------------- #22
''') #23

PuppyPose = {'roll': math.radians(0), 'pitch': math.radians(0), 'yaw': 0.000, 'height': -10, 'x_shift': -0.5, 'stance_x': 0, 'stance_y': 0} #25
GaitConfig = {'overlap_time': 0.3, 'swing_time': 0.2, 'clearance_time': 0.0, 'z_clearance': 5} #26

MP3_DIR = "//home/ubuntu/puppypi/src/puppy_extend_demo/scripts/MP3" #28
mpg123_process = None   #29


def get_mp3_files(directory): #32
    """Read all MP3 files from the directory.（从目录中读取所有 MP3 文件）""" #33
    files = [f for f in os.listdir(directory) if f.endswith(".mp3")] #34
    return {i + 1: os.path.join(directory, f) for i, f in enumerate(files)} #35


def play_audio(file_path): #38

    global mpg123_process #40
    try: #41
        if not os.path.exists(file_path): #42
            print(f"文件不存在: {file_path}") #43
            return #44
        mpg123_process = subprocess.Popen(["mpg123", file_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) #45
        print(f"正在播放音乐: {file_path}") #46
    except FileNotFoundError: #47
        print("未找到 `mpg123` 命令，检查系统安装了 `mpg123`。") #48


def stop_audio(): #51
    """Terminate music playback.（终止音乐播放）""" #52
    global mpg123_process #53
    if mpg123_process: #54
        mpg123_process.terminate() #55
        mpg123_process.wait() #56
        mpg123_process = None #57
        print("音乐播放已停止") #58


def stop_all(): #61
    """Stop all operations: music and actions.（终止所有操作：音乐和动作）""" #62
    print("正在关闭程序...") #63
    stop_audio()  # Stop music.（停止音乐） #64
    PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0)  # Stop robot actions.（停止机器人动作） #65
    runActionGroup_srv('stand.d6ac', True)  # Make the robot stand still.（让机器人站立停止） #66
    rospy.signal_shutdown("程序已安全退出")  # Shut down the ROS node.（关闭 ROS 节点） #67


def signal_handler(signum, frame): #70
    """Catch Ctrl+C signal and terminate the program.（捕获 Ctrl+C 信号并终止程序）""" #71
    stop_all() #72


def linkage(times=1): #75
    """Example: multi-axis coordination.（示例：多轴联动）""" #76
    for i in range(0, 15, 1): #77
        PuppyPose.update({'roll': math.radians(i), 'pitch': math.radians(0)}) #78
        PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #79
                             height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time=30) #80
        rospy.sleep(0.03) #81


if __name__ == "__main__": #84
    # Register Ctrl+C signal handler.（注册 Ctrl+C 信号处理） #85
    signal.signal(signal.SIGINT, signal_handler) #86


    rospy.init_node('mp3_moonwalk_demo', disable_signals=True) #89
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #90
    PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #91
    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #92
    runActionGroup_srv = rospy.ServiceProxy('/puppy_control/runActionGroup', SetRunActionName) #93
    rospy.sleep(0.3) #94

    mp3_files = get_mp3_files(MP3_DIR) #96
    if not mp3_files: #97
        print(f"目录 {MP3_DIR} 中没有找到 MP3 文件，请检查目录内容。") #98
        exit() #99

    print("可用歌曲列表:") #101
    for num, path in mp3_files.items(): #102
        print(f"{num}: {os.path.basename(path)}") #103

    try: #105
        song_number = int(input("请输入要播放的歌曲编号: ")) #106
        if song_number in mp3_files: #107
            play_audio(mp3_files[song_number])   #108
        else: #109
            print("输入的编号无效，请重试。") #110
            exit() #111
    except ValueError: #112
        print("输入无效，请输入数字编号。") #113
        exit() #114

    try: #116
        while True: #117
            # Robot dog stands.（机器狗站立） #118
            PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #119
                                 height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time=500) #120
            rospy.sleep(0.5) #121
            PuppyGaitConfigPub.publish(overlap_time=GaitConfig['overlap_time'], swing_time=GaitConfig['swing_time'], #122
                                       clearance_time=GaitConfig['clearance_time'], z_clearance=GaitConfig['z_clearance']) #123

            # Marching in place.（原地踏步） #125
            PuppyVelocityPub.publish(x=0.01, y=0, yaw_rate=0) #126
            rospy.sleep(3) #127
            PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #128
            rospy.sleep(1) #129

            # Multi-axis coordination.（多轴联动） #131
            linkage(2) #132

            # Move forward.（向前走） #134
            PuppyVelocityPub.publish(x=5, y=0, yaw_rate=0) #135
            rospy.sleep(3) #136
            PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #137

            # Move backward.（向后走） #139
            rospy.sleep(1) #140
            PuppyVelocityPub.publish(x=-5, y=0, yaw_rate=0) #141
            rospy.sleep(3) #142
            PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #143

            # Sliding motion group.（滑步动作组） #145
            runActionGroup_srv('moonwalk.d6ac', True) #146
            rospy.sleep(0.5) #147

    finally: #149
        stop_all()  #150
