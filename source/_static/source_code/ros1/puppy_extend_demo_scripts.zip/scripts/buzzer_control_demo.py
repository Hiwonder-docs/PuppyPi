#!/usr/bin/python3 #1
#coding=utf8 #2
#第8章 ROS机器狗拓展课程\2.树莓派扩展板课程\第3课 控制蜂鸣器(8.ROS Robot Expanded Course\2.Raspberry Pi Expanded Course\Lesson 3 Control Buzzer) #3
import os #4
import sys #5
import rospy #6
from ros_robot_controller.msg import BuzzerState #7
from std_msgs.msg import * #8

# 控制蜂鸣器(control buzzer) #10

print(''' #12
********************************************************** #13
******************功能:蜂鸣器控制例程(function: buzzer control routine)*********************** #14
********************************************************** #15
---------------------------------------------------------- #16
Official website:https://www.hiwonder.com #17
Online mall:https://hiwonder.tmall.com #18
---------------------------------------------------------- #19
Tips: #20
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #21
---------------------------------------------------------- #22
''') #23

if __name__ == '__main__': #25
    # 初始化节点(initialization node) #26
    rospy.init_node('buzzer_control_demo') #27
    
    buzzer_pub = rospy.Publisher("/ros_robot_controller/set_buzzer", BuzzerState, queue_size=1) #29
    rospy.sleep(0.5) # 延时一会(delay for a second) #30
    
    buzzer_msg = BuzzerState() #32

    buzzer_msg.freq = 1900 #34
    buzzer_msg.on_time = 2 #35
    buzzer_msg.off_time = 1 #36
    buzzer_msg.repeat = 1 #37
    buzzer_pub.publish(buzzer_msg) # 蜂鸣器响2秒(buzzer emit for 2 seconds) #38
    rospy.sleep(3) #39

    buzzer_msg.freq = 1900 #41
    buzzer_msg.on_time = 0.5 #42
    buzzer_msg.off_time = 0.5 #43
    buzzer_msg.repeat = 1 #44
    buzzer_pub.publish(buzzer_msg) # 蜂鸣器响0.5秒(buzzer emit for 0.5 second) #45
        
    
