#!/usr/bin/python3 #1
#coding=utf8 #2
#第8章 ROS机器狗拓展课程\2.树莓派扩展板课程\第4课 按键控制(8. ROS Robot Expanded Course\2. Raspberry Pi Expanded Course\Lesson 4 Button Control) #3
import os #4
import sys #5
import rospy #6
import gpiod #7
from ros_robot_controller.msg import RGBState,RGBsState,BuzzerState #8
from std_msgs.msg import * #9


# 按键控制(button control) #12

print(''' #14
********************************************************** #15
*********************功能:按键控制例程(function: button control routine)********************** #16
********************************************************** #17
---------------------------------------------------------- #18
Official website:https://www.hiwonder.com #19
Online mall:https://hiwonder.tmall.com #20
---------------------------------------------------------- #21
Tips: #22
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to turn off the program, please try multiple times if fail) #23
---------------------------------------------------------- #24
''') #25

# 关闭RGB彩灯(turn off RGB color light) #27
def turn_off_rgb(): #28
    led1 = RGBState() #29
    led1.id = 1 #30
    led1.r = 0 #31
    led1.g = 0 #32
    led1.b = 0 #33
    
    led2 = RGBState() #35
    led2.id = 2 #36
    led2.r = 0 #37
    led2.g = 0 #38
    led2.b = 0 #39

    msg = RGBsState() #41
    msg.data = [led1,led2] #42
    rgb_pub.publish(msg) #43
    rospy.sleep(0.01) #44

# 设置RGB彩灯显示(set the display of RGB color light) #46
def set_rgb_show(r,g,b): #47

    led1 = RGBState() #49
    led1.id = 1 #50
    led1.r = r #51
    led1.g = g #52
    led1.b = b #53
    
    led2 = RGBState() #55
    led2.id = 2 #56
    led2.r = r #57
    led2.g = g #58
    led2.b = b #59

    msg = RGBsState() #61
    msg.data = [led1,led2] #62
    rgb_pub.publish(msg) #63
    rospy.sleep(0.01) #64

# 关闭检测函数(turn off detection function) #66
run_st = True #67
def Stop(): #68
    global run_st #69
    run_st = False #70
    turn_off_rgb() #71
    print('关闭中...') #72


if __name__ == '__main__': #75
    # 按键初始化配置(key initialization configuration) #76
    key1_pin = 25 #77
    key2_pin = 23 #78
    
    chip = gpiod.chip("gpiochip4") #80
    
    key1 = chip.get_line(key1_pin) #82
    config = gpiod.line_request() #83
    config.consumer = "key1" #84
    config.request_type = gpiod.line_request.DIRECTION_INPUT #85
    config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #86
    key1.request(config) #87

    key2 = chip.get_line(key2_pin) #89
    config = gpiod.line_request() #90
    config.consumer = "key2" #91
    config.request_type = gpiod.line_request.DIRECTION_INPUT #92
    config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #93
    key2.request(config) #94
    
    # 初始化节点(initialization node) #96
    rospy.init_node('button_control_demo') #97
    rospy.on_shutdown(Stop) #98
    rgb_pub = rospy.Publisher('/ros_robot_controller/set_rgb', RGBsState, queue_size=1) #99
    buzzer_pub = rospy.Publisher("/ros_robot_controller/set_buzzer",BuzzerState, queue_size=1) #100
    rospy.sleep(0.5) # 延时一会(delay for a moment) #101
    
    buzzer_msg = BuzzerState() #103

    button_press = False # 按键按压状态(button press status) #105
    while run_st: #106
        if key1.get_value() == 0: # 检测到按键1按下(key 1 pressed detected) #107
            rospy.sleep(0.05) # 延时消抖再检测(delay for debounce before detection) #108
            if key1.get_value() == 0: #109
                if not button_press: #110
                    button_press = True #111
                    r,g,b = 0,255,0 #112
                    set_rgb_show(r,g,b) #绿色(green) #113
                    buzzer_msg.freq = 1900 #114
                    buzzer_msg.on_time = 0.5 #115
                    buzzer_msg.off_time = 0.5 #116
                    buzzer_msg.repeat = 1 #117
                    buzzer_pub.publish(buzzer_msg) # 蜂鸣器响0.5秒(buzzer sound for 0.5 seconds) #118
        
        if key2.get_value() == 0: # 检测到按键2按下(press key2 when detected) #120
            rospy.sleep(0.05) # 延时消抖再检测(delay for debounce before detecting again) #121
            if key2.get_value() == 0: #122
                if not button_press: #123
                    button_press = True #124
                    r,g,b = 0,0,255 #125
                    set_rgb_show(r,g,b) #蓝色(blue) #126
                    buzzer_msg.freq = 1900 #127
                    buzzer_msg.on_time = 0.5 #128
                    buzzer_msg.off_time = 0.5 #129
                    buzzer_msg.repeat = 1 #130
                    buzzer_pub.publish(buzzer_msg) # 蜂鸣器响0.5秒(buzzer emit for 0.5 seconds) #131
        else: #132
            if button_press: #133
                button_press = False #134
            rospy.sleep(0.05) #135
        
    
