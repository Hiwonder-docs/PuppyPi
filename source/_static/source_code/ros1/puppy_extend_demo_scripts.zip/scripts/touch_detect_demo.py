#!/usr/bin/python3 #1
#coding=utf8 #2
# 第8章 ROS机器狗拓展课程\4.传感器开发课程\第3课 触摸传感器检测(8.ROS Robot Expanded Course\4.Sensor Development Course\Lesson 3 Touch Sensor Detection) #3
import os #4
import sys #5
import math #6
import rospy #7
import gpiod #8
from ros_robot_controller.msg import BuzzerState #9
from std_msgs.msg import * #10


print(''' #13
********************************************************** #14
*******************功能:触摸检测例程(function: touch detection routine)************************ #15
********************************************************** #16
---------------------------------------------------------- #17
Official website:https://www.hiwonder.com #18
Online mall:https://hiwonder.tmall.com #19
---------------------------------------------------------- #20
Tips: #21
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #22
---------------------------------------------------------- #23
''') #24



# 触摸模块接扩展板上的IO22、IO24接口(connect the touch module to the IO22 and IO24 interfaces on the expansion board) #28

touch_pin = 22 #30
chip = gpiod.chip("gpiochip0") #31
    
touch = chip.get_line(touch_pin) #33
config = gpiod.line_request() #34
config.consumer = "touch" #35
config.request_type = gpiod.line_request.DIRECTION_INPUT #36
config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #37
touch.request(config) #38


# 关闭检测函数(close detection function) #41
run_st = True #42
def Stop(): #43
    global run_st #44
    run_st = False #45
    print('关闭中...') #46
    buzzer_pub.publish(0) #47

if __name__ == '__main__': #49
    # 初始化节点(initialization node) #50
    rospy.init_node('buzzer_control_demo') #51
    rospy.on_shutdown(Stop) #52
    
    buzzer_pub = rospy.Publisher("/ros_robot_controller/set_buzzer", BuzzerState, queue_size=1) #54
    rospy.sleep(0.5) # 延时一会(delay for a moment) #55
    buzzer_msg = BuzzerState() #56

    st = 0 #58
    while run_st: #59
        state = touch.get_value()  #读取引脚数字值(read digital pin value) #60
        if not state: #61
            if st :             #这里做一个判断，防止反复响(implement a check here to prevent repeated responses) #62
                st = 0 #63
                
                buzzer_msg.freq = 1900 #65
                buzzer_msg.on_time = 0.5 #66
                buzzer_msg.off_time = 0.5 #67
                buzzer_msg.repeat = 1 #68
                buzzer_pub.publish(buzzer_msg) # 蜂鸣器响0.5秒(buzzer emits for 0.5 second) #69
                rospy.sleep(1) #70
        else: #71
            st = 1 #72
            
        
    
