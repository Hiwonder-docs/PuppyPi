#!/usr/bin/env python3 #1
# 第8章 ROS机器狗拓展课程\4.传感器开发课程\第4课 点阵模块显示(8.ROS Robot Expanded Course\4.Sensor Development Course\Lesson 4 Dot-matrix Display) #2
import os #3
import sys #4
import time #5
from sensor import dot_matrix_sensor #6

if sys.version_info.major == 2: #8
    print('Please run this program with python3!') #9
    sys.exit(0) #10

print(''' #12
********************************************************** #13
********************功能:点阵显示实验例程(function: dot-matrix display)******************** #14
********************************************************** #15
---------------------------------------------------------- #16
Official website:https://www.hiwonder.com #17
Online mall:https://hiwonder.tmall.com #18
---------------------------------------------------------- #19
Tips: #20
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #21
---------------------------------------------------------- #22
''') #23

# 点阵模块接扩展板上的IO7、IO8接口(connect the dot matrix module to the IO7 and IO8 interfaces on the expansion board) #25
dms = dot_matrix_sensor.TM1640(dio=7, clk=8) #26

if __name__ == '__main__': #28
    # 显示'Hello'(display 'Hello') #29
    while True: #30
        try: #31
            dms.display_buf=(0x7f, 0x08, 0x7f, 0x00, 0x7c, 0x54, 0x5c, 0x00, #32
                              0x7c, 0x40, 0x00,0x7c, 0x40, 0x38, 0x44, 0x38) #33
            dms.update_display() #34
            time.sleep(5) #35
        except KeyboardInterrupt: #36
            dms.display_buf = [0]*16 #37
            dms.update_display() #38
            break #39
