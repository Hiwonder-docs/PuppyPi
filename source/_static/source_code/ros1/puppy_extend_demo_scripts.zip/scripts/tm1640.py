import RPi.GPIO as GPIO #1
import time #2
TM1640_CMD1 = (64)  # 0x40 data command #3
TM1640_CMD2 = (192) # 0xC0 address command #4
TM1640_CMD3 = (128) # 0x80 display control command #5
TM1640_DSP_ON = (8) # 0x08 display on #6
TM1640_DELAY = (10) # 10us delay between clk/dio pulses #7

def sleep_us(t): #9
    time.sleep(t / 1000000) #10

class TM1640(object): #12
    """Library for LED matrix display modules based on the TM1640 LED driver.""" #13
    def __init__(self, clk, dio, brightness=7): #14
        self.clk_p = clk #15
        self.dio_p = dio #16

        if not 0 <= brightness <= 7: #18
            raise ValueError("Brightness out of range") #19
        self._brightness = brightness #20
        GPIO.setmode(GPIO.BOARD) #21
        GPIO.setup(clk, GPIO.OUT) #22
        GPIO.output(clk, 0) #23
        GPIO.setup(dio, GPIO.OUT) #24
        GPIO.output(dio, 0) #25
        sleep_us(TM1640_DELAY) #26

        self._write_data_cmd() #28
        self._write_dsp_ctrl() #29

    def dio(self, n_s): #31
        GPIO.output(self.dio_p, n_s) #32

    def clk(self, n_s): #34
        GPIO.output(self.clk_p, n_s) #35

    def _start(self): #37
        self.dio(0) #38
        sleep_us(TM1640_DELAY) #39
        self.clk(0) #40
        sleep_us(TM1640_DELAY) #41

    def _stop(self): #43
        self.dio(0) #44
        sleep_us(TM1640_DELAY) #45
        self.clk(1) #46
        sleep_us(TM1640_DELAY) #47
        self.dio(1) #48

    def _write_data_cmd(self): #50
        # automatic address increment, normal mode #51
        self._start() #52
        self._write_byte(TM1640_CMD1) #53
        self._stop() #54

    def _write_dsp_ctrl(self): #56
        # display on, set brightness #57
        self._start() #58
        self._write_byte(TM1640_CMD3 | TM1640_DSP_ON | self._brightness) #59
        self._stop() #60

    def _write_byte(self, b): #62
        for i in range(8): #63
            self.dio((b >> i) & 1) #64
            sleep_us(TM1640_DELAY) #65
            self.clk(1) #66
            sleep_us(TM1640_DELAY) #67
            self.clk(0) #68
            sleep_us(TM1640_DELAY) #69

    def brightness(self, val=None): #71
        """Set the display brightness 0-7.""" #72
        # brightness 0 = 1/16th pulse width #73
        # brightness 7 = 14/16th pulse width #74
        if val is None: #75
            return self._brightness #76
        if not 0 <= val <= 7: #77
            raise ValueError("Brightness out of range") #78

        self._brightness = val #80
        self._write_data_cmd() #81
        self._write_dsp_ctrl() #82

    def write(self, rows, pos=0): #84
        if not 0 <= pos <= 7: #85
            raise ValueError("Position out of range") #86

        self._write_data_cmd() #88
        self._start() #89

        self._write_byte(TM1640_CMD2 | pos) #91
        for row in rows: #92
            self._write_byte(row) #93

        self._stop() #95
        self._write_dsp_ctrl() #96

    def write_int(self, int, pos=0, len=8): #98
        self.write(int.to_bytes(len, 'big'), pos) #99

    def write_hmsb(self, buf, pos=0): #101
        self._write_data_cmd() #102
        self._start() #103

        self._write_byte(TM1640_CMD2 | pos) #105
        for i in range(7-pos, -1, -1): #106
            self._write_byte(buf[i]) #107

        self._stop() #109
        self._write_dsp_ctrl() #110


display = TM1640(dio=26, clk=24) #113

display_buf = [0] * 16 #115

def set_bit(x, y, s): #117
    display_buf[x] = (display_buf[x] & (~(0x01 << y))) | (s << y) #118

def update_display(): #120
    display.write(display_buf) #121

set_bit(1, 1, 0) #123
update_display() #124

