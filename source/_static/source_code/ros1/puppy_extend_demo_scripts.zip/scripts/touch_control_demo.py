#!/usr/bin/python3 #1
#coding=utf8 #2
import os #3
import sys #4
import time #5
import math #6
import rospy #7
import gpiod #8

from std_msgs.msg import * #10
from puppy_control.msg import Velocity, Pose, Gait #11

print(''' #13
********************************************************** #14
******************功能:触摸控制例程(function: touch control routine)************************* #15
********************************************************** #16
---------------------------------------------------------- #17
Official website:https://www.hiwonder.com #18
Online mall:https://hiwonder.tmall.com #19
---------------------------------------------------------- #20
Tips: #21
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #22
---------------------------------------------------------- #23
''') #24

# 触摸模块接扩展板上的IO22、IO24接口(connect the touch module to the IO22 and IO24 interfaces on expansion board) #26

PuppyPose = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #28
# stance_x：4条腿在x轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the X-axis, measured in centimeters) #29
# stance_y：4条腿在y轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the Y-axis, measured in centimeters) #30
# x_shift: 4条腿在x轴上同向移动的距离，越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡，单位cm(the distance traveled by the four legs along the x-axis determines the degree of forward or backward tilt during walking: smaller distances lead to more forward tilt, while larger distances result in more backward tilt. Adjusting the x_shift parameter can help maintain balance during the dog's movement, measured in centimeters) #31
# height： 狗的高度，脚尖到大腿转动轴的垂直距离，单位cm(the height of the dog, measured from the toe to the axis  of rotation of the thigh, is in centimeters) #32
# pitch： 狗身体的俯仰角，单位弧度(the pitch angle of the dog's body, measured in radians) #33


GaitConfig = {'overlap_time':0.2, 'swing_time':0.2, 'clearance_time':0.0, 'z_clearance':3} #36
# overlap_time:4脚全部着地的时间，单位秒(the time when all four legs touch the ground, measured in seconds) #37
# swing_time：2脚离地时间，单位秒(the time duration when legs are off the ground, measured in second) #38
# clearance_time：前后脚间隔时间，单位秒(the time interval between the front and rear legs, measured in seconds) #39
# z_clearance：走路时，脚抬高的距离，单位cm(the distance the paw needs to be raised during walking, measured in centimeters) #40


# 触摸模块接扩展板上的IO22、IO24接口(connect the touch module to the IO22 and IO24 interfaces on the expansion board) #43
touch_pin = 22 #44
chip = gpiod.chip("gpiochip0") #45
    
touch = chip.get_line(touch_pin) #47
config = gpiod.line_request() #48
config.consumer = "touch" #49
config.request_type = gpiod.line_request.DIRECTION_INPUT #50
config.flags = gpiod.line_request.FLAG_BIAS_PULL_UP #51
touch.request(config) #52

# 关闭检测函数(close detection function) #54
run_st = True #55
def Stop(): #56
    global run_st #57
    run_st = False #58
    print('关闭中...') #59


if __name__ == '__main__': #62
    # 初始化节点(initialization node) #63
    rospy.init_node('touch_control_demo') #64
    rospy.on_shutdown(Stop) #65
    
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #67
    PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #68
    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #69
    rospy.sleep(0.5) # 延时一会(delay for a moment) #70
    # 机器狗站立(robot dog stands up) #71
    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #72
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #73
    
    rospy.sleep(0.2) #75
    PuppyGaitConfigPub.publish(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #76
                    , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']) #77
    
    
    click = 0 #80
    squat = True #81
    
    while run_st: #83
        state = touch.get_value()   #84
        rospy.sleep(0.05) #85
        if not state: #86
            detect_time = time.time()+1 #87
            while time.time() < detect_time: #88
                state = touch.get_value()   #89
                rospy.sleep(0.1) #90
                if not state: #91
                    click += 1 #92
                    rospy.sleep(0.1)              #93
            #print("click:",click) #94
            if click == 1: #95
                click = 0 #96
                if squat: #97
                    # 机器狗下蹲(the robot dog crouches down) #98
                    PuppyPose = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-6, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #99
                    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #100
                            height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #101
                    rospy.sleep(1) #102
                    squat = False #103
                    
                elif not squat: #105
                    # 机器狗站立(the robot dog stands up) #106
                    PuppyPose = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #107
                    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #108
                            height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #109
                    rospy.sleep(1) #110
                    squat = True #111
                    
            elif click == 2: #113
                click = 0 #114
                # 机器人抖一抖(the robot shakes a little) #115
                for i in range(5): #116
                    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #117
                        height=PuppyPose['height'], roll=math.radians(3.5), pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 50) #118
                    rospy.sleep(0.13) #119
                    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #120
                        height=PuppyPose['height'], roll=math.radians(-3.5), pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 50) #121
                    rospy.sleep(0.13) #122
                
                PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #124
                    height=PuppyPose['height'], roll=math.radians(0), pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 300) #125
                rospy.sleep(1) #126
            else:  #127
                click = 0 #128
       
        
    
