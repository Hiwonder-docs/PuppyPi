#!/usr/bin/env python3 #1
# 第8章 ROS机器狗拓展课程\4.传感器开发课程\第2课 机器狗超声波测距避障(8.ROS Robot Expanded Course\4.Sensor Development Course\Lesson 2 Robot Dog Ultrasonic Distance Measurement and Obstacle Avoidance) #2
import os #3
import sys #4
import math #5
import rospy #6
import sensor.Sonar as Sonar #7
from puppy_control.msg import Velocity, Pose, Gait #8

print(''' #10
********************************************************** #11
********************功能:超声波避障例程(function: ultrasonic obstacle avoidance routine)********************** #12
********************************************************** #13
---------------------------------------------------------- #14
Official website:https://www.hiwonder.com #15
Online mall:https://hiwonder.tmall.com #16
---------------------------------------------------------- #17
Tips: #18
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #19
---------------------------------------------------------- #20
''') #21

if sys.version_info.major == 2: #23
    print('Please run this program with python3!') #24
    sys.exit(0) #25

PuppyPose = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #27
# stance_x：4条腿在x轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the X-axis, measured in centimeters) #28
# stance_y：4条腿在y轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the Y-axis, measured in centimeters) #29
# x_shift: 4条腿在x轴上同向移动的距离，越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡，单位cm(the distance traveled by the four legs along the x-axis determines the degree of forward or backward tilt during walking: smaller distances lead to more forward tilt, while larger distances result in more backward tilt. Adjusting the x_shift parameter can help maintain balance during the dog's movement, measured in centimeters) #30
# height： 狗的高度，脚尖到大腿转动轴的垂直距离，单位cm(the height of the dog, measured from the toe to the axis  of rotation of the thigh, is in centimeters) #31
# pitch： 狗身体的俯仰角，单位弧度(the pitch angle of the dog's body, measured in radians) #32


GaitConfig = {'overlap_time':0.15, 'swing_time':0.2, 'clearance_time':0.0, 'z_clearance':3} #35
# overlap_time:4脚全部着地的时间，单位秒(the time when all four legs touch the ground, measured in seconds) #36
# swing_time：2脚离地时间，单位秒(the time duration when legs are off the ground, measured in second) #37
# clearance_time：前后脚间隔时间，单位秒(the time interval between the front and rear legs, measured in seconds) #38
# z_clearance：走路时，脚抬高的距离，单位cm(the distance the paw needs to be raised during walking, measured in centimeters) #39

# 关闭检测函数(close detection function) #41
run_st = True #42
def Stop(): #43
    global run_st #44
    run_st = False #45
    PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #46
    print('关闭中...') #47
    

if __name__ == '__main__': #50
    s = Sonar.Sonar() #51
    s.setRGBMode(0) # 0:彩灯模块,1:呼吸灯模式(0:color light mode, 1:breathing light mode) #52
    s.setRGB(1, (0, 0, 0)) # 关闭RGB灯(turn off RGB light) #53
    s.setRGB(0, (0, 0, 0)) #54
    
    # 初始化节点(initialization node) #56
    rospy.init_node('Sonar_avoidance') #57
    rospy.on_shutdown(Stop) #58
    
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #60
    PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #61
    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #62
    rospy.sleep(0.2) #63
    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #64
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #65
    
    rospy.sleep(0.2) #67
    PuppyGaitConfigPub.publish(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #68
                    , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']) #69
    
    forward = True #71
    
    while run_st: #73
        rospy.sleep(0.1) #74
        distance = s.getDistance() # 获得检测的距离(obtain detected distance) #75
        print('distance: {}(mm)'.format(distance)) #76
        if distance <= 300: # 距离小于300mm(distance is less than 300 millimeters) #77
            if not forward: #78
                forward = True #79
                s.setRGB(1, (255, 0, 0)) # 设为红色(set to red color) #80
                s.setRGB(0, (255, 0, 0)) #81
                PuppyVelocityPub.publish(x=5, y=0, yaw_rate=0.3) # 左转(turn left) #82
                rospy.sleep(6) #83
            
        else: #85
            if forward: #86
                forward = False #87
                s.setRGB(1, (0, 0, 255)) # 设为蓝色(set to blue) #88
                s.setRGB(0, (0, 0, 255)) #89
                PuppyVelocityPub.publish(x=15, y=0, yaw_rate=0) # 前进(move forward) #90
            
    s.setRGB(1, (0, 0, 0)) #92
    s.setRGB(0, (0, 0, 0)) #93
