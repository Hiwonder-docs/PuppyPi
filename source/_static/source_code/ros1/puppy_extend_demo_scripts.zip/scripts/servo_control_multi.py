#!/usr/bin/env python3 #1
# coding=utf8 #2
import sys #3
import time #4
import signal #5
HomePath = '/home/pi' #6
sys.path.append(HomePath + '/PuppyPi_PC_Software') #7
from PWMServoControl import * #8

# 控制多个舵机(control multiple servos) #10

print(''' #12
********************************************************** #13
*****************功能:多个舵机控制例程(function: multiple servo control routine)*********************** #14
********************************************************** #15
---------------------------------------------------------- #16
Official website:https://www.hiwonder.com #17
Online mall:https://hiwonder.tmall.com #18
---------------------------------------------------------- #19
Tips: #20
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #21
---------------------------------------------------------- #22
''') #23

# 关闭检测函数(close detection function) #25
run_st = True #26
def Stop(signum, frame): #27
    global run_st #28
    run_st = False #29
    print('关闭中...') #30

signal.signal(signal.SIGINT, Stop) #32

if __name__ == '__main__': #34
    servo = PWMServo() #35
    
    while run_st: #37
        servo.setPulse(1,1000,2000) # 驱动1号舵机(drive servo No.1) #38
        servo.setPulse(3,2000,2000) # 驱动3号舵机(drive servo No.3) #39
        time.sleep(2) # 延时(delay) #40
        servo.setPulse(1,2000,2000) # 驱动1号舵机(drive servo No.1) #41
        servo.setPulse(3,1000,2000) # 驱动3号舵机(drive servo No.3) #42
        time.sleep(2) # 延时(delay) #43
    
    servo.setPulse(1,1500,2000) #45
    servo.setPulse(3,1500,2000) #46
    
