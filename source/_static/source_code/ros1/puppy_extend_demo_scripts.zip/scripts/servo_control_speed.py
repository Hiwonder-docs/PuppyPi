#!/usr/bin/env python3 #1
# coding=utf8 #2
# 第8章 ROS机器狗拓展课程\3.空心杯舵机控制课程\第3课 控制舵机速度(8.ROS Robot Expanded Course\3.Hollow Cup Servo Control Course\Lesson 3 Control Servo Speed) #3
import sys #4
import time #5
import signal #6
sys.path.append('/home/ubuntu/software/puppypi_control') #7
from ros_robot_controller_sdk import Board #8
from pwm_servo_control import PWMServoControl #9

# 控制舵机速度(control servo speed) #11

print(''' #13
********************************************************** #14
*****************功能:舵机速度控制例程(function: servo speed control routine)*********************** #15
********************************************************** #16
---------------------------------------------------------- #17
Official website:https://www.hiwonder.com #18
Online mall:https://hiwonder.tmall.com #19
---------------------------------------------------------- #20
Tips: #21
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #22
---------------------------------------------------------- #23
''') #24

# 关闭检测函数(close detection function) #26
run_st = True #27
def Stop(signum, frame): #28
    global run_st #29
    run_st = False #30
    print('关闭中...') #31

signal.signal(signal.SIGINT, Stop) #33

if __name__ == '__main__': #35
    board = Board() #36
    servo = PWMServoControl(board) #37
    
    while run_st: #39
        servo.setPulse(1,1500,1000) # 驱动1号舵机(drive servo No.1) #40
        time.sleep(1) # 延时(delay) #41
        servo.setPulse(1,2500,1000) # 驱动1号舵机(drive servo No.1) #42
        time.sleep(2) # 延时(delay) #43
        servo.setPulse(1,1500,1000) # 驱动1号舵机(drive servo No.1) #44
        time.sleep(2) # 延时(delay) #45
        servo.setPulse(1,500,500) # 驱动1号舵机(drive servo No.1) #46
        time.sleep(1) # 延时(delay) #47
    
    servo.setPulse(1,1500,2000) #49
    
