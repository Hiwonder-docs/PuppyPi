import os #1
import sys #2
import rospy #3
import math #4
import serial #5
from std_msgs.msg import * #6
from puppy_control.msg import Velocity, Pose, Gait #7

print(''' #9
********************************************************** #10
******************功能:语音交互例程(function: voice interaction routine)************************* #11
********************************************************** #12
---------------------------------------------------------- #13
Official website:https://www.hiwonder.com #14
Online mall:https://hiwonder.tmall.com #15
---------------------------------------------------------- #16
Tips: #17
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #18
---------------------------------------------------------- #19
''') #20

# Initialize robot dog's posture and gait configuration.（初始化机器狗的姿态和步态配置） #22
PuppyPose = {'roll': math.radians(0), 'pitch': math.radians(0), 'yaw': 0.000, 'height': -10, 'x_shift': -0.5, 'stance_x': 0, 'stance_y': 0} #23
GaitConfig = {'overlap_time': 0.2, 'swing_time': 0.2, 'clearance_time': 0.0, 'z_clearance': 3} #24

# Stop function.（停止函数） #26
run_st = True #27
def Stop(): #28
    global run_st #29
    run_st = False #30
    print('关闭中...') #31

# Parse serial data.（解析串口数据） #33
def parse_serial_data(data): #34
    # Convert byte data to hexadecimal string.（将字节数据转换为十六进制字符串） #35
    hex_data = ' '.join(format(byte, '02X') for byte in data) #36
    print(f"Received data: {hex_data}") #37

    # Execute corresponding actions based on different commands.（根据不同的指令执行相应的动作） #39
    if hex_data == "AA 55 00 76 FB":  # March in place.（原地踏步） #40
        print("执行原地踏步") #41
        PuppyPose = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #42
        PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'],height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #43
        rospy.sleep(0.5) #44
        PuppyVelocityPub.publish(x=0.1, y=0, yaw_rate=0) #45
        rospy.sleep(2) #46
        PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #47

    elif hex_data == "AA 55 00 0A FB":  # Stand at attention.（立正） #49
        print("执行立正") #50
        PuppyPose = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #51
        PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'],height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #52
    elif hex_data == "AA 55 00 0B FB":  # Lie down.（趴下） #53
        print("执行趴下") #54
        PuppyPose = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-6, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #55
        PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'],height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #56

    elif hex_data == "AA 55 00 8D FB":  # （抬头） #58
        print("执行抬头") #59
        PuppyPose = {'roll':math.radians(0), 'pitch':math.radians(20), 'yaw':0.000, 'height':-10, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #60
        PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'],height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #61

    elif hex_data == "AA 55 00 09 FB":  # Stop.（停止） #63
        print("停止识别") #64
        PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #65
        global run_st #66
        run_st = False #67

if __name__ == "__main__": #69
    # Initialize ROS node.（初始化 ROS 节点） #70
    rospy.init_node('voice_interaction_demo') #71
    rospy.on_shutdown(Stop) #72

    # Initialize publisher.（发布器初始化） #74
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #75
    PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #76
    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #77

    rospy.sleep(0.5) #79

    # Robot dog stands.（机器狗站立） #81
    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'], #82
                         height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time=500) #83
    rospy.sleep(0.2) #84
    PuppyGaitConfigPub.publish(overlap_time=GaitConfig['overlap_time'], swing_time=GaitConfig['swing_time'], #85
                               clearance_time=GaitConfig['clearance_time'], z_clearance=GaitConfig['z_clearance']) #86

    ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1) #88

    while run_st: #90
        # Read and parse all serial port data.（读取所有串口数据并解析） #91
        if ser.in_waiting > 0: #92
            data = ser.read_all()  # Read all available data.（读取所有可用数据） #93
            parse_serial_data(data)  # Parse data.（解析数据） #94
        rospy.sleep(0.1) #95
