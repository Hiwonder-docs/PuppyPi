#!/usr/bin/env python3 #1
# coding=utf-8 #2

import os #4
import time #5
import rospy #6
import serial #7
import binascii #8
from std_srvs.srv import Trigger #9
from std_msgs.msg import String, Bool #10
from ros_robot_controller.msg import RGBState, RGBsState #11

print(''' #13
********************************************************** #14
*******************功能:语音识别例程(function: voice recognition routine)************************ #15
********************************************************** #16
---------------------------------------------------------- #17
Official website:https://www.hiwonder.com #18
Online mall:https://hiwonder.tmall.com #19
---------------------------------------------------------- #20
Tips: #21
    * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close the program, please try multiple times if fail) #22
---------------------------------------------------------- #23
''') #24

def turn_off_rgb(): #26
    led1 = RGBState() #27
    led1.id = 1 #28
    led1.r = 0 #29
    led1.g = 0 #30
    led1.b = 0 #31
    led2 = RGBState() #32
    led2.id = 2 #33
    led2.r = 0 #34
    led2.g = 0 #35
    led2.b = 0 #36
    msg = RGBsState() #37
    msg.data = [led1, led2] #38
    rgb_pub.publish(msg) #39
    rospy.sleep(0.01) #40

def set_rgb_show(r, g, b): #42
    led1 = RGBState() #43
    led1.id = 1 #44
    led1.r = r #45
    led1.g = g #46
    led1.b = b #47
    led2 = RGBState() #48
    led2.id = 2 #49
    led2.r = r #50
    led2.g = g #51
    led2.b = b #52
    msg = RGBsState() #53
    msg.data = [led1, led2] #54
    rgb_pub.publish(msg) #55
    rospy.sleep(0.01) #56


run_st = True #59
def Stop(): #60
    global run_st #61
    run_st = False #62
    turn_off_rgb() #63
    print("关闭中...") #64

def parse_serial_data(data): #66
    hex_data = ' '.join(format(byte, '02X') for byte in data) #67
    print(f"Received data: {hex_data}") #68

    if hex_data == "AA 55 00 8A FB":  # Red light(红灯) #70
        set_rgb_show(255, 0, 0)  # Red（红色) #71
    elif hex_data == "AA 55 00 8B FB":  # Green light（绿灯) #72
        set_rgb_show(0, 255, 0)  # Green（绿色) #73
    elif hex_data == "AA 55 00 8C FB":  # Blue light（蓝灯） #74
        set_rgb_show(0, 0, 255)  # Blue（蓝色） #75
    elif hex_data == "AA 55 00 09 FB":  # Stop（停止） #76
        set_rgb_show(0, 0, 0)   #77
        print("停止识别") #78
        global run_st #79
        run_st = False #80

if __name__ == "__main__": #82
    ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1) #83
    rospy.init_node('ASR_detect_demo') #84
    rospy.on_shutdown(Stop) #85
    rgb_pub = rospy.Publisher('/ros_robot_controller/set_rgb', RGBsState, queue_size=1) #86
    rospy.sleep(0.2)   #87

    while run_st: #89
        if ser.in_waiting > 0: #90
            data = ser.read(5)   #91
            parse_serial_data(data) #92
        rospy.sleep(0.1) #93
