#!/usr/bin/env python #1
# -*- coding: utf-8 -*- #2

""" #4
MediaPipePoseNode ROS  #5

Pose detection using MediaPipe, and control four servos based on the result. Each servo is equipped with a PID controller.（MediaPipe 进行姿态检测，并根据检测结果控制四个舵机。每个舵机都配备了一个 PID 控制器） #7
""" #8

import rospy #10
from sensor_msgs.msg import Image #11
from cv_bridge import CvBridge #12
import cv2 #13
import mediapipe as mp #14
import time #15
import signal #16
import sys #17
import math #18
import threading #19
import queue #20
from collections import deque #21
from enum import Enum #22
from dataclasses import dataclass, field #23

sys.path.append('/home/ubuntu/software/puppypi_control') #25

from puppy_control.msg import Velocity, Pose, Gait, SetServo #27
from ros_robot_controller_sdk import Board #28
from pwm_servo_control import PWMServoControl #29
from ros_robot_controller.msg import BuzzerState  #30
from puppy_control.srv import SetRunActionName #31
from action_group_control import runActionGroup, stopActionGroup #32
from std_srvs.srv import Empty   #33


class Landmark(Enum): #36
    NOSE = 0 #37
    LEFT_SHOULDER = 11 #38
    RIGHT_SHOULDER = 12 #39
    LEFT_ELBOW = 13 #40
    RIGHT_ELBOW = 14 #41
    LEFT_WRIST = 15 #42
    RIGHT_WRIST = 16 #43
    LEFT_HIP = 23 #44
    RIGHT_HIP = 24 #45


class PID: #48
    """PID Controller""" #49

    def __init__(self, P=1.0, I=0.05, D=0.01): #51
        self.Kp = P #52
        self.Ki = I #53
        self.Kd = D #54

        self.sample_time = 0.00 #56
        self.current_time = time.time() #57
        self.last_time = self.current_time #58

        self.clear() #60

    def clear(self): #62
        """Clears PID computations and coefficients""" #63
        self.SetPoint = 0.0 #64

        self.PTerm = 0.0 #66
        self.ITerm = 0.0 #67
        self.DTerm = 0.0 #68
        self.last_error = 0.0 #69

        # Windup Guard #71
        self.int_error = 0.0 #72
        self.windup_guard = 20.0 #73

        self.output = 0.0 #75

    def update(self, feedback_value): #77
        """Calculates PID value for given reference feedback""" #78
        error = self.SetPoint - feedback_value #79

        self.current_time = time.time() #81
        delta_time = self.current_time - self.last_time #82
        delta_error = error - self.last_error #83

        if delta_time >= self.sample_time: #85
            self.PTerm = self.Kp * error #86
            self.ITerm += error * delta_time #87

            if self.ITerm < -self.windup_guard: #89
                self.ITerm = -self.windup_guard #90
            elif self.ITerm > self.windup_guard: #91
                self.ITerm = self.windup_guard #92

            self.DTerm = 0.0 #94
            if delta_time > 0: #95
                self.DTerm = delta_error / delta_time #96

            self.last_time = self.current_time #98
            self.last_error = error #99

            self.output = self.PTerm + (self.Ki * self.ITerm) + (self.Kd * self.DTerm) #101

    def setKp(self, proportional_gain): #103
        self.Kp = proportional_gain #104

    def setKi(self, integral_gain): #106
        self.Ki = integral_gain #107

    def setKd(self, derivative_gain): #109
        self.Kd = derivative_gain #110

    def setWindup(self, windup): #112
        """Sets the windup guard""" #113
        self.windup_guard = windup #114

    def setSampleTime(self, sample_time): #116
        """Sets the sample time""" #117
        self.sample_time = sample_time #118


@dataclass #121
class Servo: #122
    name: str #123
    channel: int #124
    angle_min: int #125
    angle_max: int #126
    pulse_min: int #127
    pulse_max: int #128
    initial_pulse: int #129
    invert: bool = False #130
    pid: PID = field(default_factory=lambda: PID()) #131
    current_pulse: int = field(init=False) #132
    pulse_queue: queue.Queue = field(default_factory=lambda: queue.Queue(maxsize=10)) #133

    def __post_init__(self): #135
        self.current_pulse = self.initial_pulse #136


class MediaPipePoseNode: #139
    """MediaPipePoseNode ROS 节点""" #140

    def __init__(self): #142
        # Initialize the ROS node.（初始化 ROS 节点） #143
        rospy.init_node('mediapipe_pose_node', anonymous=True) #144
        runActionGroup('demo.d6ac', True) #145
        # Read parameters.（读取参数） #146
        self.scale_percent = rospy.get_param('~scale_percent', 50)   #147
        self.alpha = rospy.get_param('~alpha', 0.2)   #148

        # Initialize CvBridge.（初始化 CvBridge） #150
        self.bridge = CvBridge() #151

        # Initialize MediaPipe Pose.（初始化 MediaPipe Pose） #153
        self.mp_pose = mp.solutions.pose #154
        self.pose = self.mp_pose.Pose( #155
            static_image_mode=False, #156
            model_complexity=1, #157
            smooth_landmarks=True, #158
            min_detection_confidence=0.5, #159
            min_tracking_confidence=0.5 #160
        ) #161
        self.mp_drawing = mp.solutions.drawing_utils #162

        # Initialize the servo controller.（初始化舵机控制器） #164
        self.board = Board() #165
        self.servo_controller = PWMServoControl(self.board) #166


        self.servos = { #169
            'left_upper': Servo( #170
                name='left_upper', #171
                channel=1, #172
                angle_min=60, #173
                angle_max=120, #174
                pulse_min=862, #175
                pulse_max=1966, #176
                initial_pulse=1011, #177
                invert=True, #178
                pid=PID(P=1.0, I=0.05, D=0.01) #179
            ), #180
            'left_forearm': Servo( #181
                name='left_forearm', #182
                channel=2, #183
                angle_min=90, #184
                angle_max=180, #185
                pulse_min=953, #186
                pulse_max=1818, #187
                initial_pulse=862, #188
                invert=False, #189
                pid=PID(P=1.0, I=0.05, D=0.01) #190
            ), #191
            'right_upper': Servo( #192
                name='right_upper', #193
                channel=3, #194
                angle_min=60, #195
                angle_max=120, #196
                pulse_min=981, #197
                pulse_max=2138, #198
                initial_pulse=1989, #199
                invert=False, #200
                pid=PID(P=1.0, I=0.05, D=0.01) #201
            ), #202
            'right_forearm': Servo( #203
                name='right_forearm', #204
                channel=4, #205
                angle_min=90, #206
                angle_max=180, #207
                pulse_min=1253, #208
                pulse_max=2288, #209
                initial_pulse=1989, #210
                invert=True, #211
                pid=PID(P=1.0, I=0.05, D=0.01) #212
            ) #213
        } #214

        # Initialize servo pulse widths.（初始化舵机脉冲宽度） #216
        for servo in self.servos.values(): #217
            self.servo_controller.setPulse(servo.channel, servo.initial_pulse, 350) #218

        # Initialize publishers and services.（初始化发布者和服务） #220
        self.buzzer_pub = rospy.Publisher('/ros_robot_controller/set_buzzer', BuzzerState, queue_size=10) #221
        self.run_action_group_srv = rospy.ServiceProxy('/puppy_control/runActionGroup', SetRunActionName) #222
        self.PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #223
        self.PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #224
        self.PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #225

        # Subscribe to the camera image topic.（订阅摄像头图像话题） #227
        self.image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, self.image_callback) #228

        self.play_mode = False #230
        self.stop_event = threading.Event() #231

        self.display_queue = queue.Queue(maxsize=10) #233

        # Initialize threads.（初始化线程） #235
        self.servo_threads = [] #236
        for servo in self.servos.values(): #237
            t = threading.Thread(target=self.servo_control_thread, args=(servo,), name=f"{servo.name}_ControlThread") #238
            t.start() #239
            self.servo_threads.append(t) #240

        self.display_thread = threading.Thread(target=self.image_display_thread, name="ImageDisplayThread") #242
        self.display_thread.start() #243

        # Initialize current pulse widths.（初始化当前脉冲宽度） #245
        for servo in self.servos.values(): #246
            servo.current_pulse = servo.initial_pulse #247

        self.angle_history = { #249
            'left_upper': deque(maxlen=5), #250
            'right_upper': deque(maxlen=5), #251
            'left_forearm': deque(maxlen=5), #252
            'right_forearm': deque(maxlen=5) #253
        } #254

        # Filtered angles.（过滤后的角度） #256
        self.filtered_angles = { #257
            'left_upper': None, #258
            'right_upper': None, #259
            'left_forearm': None, #260
            'right_forearm': None #261
        } #262

        # History of hand-cross detection.（手部交叉检测历史） #264
        self.hands_crossed_history = deque(maxlen=10)   #265

        rospy.loginfo("MediaPipePoseNode 初始化完成。") #267

    def convert_landmarks_to_pixels(self, img, landmarks): #269
        """Convert MediaPipe keypoints to pixel coordinates.（将 MediaPipe 关键点转换为像素坐标）""" #270
        img_height, img_width, _ = img.shape #271
        return [(int(lm.x * img_width), int(lm.y * img_height)) for lm in landmarks] #272

    def is_T_pose(self, pixel_landmarks): #274
        """Determine if it's a T-pose.（判断是否为 T 姿势）""" #275
        try: #276
            left_shoulder = pixel_landmarks[Landmark.LEFT_SHOULDER.value] #277
            right_shoulder = pixel_landmarks[Landmark.RIGHT_SHOULDER.value] #278
            left_elbow = pixel_landmarks[Landmark.LEFT_ELBOW.value] #279
            right_elbow = pixel_landmarks[Landmark.RIGHT_ELBOW.value] #280
            left_wrist = pixel_landmarks[Landmark.LEFT_WRIST.value] #281
            right_wrist = pixel_landmarks[Landmark.RIGHT_WRIST.value] #282
        except IndexError: #283
            rospy.logwarn("检测到的关键点数量不足以判断 T 姿势。") #284
            return False #285

        angle_threshold = 20 #287
        horizontal_threshold = 20 #288

        left_arm_angle = self.calculate_angle(left_shoulder, left_elbow, left_wrist) #290
        right_arm_angle = self.calculate_angle(right_shoulder, right_elbow, right_wrist) #291

        rospy.logdebug(f"左前臂角度: {left_arm_angle:.2f} 度") #293
        rospy.logdebug(f"右前臂角度: {right_arm_angle:.2f} 度") #294

        left_straight = abs(left_arm_angle - 180) < angle_threshold #296
        right_straight = abs(right_arm_angle - 180) < angle_threshold #297

        left_horizontal = self.is_horizontal(left_shoulder, left_wrist, horizontal_threshold) #299
        right_horizontal = self.is_horizontal(right_shoulder, right_wrist, horizontal_threshold) #300

        return left_straight and right_straight and left_horizontal and right_horizontal #302

    def is_hands_crossed_on_chest(self, pixel_landmarks): #304
        """Detect whether hands are crossed in front of the chest.（判断双手是否交叉抱胸）""" #305
        try: #306
            nose = pixel_landmarks[Landmark.NOSE.value] #307
            left_shoulder = pixel_landmarks[Landmark.LEFT_SHOULDER.value] #308
            right_shoulder = pixel_landmarks[Landmark.RIGHT_SHOULDER.value] #309
            left_elbow = pixel_landmarks[Landmark.LEFT_ELBOW.value] #310
            right_elbow = pixel_landmarks[Landmark.RIGHT_ELBOW.value] #311
            left_wrist = pixel_landmarks[Landmark.LEFT_WRIST.value] #312
            right_wrist = pixel_landmarks[Landmark.RIGHT_WRIST.value] #313
            left_hip = pixel_landmarks[Landmark.LEFT_HIP.value] #314
            right_hip = pixel_landmarks[Landmark.RIGHT_HIP.value] #315
        except IndexError: #316
            rospy.logwarn("检测到的关键点数量不足以判断双手交叉抱胸。") #317
            return False #318

        # Define the chest region.（定义胸部区域） #320
        chest_upper = nose[1] #321
        chest_lower = min(left_shoulder[1], right_shoulder[1]) + 50 #322

        # Check whether the wrists are in the chest region.（检查手腕是否位于胸部区域） #324
        left_wrist_in_chest = chest_upper < left_wrist[1] < chest_lower #325
        right_wrist_in_chest = chest_upper < right_wrist[1] < chest_lower #326

        rospy.logdebug(f"左手腕位于胸部区域: {left_wrist_in_chest}") #328
        rospy.logdebug(f"右手腕位于胸部区域: {right_wrist_in_chest}") #329

        if not (left_wrist_in_chest and right_wrist_in_chest): #331
            self.hands_crossed_history.append(False) #332
            return False #333

        # Check wrist position relative to shoulders.（检查手腕相对于肩膀的位置） #335
        left_wrist_right_of_right_shoulder = left_wrist[0] > right_shoulder[0] #336
        right_wrist_left_of_left_shoulder = right_wrist[0] < left_shoulder[0] #337

        rospy.logdebug(f"左手腕位于右肩膀的右侧: {left_wrist_right_of_right_shoulder}") #339
        rospy.logdebug(f"右手腕位于左肩膀的左侧: {right_wrist_left_of_left_shoulder}") #340

        if not (left_wrist_right_of_right_shoulder and right_wrist_left_of_left_shoulder): #342
            self.hands_crossed_history.append(False) #343
            return False #344

        # Calculate elbow angles.（计算肘部角度） #346
        left_elbow_angle = self.calculate_angle(left_wrist, left_elbow, left_shoulder) #347
        right_elbow_angle = self.calculate_angle(right_wrist, right_elbow, right_shoulder) #348

        elbow_angle_threshold = 50 #350
        elbows_bent = left_elbow_angle < elbow_angle_threshold and right_elbow_angle < elbow_angle_threshold #351

        rospy.logdebug(f"左肘弯曲角度: {left_elbow_angle:.2f} 度") #353
        rospy.logdebug(f"右肘弯曲角度: {right_elbow_angle:.2f} 度") #354

        if not elbows_bent: #356
            self.hands_crossed_history.append(False) #357
            return False #358

        hands_distance = abs(left_wrist[0] - right_wrist[0]) #360
        hands_distance_threshold = 100  # Pixels.（像素） #361

        rospy.logdebug(f"双手水平距离: {hands_distance} 像素") #363
        rospy.logdebug(f"双手水平距离阈值: {hands_distance_threshold} 像素") #364

        hands_close = hands_distance < hands_distance_threshold #366

        if hands_close and elbows_bent and left_wrist_right_of_right_shoulder and right_wrist_left_of_left_shoulder and left_wrist_in_chest and right_wrist_in_chest: #368
            self.hands_crossed_history.append(True) #369
            # Check history to confirm hand crossing is detected across multiple frames.（检查历史记录，确保连续多帧检测到双手交叉） #370
            if self.hands_crossed_history.count(True) >= 5: #371
                return True #372
        else: #373
            self.hands_crossed_history.append(False) #374

        return False #376

    def is_horizontal(self, shoulder, wrist, threshold): #378
        """Determine if wrists are level.（判断手腕是否水平）""" #379
        vertical_diff = abs(shoulder[1] - wrist[1]) #380
        return vertical_diff < threshold #381

    @staticmethod #383
    def calculate_angle(a, b, c): #384
        """ #385
        Calculate the angle at point b, where points a, b, c have (x, y) coordinates.（计算点 b 处的夹角，点 a, b, c 坐标为 (x, y)） #386
        """ #387
        try: #388
            vector1 = (a[0] - b[0], a[1] - b[1]) #389
            vector2 = (c[0] - b[0], c[1] - b[1]) #390

            len1 = math.hypot(*vector1) #392
            len2 = math.hypot(*vector2) #393

            if len1 == 0 or len2 == 0: #395
                return 0.0 #396

            dot = vector1[0] * vector2[0] + vector1[1] * vector2[1] #398
            angle = math.acos(max(min(dot / (len1 * len2), 1.0), -1.0)) * (180.0 / math.pi) #399
            return angle #400
        except Exception as e: #401
            rospy.logwarn(f"计算角度时出错: {e}") #402
            return 0.0 #403

    def calculate_shoulder_angle(self, shoulder, elbow, neck): #405
        """Calculate shoulder angle.（计算肩部角度）""" #406
        return self.calculate_angle(elbow, shoulder, neck) #407

    def apply_low_pass_filter(self, servo_name, new_angle): #409
        """Apply a low-pass filter to smooth the angle.（应用低通滤波器平滑角度）""" #410
        if self.filtered_angles[servo_name] is None: #411
            self.filtered_angles[servo_name] = new_angle #412
        else: #413
            self.filtered_angles[servo_name] = self.alpha * new_angle + (1 - self.alpha) * self.filtered_angles[servo_name] #414
        rospy.logdebug(f"{servo_name} 滤波后的角度: {self.filtered_angles[servo_name]:.2f} 度") #415
        return self.filtered_angles[servo_name] #416

    def map_arm_angle_to_pulse(self, angle, servo: Servo): #418
        """ #419
        Map angles to pulse widths.（将角度映射到脉冲宽度） #420
        """ #421
        # Limit angles within the servo’s valid range.（限制角度在伺服的范围内） #422
        clamped_angle = max(servo.angle_min, min(servo.angle_max, angle)) #423

        if servo.invert: #425
            clamped_angle = servo.angle_max - (clamped_angle - servo.angle_min) #426

        # Linearly map angle to pulse width.（线性映射角度到脉冲宽度） #428
        pulse = ((clamped_angle - servo.angle_min) / (servo.angle_max - servo.angle_min)) * \ #429
                (servo.pulse_max - servo.pulse_min) + servo.pulse_min #430
        pulse = int(round(pulse)) #431

        # Clamp pulse width to valid range.（限制脉冲在有效范围内） #433
        pulse = max(servo.pulse_min, min(servo.pulse_max, pulse)) #434

        rospy.logdebug(f"将角度 {angle:.2f}° 映射到脉冲 {pulse}μs（伺服通道 {servo.channel}）") #436
        return pulse #437

    def servo_control_thread(self, servo: Servo): #439
        """Independent servo control thread.（独立的舵机控制线程）""" #440
        rospy.loginfo(f"{servo.name} 控制线程启动。") #441
        while not self.stop_event.is_set(): #442
            try: #443
                target_pulse = servo.pulse_queue.get(timeout=0.1) #444
                self.smooth_pulse_transition(servo, target_pulse) #445
            except queue.Empty: #446
                continue #447
            except Exception as e: #448
                rospy.logerr(f"{servo.name} 控制线程出错: {e}") #449
        rospy.loginfo(f"{servo.name} 控制线程停止。") #450

    def smooth_pulse_transition(self, servo: Servo, target_pulse: int): #452
        """ #453
        Smoothly transition current pulse to target pulse.（平滑地将当前脉冲宽度过渡到目标脉冲宽度） #454
        """ #455
        step = 10  # Increase step size.（增大步进值） #456
        delay = 0.001  # Decrease delay time in seconds.（减少延迟时间（秒））减少延迟时间（秒） #457

        while abs(servo.current_pulse - target_pulse) > step and not self.stop_event.is_set(): #459
            if servo.current_pulse < target_pulse: #460
                servo.current_pulse += step #461
            else: #462
                servo.current_pulse -= step #463
            # Ensure pulse width does not exceed range.（确保脉冲宽度不超出范围） #464
            servo.current_pulse = max(servo.pulse_min, min(servo.pulse_max, servo.current_pulse)) #465
            self.servo_controller.setPulse(servo.channel, servo.current_pulse, int(delay * 1000)) #466
            rospy.logdebug(f"{servo.name} 调整到脉冲 {servo.current_pulse}μs") #467
            time.sleep(delay) #468

        # Set final pulse width.（设置最终脉冲宽度） #470
        servo.current_pulse = target_pulse #471
        self.servo_controller.setPulse(servo.channel, servo.current_pulse, int(delay * 1000)) #472
        rospy.logdebug(f"{servo.name} 最终设置到脉冲 {servo.current_pulse}μs") #473

    def image_display_thread(self): #475
        """Image display thread.（图像显示线程）""" #476
        rospy.loginfo("图像显示线程启动。") #477
        while not self.stop_event.is_set(): #478
            try: #479
                cv_image = self.display_queue.get(timeout=0.1) #480
                cv2.imshow("MediaPipe Pose", cv_image) #481
                if cv2.waitKey(1) & 0xFF == ord('q'): #482
                    rospy.loginfo("按下 'q' 键，关闭窗口并退出。") #483
                    self.stop_all() #484
            except queue.Empty: #485
                continue #486
            except Exception as e: #487
                rospy.logerr(f"图像显示线程出错: {e}") #488
        cv2.destroyAllWindows() #489
        rospy.loginfo("图像显示线程停止。") #490

    def image_callback(self, msg): #492
        """Image callback function.（图像回调函数）""" #493
        try: #494
            # Convert ROS image message to OpenCV image.（将 ROS 图像消息转换为 OpenCV 图像） #495
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8') #496

            width = int(cv_image.shape[1] * self.scale_percent / 100) #498
            height = int(cv_image.shape[0] * self.scale_percent / 100) #499
            cv_image = cv2.resize(cv_image, (width, height), interpolation=cv2.INTER_AREA) #500

            # Convert to RGB and process using MediaPipe.（转换为 RGB 并使用 MediaPipe 处理） #502
            rgb_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB) #503
            results = self.pose.process(rgb_image) #504

            if results.pose_landmarks: #506
                self.mp_drawing.draw_landmarks(cv_image, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS) #507
                pixel_landmarks = self.convert_landmarks_to_pixels(cv_image, results.pose_landmarks.landmark) #508

                if not self.play_mode: #510
                    if self.is_T_pose(pixel_landmarks): #511
                        self.enter_play_mode() #512
                else: #513
                    self.process_play_mode(pixel_landmarks) #514
                try: #515
                    self.display_queue.put_nowait(cv_image) #516
                except queue.Full: #517
                    rospy.logwarn("图像显示队列已满，丢弃当前帧。") #518
        except Exception as e: #519
            rospy.logerr(f"处理图像时出错: {e}") #520

    def enter_play_mode(self): #522
        """Enter gameplay mode.（进入玩法模式）""" #523
        self.play_mode = True #524
        rospy.loginfo("T-pose detected. Entering play mode.") #525
        rospy.logdebug("T-pose detected. Entering play mode.") #526

        desired_set_point = { #528
            'left_upper': 90,      #529
            'right_upper': 90,     #530
            'left_forearm': 135,    #531
            'right_forearm': 135  #532
        } #533

        # Set target point for PID controller.（设置 PID 控制器的目标点） #535
        for servo_name, set_point in desired_set_point.items(): #536
            self.servos[servo_name].pid.SetPoint = set_point #537

        buzzer_msg = BuzzerState(freq=2400, on_time=0.1, off_time=0.9, repeat=1) #539
        self.buzzer_pub.publish(buzzer_msg) #540

    def exit_play_mode(self): #542
        """Exit gameplay mode.（退出玩法模式）""" #543
        self.play_mode = False #544
        rospy.loginfo("Exiting play mode.") #545
        rospy.logdebug("Exiting play mode.") #546

        # Execute action group.（执行动作组） #548
        try: #549
            runActionGroup('stand.d6a', True) #550
            rospy.loginfo("已执行退出玩法模式的动作组 'stand.d6a'。") #551
        except Exception as e: #552
            rospy.logerr(f"执行退出玩法模式动作组时出错: {e}") #553

        buzzer_msg_exit = BuzzerState(freq=2000, on_time=0.2, off_time=0.8, repeat=1) #555
        self.buzzer_pub.publish(buzzer_msg_exit) #556

    def process_play_mode(self, pixel_landmarks): #558
        """Handle servo control during gameplay mode.（处理玩法模式下的舵机控制）""" #559
        try: #560
            # Extract relevant keypoints.（提取相关关键点） #561
            nose = pixel_landmarks[Landmark.NOSE.value] #562
            left_shoulder = pixel_landmarks[Landmark.LEFT_SHOULDER.value] #563
            right_shoulder = pixel_landmarks[Landmark.RIGHT_SHOULDER.value] #564
            left_elbow = pixel_landmarks[Landmark.LEFT_ELBOW.value] #565
            right_elbow = pixel_landmarks[Landmark.RIGHT_ELBOW.value] #566
            left_wrist = pixel_landmarks[Landmark.LEFT_WRIST.value] #567
            right_wrist = pixel_landmarks[Landmark.RIGHT_WRIST.value] #568
            left_hip = pixel_landmarks[Landmark.LEFT_HIP.value] #569
            right_hip = pixel_landmarks[Landmark.RIGHT_HIP.value] #570

            # Calculate left upper arm angle.（计算左上臂角度） #572
            left_shoulder_angle = self.calculate_shoulder_angle(left_shoulder, left_elbow, nose) #573
            self.filtered_angles['left_upper'] = self.apply_low_pass_filter('left_upper', left_shoulder_angle) #574
            self.servos['left_upper'].pid.update(left_shoulder_angle) #575
            pulse_left_upper = self.map_arm_angle_to_pulse(self.filtered_angles['left_upper'], self.servos['left_upper']) #576

            # Calculate right upper arm angle.（计算右上臂角度） #578
            right_shoulder_angle = self.calculate_shoulder_angle(right_shoulder, right_elbow, nose) #579
            self.filtered_angles['right_upper'] = self.apply_low_pass_filter('right_upper', right_shoulder_angle) #580
            self.servos['right_upper'].pid.update(right_shoulder_angle) #581
            pulse_right_upper = self.map_arm_angle_to_pulse(self.filtered_angles['right_upper'], self.servos['right_upper']) #582

            # Calculate left forearm angle.（计算左前臂角度） #584
            left_forearm_angle = self.calculate_angle(left_shoulder, left_elbow, left_wrist) #585
            self.filtered_angles['left_forearm'] = self.apply_low_pass_filter('left_forearm', left_forearm_angle) #586
            self.servos['left_forearm'].pid.update(left_forearm_angle) #587
            pulse_left_forearm = self.map_arm_angle_to_pulse(self.filtered_angles['left_forearm'], self.servos['left_forearm']) #588

            # Calculate right forearm angle.（计算右前臂角度） #590
            right_forearm_angle = self.calculate_angle(right_shoulder, right_elbow, right_wrist) #591
            self.filtered_angles['right_forearm'] = self.apply_low_pass_filter('right_forearm', right_forearm_angle) #592
            self.servos['right_forearm'].pid.update(right_forearm_angle) #593
            pulse_right_forearm = self.map_arm_angle_to_pulse(self.filtered_angles['right_forearm'], self.servos['right_forearm']) #594

            pulses = { #596
                'left_upper': pulse_left_upper, #597
                'right_upper': pulse_right_upper, #598
                'left_forearm': pulse_left_forearm, #599
                'right_forearm': pulse_right_forearm #600
            } #601

            # Push pulses into corresponding queues.（将脉冲分别放入各自的队列） #603
            for servo_name, pulse in pulses.items(): #604
                try: #605
                    self.servos[servo_name].pulse_queue.put_nowait(pulse) #606
                except queue.Full: #607
                    rospy.logwarn(f"{servo_name} 脉冲队列已满，丢弃当前脉冲。") #608

            if self.is_hands_crossed_on_chest(pixel_landmarks): #610
                self.exit_play_mode() #611
        except IndexError: #612
            rospy.logwarn("关键点检测不到，无法处理玩法模式。") #613
        except Exception as e: #614
            rospy.logerr(f"处理玩法模式时出错: {e}") #615

    def run(self): #617
        """Run the node.（运行节点）""" #618
        rospy.on_shutdown(self.stop_all) #619
        rospy.spin() #620

    def stop_all(self): #622
        """Gracefully shut down the node.（优雅关闭节点）""" #623
        if not self.stop_event.is_set(): #624
            rospy.loginfo("正在关闭 MediaPipePoseNode...") #625
            self.stop_event.set() #626
            # Wait for all servo control threads to finish.（等待所有舵机控制线程结束） #627
            for t in self.servo_threads: #628
                t.join() #629
            # Wait for image display thread to finish.（等待图像显示线程结束） #630
            self.display_thread.join() #631
            cv2.destroyAllWindows() #632
            rospy.loginfo("MediaPipePoseNode 已关闭。") #633

    def signal_handler(self, signum, frame): #635
        rospy.loginfo("接收到退出信号，正在优雅关闭...") #636
        self.stop_all() #637
        sys.exit(0) #638


if __name__ == '__main__': #641
    try: #642
        node = MediaPipePoseNode() #643

        signal.signal(signal.SIGINT, node.signal_handler) #645
        signal.signal(signal.SIGTERM, node.signal_handler) #646

        node.run() #648
    except rospy.ROSInterruptException: #649
        pass #650
