#!/usr/bin/python3 #1
#coding=utf8 #2
#第8章 ROS机器狗拓展课程\2.树莓派扩展板课程\第5课 姿态控制(8.ROS Robot Expanded Course\2.Raspberry Pi Expansion Board Course\Lesson 5 Posture Control) #3
import os #4
import sys #5
import rospy #6
from ros_robot_controller.msg import RGBState, RGBsState #7
from std_msgs.msg import * #8
from sensor_msgs.msg import Imu #9

# 姿态检测(posture detection) #11

print(''' #13
********************************************************** #14
******************功能:姿态检测例程(function: posture detection routine)************************* #15
********************************************************** #16
---------------------------------------------------------- #17
Official website:https://www.hiwonder.com #18
Online mall:https://hiwonder.tmall.com #19
---------------------------------------------------------- #20
Tips: #21
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close this program, please try multiple times if fail) #22
---------------------------------------------------------- #23
''') #24


# 设置RGB彩灯显示(set the display of RGB color light) #27
def set_rgb_show(r1,g1,b1,r2,g2,b2): #28
    led1 = RGBState() #29
    led1.r = r1 #30
    led1.g = g1 #31
    led1.b = b1 #32
    led1.id = 1 #33

    led2 = RGBState() #35
    led2.r = r2 #36
    led2.g = g2 #37
    led2.b = b2 #38
    led2.id = 2 #39
    msg = RGBsState() #40
    msg.data = [led1,led2] #41
    rgb_pub.publish(msg) #42
    rospy.sleep(0.01) #43

rgb_color = 'None' #45
def run(msg): #46
    global rgb_color #47
    
    x = msg.linear_acceleration.x #49
    y = msg.linear_acceleration.y #50
   
    if x >= 3: # 机器人左倾斜(the robot tilts to the left) #52
        if rgb_color != 'red_r': #53
            print('机器人左倾斜') #54
            rgb_color = 'red_r' #55
            set_rgb_show(255,0,0,0,0,0) #56
        
    elif x <= -3: # 机器人右倾斜(the robot tilts to the right) #58
        if rgb_color != 'red_l': #59
            print('机器人右倾斜') #60
            rgb_color = 'red_l' #61
            set_rgb_show(0,0,0,255,0,0) #62
    
    elif y >= 3: # 机器人前倾斜(the robot leans forward) #64
        if rgb_color != 'red': #65
            print('机器人前倾斜') #66
            rgb_color = 'red' #67
            set_rgb_show(255,0,0,255,0,0) #68
            
    
    elif y <= -3: # 机器人后倾斜(the robot leans backward) #71
        if rgb_color != 'blue': #72
            print('机器人后倾斜') #73
            rgb_color = 'blue' #74
            set_rgb_show(0,0,255,0,0,255) #75
    
    else: #77
        if rgb_color != 'None': #78
            print('机器人姿态正常') #79
            rgb_color = 'None' #80
            set_rgb_show(0,0,0,0,0,0) #81

# 关闭检测函数(close detection function) #83
run_st = True #84
def Stop(): #85
    global run_st #86
    run_st = False #87
    set_rgb_show(0,0,0,0,0,0) #88
    print('关闭中...') #89

if __name__ == '__main__': #91
    # 初始化节点(initialization node) #92
    rospy.init_node('posture_detect_demo') #93
    rgb_pub = rospy.Publisher('/ros_robot_controller/set_rgb', RGBsState, queue_size=1) #94
    imu_sub = rospy.Subscriber('/ros_robot_controller/imu_raw', Imu, run) #95

    try: #97
        rospy.spin() #98
    except KeyboardInterrupt: #99
        rospy.loginfo("Shutting down") #100
        
    
