#!/usr/bin/env python3 #1
# encoding: utf-8 #2
import os #3
import dashscope #4

###Only in China### #6
# 阶跃星辰key #7
stepfun_api_key = '' #8
stepfun_base_url = 'https://api.stepfun.com/v1' #9
stepfun_llm_model = '' #10
#'step-1v-8k'/'step-1o-vision-32k'/'step-1.5v-mini' #11
stepfun_vllm_model = 'step-1o-vision-32k' #12

# 阿里云key #14
aliyun_api_key = '' #15
aliyun_base_url = 'https://dashscope.aliyuncs.com/compatible-mode/v1' #16
aliyun_llm_model = 'qwen-max-latest'#'qwen-turbo'#'qwen-max-latest' #17
aliyun_vllm_model = 'qwen-vl-max-latest' #18
aliyun_tts_model = 'sambert-zhinan-v1' #19
aliyun_asr_model = 'paraformer-realtime-v2' #20
aliyun_voice_model = '' #21
###### #22

###Internationally### #24
vllm_api_key = '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' #25
vllm_base_url = 'https://openrouter.ai/api/v1' #26
vllm_model = 'qwen/qwen2.5-vl-72b-instruct:free' #27

llm_api_key = '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' #29
llm_base_url = 'https://api.openai.com/v1' #30
llm_model = 'gpt-4o-mini' #31
openai_vllm_model = 'gpt-4o' #32
openai_tts_model = 'tts-1' #33
openai_asr_model = 'whisper-1' #34
openai_voice_model = 'onyx' #35
###### #36

if os.environ["ASR_LANGUAGE"] == 'Chinese': #38
    # Actual API key used for calls (实际调用的key) #39
    api_key = aliyun_api_key #40
    dashscope.api_key = aliyun_api_key #41
    base_url = aliyun_base_url #42
    asr_model = aliyun_asr_model #43
    tts_model = aliyun_tts_model #44
    voice_model = aliyun_voice_model #45
    llm_model = aliyun_llm_model #46
    vllm_model = aliyun_vllm_model #47
else: #48
    api_key = llm_api_key #49
    os.environ["OPENAI_API_KEY"] = api_key #50
    base_url = llm_base_url #51
    asr_model = openai_asr_model #52
    tts_model = openai_tts_model #53
    voice_model = openai_voice_model #54

# Get the path of the current program (获取程序所在路径) #56
code_path = os.path.abspath(os.path.split(os.path.realpath(__file__))[0]) #57

if os.environ["ASR_LANGUAGE"] == 'Chinese': #59
    audio_path = os.path.join(code_path, 'resources/audio') #60
else: #61
    audio_path = os.path.join(code_path, 'resources/audio/en') #62

# Path for the recorded audio file (录音音频的路径) #64
recording_audio_path = os.path.join(audio_path, 'recording.wav') #65

# Path for the synthesized speech audio file (语音合成音频的路径) #67
tts_audio_path = os.path.join(audio_path, "tts_audio.wav") #68

# Path for the startup sound file (启动音频的路径) #70
start_audio_path = os.path.join(audio_path, "start_audio.wav") #71

# Path for the wake-up response sound file (唤醒回答音频的路径) #73
wakeup_audio_path = os.path.join(audio_path, "wakeup.wav") #74

# Path for the error sound file (出错音频的路径) #76
error_audio_path = os.path.join(audio_path, "error.wav") #77

# Path for the "no sound detected" audio file (没有检测到声音时音频的路径) #79
no_voice_audio_path = os.path.join(audio_path, "no_voice.wav") #80

# Path for the "recording completed" audio file (录音完成时音频的路径) #82
dong_audio_path = os.path.join(audio_path, "dong.wav") #83

record_finish_audio_path = os.path.join(audio_path, "record_finish.wav") #85

start_track_audio_path = os.path.join(audio_path, "start_track.wav") #87

track_fail_audio_path = os.path.join(audio_path, "track_fail.wav") #89
