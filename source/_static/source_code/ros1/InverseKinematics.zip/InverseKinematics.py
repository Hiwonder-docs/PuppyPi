#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# 2自由度机械臂逆运动学：给定相应的坐标（X,Y,Z），计算出每个关节转动的角度(inverse kinematics for a 2-degree-of-freedom robotic arm: Given the corresponding coordinates (X, Y, Z), calculate the angle of rotation for each joint) #3

from math import * #5


class IK:        #从下往上，最下面为第一个舵机(from bottom to top, the bottommost servo is considered the first servo) #8
    l1 = 4.21    #机械臂第一个舵机中心轴到第二个舵机中心轴的距离4.21cm,(the distance from the center axis of the first servo to the center axis of the second servo on the robotic arm is 4.21 cm) #9
    l2 = 3.3     #第二个舵机中心轴到爪子末端所在平面的距离3.3cm(the distance from the center axis of the second servo to the plane where the end of the gripper is located is 3.3 cm) #10
    l3 = 12.7    #第二个舵机中心轴垂直于爪子末端所在平面的交点到爪子末端的距离12.7cm(the distance from the intersection of the center axis of the second servo perpendicular to the plane where the end of the gripper is located to the end of the gripper is 12.7 cm) #11
    
    def __init__(self): # 舵机从下往上数(count the servos from bottom to top) #13
        l1 = 4.21    #机械臂第一个舵机中心轴到第二个舵机中心轴的距离4.21cm,(count the servos from bottom to top) #14
        l2 = 3.3     #第二个舵机中心轴到爪子末端所在平面的距离3.3cm(the distance from the center axis of the second servo to the plane where the end of the gripper is located is 3.3 cm) #15
        l3 = 12.7    #第二个舵机中心轴垂直于爪子末端所在平面的交点到爪子末端的距离12.7cm(the distance from the intersection of the center axis of the second servo perpendicular to the plane where the end of the gripper is located to the end of the gripper is 12.7 cm) #16

        

    def setLinkLength(self, L1=l1, L2=l2, L3=l3): #20
        # 更改机械臂的连杆长度，为了适配相同结构不同长度的机械臂(change the linkage length of the robotic arm to adapt to arms of the same structure but different lengths) #21
        self.l1 = L1 #22
        self.l2 = L2 #23
        self.l3 = L3 #24

    def getLinkLength(self): #26
        # 获取当前设置的连杆长度(get the current set linkage length) #27
        
        return {"L1":self.l1, "L2":self.l2, "L3":self.l3} #29

    def getRotationAngle(self, coordinate_data): #31
        
        X, Y, Z = coordinate_data #33
        # 没有左右转向，Y都为0(without left or right turning, Y is always 0) #34
        
        if Y != 0: #36
            print("ERROR:给的坐标Y值必须为0") #37
            return False #38
        
        # 给定指定坐标，返回每个关节应该旋转的角度，如果无解返回False(given specific coordinates, return the angle each joint should rotate to. If there's no solution, return False) #40
        # coordinate_data为夹持器末端坐标，坐标单位cm， 以元组形式传入，例如(5, 0, 10)(the coordinate_data represents the end effector coordinates of the gripper, with units in centimeters, passed in as a tuple, for example, (5, 0, 10)) #41
        
        # 设夹持器末端为P(X, Y, Z), 坐标原点为O, 原点为机械臂第一个舵机中心轴(let the end effector of the gripper be denoted as P(X, Y, Z), with the origin at O, where O is the center axis of the first servo of the robotic arm) #43
        # 从机械臂后面往前看，正前方为X轴正方向，Z轴竖直向上为正方向，遵循右手定则，Y轴往左边为正方向(viewing the robotic arm from behind, the positive X-axis direction is straight ahead, the positive Z-axis direction is vertically upwards, following the right-hand rule, and the positive Y-axis direction is to the left) #44
        # l1与l2的交点为A(the intersection point of l1 and l2 is denoted as point A) #45
        # 夹角表示，AB和BC的夹角为 ABC(the angle formed by AB and BC is denoted as ABC) #46
        # l1与X轴的夹角为theta(the angle between l1 and the X-axis is denoted as theta) #47
        # l1与l2的夹角为OAP(the angle between l1 and l2 is denoted as OAP) #48
        # theta为第一个舵机转动角度(theta is the rotation angle of the first servo) #49
        # beta为第二个舵机转动角度(beta is the rotation angle of the second servo) #50
        # #51
        
        
        PO = sqrt(X*X + Z*Z) #P到原点O距离，Y为0所以省略不写(the distance from point P to the origin O is denoted, with Y being 0, which is omitted) #54
        PA = sqrt(pow(self.l2,2) + pow(self.l3,2)) #因为l2与l3为垂直关系，根据勾股定理可以算出斜边PA(since l2 and l3 are perpendicular, according to the Pythagorean theorem, we can calculate the hypotenuse PA) #55

        #print("PO:",PO) #57
        #Z不同的范围，theta的计算方式不一样，有三种情况，需要分类讨论，beta三种情况里计算方式都一样(depending on the range of Z, there are three cases for calculating theta, and beta is the same in all three cases) #58
        #beta = OAP #59

        if X == -3.3 and Z == (self.l1 + self.l3 ): #61
            theta = 90 #62
            beta = 180  #63
            return {"theta":theta, "beta":beta} # 有解时返回角度字典(return a dictionary of angles when a solution exists) #64
        
        if X == (self.l1 + self.l3 ) and Z == 3.3: #66
            theta = 180 #67
            beta = 180  #68
            return {"theta":theta, "beta":beta} # 有解时返回角度字典(return a dictionary of angles when a solution exists) #69
        
        cos_OAP = (pow(self.l1,2)+pow(PA,2)-pow(PO,2))/(2*self.l1*PA)#根据余弦定理(according to the law of cosines) #71
        cos_OAP = round(cos_OAP,4) #取四位小数点(take four decimal places) #72
        if abs(cos_OAP) > 1: #73
            print('ERROR:不能构成连杆结构, abs(cos_OAP)为%s > 1' %(abs(cos_OAP)) ) #74
            return False #75
        
        cos_PAC = (pow(self.l2,2)+pow(PA,2)-pow(self.l3,2))/(2*self.l2*PA)#根据余弦定理(according to the law of cosines) #77
        cos_PAC = round(cos_PAC,4) #取四位小数点(take four decimal places) #78
        if abs(cos_PAC) > 1: #79
            print('ERROR:不能构成连杆结构, abs(cos_PAC)为%s > 1' %(abs(cos_PAC))) #80
            return False #81
        
        OAP = acos(cos_OAP) #83
        PAC = acos(cos_PAC) #84
        OAC = OAP + PAC #85
        beta = degrees(OAC) - 90 #86
        
        #当Z>0时，PB垂直于OB，B点在X轴上，AC垂直于X轴，C在X轴上(when Z > 0, PB is perpendicular to OB, point B is on the X-axis, and AC is perpendicular to the X-axis, with point C on the X-axis) #88
        # theta = AOB #89
        # AOB = AOP + POB #90
       
        if Z > 0: #92
            
            PB = Z #94
            
            cos_AOP = (pow(self.l1,2)+pow(PO,2)-pow(PA,2))/(2*self.l1*PO)#根据余弦定理(according to the law of cosines) #96
            cos_AOP = round(cos_AOP,4) #取四位小数点(take four decimal places) #97
            if abs(cos_AOP) > 1: #98
               print('ERROR:不能构成连杆结构, abs(cos_AOP)为%s > 1' %(abs(cos_AOP))) #99
               return False #100
        
            sin_POB = round(PB/PO,4) #102
            if abs(sin_POB) > 1: #103
               print('ERROR:不能构成连杆结构, abs(sin_POB)为%s > 1' %(abs(sin_POB)) ) #104
               return False #105
           
            AOB = acos(cos_AOP) + asin(sin_POB) #l1与x轴的夹角(the angle between l1 and the X-axis) #107
           
            theta = 180 - degrees(AOB)     #109
            
        #当Z为0时，P点在X轴上，theta = AOP(when Z is 0, point P is on the X-axis, and theta equals AOP) #111
        elif Z == 0: #112
            
            cos_AOP = (pow(self.l1,2)+pow(PO,2)-pow(PA,2))/(2*self.l1*PO)#根据余弦定理(according to the law of cosines) #114
            cos_AOP = round(cos_AOP,4) #取四位小数点(take four decimal places) #115
            
            if abs(cos_AOP) > 1: #117
               print('ERROR:不能构成连杆结构, abs(cos_AOP)为%s > 1' %(abs(cos_AOP))) #118
               return False #119
            
           
            AOB = acos(cos_AOP) #122
            theta = 180 - degrees(AOB) #123
            
        #当Z<0时，PB垂直于OB，B在X轴上，theta = AOP - AOB(when Z is less than 0, PB is perpendicular to OB, point B is on the X-axis, and theta equals AOP minus AOB) #125
        elif Z < 0: #126
            PB = abs(Z)  #127

            
            cos_AOP = (pow(self.l1,2)+pow(PO,2)-pow(PA,2))/(2*self.l1*PO)#根据余弦定理(according to the law of cosines) #130
            cos_AOP = round(cos_AOP,4) #取四位小数点(take four decimal places) #131
            if abs(cos_AOP) > 1: #132
               print('ERROR:不能构成连杆结构, abs(cos_AOP)为%s > 1' %(abs(cos_AOP))) #133
               return False #134
            sin_POB = round(PB/PO,4) #135
            if abs(sin_POB) > 1: #136
               print('ERROR:不能构成连杆结构, abs(sin_POB)为%s > 1' %(abs(sin_POB)) ) #137
               return False #138
           
            AOB = acos(cos_AOP) - asin(sin_POB) #l1与x轴的夹角(the angle between l1 and the X-axis) #140
            theta = 180 - degrees(AOB)     #141
 
 
        if self.l1 + PA < round(PO, 4): #两边之和小于第三边(the sum of any two sides is always greater than the third side) #144
            print('ERROR:不能构成连杆结构, l1(%s) + PA(%s) < PO(%s)' %(self.l1, PA, PO)) #145
            return False #146
        
        return {"theta":theta, "beta":beta} # 有解时返回角度字典(return a dictionary of angles when a solution exists) #148
            
if __name__ == '__main__': #150
    ik = IK() #151
    #ik.setLinkLength(L1=ik.l1 + 1.30, L4=ik.l4) #152
    #print('连杆长度：', ik.getLinkLength()) #153
    print(ik.getRotationAngle((5, 0, 0))) #154
